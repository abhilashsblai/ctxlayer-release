from __future__ import annotations

import math
from pathlib import Path
from typing import Any


class EFEScorer:
    def __init__(self, store: Any, world_model: Any, impact_engine: Any):
        self.store = store
        self.world_model = world_model
        self.impact_engine = impact_engine

    def predict_change_set(
        self, *, candidate: dict[str, Any], context: dict[str, Any]
    ) -> dict[str, Any]:
        paths = [
            _normalize_path(path)
            for path in candidate.get("paths", [])
            or candidate.get("current_paths", [])
            or []
            if str(path).strip()
        ]
        if not paths and candidate.get("path"):
            paths = [_normalize_path(str(candidate["path"]))]
        if not paths:
            directory = str(
                candidate.get("target_dir") or context.get("active_dir") or ""
            )
            paths = [f"{directory}/__candidate__" if directory else "__candidate__"]
        prediction = self.world_model.predict(context)
        probabilities = {path: round(1.0 / len(paths), 6) for path in paths}
        return {
            "paths": sorted(paths),
            "probabilities": probabilities,
            "model_id": prediction.get("model_id"),
            "approximate": prediction.get("model_id") is None,
        }

    def expected_uncertainty(
        self,
        *,
        candidate: dict[str, Any],
        context: dict[str, Any],
        pack: dict[str, Any] | None = None,
    ) -> float:
        predicted = self.predict_change_set(candidate=candidate, context=context)
        paths = predicted["paths"]
        pack_paths = _pack_paths(pack)
        coverage_gap = 0.0
        if paths:
            missing = [path for path in paths if path not in pack_paths]
            coverage_gap = len(missing) / len(paths)
        entropy = _entropy(list(predicted["probabilities"].values()))
        return round(min(1.0, (coverage_gap * 0.7) + (entropy * 0.3)), 6)

    def score(
        self,
        *,
        snapshot: Any,
        task: str,
        current_paths: list[str],
        candidates: list[dict[str, Any]] | None = None,
        pack: dict[str, Any] | None = None,
        top_k: int = 5,
        interoception: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        context = {
            "task_terms": _terms(task),
            "active_dir": _dirname(current_paths[0]) if current_paths else "",
        }
        candidate_items = (
            candidates
            or [
                {"kind": "path", "paths": [path], "label": path}
                for path in current_paths
            ]
            or [{"kind": "task", "target_dir": "", "label": "current task"}]
        )
        scored = []
        model_id = None
        for candidate in candidate_items:
            predicted = self.predict_change_set(candidate=candidate, context=context)
            model_id = model_id or predicted.get("model_id")
            report = self.impact_engine.report(
                snapshot=snapshot,
                paths=predicted["paths"],
                pack_id=pack.get("pack_id") if isinstance(pack, dict) else None,
            )
            risk = min(
                1.0, float(report.get("risk", {}).get("score", 0.0) or 0.0) / 10.0
            )
            gut = float((interoception or {}).get("gut", 0.0) or 0.0)
            expected_risk = round(min(1.0, risk * (1.0 + (0.3 * gut))), 6)
            expected_uncertainty = self.expected_uncertainty(
                candidate=candidate, context=context, pack=pack
            )
            efe = round(
                min(1.0, (0.6 * expected_risk) + (0.4 * expected_uncertainty)), 6
            )
            item = {
                "candidate": candidate,
                "predicted_paths": predicted["paths"],
                "expected_risk": expected_risk,
                "expected_uncertainty": expected_uncertainty,
                "efe": efe,
                "recommended_action": _recommended_action(
                    expected_risk, expected_uncertainty
                ),
                "rationale": _rationale(expected_risk, expected_uncertainty),
                "approximate": bool(predicted.get("approximate")),
            }
            scored.append(item)
        scored = sorted(scored, key=lambda item: (item["efe"], str(item["candidate"])))[
            :top_k
        ]
        prefetch = sorted(
            {
                path
                for item in scored
                if item["expected_uncertainty"] >= 0.5
                for path in item["predicted_paths"]
            }
        )
        return {
            "schema_version": "ctxlayer.anticipation.efe.v1",
            "task": task,
            "candidates": scored,
            "recommended": scored[0] if scored else None,
            "prefetch": prefetch,
            "model_id": model_id,
        }


def _recommended_action(risk: float, uncertainty: float) -> str:
    if uncertainty >= 0.55 and uncertainty >= risk:
        return "fetch_context"
    if risk >= 0.75:
        return "replan"
    if risk >= 0.45:
        return "warn"
    return "proceed"


def _rationale(risk: float, uncertainty: float) -> str:
    if uncertainty >= 0.55 and uncertainty >= risk:
        return "uncertainty dominates; fetch context before editing"
    if risk >= 0.45:
        return "expected risk is elevated"
    return "expected risk and uncertainty are low"


def _entropy(probabilities: list[float]) -> float:
    if len(probabilities) <= 1:
        return 0.0
    entropy = -sum(p * math.log(max(p, 1e-9), 2) for p in probabilities)
    return min(1.0, entropy / math.log(len(probabilities), 2))


def _pack_paths(pack: dict[str, Any] | None) -> set[str]:
    if not isinstance(pack, dict):
        return set()
    paths = {
        _normalize_path(item["path"])
        for item in pack.get("items", [])
        if isinstance(item, dict) and item.get("path")
    }
    manifest = pack.get("manifest")
    if isinstance(manifest, dict):
        paths.update(
            _normalize_path(item["path"])
            for item in manifest.get("items", [])
            if isinstance(item, dict) and item.get("path")
        )
    return paths


def _terms(task: str) -> list[str]:
    return sorted(
        {part.strip(".,:;()[]{}").lower() for part in task.split() if len(part) >= 4}
    )


def _dirname(path: str) -> str:
    parent = str(Path(_normalize_path(path)).parent).replace("\\", "/")
    return "" if parent == "." else parent


def _normalize_path(path: str) -> str:
    return str(path).replace("\\", "/").lstrip("./")
