from __future__ import annotations

import ast
import json
import hashlib
import fnmatch
import os
import re
import statistics
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from ctxlayer import __version__
from ctxlayer.agents import AgentRouter
from ctxlayer.agents.adapters import detect_running, known_agent_names, resolve
from ctxlayer.agents.adapters.base import BootstrapContext
from ctxlayer.anticipation.brief import build_brief
from ctxlayer.anticipation.ui_redundancy import review_ui_redundancy
from ctxlayer.analytics.duckdb_replica import duckdb_status
from ctxlayer.architecture import ArchitectureEngine
from ctxlayer.audit import AuditLog
from ctxlayer.behavior import BehaviorEngine
from ctxlayer.bench import DatabaseBenchmarkHarness
from ctxlayer.bootstrap import bootstrap_project
from ctxlayer.ci import CIChecker
from ctxlayer.ci.annotations import github_annotations, gitlab_annotations
from ctxlayer.ci.github_action import GITHUB_ACTION_YAML
from ctxlayer.ci.gitlab_check import GITLAB_CI_YAML
from ctxlayer.compiler import ContextCompiler
from ctxlayer.config import Settings, load_settings
from ctxlayer.cie.engine import CIEEngine
from ctxlayer.codex import (
    _apply_enforcement_mode as codex_apply_enforcement_mode,
    enforcement_status as codex_enforcement_report,
    memory_retrieval_manifest as codex_memory_retrieval_manifest,
    parallel_plan as build_codex_parallel_plan,
    pre_tool_gate as codex_pre_tool_gate,
)
from ctxlayer.crossrepo.workspace import WorkspaceManager
from ctxlayer.decision import DecisionEngine
from ctxlayer.eval import (
    FINAL_BENCHMARK_CORPUS_REQUIREMENTS,
    AgentBenchmarkHarness,
    ComponentEvalHarness,
    GraphAccuracyHarness,
    PRReplayHarness,
    build_release_benchmark_report,
    default_final_benchmark_cases,
    gate_agent_benchmark_report,
    latest_efficacy_scorecard,
    run_efficacy,
    validate_benchmark_corpus,
    verify_recall_closure,
    verify_loop,
)
from ctxlayer.eval.redteam_runner import RedTeamRunner
from ctxlayer.governance import (
    CapabilityPolicy,
    ConstitutionBuilder,
    GoalGovernance,
    TaskGovernance,
    TaskPlanGovernance,
)
from ctxlayer.governance.plans import intended_files, normalize_plan
from ctxlayer.impact import ImpactEngine
from ctxlayer.intent import IntentEngine
from ctxlayer.registry import (
    ProjectRegistry,
    is_temp_project_path,
    path_under_root,
    registry_disabled,
)
from ctxlayer.learning.optimizer import (
    ReflectiveOptimizer,
    apply_parameters,
    archive_rows,
    current_parameters,
    default_evaluator,
    parse_run_json,
)
from ctxlayer.learning.loop_verify import LoopVerifier
from ctxlayer.learning.provider import (
    BudgetedProvider,
    EnrichmentBudget,
    build_agent_provider,
    is_real_provider,
    provider_readiness,
    provider_status,
)
from ctxlayer.learning.reflection import MemoryReflector
from ctxlayer.learning.selfmod import SelfModEngine
from ctxlayer.learning.skill_evolution import SkillEvolutionEngine
from ctxlayer.learning.skills import SkillLibrary
from ctxlayer.loop import core_loop_runbook
from ctxlayer.memory import (
    AgentSessionMemory,
    BusinessRuleMemory,
    ContinuationMemory,
    EpisodicMemory,
    MemoryConsolidator,
    UnifiedMemory,
)
from ctxlayer.memory.decay import decayed_confidence
from ctxlayer.memory.sleep_consolidation import SleepConsolidator
from ctxlayer.memory.unified import prefetch_cache_key
from ctxlayer.metacognition import MetacognitiveController
from ctxlayer.judgment import (
    applicable_judgment,
    propose_judgment_heuristics_from_store,
)
from ctxlayer.narrative import build_project_narrative
from ctxlayer.nextgen import (
    changed_code_symbols,
    context_budget_report,
    defend_served_items,
    dependency_grounding_report,
    economics_report,
    extract_signatures,
    file_provenance,
    graph_reasoning_report,
    imported_packages_from_diff,
    nextgen_status_report,
    oracle_and_reward_report,
    ownership_report,
    regrounding_capsule,
    scan_untrusted_text,
    semantic_conflict_report,
    semantic_merge_conflict_report,
    spec_code_drift_report,
    stale_state_report,
    supervision_decision,
)
from ctxlayer.org import OrgIngestor
from ctxlayer.parsing.tree_sitter_registry import status as tree_sitter_status
from ctxlayer.providers.github import harvest as harvest_github
from ctxlayer.providers.gitlab import harvest as harvest_gitlab
from ctxlayer.product import Dashboard, MetricsRollup
from ctxlayer.release import ReleaseValidator
from ctxlayer.release.completion import (
    default_gap_register,
    validate_gap_register,
    write_default_gap_register,
)
from ctxlayer.retrieval.embedder import make_embedder
from ctxlayer.retrieval.diagnostics import diagnose
from ctxlayer.runtime import RuntimeIngestor
from ctxlayer.runtime import ci_failures as runtime_ci_failures
from ctxlayer.runtime import feature_flags as runtime_feature_flags
from ctxlayer.runtime import incidents as runtime_incidents
from ctxlayer.runtime import opentelemetry as runtime_opentelemetry
from ctxlayer.runtime import sentry as runtime_sentry
from ctxlayer.security.encryption import encryption_status
from ctxlayer.security.memory_defense import require_actor_role
from ctxlayer.security.policy import privacy_statement
from ctxlayer.security.retention import retention_policy
from ctxlayer.security.secret_scan import SecretScanner
from ctxlayer.semantic import BusinessGraph, BusinessNodeCandidate, SemanticGraphIndexer
from ctxlayer.semantic.repair import SemanticRepairQueue
from ctxlayer.setup import (
    init_git_repo,
    is_git_repo,
    setup_readiness,
)
from ctxlayer.snapshot import SnapshotInfo, SnapshotResolver
from ctxlayer.store import CtxBudgetExceeded, SQLiteStore
from ctxlayer.store.sqlite_store import LATEST_MIGRATION_VERSION
from ctxlayer.store.read_pool import SQLiteReadPool
from ctxlayer.utils import canonical_json, estimate_tokens, stable_id, utc_now
from ctxlayer.verification import VerificationRunner
from ctxlayer.verification.differential import differential_check
from ctxlayer.verification.mutation import MutationTester
from ctxlayer.verification.properties import validate_invariants
from ctxlayer.workspace import run_cognitive_workspace
from ctxlayer.workflow import GateEvaluator, WorkflowRouter
from ctxlayer.workflow.adaptation import (
    adopted_overlay as governance_adopted_overlay,
    preview_adoption as governance_preview_adoption,
    propose_playbook_changes,
)
from ctxlayer.workflow.classifier import infer_mode
from ctxlayer.workflow.feature_catalog import (
    WORKFLOW_NEXT_SCHEMA,
    WORKFLOW_RECOMMEND_SCHEMA,
)
from ctxlayer.workflow.governance_events import record_session_feature_events


class CtxLayerService:
    def __init__(self, repo: str | Path):
        self.repo_root = Path(repo).resolve()
        self._memory_workspace_id = stable_id(str(self.repo_root))[:16]
        self._memory_repo_id = self._memory_workspace_id
        self.settings: Settings = load_settings(self.repo_root)
        self.workspace_dir = self.repo_root / self.settings.toolchain.workspace_dir
        if self.settings.security.encrypt_workspace_db:
            raise RuntimeError(
                "encrypt_workspace_db=true but at-rest encryption is not implemented; "
                "set it to false or remove it."
            )
        self.store = SQLiteStore(self.workspace_dir / "workspace.db")
        cold_archive_path = Path(self.settings.maintenance.cold_archive_path)
        self.store.cold_archive_path = (
            cold_archive_path
            if cold_archive_path.is_absolute()
            else self.repo_root / cold_archive_path
        )
        requested_vector_backend = self._requested_vector_backend()
        if (
            requested_vector_backend == "sqlite-vec"
            or self.settings.storage.require_sqlite_vec
        ) and not self.store.sqlite_vec_loaded:
            self.store.close()
            raise RuntimeError(
                "sqlite-vec backend requested but unavailable; install ctxlayer[full] "
                "or set storage.vector_backend='json-cosine'"
            )
        self.store.migrate()
        self._apply_promoted_optimization_overrides()
        self._resolver: SnapshotResolver | None = None
        self._compiler: ContextCompiler | None = None
        self._impact: ImpactEngine | None = None
        self._anticipation: Any | None = None
        self._self_improve: Any | None = None
        self._behavior: BehaviorEngine | None = None
        self._audit: AuditLog | None = None
        self._intent: IntentEngine | None = None
        self._goals: GoalGovernance | None = None
        self._replay: PRReplayHarness | None = None
        self._ci: CIChecker | None = None
        self._release: ReleaseValidator | None = None
        self._workspace: WorkspaceManager | None = None
        self._semantic: SemanticGraphIndexer | None = None
        self._business_graph: BusinessGraph | None = None
        self._architecture: ArchitectureEngine | None = None
        self._graph_accuracy: GraphAccuracyHarness | None = None
        self._semantic_repair: SemanticRepairQueue | None = None
        self._agent_router: AgentRouter | None = None
        self._component_eval: ComponentEvalHarness | None = None
        self._in_maintenance = False

    def close(self) -> None:
        self.store.close()

    def __enter__(self) -> "CtxLayerService":
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    @property
    def resolver(self) -> SnapshotResolver:
        if self._resolver is None:
            self._resolver = SnapshotResolver(self.repo_root, self.store, self.settings)
        return self._resolver

    @property
    def compiler(self) -> ContextCompiler:
        if self._compiler is None:
            self._compiler = ContextCompiler(self.repo_root, self.store, self.settings)
        return self._compiler

    @property
    def impact(self) -> ImpactEngine:
        if self._impact is None:
            self._impact = ImpactEngine(self.repo_root, self.store, self.settings)
        return self._impact

    @property
    def anticipation(self) -> Any:
        if self._anticipation is None:
            from ctxlayer.anticipation import AnticipationEngine

            self._anticipation = AnticipationEngine(
                self.store,
                self._memory_repo_id,
                workspace_id=self._memory_workspace_id,
                snapshot_resolver=self.resolver,
                impact_engine=self.impact,
                behavior_engine=self.behavior,
                settings=self.settings,
            )
        return self._anticipation

    @property
    def self_improve(self) -> Any:
        if self._self_improve is None:
            from ctxlayer.selfimprove import SelfImproveEngine

            self._self_improve = SelfImproveEngine(self)
        return self._self_improve

    @property
    def behavior(self) -> BehaviorEngine:
        if self._behavior is None:
            self._behavior = BehaviorEngine(
                self.repo_root, self.store, self.settings, self.impact
            )
        return self._behavior

    @property
    def audit(self) -> AuditLog:
        if self._audit is None:
            self._audit = AuditLog(self.store)
        return self._audit

    @property
    def intent(self) -> IntentEngine:
        if self._intent is None:
            self._intent = IntentEngine(
                self.repo_root,
                self.store,
                self.settings,
                self.impact,
                self.audit,
                workspace_id=stable_id(str(self.repo_root))[:16],
                event_logger=self._learning_event_logger,
            )
        return self._intent

    @property
    def goals(self) -> GoalGovernance:
        if self._goals is None:
            self._goals = GoalGovernance(
                self.repo_root,
                self.store,
                self.settings,
                self.impact,
                self.audit,
                workspace_id=stable_id(str(self.repo_root))[:16],
                event_logger=self._learning_event_logger,
            )
        return self._goals

    @property
    def replay(self) -> PRReplayHarness:
        if self._replay is None:
            self._replay = PRReplayHarness(
                self.repo_root, self.store, self.settings, self.compiler
            )
        return self._replay

    @property
    def ci(self) -> CIChecker:
        if self._ci is None:
            self._ci = CIChecker(
                self.repo_root, self.store, self.impact, self.settings.ci
            )
        return self._ci

    @property
    def release(self) -> ReleaseValidator:
        if self._release is None:
            self._release = ReleaseValidator(self.repo_root, self.store, self.replay)
        return self._release

    @property
    def workspace(self) -> WorkspaceManager:
        if self._workspace is None:
            self._workspace = WorkspaceManager(self.repo_root, self.store)
        return self._workspace

    @property
    def semantic(self) -> SemanticGraphIndexer:
        if self._semantic is None:
            self._semantic = SemanticGraphIndexer(self.repo_root, self.store)
        return self._semantic

    @property
    def business_graph(self) -> BusinessGraph:
        if self._business_graph is None:
            self._business_graph = BusinessGraph(self.repo_root, self.store)
        return self._business_graph

    @property
    def architecture(self) -> ArchitectureEngine:
        if self._architecture is None:
            self._architecture = ArchitectureEngine(
                self.repo_root, self.store, self.settings
            )
        return self._architecture

    @property
    def graph_accuracy(self) -> GraphAccuracyHarness:
        if self._graph_accuracy is None:
            self._graph_accuracy = GraphAccuracyHarness(self.repo_root, self.store)
        return self._graph_accuracy

    @property
    def semantic_repair(self) -> SemanticRepairQueue:
        if self._semantic_repair is None:
            self._semantic_repair = SemanticRepairQueue(self.repo_root, self.store)
        return self._semantic_repair

    @property
    def agent_router(self) -> AgentRouter:
        if self._agent_router is None:
            self._agent_router = AgentRouter()
        return self._agent_router

    @property
    def component_eval(self) -> ComponentEvalHarness:
        if self._component_eval is None:
            self._component_eval = ComponentEvalHarness(self.store)
        return self._component_eval

    def init(self) -> dict[str, Any]:
        self.workspace_dir.mkdir(parents=True, exist_ok=True)
        gitignore = self.repo_root / ".gitignore"
        existing = gitignore.read_text(encoding="utf-8") if gitignore.exists() else ""
        changed = False
        if ".ctxlayer/" not in existing.splitlines():
            with gitignore.open("a", encoding="utf-8") as handle:
                if existing and not existing.endswith("\n"):
                    handle.write("\n")
                handle.write(".ctxlayer/\n")
            changed = True
        return {
            "ok": True,
            "workspace_db": str(self.workspace_dir / "workspace.db"),
            "gitignore_updated": changed,
        }

    def bootstrap(
        self,
        *,
        agents: str = "codex,claude",
        mcp_command: str = "ctxlayer",
        absolute_mcp_repo: bool = False,
        skip_index: bool = False,
    ) -> dict[str, Any]:
        init = self.init()
        mcp_repo = str(self.repo_root) if absolute_mcp_repo else "."
        bootstrap = bootstrap_project(
            self.repo_root,
            agents=[agent for agent in re.split(r"[\s,]+", agents) if agent],
            mcp_command=mcp_command,
            mcp_repo=mcp_repo,
        )
        snapshot = None if skip_index else self.resolver.resolve(refresh=True)
        # Bootstrapping is the install path; record this project in the global registry so CTX
        # Layer can track every project it manages.
        self._register_project(
            action="install", repo_id=snapshot.repo_id if snapshot else None
        )
        return {
            "ok": True,
            "init": init,
            "bootstrap": bootstrap,
            "snapshot": None if snapshot is None else self._snapshot_dict(snapshot),
            "next_steps": [
                "Run `ctxlayer doctor --repo .` to verify local setup.",
                'Use `ctxlayer pack --repo . --task "<task>"` before agent edits.',
                "Use `.ctxlayer/mcp/` snippets to configure agent MCP clients.",
                "Use `ctxlayer setup --agents codex,claude,cursor --install-hooks --configure-mcp` for full setup.",
            ],
        }

    def setup(
        self,
        agents: list[str] | str | None = None,
        *,
        mcp_command: str = "ctxlayer",
        install_hooks: bool = False,
        configure_mcp: bool = False,
        init_git: bool = False,
        absolute_mcp_repo: bool = False,
        codex_config: str | None = None,
        skip_index: bool = False,
    ) -> dict[str, Any]:
        selected = _split_agents(agents or ["codex"])
        adapters = resolve(selected)
        agent_names = [adapter.name for adapter in adapters]
        steps: list[dict[str, Any]] = []
        git_before = is_git_repo(self.repo_root)
        git_init = None
        if not git_before and init_git:
            git_init = init_git_repo(self.repo_root)
            steps.append({"name": "git_init", **git_init})

        git_ready = is_git_repo(self.repo_root)
        if not git_ready:
            return {
                "ok": False,
                "error": "target is not a git repository; rerun with --init-git to initialize it",
                "repo": str(self.repo_root),
                "git_repo": False,
                "git_init": git_init,
                "readiness": setup_readiness(self.repo_root, agent_names),
                "known_agents": known_agent_names(),
            }

        bootstrap = self.bootstrap(
            agents=",".join(agent_names),
            mcp_command=mcp_command,
            absolute_mcp_repo=absolute_mcp_repo,
            skip_index=skip_index,
        )
        steps.append({"name": "bootstrap", "ok": bootstrap.get("ok", False)})

        hooks = None
        if install_hooks:
            hooks = self.install_post_commit_hook()
            steps.append({"name": "hook_install", "ok": hooks.get("ok", False)})

        mcp_repo = str(self.repo_root) if absolute_mcp_repo else "."
        ctx = BootstrapContext(
            repo_root=self.repo_root,
            mcp_command=mcp_command,
            mcp_repo=mcp_repo,
            shell="powershell",
            agent_names=agent_names,
        )
        mcp_results: dict[str, Any] = {}
        if configure_mcp:
            for adapter in adapters:
                config_path = None
                if adapter.name == "codex" and codex_config:
                    config_path = Path(codex_config).expanduser()
                result = adapter.configure_mcp(ctx, config_path=config_path)
                mcp_results[adapter.name] = result
                steps.append(
                    {
                        "name": f"{adapter.name}_mcp_config",
                        "ok": result.get("ok", False),
                    }
                )

        readiness = setup_readiness(self.repo_root, agent_names)
        setup_proof = None
        if "codex" in agent_names:
            setup_proof = self._write_codex_setup_mode_proof(readiness)
        return {
            "ok": readiness["ok"],
            "repo": str(self.repo_root),
            "agents_configured": agent_names,
            "steps": steps,
            "bootstrap": bootstrap,
            "hooks": hooks,
            "mcp": mcp_results or None,
            "codex_mcp": mcp_results.get("codex") if mcp_results else None,
            "readiness": readiness,
            "setup_proof": setup_proof,
            "next_steps": [
                "Commit generated instruction files and ctxlayer.capabilities.yaml when the baseline is ready.",
                "Do not commit .ctxlayer/.",
                "Use `ctxlayer --repo . doctor` to re-check setup readiness.",
            ],
        }

    def setup_auto(
        self,
        *,
        mcp_command: str = "ctxlayer",
        install_hooks: bool = False,
        configure_mcp: bool = False,
        init_git: bool = False,
        absolute_mcp_repo: bool = False,
        codex_config: str | None = None,
        skip_index: bool = False,
        env: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        adapters = detect_running(os.environ if env is None else env)
        if not adapters:
            return {
                "ok": False,
                "error": "no supported running agent detected",
                "known_agents": known_agent_names(),
                "hint": "Run `ctxlayer setup --agents <agent>` or run from inside a supported agent.",
            }
        return self.setup(
            [adapter.name for adapter in adapters],
            mcp_command=mcp_command,
            install_hooks=install_hooks,
            configure_mcp=configure_mcp,
            init_git=init_git,
            absolute_mcp_repo=absolute_mcp_repo,
            codex_config=codex_config,
            skip_index=skip_index,
        )

    def setup_codex(
        self,
        *,
        mcp_command: str = "ctxlayer",
        install_hooks: bool = False,
        configure_mcp: bool = False,
        init_git: bool = False,
        absolute_mcp_repo: bool = False,
        codex_config: str | None = None,
        skip_index: bool = False,
    ) -> dict[str, Any]:
        return self.setup(
            ["codex"],
            mcp_command=mcp_command,
            install_hooks=install_hooks,
            configure_mcp=configure_mcp,
            init_git=init_git,
            absolute_mcp_repo=absolute_mcp_repo,
            codex_config=codex_config,
            skip_index=skip_index,
        )

    def _write_codex_setup_mode_proof(
        self, readiness: dict[str, Any]
    ) -> dict[str, Any]:
        codex_dir = self.repo_root / ".ctxlayer" / "codex"
        codex_dir.mkdir(parents=True, exist_ok=True)
        proof_path = codex_dir / "setup-proof.json"
        docs_path = codex_dir / "setup-modes.md"
        checks = readiness.get("checks", {}) if isinstance(readiness, dict) else {}
        proof = {
            "schema_version": "ctxlayer.codex_setup_modes.v1",
            "repo": str(self.repo_root),
            "modes": {
                "local": {
                    "ok": bool(readiness.get("ok")),
                    "requires": [
                        "AGENTS.md",
                        ".codex/config.toml",
                        ".ctxlayer/codex/hooks",
                    ],
                    "proof": checks,
                },
                "worktree": {
                    "ok": bool(
                        checks.get("agents_contract")
                        and checks.get("codex_project_config")
                    ),
                    "requires": [
                        "one CTX task session per worktree thread",
                        "run codex preflight from inside the worktree",
                        "record task_session_id, pack_id, and agent_session_id in the child summary",
                    ],
                },
                "cloud": {
                    "ok": bool(
                        checks.get("agents_contract")
                        and checks.get("codex_mcp_snippet")
                    ),
                    "requires": [
                        "install or expose ctxlayer in the cloud environment",
                        "include CTX preflight commands in the cloud task prompt",
                        "copy task_session_id, pack_id, and agent_session_id into the cloud result",
                    ],
                },
                "managed_requirements": {
                    "ok": True,
                    "requires": [
                        "use organization-managed requirements for hard policy enforcement",
                        "treat repo-local hooks as tamper-evident guidance for trusted projects",
                        "enforce sandbox, approval policy, MCP allowlists, internet, and secrets policy outside the repo",
                    ],
                },
            },
        }
        docs = "\n".join(
            [
                "# Codex CTX Layer Setup Modes",
                "",
                "## Local",
                "",
                '- Run `ctxlayer --repo . codex preflight --task "<task>"` before write-capable work.',
                "- Keep AGENTS.md, `.codex/config.toml`, hooks, and MCP snippets committed or installed.",
                "",
                "## Worktree",
                "",
                "- Create one CTX task session per worktree thread.",
                "- Run preflight from inside each worktree so paths, base commit, and memory match the task.",
                "- Record `task_session_id`, `pack_id`, and `agent_session_id` in child summaries.",
                "",
                "## Cloud",
                "",
                "- Install or expose `ctxlayer` in the cloud environment before starting Codex work.",
                "- Include the CTX preflight and pack commands in the cloud task prompt.",
                "- Copy returned session IDs into the cloud result so local continuation memory can resume.",
                "",
                "## Managed Requirements",
                "",
                "- Repo-local hooks are tamper-evident guidance for trusted projects, not hard enterprise control.",
                "- Use managed requirements for sandbox, approval, MCP allowlist, internet, and secrets policy.",
                "",
            ]
        )
        proof_path.write_text(
            json.dumps(proof, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        docs_path.write_text(docs, encoding="utf-8")
        return {
            "ok": all(
                bool(proof["modes"][mode]["ok"])
                for mode in ["local", "worktree", "cloud"]
            ),
            "proof_path": str(proof_path),
            "docs_path": str(docs_path),
            "modes": proof["modes"],
        }

    def codex_install_surfaces(
        self,
        *,
        mcp_command: str = "ctxlayer",
        install_hooks: bool = True,
        configure_mcp: bool = False,
        init_git: bool = False,
        absolute_mcp_repo: bool = False,
        codex_config: str | None = None,
        skip_index: bool = True,
    ) -> dict[str, Any]:
        return self.setup_codex(
            mcp_command=mcp_command,
            install_hooks=install_hooks,
            configure_mcp=configure_mcp,
            init_git=init_git,
            absolute_mcp_repo=absolute_mcp_repo,
            codex_config=codex_config,
            skip_index=skip_index,
        )

    def ctx_health(
        self,
        *,
        last_recall_ms: float | None = None,
        persist: bool = True,
        unavailable_reason: str | None = None,
    ) -> dict[str, Any]:
        db_path = self.workspace_dir / "workspace.db"
        wal_path = Path(str(db_path) + "-wal")
        db_bytes = db_path.stat().st_size if db_path.exists() else 0
        wal_bytes = wal_path.stat().st_size if wal_path.exists() else 0
        fluid_memory = self._fluid_memory_health_block(
            db_bytes=db_bytes,
            wal_bytes=wal_bytes,
            last_recall_ms=last_recall_ms,
        )
        reasons: list[str] = []
        status = "ok"
        if unavailable_reason:
            status = "unavailable"
            reasons.append(unavailable_reason)
        if wal_bytes > self.settings.maintenance.wal_warn_bytes:
            status = "degraded" if status == "ok" else status
            reasons.append("wal_size_over_threshold")
        if (
            last_recall_ms is not None
            and last_recall_ms > self.settings.reliability.memory_recall_budget_ms
        ):
            status = "degraded" if status == "ok" else status
            reasons.append("recall_over_budget")
        if persist:
            probe = self.store.write_ctx_health_probe(
                status=status,
                reasons=sorted(set(reasons)),
                db_bytes=db_bytes,
                wal_bytes=wal_bytes,
                last_recall_ms=last_recall_ms,
            )
            if (
                status != "ok"
                and self.settings.maintenance.auto_gc_on_degraded
                and not self._in_maintenance
                and "wal_size_over_threshold" in set(reasons)
            ):
                try:
                    self.maybe_run_maintenance(full=True, trigger="health")
                except Exception as exc:  # noqa: BLE001 - health probes must not fail.
                    self._learning_event_logger(
                        "phase1",
                        "health_gc_error",
                        None,
                        {"error": str(exc), "reasons": sorted(set(reasons))},
                    )
            probe["fluid_memory"] = fluid_memory
            return probe
        return {
            "status": status,
            "reasons": sorted(set(reasons)),
            "db_bytes": db_bytes,
            "wal_bytes": wal_bytes,
            "last_recall_ms": last_recall_ms,
            "fluid_memory": fluid_memory,
        }

    def _fluid_memory_health_block(
        self,
        *,
        db_bytes: int,
        wal_bytes: int,
        last_recall_ms: float | None,
    ) -> dict[str, Any]:
        recall_budget = self.settings.reliability.memory_recall_budget_ms
        informational_reasons = []
        if db_bytes > self.settings.maintenance.db_warn_bytes:
            informational_reasons.append("db_size_over_threshold")
        if wal_bytes > self.settings.maintenance.wal_warn_bytes:
            informational_reasons.append("wal_size_over_threshold")
        recall_over_budget = bool(
            last_recall_ms is not None and last_recall_ms > recall_budget
        )
        if recall_over_budget:
            informational_reasons.append("recall_over_budget")
        fluid_status = (
            "degraded"
            if wal_bytes > self.settings.maintenance.wal_warn_bytes
            or recall_over_budget
            else "ok"
        )
        return {
            "schema_version": "ctxlayer.fluid_memory_health.v1",
            "status": fluid_status,
            "hot_db_bytes": int(db_bytes),
            "total_db_bytes": int(db_bytes),
            "cold_archive": self.store.cold_archive_stats(),
            "wal_bytes": int(wal_bytes),
            "db_size_warning_informational": db_bytes
            > self.settings.maintenance.db_warn_bytes,
            "informational_reasons": sorted(set(informational_reasons)),
            "wal_over_budget": wal_bytes > self.settings.maintenance.wal_warn_bytes,
            "last_recall_ms": last_recall_ms,
            "recall_budget_ms": recall_budget,
            "recall_over_budget": recall_over_budget,
            "status_driven_by": [
                item
                for item in ("wal_size_over_threshold", "recall_over_budget")
                if item in informational_reasons
            ],
        }

    def latest_ctx_health(self) -> dict[str, Any]:
        row = self.store.latest_ctx_health_probe()
        if not row:
            return self.ctx_health(persist=False)
        health = {
            "probe_id": row["probe_id"],
            "status": row["status"],
            "reasons": _json_list(row["reasons_json"]),
            "db_bytes": int(row["db_bytes"] or 0),
            "wal_bytes": int(row["wal_bytes"] or 0),
            "last_recall_ms": row["last_recall_ms"],
            "created_at": row["created_at"],
        }
        health["fluid_memory"] = self._fluid_memory_health_block(
            db_bytes=health["db_bytes"],
            wal_bytes=health["wal_bytes"],
            last_recall_ms=health["last_recall_ms"],
        )
        return health

    def _ctx_health_banner(self, health: dict[str, Any]) -> str | None:
        status = str(health.get("status") or "ok")
        if status == "ok":
            return None
        return (
            "CTX operating without full safety net: "
            f"status={status}, reasons={','.join(health.get('reasons') or [])}; "
            "run `ctxlayer --repo . gc --deep` and `ctxlayer --repo . doctor`."
        )

    def codex_enforcement_status(self, *, probe: bool = False) -> dict[str, Any]:
        try:
            with self.store.budget(
                self.settings.reliability.enforcement_status_budget_ms
            ):
                result = codex_enforcement_report(
                    self.repo_root, setup_readiness(self.repo_root)
                )
        except CtxBudgetExceeded:
            health = self.ctx_health(
                unavailable_reason="enforcement_status_budget_exceeded"
            )
            return {
                "ok": False,
                "schema_version": "ctxlayer.codex_enforcement.v1",
                "status": "degraded",
                "reason": "budget_exceeded",
                "ctx_health": health,
                "banner": self._ctx_health_banner(health),
            }
        health = self.ctx_health(persist=True)
        preflight_state = self._derive_preflight_state({})
        result["ctx_health"] = health
        result["status"] = "ok" if health["status"] == "ok" else "degraded"
        result["enforcement_mode"] = self.settings.governance.enforcement_mode
        result["derive_state_from_store"] = (
            self.settings.governance.derive_state_from_store
        )
        result["preflight_state"] = preflight_state
        result["hooks"] = {
            "codex": self._hook_runtime_status("codex"),
            "claude": self._hook_runtime_status("claude"),
        }
        if self.settings.governance.config_warning:
            result["config_warning"] = self.settings.governance.config_warning
        if probe:
            result["probe"] = self.codex_hook_event(
                "PreToolUse",
                {"tool_name": "Edit", "read_only": False, "probe": True},
            )
        banner = self._ctx_health_banner(health)
        if banner:
            result["banner"] = banner
        return result

    def migrate_verify(self) -> dict[str, Any]:
        self.store.migrate()
        rows = self.store.conn.execute(
            "SELECT version, name FROM schema_migrations ORDER BY version"
        ).fetchall()
        versions = {int(row["version"]) for row in rows}
        expected = set(range(1, LATEST_MIGRATION_VERSION + 1))
        missing = sorted(expected - versions)
        extra = sorted(
            version for version in versions if version > LATEST_MIGRATION_VERSION
        )
        table_checks = {
            "governance_feature_events": self.store._table_exists(
                "governance_feature_events"
            ),
            "governance_playbook_proposals": self.store._table_exists(
                "governance_playbook_proposals"
            ),
            "governance_playbook_adoptions": self.store._table_exists(
                "governance_playbook_adoptions"
            ),
            "clarification_requests": self.store._table_exists(
                "clarification_requests"
            ),
            "metacognitive_states": self.store._table_exists("metacognitive_states"),
            "judgment_heuristics": self.store._table_exists("judgment_heuristics"),
            "agent_narrative": self.store._table_exists("agent_narrative"),
        }
        return {
            "ok": not missing and all(table_checks.values()),
            "schema_version": "ctxlayer.migrate_verify.v1",
            "latest_migration_version": LATEST_MIGRATION_VERSION,
            "applied_count": len(versions),
            "missing_versions": missing,
            "extra_versions": extra,
            "table_checks": table_checks,
            "knowledge_preservation": {
                "registry_current": not missing,
                "assertion": "all migrations through the current registry are present",
            },
        }

    def _hook_runtime_status(self, agent: str) -> dict[str, Any]:
        log_path = self.repo_root / ".ctxlayer" / agent / "hook-events.jsonl"
        status = {
            "registered": log_path.exists(),
            "log_path": str(log_path),
            "last_fired_at": None,
            "last_event": None,
            "last_decision": None,
        }
        if not log_path.exists():
            return status
        last: dict[str, Any] | None = None
        try:
            for line in log_path.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    last = json.loads(line)
        except (OSError, json.JSONDecodeError):
            return {**status, "status": "degraded"}
        if last:
            result = last.get("result") if isinstance(last.get("result"), dict) else {}
            status.update(
                {
                    "last_fired_at": last.get("fired_at")
                    or datetime.fromtimestamp(
                        log_path.stat().st_mtime, tz=timezone.utc
                    ).isoformat(),
                    "last_event": last.get("event"),
                    "last_decision": result.get("decision"),
                    "status": "ok",
                }
            )
        return status

    def codex_preflight(
        self,
        task: str,
        paths: list[str] | None = None,
        mode: str = "write",
        probe: bool = False,
    ) -> dict[str, Any]:
        if probe:
            return self._codex_preflight_probe(task, paths=paths, mode=mode)
        task_result = self.task_start(task)
        seed_paths = sorted({path for path in paths or [] if path})
        pack = self.get_context_pack(task, seed_paths=seed_paths)
        continuation = self.continuation_resume(task)
        recall = self.memory_recall(task, paths=seed_paths, limit=20)
        skills = self.skill_search(task, limit=5, include_untrusted=False)
        status = self.codex_enforcement_status()
        memory_manifest = codex_memory_retrieval_manifest(
            task=task, pack=pack, recall=recall
        )
        impact = self.get_impact_report(paths=seed_paths, pack_id=pack["pack_id"])
        ready = bool(pack.get("pack_id")) and bool(
            memory_manifest.get("memory_retrieval_id")
        )
        if mode.strip().lower() != "read":
            ready = ready and bool(status.get("ok"))
        parallel = build_codex_parallel_plan(
            task=task,
            task_session_id=task_result["task_session_id"],
            pack_id=pack["pack_id"],
            paths=seed_paths,
            impact_report=impact,
            preflight_ready=ready,
            worktree_clean=pack.get("worktree_state") == "clean",
        )
        enforcement = {
            **status,
            "preflight_ready": ready,
            "blocking_reasons": [] if ready else status.get("blocking_reasons", []),
        }
        result = {
            "ok": ready,
            "schema_version": "ctxlayer.codex_preflight.v1",
            "task": task,
            "mode": mode,
            "task_session_id": task_result["task_session_id"],
            "agent_session_id": pack.get("agent_session_id")
            or task_result.get("agent_session_id"),
            "pack_id": pack["pack_id"],
            "memory_retrieval_id": memory_manifest["memory_retrieval_id"],
            "continuation_matches": continuation.get("matches", []),
            "served_memory_counts_by_type": memory_manifest["served_counts_by_type"],
            "policy_reference_count": len(pack.get("policy_references", []) or []),
            "skill_match_count": len(
                skills.get("skills", []) or pack.get("skills", []) or []
            ),
            "parallel_recommendation": parallel["parallel_recommendation"],
            "parallel_agent_plan": parallel,
            "enforcement_status": enforcement,
            "memory_retrieval": memory_manifest,
            "plan_required": mode.strip().lower() != "read",
            "required_next_step": "create a structured CTX task plan before write-capable actions",
        }
        if self.settings.governance.surface_in_preflight:
            result["workflow"] = self._governance_brief(
                task=task,
                paths=seed_paths,
                mode=mode,
                pack=pack,
                task_session_id=task_result["task_session_id"],
                source="codex_preflight",
            )
        session_id = result.get("agent_session_id")
        if session_id:
            self._record_agent_session_event(
                str(session_id),
                "codex_preflight",
                {
                    "task_session_id": result["task_session_id"],
                    "pack_id": result["pack_id"],
                    "memory_retrieval_id": result["memory_retrieval_id"],
                    "preflight_ready": ready,
                    "parallel_recommendation": result["parallel_recommendation"],
                    "mode": mode,
                },
            )
        return result

    def _codex_preflight_probe(
        self,
        task: str,
        paths: list[str] | None = None,
        mode: str = "write",
    ) -> dict[str, Any]:
        started = time.perf_counter()
        seed_paths = sorted({path for path in paths or [] if path})
        setup = setup_readiness(self.repo_root)
        blocking_missing = _setup_blocking_missing(setup.get("missing", []))
        setup_status = (
            "complete"
            if setup.get("ok")
            else "blocked" if blocking_missing else "advisory_incomplete"
        )
        tree_sitter = tree_sitter_status()
        status = self.codex_enforcement_status(probe=True)
        storage = self.db_backend_status()
        health = status.get("ctx_health") if isinstance(status, dict) else None
        setup_ready = bool(status.get("ok")) and not blocking_missing
        return {
            "ok": setup_ready,
            "schema_version": "ctxlayer.codex_preflight.v1",
            "task": task,
            "mode": mode,
            "probe_only": True,
            "fast": True,
            "preflight_ready": False,
            "setup_ready": setup_ready,
            "task_session_id": None,
            "agent_session_id": None,
            "pack_id": None,
            "memory_retrieval_id": None,
            "seed_paths": seed_paths,
            "setup_status": setup_status,
            "ready_for_work": not blocking_missing,
            "setup_blocking_missing": blocking_missing,
            "setup_advisory_missing": [
                item
                for item in setup.get("missing", [])
                if item not in blocking_missing
            ],
            "tree_sitter": {
                "available": tree_sitter.available,
                "languages": tree_sitter.languages,
                "error": tree_sitter.error,
            },
            "storage": storage,
            "ctx_health": health,
            "enforcement_status": status,
            "plan_required": mode.strip().lower() != "read",
            "required_next_step": (
                "run full `ctxlayer --repo . codex preflight --task <task>` "
                "when a pack-backed write gate is required"
            ),
            "performance": {
                "mode": "codex_preflight_probe",
                "elapsed_ms": round((time.perf_counter() - started) * 1000, 2),
                "pack_compilation": False,
                "task_session_created": False,
            },
        }

    def codex_parallel_plan(
        self,
        task_session_id: str,
        pack_id: str,
        paths: list[str] | None = None,
    ) -> dict[str, Any]:
        task = self._task_text_for_session(task_session_id) or "Codex parallel task"
        impact = self.get_impact_report(paths=paths or [], pack_id=pack_id)
        snapshot = self.resolver.resolve()
        return build_codex_parallel_plan(
            task=task,
            task_session_id=task_session_id,
            pack_id=pack_id,
            paths=paths,
            impact_report=impact,
            preflight_ready=True,
            worktree_clean=snapshot.worktree_state == "clean",
        )

    def codex_child_start(
        self,
        parent_task_session_id: str,
        role: str,
        objective: str,
        write_scope: list[str] | None = None,
        read_scope: list[str] | None = None,
        parent_pack_id: str | None = None,
    ) -> dict[str, Any]:
        if not self.store.task_session(parent_task_session_id):
            raise KeyError(f"task session not found: {parent_task_session_id}")
        write_scope = sorted({path for path in write_scope or [] if path})
        read_scope = sorted({path for path in read_scope or [] if path})
        parent_session_id = self._session_id_for_task_session(parent_task_session_id)
        parallel_run_id = stable_id(
            parent_task_session_id, parent_pack_id or "", "codex-parallel"
        )
        if parent_session_id:
            overlap = self._codex_write_scope_overlap(
                parent_session_id, parallel_run_id, write_scope
            )
            if overlap:
                raise ValueError(
                    f"child write scope overlaps an active child session: {', '.join(overlap)}"
                )
        child = self.session_start(
            objective,
            agent_name=f"codex:{role}",
            metadata={
                "parent_task_session_id": parent_task_session_id,
                "parent_pack_id": parent_pack_id,
                "parallel_run_id": parallel_run_id,
                "child_role": role,
                "read_scope": read_scope,
                "write_scope": write_scope,
                "ctx_child": True,
            },
        )
        event = {
            "parallel_run_id": parallel_run_id,
            "parent_task_session_id": parent_task_session_id,
            "parent_pack_id": parent_pack_id,
            "child_agent_session_id": child["session_id"],
            "child_role": role,
            "child_objective": objective,
            "read_scope": read_scope,
            "write_scope": write_scope,
            "status": "active",
        }
        self.session_event(child["session_id"], "codex_child_start", event)
        if parent_session_id:
            self._record_agent_session_event(
                parent_session_id, "codex_child_start", event
            )
        return {"ok": True, **event}

    def codex_child_stop(
        self,
        child_agent_session_id: str,
        summary: str,
        changed_files: list[str] | None = None,
        tests_run: list[str] | None = None,
        blockers: list[str] | None = None,
    ) -> dict[str, Any]:
        row = self.store.agent_session(child_agent_session_id)
        if not row:
            raise KeyError(f"child agent session not found: {child_agent_session_id}")
        metadata = json.loads(row["metadata_json"] or "{}")
        status = "blocked" if blockers else "completed"
        payload = {
            "parallel_run_id": metadata.get("parallel_run_id"),
            "parent_task_session_id": metadata.get("parent_task_session_id"),
            "child_agent_session_id": child_agent_session_id,
            "summary": summary,
            "changed_files": sorted(changed_files or []),
            "tests_run": tests_run or [],
            "blockers": blockers or [],
            "status": status,
        }
        self.session_event(child_agent_session_id, "codex_child_stop", payload)
        self.session_finish(child_agent_session_id, status, metadata=payload)
        parent_session_id = None
        if metadata.get("parent_task_session_id"):
            parent_session_id = self._session_id_for_task_session(
                str(metadata["parent_task_session_id"])
            )
        if parent_session_id:
            self._record_agent_session_event(
                parent_session_id, "codex_child_stop", payload
            )
        parent_task_session_id = metadata.get("parent_task_session_id")
        if parent_task_session_id:
            role = str(metadata.get("child_role") or "child")
            next_action = f"Review and integrate {role} result: {summary}"
            if payload["changed_files"]:
                next_action = f"{next_action} Changed files: {', '.join(payload['changed_files'])}."
            if payload["tests_run"]:
                next_action = (
                    f"{next_action} Tests run: {', '.join(payload['tests_run'])}."
                )
            self._continuation_memory().upsert_for_task_session(
                str(parent_task_session_id),
                agent_session_id=parent_session_id,
                event="codex_child_stop",
                state="blocked" if payload["blockers"] else "ready_to_resume",
                next_action=next_action,
                blockers=payload["blockers"],
                reason=f"codex child stopped: {status}",
            )
        return {"ok": True, **payload}

    def codex_child_pack(
        self, parent_pack_id: str, role: str, scope: list[str] | None = None
    ) -> dict[str, Any]:
        pack = self.get_pack_manifest(parent_pack_id)
        scope_set = {path for path in scope or [] if path}
        items = [
            item
            for item in pack.get("items", [])
            if not scope_set or item.get("path") in scope_set
        ]
        return {
            "ok": True,
            "parent_pack_id": parent_pack_id,
            "role": role,
            "scope": sorted(scope_set),
            "pack_excerpt": {
                "pack_id": parent_pack_id,
                "repo_id": pack.get("repo_id"),
                "snapshot_id": pack.get("snapshot_id"),
                "items": items,
                "continuations": pack.get("continuations", []),
                "project_memory": pack.get("project_memory", []),
                "policy_references": pack.get("policy_references", []),
                "skills": pack.get("skills", []),
                "memory_retrieval": pack.get("memory_retrieval", {}),
            },
        }

    def codex_merge_parallel_results(self, parallel_run_id: str) -> dict[str, Any]:
        children = self._codex_child_events(parallel_run_id)
        stopped = [
            event for event in children if event["event_type"] == "codex_child_stop"
        ]
        blockers = [
            blocker
            for event in stopped
            for blocker in event["payload"].get("blockers", [])
        ]
        changed_files = sorted(
            {
                path
                for event in stopped
                for path in event["payload"].get("changed_files", [])
            }
        )
        return {
            "ok": not blockers,
            "parallel_run_id": parallel_run_id,
            "child_count": len(
                {event["payload"].get("child_agent_session_id") for event in children}
            ),
            "completed_child_count": len(stopped),
            "changed_files": changed_files,
            "blockers": blockers,
            "merge_contract": {
                "parent_integrates": True,
                "run_final_check_diff": True,
                "run_impact": True,
                "record_outcome": True,
            },
        }

    def _derive_preflight_state(self, payload: dict[str, Any]) -> dict[str, Any]:
        if not self.settings.governance.derive_state_from_store:
            return {
                "source": "payload",
                "preflight_ready": bool(payload.get("preflight_ready")),
                "active_plan_step": bool(payload.get("active_plan_step")),
                "task_session_id": payload.get("task_session_id"),
                "pack_id": payload.get("pack_id"),
            }
        session_id = str(
            payload.get("session_id") or payload.get("agent_session_id") or ""
        ).strip()
        task_session_id = str(payload.get("task_session_id") or "").strip() or None
        pack_id = str(payload.get("pack_id") or "").strip() or None
        try:
            if not task_session_id and session_id:
                task_session_id = self._task_session_id_for_agent_session(session_id)
            task_row = (
                self.store.task_session(task_session_id) if task_session_id else None
            )
            if task_row is not None and not pack_id:
                pack_id = str(task_row["pack_id"] or "") or None
            if not pack_id and session_id:
                for event in reversed(self.store.agent_session_events(session_id)):
                    body = _json_dict(event["payload_json"])
                    candidate = body.get("pack_id")
                    if candidate:
                        pack_id = str(candidate)
                        break
            plan_row = (
                self.store.latest_task_plan_for_session(task_session_id)
                if task_session_id
                else None
            )
            active_plan_step = bool(
                plan_row is not None and str(plan_row["status"] or "") == "active"
            )
            return {
                "source": "store",
                "preflight_ready": bool(task_row is not None and pack_id),
                "active_plan_step": active_plan_step,
                "task_session_id": task_session_id,
                "pack_id": pack_id,
                "plan_id": plan_row["plan_id"] if plan_row is not None else None,
            }
        except Exception as exc:  # noqa: BLE001 - fail closed through enforcement mode.
            return {
                "source": "store_error",
                "preflight_ready": False,
                "active_plan_step": False,
                "task_session_id": task_session_id,
                "pack_id": pack_id,
                "derive_error": str(exc),
            }

    def _governance_block_grace_remaining(self, payload: dict[str, Any]) -> int:
        configured = max(0, int(self.settings.governance.block_grace_events or 0))
        if configured <= 0:
            return 0
        session_id = str(
            payload.get("session_id") or payload.get("agent_session_id") or ""
        ).strip()
        if not session_id:
            return configured
        try:
            prior = 0
            for row in self.store.agent_session_events(session_id):
                if row["event_type"] not in {"tool_allowed", "tool_blocked"}:
                    continue
                body = _json_dict(row["payload_json"])
                if body.get("would_have_blocked"):
                    prior += 1
            return max(0, configured - prior)
        except Exception:  # noqa: BLE001 - grace is advisory.
            return configured

    def codex_hook_event(
        self,
        event: str,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload = payload or {}
        if event == "SessionStart":
            result = self.codex_enforcement_status()
            result["event"] = event
            return result
        if event == "PreToolUse":
            target_paths = _tool_payload_paths(payload)
            proposed_content = _tool_payload_content(payload)
            diff = str(payload.get("diff") or "") or None
            directives: list[dict[str, Any]] = []
            guardrail_degraded: dict[str, Any] | None = None
            if self.settings.guardrails.enabled and target_paths:
                try:
                    snapshot = self.resolver.resolve()
                    with self.store.budget(
                        self.settings.reliability.enforcement_status_budget_ms
                    ):
                        directives = self.store.directives_for_paths(
                            target_paths, snapshot.repo_id
                        )
                except (
                    Exception
                ) as exc:  # noqa: BLE001 - semantic guardrails fail open.
                    guardrail_degraded = {
                        "status": "degraded",
                        "reason": "semantic_guardrail_error",
                        "error": str(exc),
                    }
                    self._learning_event_logger(
                        "phase_g2",
                        "guardrail_degraded",
                        str(payload.get("session_id") or "codex_hook"),
                        {
                            "target_paths": target_paths,
                            "error": str(exc),
                        },
                    )
            anticipation = self._anticipation_gate_signal(payload, target_paths)
            workflow_next_action = self._workflow_hint_for_payload(payload)
            preflight_state = self._derive_preflight_state(payload)
            decision = codex_pre_tool_gate(
                tool_name=str(payload.get("tool_name") or payload.get("tool") or ""),
                preflight_ready=bool(preflight_state.get("preflight_ready")),
                active_plan_step=bool(preflight_state.get("active_plan_step")),
                read_only=bool(payload.get("read_only")),
                target_paths=target_paths,
                proposed_content=proposed_content,
                diff=diff,
                directives=directives,
                guardrails_mode=self.settings.guardrails.mode,
                block_min_severity=self.settings.guardrails.block_min_severity,
                min_block_confidence=self.settings.guardrails.min_block_confidence,
                content_match_required_for_block=(
                    self.settings.guardrails.content_match_required_for_block
                ),
                block_requires_approval=self.settings.guardrails.block_requires_approval,
                approval_token=str(payload.get("guardrail_approval_token") or ""),
                surprise=anticipation.get("surprise"),
                interoception=anticipation.get("interoception"),
                surprise_nudge_threshold=(
                    self.settings.anticipation.surprise.nudge_threshold
                ),
                surprise_block_threshold=(
                    self.settings.anticipation.surprise.block_threshold
                ),
                surprise_requires_corroboration=(
                    self.settings.anticipation.surprise.requires_corroboration_for_block
                ),
                anticipation_mode=anticipation.get("mode", "off"),
                surprise_nudge_count=int(anticipation.get("nudge_count", 0) or 0),
                max_nudges_per_session=(
                    self.settings.anticipation.guards.max_nudges_per_session
                ),
                workflow_next_action=workflow_next_action,
                enforcement_mode=self.settings.governance.enforcement_mode,
                block_grace_remaining=self._governance_block_grace_remaining(payload),
            )
            decision["preflight_state"] = preflight_state
            task_text = str(
                payload.get("task")
                or payload.get("prompt")
                or (
                    self._task_text_for_session(
                        str(preflight_state.get("task_session_id"))
                    )
                    if preflight_state.get("task_session_id")
                    else ""
                )
                or ""
            )
            if self.settings.metacognition.online_tick_enabled and task_text:
                try:
                    pack_for_meta: dict[str, Any] = {}
                    if preflight_state.get("pack_id"):
                        try:
                            pack_for_meta = self.get_pack_manifest(
                                str(preflight_state["pack_id"])
                            )
                        except Exception:
                            pack_for_meta = {}
                    metacognition = self._metacognitive_state(
                        task=task_text,
                        paths=target_paths,
                        checkpoint="pre_write",
                        pack=pack_for_meta,
                        task_session_id=preflight_state.get("task_session_id"),
                        payload={
                            **payload,
                            "surprise": anticipation.get("surprise"),
                        },
                        persist=True,
                        create_clarification=True,
                    )
                    decision["metacognition"] = metacognition
                    if (
                        metacognition.get("action") == "ask_human"
                        and decision.get("decision") != "block"
                    ):
                        meta_decision = codex_apply_enforcement_mode(
                            {
                                "ok": False,
                                "decision": "block",
                                "reason": "metacognition requires human clarification",
                                "metacognition": metacognition,
                            },
                            self.settings.metacognition.clarification_mode,
                            0,
                        )
                        if meta_decision.get("decision") in {"block", "warn"}:
                            decision.update(meta_decision)
                except (
                    Exception
                ) as exc:  # noqa: BLE001 - metacognition is governed advisory.
                    decision["metacognition"] = {
                        "ok": False,
                        "active": False,
                        "reason": "metacognition_error",
                        "error": str(exc),
                    }
            if (
                guardrail_degraded
                and self.settings.guardrails.critical_fail_closed
                and decision.get("decision") in {"allow", "warn"}
            ):
                decision = {
                    "ok": False,
                    "decision": "block",
                    "reason": "semantic guardrail evaluation failed closed",
                    "target_paths": target_paths,
                    "guardrail_degraded": guardrail_degraded,
                    "approval": {
                        "required": True,
                        "approved": False,
                        "reason": "critical_fail_closed",
                    },
                }
            if guardrail_degraded and decision.get("decision") == "allow":
                decision["guardrail_degraded"] = guardrail_degraded
            if anticipation.get("degraded") and decision.get("decision") == "allow":
                decision["anticipation_degraded"] = anticipation["degraded"]
            if proposed_content and target_paths:
                ui_review = review_ui_redundancy(
                    self.repo_root,
                    task=str(payload.get("task") or payload.get("prompt") or ""),
                    paths=target_paths,
                    proposed_content=proposed_content,
                    proposed_path=target_paths[0],
                    max_findings=self.settings.anticipation.brief.max_ui_findings,
                )
                if ui_review.get("finding_count"):
                    decision["intuition"] = {
                        "schema_version": "ctxlayer.intuition_pre_tool.v1",
                        "advisory_only": True,
                        "ui_redundancy": ui_review,
                        "message": ui_review.get("message"),
                    }
            health = self.latest_ctx_health()
            decision["ctx_health"] = {
                "status": health.get("status", "ok"),
                "reasons": health.get("reasons", []),
            }
            self._maybe_attach_memory_prefetch(decision, payload, target_paths)
            self._record_anticipation_gate_event(payload, decision, anticipation)
            self._record_codex_tool_gate(payload, decision)
            return decision
        if event == "UserPromptSubmit":
            task = str(payload.get("prompt") or payload.get("task") or "")
            prompt_paths = (
                payload.get("paths") if isinstance(payload.get("paths"), list) else []
            )
            plan = build_codex_parallel_plan(
                task=task,
                task_session_id=str(payload.get("task_session_id") or "pending"),
                pack_id=str(payload.get("pack_id") or "pending"),
                paths=prompt_paths,
                preflight_ready=bool(payload.get("preflight_ready", False)),
                worktree_clean=True,
            )
            health = self.ctx_health(persist=True)
            result = {
                "ok": True,
                "event": event,
                "parallel_agent_plan": plan,
                "ctx_health": health,
            }
            banner = self._ctx_health_banner(health)
            if banner:
                result["banner"] = banner
            if self.settings.anticipation.brief.surface_at_prompt:
                result["intuition"] = self._intuition_brief(
                    task=task,
                    paths=[str(path) for path in prompt_paths],
                    session_id=str(
                        payload.get("session_id")
                        or payload.get("agent_session_id")
                        or ""
                    )
                    or None,
                    task_session_id=str(payload.get("task_session_id") or "") or None,
                    source="intuition_prompt",
                )
            if self.settings.governance.surface_at_prompt:
                result["workflow"] = self._governance_brief(
                    task=task,
                    paths=[str(path) for path in prompt_paths],
                    mode=infer_mode(task, "auto"),
                    task_session_id=str(payload.get("task_session_id") or "") or None,
                    source="prompt_push",
                )
            self._maybe_attach_memory_prefetch(
                result,
                payload,
                [str(path) for path in prompt_paths],
                task=task,
            )
            return result
        if event == "Stop":
            return self._codex_finalize_session(event, payload)
        return {"ok": True, "event": event, "record_only": True}

    def _anticipation_gate_signal(
        self, payload: dict[str, Any], target_paths: list[str]
    ) -> dict[str, Any]:
        if not self.settings.anticipation.enabled:
            return {"mode": "off"}
        mode, degraded = self._anticipation_gate_mode()
        if mode == "off":
            return {"mode": "off", "degraded": degraded}
        session_id = str(
            payload.get("session_id") or payload.get("agent_session_id") or ""
        ).strip()
        task_session_id = str(payload.get("task_session_id") or "").strip() or None
        if not task_session_id and session_id:
            task_session_id = self._task_session_id_for_agent_session(session_id)
        body = dict(payload)
        if target_paths and "target_paths" not in body:
            body["target_paths"] = target_paths
        previous_event = (
            self._last_agent_event_type(session_id) if session_id else "START"
        )
        try:
            from ctxlayer.anticipation.world_model import (
                context_from_payload,
                observation_from_event,
            )

            started = time.perf_counter()
            surprise = self.anticipation.score_action(
                context=context_from_payload(body, previous_event=previous_event),
                observation=observation_from_event(
                    str(body.get("tool_name") or body.get("tool") or "tool"), body
                ),
                session_id=session_id or None,
                task_session_id=task_session_id,
            )
            elapsed_ms = round((time.perf_counter() - started) * 1000, 3)
            prediction_id = str(surprise.get("prediction_id") or "")
            if prediction_id:
                self.store.update_anticipation_prediction_runtime(
                    prediction_id,
                    latency_ms=elapsed_ms,
                    timed_out=elapsed_ms
                    > self.settings.anticipation.guards.score_timeout_ms,
                    source="codex_pre_tool",
                )
        except Exception as exc:  # noqa: BLE001 - hook must fall back to policy gate.
            return {
                "mode": mode,
                "degraded": {
                    "status": "degraded",
                    "reason": "anticipation_score_error",
                    "error": str(exc),
                },
            }
        timed_out = elapsed_ms > self.settings.anticipation.guards.score_timeout_ms
        if timed_out:
            return {
                "mode": mode,
                "degraded": {
                    "status": "degraded",
                    "reason": "anticipation_score_timeout",
                    "elapsed_ms": elapsed_ms,
                },
            }
        interoception = None
        if session_id:
            try:
                interoception = self.anticipation.gut(
                    session_id=session_id,
                    task_session_id=task_session_id,
                    active_paths=target_paths,
                )
            except Exception as exc:  # noqa: BLE001 - gut is advisory.
                degraded = degraded or {
                    "status": "degraded",
                    "reason": "anticipation_gut_error",
                    "error": str(exc),
                }
        return {
            "mode": mode,
            "surprise": surprise,
            "latency_ms": elapsed_ms,
            "interoception": interoception,
            "nudge_count": self._anticipation_nudge_count(session_id),
            "degraded": degraded,
        }

    def _anticipation_gate_mode(self) -> tuple[str, dict[str, Any] | None]:
        mode = self.settings.anticipation.mode.strip().lower()
        if mode not in {"off", "silent", "warn", "block", "enforce"}:
            mode = "warn"
        if mode != "enforce":
            return mode, None
        status = self.anticipate_status()
        latest = status.get("latest_model") or {}
        ece = latest.get("ece")
        limit = self.settings.anticipation.guards.enforce_requires_ece_below
        if status.get("cold_start") or ece is None or float(ece) > float(limit):
            return (
                "warn",
                {
                    "status": "degraded",
                    "reason": "anticipation_enforce_ece_gate_not_met",
                    "ece": ece,
                    "required_below": limit,
                },
            )
        return mode, None

    def _last_agent_event_type(self, session_id: str) -> str:
        try:
            rows = self.store.agent_session_events(session_id)
        except Exception:
            return "START"
        return str(rows[-1]["event_type"]) if rows else "START"

    def _anticipation_nudge_count(self, session_id: str) -> int:
        if not session_id:
            return 0
        try:
            return sum(
                1
                for event in self.store.agent_session_events(session_id)
                if event["event_type"] == "anticipation_nudge"
            )
        except Exception:
            return 0

    def _record_anticipation_gate_event(
        self,
        payload: dict[str, Any],
        decision: dict[str, Any],
        anticipation: dict[str, Any],
    ) -> None:
        session_id = str(
            payload.get("session_id") or payload.get("agent_session_id") or ""
        ).strip()
        surprise = decision.get("surprise")
        if not session_id or not isinstance(surprise, dict):
            return
        level = str(surprise.get("level") or "silent")
        if level == "silent":
            return
        self._record_agent_session_event(
            session_id,
            "anticipation_nudge",
            {
                "level": level,
                "tool_name": str(payload.get("tool_name") or payload.get("tool") or ""),
                "decision": decision.get("decision"),
                "message": surprise.get("message"),
                "score": surprise.get("score"),
                "prediction_id": (anticipation.get("surprise") or {}).get(
                    "prediction_id"
                ),
                "latency_ms": anticipation.get("latency_ms"),
                "target_paths": _tool_payload_paths(payload),
            },
        )

    def _observe_anticipation_signal(
        self,
        *,
        session_id: str,
        signal_kind: str,
        task_session_id: str | None = None,
        target_paths: list[str] | None = None,
        magnitude: float = 1.0,
    ) -> dict[str, Any] | None:
        if not self.settings.anticipation.enabled:
            return None
        paths = sorted(
            {str(path).replace("\\", "/").lstrip("./") for path in target_paths or []}
        )
        payload = {
            "target_paths": paths,
            "state": "VERIFY",
            "task_session_id": task_session_id,
        }
        try:
            from ctxlayer.anticipation.world_model import (
                context_from_payload,
                observation_from_event,
            )

            return self.anticipation.observe(
                session_id=session_id,
                task_session_id=task_session_id,
                signal_kind=signal_kind,
                context=context_from_payload(
                    payload, previous_event=self._last_agent_event_type(session_id)
                ),
                observation=observation_from_event(signal_kind, payload),
                magnitude=magnitude,
            )
        except Exception as exc:  # noqa: BLE001 - do not block durable outcome writes.
            self._learning_event_logger(
                "anticipation",
                "observe_error",
                session_id,
                {"error": str(exc), "signal_kind": signal_kind, "target_paths": paths},
            )
            return {"ok": False, "error": str(exc)}

    def _synthesize_anticipation_candidates(self, session_id: str) -> list[str]:
        if not self.settings.anticipation.enabled:
            return []
        try:
            from ctxlayer.learning.online import OnlineLearner

            return OnlineLearner(
                self.store, self._memory_repo_id, session_id
            ).synthesize_candidates()
        except Exception as exc:  # noqa: BLE001 - session finish must remain durable.
            self._learning_event_logger(
                "anticipation",
                "candidate_synthesis_error",
                session_id,
                {"error": str(exc)},
            )
            return []

    def _reconcile_approved_anticipation_candidates(self) -> dict[str, Any]:
        if not self.settings.anticipation.enabled:
            return {"ran": False, "reason": "disabled"}
        try:
            approved = self.store.conn.execute(
                """
                SELECT candidate_id FROM learning_candidate
                WHERE status = 'approved'
                  AND (
                    kind = 'anticipation_adjustment'
                    OR provenance_json LIKE '%anticipation_online%'
                  )
                ORDER BY created_at, candidate_id
                """
            ).fetchall()
            if not approved:
                return {"ran": False, "reason": "no_approved_candidates"}
            trained = self.anticipate_train()
            limit = self.settings.anticipation.guards.enforce_requires_ece_below
            gate_pass = trained.get("ece") is not None and float(
                trained.get("ece") or 0.0
            ) <= float(limit)
            return {
                "ran": True,
                "approved_candidate_count": len(approved),
                "model_id": trained.get("model_id"),
                "ece": trained.get("ece"),
                "gate_pass": gate_pass,
            }
        except Exception as exc:  # noqa: BLE001 - reconciliation is opportunistic.
            return {"ran": False, "reason": "error", "error": str(exc)}

    def _record_codex_tool_gate(
        self, payload: dict[str, Any], decision: dict[str, Any]
    ) -> None:
        session_id = str(
            payload.get("session_id") or payload.get("agent_session_id") or ""
        ).strip()
        event_type = (
            "tool_blocked" if decision.get("decision") == "block" else "tool_allowed"
        )
        preflight_state = (
            decision.get("preflight_state")
            if isinstance(decision.get("preflight_state"), dict)
            else {}
        )
        try:
            if session_id:
                self.session_event(
                    session_id,
                    event_type,
                    {
                        "tool_name": str(
                            payload.get("tool_name") or payload.get("tool") or ""
                        ),
                        "decision": decision.get("decision"),
                        "reason": decision.get("reason"),
                        "would_have_blocked": bool(decision.get("would_have_blocked")),
                        "enforcement_mode": decision.get("enforcement_mode"),
                        "preflight_ready": bool(preflight_state.get("preflight_ready")),
                        "active_plan_step": bool(
                            preflight_state.get("active_plan_step")
                        ),
                        "preflight_state": preflight_state,
                        "read_only": bool(payload.get("read_only")),
                        "target_paths": _tool_payload_paths(payload),
                        "matched_guardrails": decision.get("matched", []),
                    },
                )
            self._learning_event_logger(
                "phase_g2",
                "guardrail_decision",
                session_id
                or str(
                    payload.get("task_session_id")
                    or payload.get("pack_id")
                    or "codex_hook"
                ),
                {
                    "tool_name": str(
                        payload.get("tool_name") or payload.get("tool") or ""
                    ),
                    "decision": decision.get("decision"),
                    "ok": bool(decision.get("ok")),
                    "reason": decision.get("reason"),
                    "target_paths": _tool_payload_paths(payload),
                    "matched": decision.get("matched", []),
                    "guardrail_degraded": decision.get("guardrail_degraded"),
                    "preflight_state": preflight_state,
                },
            )
        except (
            Exception
        ) as exc:  # noqa: BLE001 - hook decisions must remain best-effort.
            self._learning_event_logger(
                "phase1",
                "tool_gate_record_error",
                session_id,
                {"error": str(exc), "decision": decision},
            )

    def _codex_finalize_session(
        self, event: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        """Best-effort capture of a session's knowledge when Codex stops.

        Guarantees that an ended session leaves something in memory even if the
        agent never ran `outcome`: if a served pack is known and no outcome was
        recorded yet, record one (which captures summary + promotes candidates +
        consolidates); otherwise still consolidate the episode and update the
        continuation so the next session can resume. This must never raise.
        """
        base = {"ok": True, "event": event, "record_only": True}
        try:
            snapshot = self.resolver.resolve()
            sessions = self._agent_session_memory(snapshot.repo_id)
            session_id = str(payload.get("session_id") or "").strip()
            if not session_id:
                recent = sessions.recent(limit=1)
                session_id = str(recent[0]["session_id"]) if recent else ""
            if not session_id:
                return {**base, "finalized": False, "reason": "no_active_session"}

            explanation = sessions.explain(session_id)
            events = explanation.get("events", []) if explanation.get("ok") else []
            artifacts = (
                explanation.get("artifacts", []) if explanation.get("ok") else []
            )
            has_outcome = any(item.get("event_type") == "outcome" for item in events)

            result = str(payload.get("result") or "unknown").strip()
            summary = payload.get("summary")
            summary = summary if isinstance(summary, str) and summary.strip() else None
            pack_id = str(payload.get("pack_id") or "").strip()
            if not pack_id:
                for item in artifacts:
                    if item.get("artifact_type") == "pack_served" and item.get("ref"):
                        pack_id = str(item["ref"])
                        break

            finalize: dict[str, Any] = {
                "session_id": session_id,
                "recorded_outcome": False,
            }
            task_session_id = self._task_session_id_for_agent_session(session_id)
            if pack_id and not has_outcome:
                try:
                    outcome = self.record_outcome(
                        pack_id, result, None, session_id, summary=summary
                    )
                    finalize["recorded_outcome"] = True
                    finalize["outcome_id"] = outcome.get("outcome_id")
                    if outcome.get("episode_memory"):
                        finalize["episode_memory"] = outcome["episode_memory"]
                    if outcome.get("task_learning"):
                        finalize["learned"] = outcome["task_learning"].get("summary")
                except Exception as exc:  # noqa: BLE001
                    finalize["outcome_error"] = str(exc)
            else:
                if task_session_id:
                    finalize["task_learning"] = self.consolidate_task(
                        task_session_id,
                        trigger="codex_stop",
                        result=result,
                    )
                    finalize["learned"] = finalize["task_learning"].get("summary")
                elif self.settings.learning.enabled:
                    try:
                        finalize["dream"] = self.memory_dream(session_id=session_id)
                    except Exception as exc:  # noqa: BLE001
                        finalize["dream_error"] = str(exc)
                try:
                    passed = result.lower() in {"pass", "passed", "ok", "success"}
                    state = (
                        "completed"
                        if passed
                        else ("blocked" if result != "unknown" else None)
                    )
                    self._continuation_memory(
                        snapshot.repo_id
                    ).upsert_for_agent_session(
                        session_id,
                        event="stop",
                        state=state,
                        reason=f"codex stop: {result}",
                    )
                    finalize["continuation_updated"] = True
                except Exception as exc:  # noqa: BLE001
                    finalize["continuation_error"] = str(exc)
                if self.settings.memory.episodes_enabled:
                    try:
                        finalize[
                            "episode_memory"
                        ] = self._episodic_memory().upsert_for_agent_session(
                            session_id,
                            trigger="codex_stop",
                            result=result,
                            pack_id=pack_id or None,
                            summary=summary,
                            require_useful_evidence=True,
                        )
                    except Exception as exc:  # noqa: BLE001
                        finalize["episode_error"] = str(exc)
                else:
                    finalize["episode_memory"] = {
                        "ok": False,
                        "skipped": True,
                        "reason": "episodes_disabled",
                    }
            return {**base, "finalized": True, **finalize}
        except Exception as exc:  # noqa: BLE001 - finalize must never break Stop.
            return {**base, "finalized": False, "reason": str(exc)}

    def resolve_snapshot(self, refresh: bool = False) -> dict[str, Any]:
        return self._snapshot_dict(self.resolver.resolve(refresh=refresh))

    def snapshot_current(self) -> dict[str, Any]:
        snapshot = self.resolver.current_identity()
        row = self.store.snapshot_row(snapshot.snapshot_id)
        return {
            **self._snapshot_dict(snapshot),
            "indexed": row is not None,
            "parent_snapshot": row["parent_snapshot"] if row else None,
        }

    def snapshot_lineage(
        self, snapshot_id: str | None = None, limit: int = 50
    ) -> dict[str, Any]:
        current = snapshot_id or self.resolver.current_identity().snapshot_id
        rows = self.store.snapshot_lineage(current, limit=limit)
        return {
            "ok": True,
            "snapshot_id": current,
            "lineage": [
                {
                    "snapshot_id": row["snapshot_id"],
                    "repo_id": row["repo_id"],
                    "base_commit_sha": row["base_commit_sha"],
                    "worktree_state": row["worktree_state"],
                    "branch_hint": row["branch_hint"],
                    "parent_snapshot": row["parent_snapshot"],
                    "created_at": row["created_at"],
                }
                for row in rows
            ],
        }

    def refresh_index(self) -> dict[str, Any]:
        snapshot = self.resolve_snapshot(refresh=True)
        # Re-indexing is the update path (the update scripts run `ctxlayer index`); record it so
        # the global registry tracks that this project was updated.
        self._register_project(action="update", repo_id=snapshot.get("repo_id"))
        self._trigger_maintenance("index", full=False)
        return snapshot

    # ----- global project registry ---------------------------------------
    def _register_project(
        self, *, action: str, repo_id: str | None = None
    ) -> dict[str, Any] | None:
        """Best-effort: record this project in the cross-project registry. Never raises."""
        if registry_disabled():
            return None
        try:
            return ProjectRegistry().register(
                self.repo_root,
                label=self.repo_root.name,
                repo_id=repo_id,
                engine_version=__version__,
                action=action,
            )
        except Exception:  # noqa: BLE001 - registry must never break install/update
            return None

    def registry_register(
        self, *, label: str | None = None, action: str = "install"
    ) -> dict[str, Any]:
        return ProjectRegistry().register(
            self.repo_root,
            label=label or self.repo_root.name,
            engine_version=__version__,
            action=action,
        )

    def registry_list(self) -> dict[str, Any]:
        projects = ProjectRegistry().list()
        return {"ok": True, "count": len(projects), "projects": projects}

    def registry_remove(self, path: str | None = None) -> dict[str, Any]:
        removed = ProjectRegistry().remove(path or str(self.repo_root))
        return {"ok": removed, "removed": removed, "path": path or str(self.repo_root)}

    def registry_prune(self) -> dict[str, Any]:
        removed = ProjectRegistry().prune()
        return {"ok": True, "removed": removed, "count": len(removed)}

    def registry_health(
        self,
        *,
        include_temp: bool = False,
        path_root: str | None = None,
        include_rollup: bool = False,
        output: str | None = None,
    ) -> dict[str, Any]:
        registry = ProjectRegistry()
        records = registry.list()
        projects: list[dict[str, Any]] = []
        skipped = {"temp": 0, "outside_root": 0}
        for record in records:
            project_path = record.get("path", "")
            if path_root and not path_under_root(project_path, path_root):
                skipped["outside_root"] += 1
                continue
            if not include_temp and is_temp_project_path(project_path):
                skipped["temp"] += 1
                continue
            projects.append(
                self._registry_project_health(record, include_rollup=include_rollup)
            )

        summary = {
            "total": len(projects),
            "healthy": 0,
            "degraded": 0,
            "missing": 0,
            "error": 0,
            "stale_version": 0,
        }
        for project in projects:
            status = project["status"]
            if status in summary:
                summary[status] += 1
            if project.get("stale_version"):
                summary["stale_version"] += 1

        result = {
            "ok": True,
            "generated_at": utc_now(),
            "current_engine_version": __version__,
            "registry_count": len(records),
            "skipped": skipped,
            "summary": summary,
            "projects": projects,
        }
        if output:
            out_path = self.repo_root / output
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(
                json.dumps(result, indent=2, sort_keys=True), encoding="utf-8"
            )
            result["output"] = str(out_path)
        return result

    def _registry_project_health(
        self, record: dict[str, Any], *, include_rollup: bool
    ) -> dict[str, Any]:
        path_text = str(record.get("path") or "")
        project_path = Path(path_text)
        engine_version = record.get("engine_version")
        stale_version = _version_is_older(engine_version, __version__)
        issues: list[str] = []
        recommended_actions: list[str] = []
        project = {
            "label": record.get("label") or project_path.name,
            "path": path_text,
            "repo_id": record.get("repo_id"),
            "engine_version": engine_version,
            "current_engine_version": __version__,
            "last_action": record.get("last_action"),
            "last_updated": record.get("last_updated"),
            "install_count": record.get("install_count", 0),
            "update_count": record.get("update_count", 0),
            "exists": project_path.exists(),
            "ctxlayer_dir": False,
            "workspace_db": False,
            "doctor_status": None,
            "operational": None,
            "ready_for_work": None,
            "setup_complete": None,
            "ctx_health_status": None,
            "rollup_ok": None,
            "outcome_success_rate": None,
            "outcomes_total": None,
            "stale_version": stale_version,
            "issues": issues,
            "recommended_actions": recommended_actions,
            "status": "missing",
        }
        if stale_version:
            issues.append("version_stale")
            recommended_actions.append(
                f"Update CTX Layer for this project to {__version__}."
            )
        if not project["exists"]:
            issues.append("path_missing")
            recommended_actions.append(
                "Remove the stale registry entry or restore the path."
            )
            project["recommended_actions"] = _dedupe_strings(recommended_actions)
            return project

        ctx_dir = project_path / ".ctxlayer"
        db_path = ctx_dir / "workspace.db"
        project["ctxlayer_dir"] = ctx_dir.is_dir()
        project["workspace_db"] = db_path.is_file()
        if not project["ctxlayer_dir"]:
            issues.append("ctxlayer_dir_missing")
            recommended_actions.append(
                f"Run ctxlayer --repo {path_text} setup codex to initialize CTX Layer."
            )
            project["recommended_actions"] = _dedupe_strings(recommended_actions)
            return project
        if not project["workspace_db"]:
            issues.append("workspace_db_missing")
            recommended_actions.append(
                f"Run ctxlayer --repo {path_text} index to create the workspace database."
            )
            project["recommended_actions"] = _dedupe_strings(recommended_actions)
            return project

        try:
            with CtxLayerService(project_path) as project_service:
                doctor = project_service.doctor()
                project["doctor_status"] = doctor.get("status")
                project["operational"] = bool(doctor.get("operational"))
                project["ready_for_work"] = bool(doctor.get("ready_for_work"))
                project["setup_complete"] = bool(doctor.get("setup_complete"))
                project["ctx_health_status"] = (doctor.get("ctx_health", {}) or {}).get(
                    "status"
                )
                project["setup_advisory_missing"] = doctor.get(
                    "setup_advisory_missing", []
                )
                project["setup_blocking_missing"] = doctor.get(
                    "setup_blocking_missing", []
                )
                remediation = _project_remediation_commands(
                    doctor.get("remediation", {}), path_text
                )
                project["remediation"] = remediation
                if not project["operational"]:
                    issues.append("doctor_unavailable")
                elif project["doctor_status"] != "ok":
                    issues.append("doctor_degraded")
                if not project["ready_for_work"]:
                    issues.append("not_ready_for_work")
                if not project["setup_complete"]:
                    issues.append("setup_incomplete")
                if project["ctx_health_status"] not in (None, "ok"):
                    issues.append(f"ctx_health_{project['ctx_health_status']}")
                if remediation:
                    recommended_actions.extend(remediation.values())
                project.update(_outcome_health(project_service))
                if include_rollup:
                    rollup = project_service.metrics_rollup(label=project["label"])
                    project["rollup_ok"] = bool(rollup.get("ok"))
                    project["rollup_errors"] = rollup.get("errors", [])
                    if project["rollup_errors"]:
                        issues.append("rollup_errors")
        except Exception as exc:  # noqa: BLE001 - one project must not sink the report.
            project["status"] = "error"
            project["error"] = str(exc)
            issues.append("health_error")
            project["recommended_actions"] = _dedupe_strings(recommended_actions)
            return project

        project["issues"] = sorted(set(issues))
        project["recommended_actions"] = _dedupe_strings(recommended_actions)
        project["status"] = "healthy" if not project["issues"] else "degraded"
        return project

    def get_context_pack(
        self,
        task: str | None,
        budget: int | None = None,
        seed_paths: list[str] | None = None,
        *,
        rerank: bool = True,
        intent_id: str | None = None,
        goal_id: str | None = None,
        bind_snapshot: str | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        if bind_snapshot and not self.store.snapshot_exists(bind_snapshot):
            raise KeyError(f"snapshot not found: {bind_snapshot}")
        intent_seed: dict[str, Any] | None = None
        actual_task = task
        actual_seed_paths = list(seed_paths or [])
        if intent_id:
            intent_seed = self.intent.seed_for_pack(
                intent_id=intent_id, goal_id=goal_id
            )
            if intent_seed["snapshot_id"] != snapshot.snapshot_id:
                raise ValueError(
                    "intent snapshot differs from current snapshot; refresh or recreate the intent before packing"
                )
            actual_task = intent_seed["task"]
            actual_seed_paths = sorted(
                set(actual_seed_paths) | set(intent_seed["seed_paths"])
            )
        if not actual_task:
            raise ValueError("pack requires --task or --intent-id")
        manifest = self.compiler.compile(
            snapshot=snapshot,
            task=actual_task,
            budget=budget,
            seed_paths=actual_seed_paths,
            write=True,
            rerank=rerank,
        )
        manifest["grounding"] = self._nextgen_pack_grounding(
            actual_task, snapshot=snapshot
        )
        manifest["security"] = self._nextgen_defend_pack_manifest(manifest)
        health = self.ctx_health(persist=True)
        manifest["ctx_health"] = health
        if health["status"] != "ok":
            manifest["low_confidence"] = True
            manifest.setdefault("warnings", []).append(
                {
                    "kind": (
                        "ctx_unavailable"
                        if health["status"] == "unavailable"
                        else "ctx_degraded"
                    ),
                    "message": "CTX could not provide its full safety net for this pack.",
                    "ctx_health": health,
                }
            )
        binding = self._pack_binding(snapshot, bind_snapshot)
        manifest["binding"] = binding
        manifest["staleness"] = binding["staleness"]
        if self.settings.anticipation.brief.surface_in_pack:
            manifest["intuition"] = self._intuition_brief(
                task=actual_task,
                paths=actual_seed_paths,
                source="intuition_brief",
                snapshot=snapshot,
                pack=manifest,
            )
        if self.settings.governance.surface_in_pack:
            manifest["workflow"] = self._governance_brief(
                task=actual_task,
                paths=actual_seed_paths,
                mode="write",
                snapshot=snapshot,
                pack=manifest,
                source="pack_push",
            )
        enrichment_budget = EnrichmentBudget(
            self.settings.learning.pack_enrichment_budget_seconds
        )
        manifest["workspace"] = self._workspace_for_pack(
            task=actual_task,
            paths=actual_seed_paths,
            pack=manifest,
            budget=enrichment_budget,
        )
        if enrichment_budget.expired() or enrichment_budget.truncated:
            manifest["low_confidence"] = True
            manifest.setdefault("warnings", []).append(
                {
                    "kind": "enrichment_truncated",
                    "message": (
                        "Provider-backed pack enrichment exceeded its wall-clock "
                        "budget and was cut short; the pack is usable but may be "
                        "less complete."
                    ),
                    "budget_seconds": (
                        self.settings.learning.pack_enrichment_budget_seconds
                    ),
                }
            )
        if self.settings.metacognition.judgment_enabled:
            manifest["judgment"] = self._judgment_for_pack(
                task=actual_task,
                paths=actual_seed_paths,
            )
        if self.settings.metacognition.narrative_enabled:
            manifest["narrative"] = self._narrative_for_pack(snapshot.repo_id)
        if (
            self.settings.metacognition.enabled
            and self.settings.metacognition.surface_in_pack
        ):
            manifest["metacognition"] = self._metacognitive_state(
                task=actual_task,
                paths=actual_seed_paths,
                checkpoint="session_start",
                pack=manifest,
                task_session_id=None,
                persist=False,
                create_clarification=True,
            )
        self.store.write_pack(
            pack_id=manifest["pack_id"],
            snapshot_id=manifest["snapshot_id"],
            repo_id=manifest["repo_id"],
            task_text_hash=manifest["task_text_hash"],
            manifest=manifest,
            reconstructible=manifest["worktree_state"] == "clean"
            or self.settings.audit.retain_dirty_blobs,
            metadata={
                "intent_id": intent_seed["intent_id"] if intent_seed else None,
                "goal_id": intent_seed["goal_id"] if intent_seed else None,
            },
            bound_snapshot_id=binding["bound_snapshot_id"],
            binding_mode=binding["binding_mode"],
            base_commit_sha=binding["base_commit_sha"],
            worktree_state=binding["worktree_state"],
            staleness_state=binding["staleness"]["state"],
        )
        if intent_seed:
            manifest["intent"] = {
                "intent_id": intent_seed["intent_id"],
                "goal_id": intent_seed["goal_id"],
                "goal_statement": intent_seed["task"],
                "source_task": task,
                "evidence_seed_paths": intent_seed["seed_paths"],
            }
            self.store.write_pack(
                pack_id=manifest["pack_id"],
                snapshot_id=manifest["snapshot_id"],
                repo_id=manifest["repo_id"],
                task_text_hash=manifest["task_text_hash"],
                manifest=manifest,
                reconstructible=manifest["worktree_state"] == "clean"
                or self.settings.audit.retain_dirty_blobs,
                metadata={
                    "intent_id": intent_seed["intent_id"],
                    "goal_id": intent_seed["goal_id"],
                },
                bound_snapshot_id=binding["bound_snapshot_id"],
                binding_mode=binding["binding_mode"],
                base_commit_sha=binding["base_commit_sha"],
                worktree_state=binding["worktree_state"],
                staleness_state=binding["staleness"]["state"],
            )
            self._learning_event_logger(
                "A1",
                "intent_pack_built",
                intent_seed["intent_id"],
                {"pack_id": manifest["pack_id"], "goal_id": intent_seed["goal_id"]},
            )
        audit = self.audit.record_pack(manifest)
        manifest["audit"] = audit
        session = self._ensure_agent_session(
            actual_task,
            repo_id=snapshot.repo_id,
            metadata={
                "last_pack_id": manifest["pack_id"],
                "source": "pack",
                "intent_id": intent_seed["intent_id"] if intent_seed else None,
            },
        )
        self._record_agent_session_event(
            session["session_id"],
            "pack_served",
            {
                "pack_id": manifest["pack_id"],
                "snapshot_id": manifest["snapshot_id"],
                "base_commit_sha": manifest.get("base_commit_sha"),
                "seed_paths": sorted(actual_seed_paths),
                "item_count": len(manifest.get("items", [])),
                "intent_id": intent_seed["intent_id"] if intent_seed else None,
            },
        )
        self._continuation_memory(snapshot.repo_id).upsert_for_agent_session(
            session["session_id"],
            event="pack_served",
            state="packed",
            reason=f"pack served: {manifest['pack_id']}",
        )
        manifest["agent_session_id"] = session["session_id"]
        self._trigger_maintenance("pack", full=False)
        return manifest

    def _workspace_for_pack(
        self,
        *,
        task: str,
        paths: list[str],
        pack: dict[str, Any],
        budget: EnrichmentBudget | None = None,
    ) -> dict[str, Any]:
        if not self.settings.metacognition.workspace_enabled:
            return {
                "ok": True,
                "schema_version": "ctxlayer.workspace.v1",
                "active": False,
                "reason": "workspace_disabled",
                "rounds": [],
                "converged": False,
            }
        readiness = provider_readiness(self.settings)
        provider = build_agent_provider(
            self.settings,
            repo_root=self.repo_root,
            event_logger=self._learning_event_logger,
        )
        if budget is not None and is_real_provider(provider):
            provider = BudgetedProvider(provider, budget)
        result = run_cognitive_workspace(
            repo_root=self.repo_root,
            task=task,
            pack=pack,
            provider=provider,
            max_rounds=self.settings.metacognition.workspace_max_rounds,
            convergence_delta=self.settings.metacognition.workspace_convergence_delta,
            budget_tokens=self.settings.learning.max_tokens_per_task,
        )
        result["provider_status"] = readiness
        if budget is not None and (budget.expired() or budget.truncated):
            result["truncated"] = True
            result["budget_seconds"] = (
                self.settings.learning.pack_enrichment_budget_seconds
            )
        pack["used_tokens"] = sum(
            int(item.get("token_count") or 0) for item in pack.get("items") or []
        )
        return result

    def _judgment_for_pack(self, *, task: str, paths: list[str]) -> dict[str, Any]:
        heuristics = self.store.judgment_heuristics(status="adopted", limit=100)
        return applicable_judgment(
            heuristics=heuristics,
            task=task,
            paths=paths,
            mode=self.settings.metacognition.judgment_mode,
        )

    def _narrative_for_pack(self, repo_id: str) -> dict[str, Any]:
        row = self.store.latest_agent_narrative(repo_id)
        if not row:
            return {
                "ok": True,
                "schema_version": "ctxlayer.narrative.v1",
                "active": False,
                "reason": "no_narrative_yet",
            }
        return {
            "ok": True,
            "schema_version": "ctxlayer.narrative.v1",
            "active": True,
            "narrative_id": row["narrative_id"],
            "repo_id": row["repo_id"],
            "summary": row["summary"],
            "posture": _json_dict(row["posture_json"]),
            "source_run_id": row["source_run_id"],
            "created_at": row["created_at"],
        }

    def _metacognitive_state(
        self,
        *,
        task: str,
        paths: list[str],
        checkpoint: str,
        pack: dict[str, Any] | None = None,
        task_session_id: str | None = None,
        payload: dict[str, Any] | None = None,
        persist: bool = True,
        create_clarification: bool = False,
    ) -> dict[str, Any]:
        if not self.settings.metacognition.enabled:
            return {
                "ok": True,
                "schema_version": "ctxlayer.metacognition.v1",
                "active": False,
                "reason": "metacognition_disabled",
            }
        pack = pack or {}
        payload = payload or {}
        pack_id = pack.get("pack_id") if isinstance(pack, dict) else None
        scoped_clarifications = bool(task_session_id or pack_id)
        open_count = (
            len(
                self.store.clarification_requests(
                    task_session_id=task_session_id,
                    pack_id=pack_id,
                    status="open",
                    limit=100,
                )
            )
            if scoped_clarifications
            else 0
        )
        signals = self._metacognition_signals(
            task=task,
            paths=paths,
            pack=pack,
            task_session_id=task_session_id,
            payload=payload,
        )
        state = MetacognitiveController(self.settings.metacognition).tick(
            task=task,
            checkpoint=checkpoint,
            signals=signals,
            task_session_id=task_session_id,
            open_clarification_count=open_count,
        )
        state["signals"] = _metacognition_public_signals(signals)
        open_requests = (
            [
                _clarification_row_dict(row)
                for row in self.store.clarification_requests(
                    task_session_id=task_session_id,
                    pack_id=pack_id,
                    status="open",
                    limit=10,
                )
            ]
            if scoped_clarifications
            else []
        )
        created = None
        if create_clarification and state.get("action") == "ask_human":
            created = self._open_clarification_from_state(
                task=task,
                state=state,
                task_session_id=task_session_id,
                pack_id=pack_id,
            )
            if created:
                open_requests.insert(0, created)
        state["open_clarifications"] = open_requests
        if created:
            state["clarification_request"] = created
        if persist and state.get("active"):
            self.store.write_metacognitive_state(
                state_id=state["state_id"],
                task_session_id=task_session_id,
                checkpoint=checkpoint,
                self_state=state["self_state"],
                uncertainty=float(state["uncertainty"]),
                action=state["action"],
                signals=state,
            )
        return state

    def _metacognition_signals(
        self,
        *,
        task: str,
        paths: list[str],
        pack: dict[str, Any],
        task_session_id: str | None,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        signals: dict[str, Any] = {
            "task": task,
            "paths": paths,
            "pack": pack,
        }
        if payload.get("surprise"):
            signals["surprise"] = payload.get("surprise")
        elif isinstance(pack.get("workflow"), dict):
            workflow_signals = pack["workflow"].get("signals") or {}
            if isinstance(workflow_signals, dict) and workflow_signals.get("surprise"):
                signals["surprise"] = workflow_signals["surprise"]
        if task_session_id and not payload.get("__skip_workflow_next"):
            try:
                nxt = self.workflow_next(
                    task_session_id=task_session_id, record_volatile=False
                )
                gates = nxt.get("gates", {})
                signals["unresolved_gates"] = sum(
                    1
                    for value in gates.values()
                    if isinstance(value, dict) and value.get("status") != "pass"
                )
            except Exception:
                signals["unresolved_gates"] = 0
        if payload.get("goal_confidence") is not None:
            signals["goal_confidence"] = payload.get("goal_confidence")
        if payload.get("verification_failures") is not None:
            signals["verification_failures"] = payload.get("verification_failures")
        try:
            signals["storage"] = self.db_backend_status()
        except Exception:
            pass
        return signals

    def _open_clarification_from_state(
        self,
        *,
        task: str,
        state: dict[str, Any],
        task_session_id: str | None,
        pack_id: str | None,
    ) -> dict[str, Any] | None:
        question = str(state.get("question") or "").strip()
        if not question:
            return None
        request_id = stable_id(
            "clarification",
            task_session_id or "",
            pack_id or "",
            task,
            question,
            state.get("uncertainty"),
        )
        row = self.store.create_clarification_request(
            request_id=request_id,
            task_session_id=task_session_id,
            pack_id=pack_id,
            question=question,
            uncertainty_score=float(state.get("uncertainty") or 0.0),
            resolvable_by=str(state.get("resolvable_by") or "ask"),
            provenance={
                "state_id": state.get("state_id"),
                "drivers": state.get("drivers", []),
                "checkpoint": state.get("checkpoint"),
            },
        )
        item = _clarification_row_dict(row)
        if task_session_id:
            self._continuation_memory().upsert_for_task_session(
                task_session_id,
                event="clarification_open",
                state="blocked",
                next_action=question,
                blockers=[question],
                reason="metacognition requested human clarification",
            )
        return item

    def get_pack_manifest(self, pack_id: str) -> dict[str, Any]:
        manifest = self.compiler.get_manifest(pack_id)
        if manifest is None:
            raise KeyError(f"pack not found: {pack_id}")
        row = self.store.get_pack(pack_id)
        if row:
            staleness = self._staleness_for_bound_snapshot(
                row["bound_snapshot_id"] or row["snapshot_id"]
            )
            manifest["binding"] = {
                "bound_snapshot_id": row["bound_snapshot_id"] or row["snapshot_id"],
                "binding_mode": row["binding_mode"],
                "bound_at": row["bound_at"],
                "base_commit_sha": row["base_commit_sha"],
                "worktree_state": row["worktree_state"],
                "staleness": staleness,
            }
            manifest["staleness"] = staleness
            self.store.update_pack_staleness(pack_id, staleness["state"])
        return manifest

    def _provider_advisory_candidate(
        self,
        *,
        role: str,
        input_source: str,
        target_id: str,
        title: str,
        prompt_payload: dict[str, Any],
        memory_metadata: dict[str, Any],
    ) -> dict[str, Any]:
        readiness = provider_readiness(self.settings)
        result: dict[str, Any] = {"provider_status": readiness}
        provider = build_agent_provider(
            self.settings,
            repo_root=self.repo_root,
            event_logger=self._learning_event_logger,
        )
        if not is_real_provider(provider):
            result["provider_reason"] = readiness.get("reason") or "provider_inactive"
            return result
        raw = provider.complete(
            prompt=canonical_json(prompt_payload),
            role=role,
            schema={
                "type": "object",
                "properties": {
                    "assertion": {"type": "string"},
                    "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
                },
                "additionalProperties": True,
            },
            model_family=self.settings.learning.actor_model_family,
            budget_tokens=self.settings.learning.max_tokens_per_task,
        )
        if not isinstance(raw, dict) or not str(raw.get("assertion") or "").strip():
            result["provider_reason"] = "provider_no_parseable_output"
            return result
        confidence = max(0.0, min(1.0, float(raw.get("confidence") or 0.5)))
        try:
            result["provider_candidate_memory"] = self.unified_memory().create_typed(
                {
                    "type": "decision",
                    "title": title,
                    "assertion": str(raw["assertion"]),
                    "source_kind": "agent_provider",
                    "confidence": confidence,
                    "status": "candidate",
                    "trust": "untrusted",
                    "metadata": {
                        **memory_metadata,
                        "target_id": target_id,
                        "provider_role": role,
                    },
                    "provenance": {
                        "generator": "agent_provider",
                        "validator": "pending_outcome_or_approval",
                        "input_source": input_source,
                    },
                }
            )
        except (
            Exception
        ) as exc:  # noqa: BLE001 - provider advice is never authoritative.
            result["provider_candidate_error"] = str(exc)
        return result

    def intent_start(
        self, problem: str, *, llm_propose: bool = False
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        result = self.intent.start(
            problem=problem, snapshot=snapshot, llm_propose=llm_propose
        )
        result.update(
            self._provider_advisory_candidate(
                role="intent_advisor",
                input_source="intent_start",
                target_id=result["intent_id"],
                title=f"Provider advisory for intent {result['intent_id']}",
                prompt_payload={
                    "task": "Propose advisory intent considerations only.",
                    "intent": result,
                },
                memory_metadata={
                    "rationale": "provider advisory only",
                    "alternatives": ["deterministic intent decomposition"],
                    "intent_id": result["intent_id"],
                },
            )
        )
        return result

    def intent_show(self, intent_id: str) -> dict[str, Any]:
        return self.intent.show(intent_id)

    def intent_refine(
        self,
        intent_id: str,
        *,
        evidence: list[str] | None = None,
        select_goal: str | None = None,
    ) -> dict[str, Any]:
        result = self.intent.refine(
            intent_id=intent_id, evidence=evidence, select_goal=select_goal
        )
        result.update(
            self._provider_advisory_candidate(
                role="intent_advisor",
                input_source="intent_refine",
                target_id=intent_id,
                title=f"Provider advisory for intent {intent_id}",
                prompt_payload={
                    "task": "Propose advisory intent-refinement considerations only.",
                    "intent": result,
                    "selected_goal": select_goal,
                    "new_evidence": evidence or [],
                },
                memory_metadata={
                    "rationale": "provider advisory only",
                    "alternatives": ["deterministic intent refinement"],
                    "intent_id": intent_id,
                },
            )
        )
        return result

    def intent_list(
        self, *, status: str | None = None, limit: int = 50
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.intent.list(repo_id=snapshot.repo_id, status=status, limit=limit)

    def goal_evaluate(
        self,
        intent_id: str,
        *,
        candidate_goal_id: str | None = None,
        mode: str | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        result = self.goals.evaluate(
            intent_id=intent_id,
            snapshot=snapshot,
            candidate_goal_id=candidate_goal_id,
            mode=mode,
        )
        result.update(
            self._provider_advisory_candidate(
                role="goal_advisor",
                input_source="goal_evaluate",
                target_id=result["goal_id"],
                title=f"Provider advisory for goal {result['goal_id']}",
                prompt_payload={
                    "task": "Propose advisory goal-governance considerations only.",
                    "goal": result,
                },
                memory_metadata={
                    "rationale": "provider advisory only",
                    "alternatives": ["deterministic goal evaluation"],
                    "goal_id": result["goal_id"],
                    "intent_id": intent_id,
                },
            )
        )
        return result

    def goal_show(self, goal_id: str) -> dict[str, Any]:
        return self.goals.show(goal_id)

    def goal_challenge(self, goal_id: str) -> dict[str, Any]:
        result = self.goals.challenge(goal_id)
        result.update(
            self._provider_advisory_candidate(
                role="goal_advisor",
                input_source="goal_challenge",
                target_id=goal_id,
                title=f"Provider advisory for goal {goal_id}",
                prompt_payload={
                    "task": "Propose advisory goal-challenge considerations only.",
                    "challenge": result,
                },
                memory_metadata={
                    "rationale": "provider advisory only",
                    "alternatives": ["deterministic goal challenge"],
                    "goal_id": goal_id,
                },
            )
        )
        return result

    def goal_accept_alternative(
        self, goal_id: str, alt_id: str, rationale: str, *, actor: str = "local-user"
    ) -> dict[str, Any]:
        return self.goals.accept_alternative(
            goal_id=goal_id,
            alt_id=alt_id,
            rationale=rationale,
            actor=actor,
            memory=self.unified_memory(),
        )

    def goal_reject_alternative(
        self, goal_id: str, alt_id: str, rationale: str, *, actor: str = "local-user"
    ) -> dict[str, Any]:
        return self.goals.reject_alternative(
            goal_id=goal_id,
            alt_id=alt_id,
            rationale=rationale,
            actor=actor,
        )

    def goal_reevaluate(
        self, goal_id: str, *, trigger: str = "manual"
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.goals.reevaluate(
            goal_id=goal_id, snapshot=snapshot, trigger=trigger
        )

    def goal_list(
        self, *, status: str | None = None, limit: int = 50
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.goals.list(repo_id=snapshot.repo_id, status=status, limit=limit)

    def reconstruct_pack(
        self, pack_id: str, task_text: str | None = None
    ) -> dict[str, Any]:
        return self.compiler.reconstruct(pack_id, task_text)

    def get_impact_report(
        self,
        paths: list[str] | None = None,
        pack_id: str | None = None,
        diff: str | None = None,
        business: bool = False,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        input_paths = paths or []
        if diff:
            input_paths.extend(paths_from_diff(diff))
        return self.impact.report(
            snapshot=snapshot,
            paths=input_paths,
            pack_id=pack_id,
            business=business,
        )

    def _intuition_brief(
        self,
        *,
        task: str,
        paths: list[str] | None = None,
        session_id: str | None = None,
        task_session_id: str | None = None,
        source: str = "intuition_consult",
        snapshot: SnapshotInfo | None = None,
        pack: dict[str, Any] | None = None,
        proposed_content: str | None = None,
        proposed_path: str | None = None,
    ) -> dict[str, Any]:
        mode, degraded = self._anticipation_gate_mode()
        return build_brief(
            engine=self.anticipation,
            mode=mode,
            degraded=degraded,
            repo_root=self.repo_root,
            snapshot=snapshot or self.resolver.resolve(),
            task=task,
            seed_paths=paths or [],
            session_id=session_id,
            task_session_id=task_session_id,
            settings=self.settings,
            pack=pack,
            source=source,
            proposed_content=proposed_content,
            proposed_path=proposed_path,
        )

    def anticipate_consult(
        self,
        *,
        task: str,
        paths: list[str] | None = None,
        session_id: str | None = None,
        task_session_id: str | None = None,
    ) -> dict[str, Any]:
        return self._intuition_brief(
            task=task,
            paths=paths or [],
            session_id=session_id,
            task_session_id=task_session_id,
            source="intuition_consult",
        )

    def _governance_brief(
        self,
        *,
        task: str,
        paths: list[str] | None = None,
        mode: str = "write",
        snapshot: SnapshotInfo | None = None,
        pack: dict[str, Any] | None = None,
        task_session_id: str | None = None,
        source: str = "governance_brief",
    ) -> dict[str, Any]:
        del snapshot
        seed_paths = sorted({str(path).replace("\\", "/") for path in paths or []})
        try:
            impact = self.get_impact_report(
                paths=seed_paths,
                pack_id=str(pack.get("pack_id")) if isinstance(pack, dict) else None,
            )
        except Exception:
            impact = None
        signals = self._workflow_surprise_signal(task=task, paths=seed_paths)
        signals["governance_overlay"] = self._governance_adopted_overlay()
        if task_session_id:
            signals["task_session_id"] = task_session_id
        workflow_signals = self._workflow_surprise_signal(task=task, paths=seed_paths)
        workflow_signals["governance_overlay"] = self._governance_adopted_overlay()
        recommendation = WorkflowRouter().recommend(
            task=task,
            mode=mode,
            paths=seed_paths,
            impact_report=impact,
            task_session_id=task_session_id,
            pack_id=str(pack.get("pack_id")) if isinstance(pack, dict) else None,
            signals=signals,
        )
        gate_status = {}
        if task_session_id:
            gate_status = GateEvaluator(
                self.store,
                fingerprint_provider=self._workflow_fingerprint,
                session_resolver=self._session_id_for_task_session,
            ).evaluate(
                task_session_id,
                [item["gate_id"] for item in recommendation.get("gates", [])],
                pack_id=str(pack.get("pack_id")) if isinstance(pack, dict) else None,
            )
        gates = [
            {
                **gate,
                "status": gate_status.get(gate["gate_id"], {}).get("status", "pending"),
                "detail": gate_status.get(gate["gate_id"], {}),
            }
            for gate in recommendation.get("gates", [])
        ]
        return {
            "ok": True,
            "schema_version": "ctxlayer.pack_governance.v1",
            "mode": recommendation.get("mode"),
            "task_types": recommendation.get("task_types", []),
            "enforcement_mode": self.settings.governance.enforcement_mode,
            "now": recommendation.get("now", []),
            "before_writing": recommendation.get("before_writing", []),
            "before_complete": recommendation.get("before_complete", []),
            "on_demand": recommendation.get("on_demand", []),
            "required_features": recommendation.get("required_features", []),
            "optional_features": recommendation.get("optional_features", []),
            "gates": gates,
            "stop_when": recommendation.get("stop_when", []),
            "next_action": self._workflow_next_action_from_recommendation(
                recommendation
            ),
            "adapted": bool(recommendation.get("adapted")),
            "source": source,
        }

    def workflow_brief(
        self,
        task: str,
        *,
        paths: list[str] | None = None,
        mode: str = "auto",
        task_session_id: str | None = None,
    ) -> dict[str, Any]:
        return self._governance_brief(
            task=task,
            paths=paths or [],
            mode=mode,
            task_session_id=task_session_id,
            source="workflow_brief",
        )

    def _governance_adopted_overlay(self) -> list[dict[str, Any]]:
        if not self.settings.governance.adaptation_enabled:
            return []
        try:
            return governance_adopted_overlay(self.store)
        except Exception:  # noqa: BLE001 - governance overlay must not break routing.
            return []

    def governance_status(self) -> dict[str, Any]:
        proposals = self.store.governance_playbook_proposals(limit=500)
        adopted = self.store.governance_playbook_adoptions(active_only=True)
        return {
            "ok": True,
            "schema_version": "ctxlayer.governance_status.v1",
            "adaptation_enabled": self.settings.governance.adaptation_enabled,
            "min_samples": self.settings.governance.adaptation_min_samples,
            "enforcement_mode": self.settings.governance.enforcement_mode,
            "proposal_count": len(proposals),
            "adopted_overlay_count": len(adopted),
            "workflow_lint": self.workflow_lint(),
        }

    def governance_propose(self, *, min_samples: int | None = None) -> dict[str, Any]:
        if not self.settings.governance.adaptation_enabled:
            return {"ok": False, "reason": "governance adaptation disabled"}
        return propose_playbook_changes(
            self.store,
            min_samples=min_samples or self.settings.governance.adaptation_min_samples,
            analytics_backend=self.settings.storage.analytics_backend,
            db_path=self.store.db_path,
        )

    def governance_list(self, *, status: str | None = None) -> dict[str, Any]:
        return {
            "ok": True,
            "schema_version": "ctxlayer.governance_proposals.v1",
            "proposals": [
                _governance_proposal_dict(row)
                for row in self.store.governance_playbook_proposals(status=status)
            ],
        }

    def governance_show(self, proposal_id: str) -> dict[str, Any]:
        row = self.store.governance_playbook_proposal(proposal_id)
        if not row:
            raise KeyError(f"governance proposal not found: {proposal_id}")
        return {
            "ok": True,
            "schema_version": "ctxlayer.governance_proposal.v1",
            "proposal": _governance_proposal_dict(row),
        }

    def governance_preview_adoption(self, proposal_id: str) -> dict[str, Any]:
        proposal = self.governance_show(proposal_id)["proposal"]
        return governance_preview_adoption(proposal)

    def governance_adopt(
        self,
        proposal_id: str,
        *,
        actor: str = "local-user",
        reason: str | None = None,
    ) -> dict[str, Any]:
        row = self.store.governance_playbook_proposal(proposal_id)
        if not row:
            raise KeyError(f"governance proposal not found: {proposal_id}")
        adoption_id = self.store.create_governance_playbook_adoption(
            proposal_id=proposal_id,
            task_type=str(row["task_type"]),
            feature_id=str(row["feature_id"]),
            change=str(row["change"]),
            adopted_by=actor,
            reason=reason,
        )
        audit = self.store.append_audit(
            pack_id=f"governance:{adoption_id}",
            payload={
                "kind": "governance_playbook_adoption",
                "proposal_id": proposal_id,
                "adoption_id": adoption_id,
                "task_type": row["task_type"],
                "feature_id": row["feature_id"],
                "change": row["change"],
                "actor": actor,
                "reason": reason,
            },
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.governance_adopt.v1",
            "adoption_id": adoption_id,
            "proposal_id": proposal_id,
            "audit": audit,
            "overlay": self._governance_adopted_overlay(),
        }

    def governance_reject(
        self, proposal_id: str, *, reason: str | None = None
    ) -> dict[str, Any]:
        if not self.store.governance_playbook_proposal(proposal_id):
            raise KeyError(f"governance proposal not found: {proposal_id}")
        self.store.update_governance_playbook_proposal_status(proposal_id, "rejected")
        audit = self.store.append_audit(
            pack_id=f"governance:{proposal_id}",
            payload={
                "kind": "governance_playbook_rejection",
                "proposal_id": proposal_id,
                "reason": reason,
            },
        )
        return {
            "ok": True,
            "proposal_id": proposal_id,
            "status": "rejected",
            "audit": audit,
        }

    def governance_rollback(
        self, adoption_id: str, *, reason: str | None = None
    ) -> dict[str, Any]:
        self.store.rollback_governance_playbook_adoption(adoption_id, reason=reason)
        audit = self.store.append_audit(
            pack_id=f"governance:{adoption_id}",
            payload={
                "kind": "governance_playbook_rollback",
                "adoption_id": adoption_id,
                "reason": reason,
            },
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.governance_rollback.v1",
            "adoption_id": adoption_id,
            "audit": audit,
            "overlay": self._governance_adopted_overlay(),
        }

    def anticipate_ui_review(
        self,
        *,
        task: str = "",
        paths: list[str] | None = None,
        proposed_content: str | None = None,
        proposed_path: str | None = None,
    ) -> dict[str, Any]:
        return review_ui_redundancy(
            self.repo_root,
            task=task,
            paths=paths or [],
            proposed_content=proposed_content,
            proposed_path=proposed_path,
            max_findings=self.settings.anticipation.brief.max_ui_findings,
        )

    def anticipate_train(self) -> dict[str, Any]:
        return self.anticipation.train()

    def anticipate_status(self) -> dict[str, Any]:
        return self.anticipation.status()

    def anticipate_score(self, session_id: str) -> dict[str, Any]:
        return self.anticipation.score_session(session_id=session_id)

    def anticipate_lookahead(
        self,
        *,
        task: str,
        paths: list[str] | None = None,
        top_k: int = 5,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.impact.anticipate(
            snapshot=snapshot,
            task=task,
            current_paths=paths or [],
            world_model=self.anticipation.world_model,
            top_k=top_k,
        )

    def anticipate_simulate(
        self,
        *,
        task: str,
        paths: list[str] | None = None,
        depth: int = 2,
        beam: int = 3,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.anticipation.simulate(
            snapshot=snapshot,
            task=task,
            current_paths=paths or [],
            depth=depth,
            beam=beam,
        )

    def anticipate_transfer_export(self) -> dict[str, Any]:
        from ctxlayer.anticipation.pattern_library import PatternLibrary

        transfer = self.settings.anticipation.transfer
        library = PatternLibrary(
            library=transfer.library,
            max_transfer_weight=transfer.max_transfer_weight,
        )
        patterns = library.export(self.anticipation.world_model)
        result = library.write(patterns)
        self._learning_event_logger(
            "anticipation",
            "transfer_export",
            self._memory_repo_id,
            {"pattern_count": len(patterns), "library": transfer.library},
        )
        return {**result, "pattern_count": len(patterns)}

    def anticipate_transfer_import_status(self) -> dict[str, Any]:
        from ctxlayer.anticipation.pattern_library import PatternLibrary
        from ctxlayer.retrieval.embedder import make_embedder

        transfer = self.settings.anticipation.transfer
        toolchain = self.settings.toolchain
        embedder = make_embedder(
            model_name=toolchain.embed_model,
            backend=toolchain.embed_backend,
        )
        patterns = PatternLibrary(
            library=transfer.library,
            max_transfer_weight=transfer.max_transfer_weight,
            embedder_signature={
                "name": embedder.model_name,
                "dim": embedder.dims,
                "backend": getattr(embedder, "backend", "unknown"),
            },
        ).import_for(self._memory_repo_id)
        return {
            "ok": True,
            "enabled": transfer.enabled,
            "pattern_count": len(patterns),
            "max_transfer_weight": transfer.max_transfer_weight,
        }

    def anticipate_doctor(self) -> dict[str, Any]:
        status = self.anticipate_status()
        embedder = status.get("embedder") or {}
        latest = status.get("latest_model") or {}
        gate_mode, gate_degraded = self._anticipation_gate_mode()
        return {
            "ok": True,
            "model_kind": latest.get("kind") or self.settings.anticipation.model.kind,
            "active_embedder": embedder,
            "semantic": embedder.get("backend") == "sentence-transformers",
            "degraded": status.get("degraded"),
            "enforce_degraded": gate_degraded,
            "cold_start": status.get("cold_start"),
            "prediction_count": status.get("prediction_count"),
            "enforce_ready": gate_mode == "enforce",
            "ece": latest.get("ece"),
            "enforce_requires_ece_below": self.settings.anticipation.guards.enforce_requires_ece_below,
        }

    def anticipate_benchmark(
        self,
        *,
        arms: list[str] | None = None,
        threshold: float = 0.55,
        limit: int = 200,
        holdout_ratio: float = 0.3,
        ece_bins: int = 10,
        semantic_model: str | None = None,
        semantic_backend: str = "sentence-transformers",
    ) -> dict[str, Any]:
        from ctxlayer.anticipation.validation import (
            DEFAULT_SEMANTIC_MODEL,
            run_benchmark,
        )

        report = run_benchmark(
            store=self.store,
            repo_id=self._memory_repo_id,
            settings=self.settings,
            arms=arms,
            threshold=threshold,
            limit=limit,
            holdout_ratio=holdout_ratio,
            ece_bins=ece_bins,
            semantic_model=semantic_model or DEFAULT_SEMANTIC_MODEL,
            semantic_backend=semantic_backend,
        )
        run_id = self.store.write_agent_benchmark_run(
            repo_id=self._memory_repo_id,
            report=report,
        )
        report["benchmark_run_id"] = run_id
        self._learning_event_logger(
            "anticipation",
            "anticipation_benchmark_recorded",
            self._memory_repo_id,
            {
                "benchmark_run_id": run_id,
                "cases": report.get("cases", 0),
                "gate": report.get("gate", {}),
            },
        )
        return report

    def anticipate_shadow_validate(
        self, *, limit: int = 100, mode: str = "shadow"
    ) -> dict[str, Any]:
        from ctxlayer.anticipation.validation import shadow_validate

        report = shadow_validate(
            store=self.store,
            repo_id=self._memory_repo_id,
            limit=limit,
            mode=mode,
        )
        self._learning_event_logger(
            "anticipation",
            "anticipation_shadow_validation",
            self._memory_repo_id,
            report,
        )
        return report

    def anticipate_gut(
        self,
        *,
        session_id: str,
        task_session_id: str | None = None,
        paths: list[str] | None = None,
    ) -> dict[str, Any]:
        return self.anticipation.gut(
            session_id=session_id,
            task_session_id=task_session_id,
            active_paths=paths or [],
        )

    def select_minimal_tests(
        self, paths: list[str] | None = None, diff: str | None = None
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        input_paths = list(paths or [])
        if diff:
            input_paths.extend(paths_from_diff(diff))
        return self.impact.select_minimal_tests(snapshot=snapshot, paths=input_paths)

    def check_diff_against_pack(
        self,
        pack_id: str,
        diff: str | None = None,
        paths: list[str] | None = None,
    ) -> dict[str, Any]:
        snapshot = self._pack_snapshot(pack_id)
        changed_paths = (
            paths
            if paths is not None
            else paths_from_diff(diff) if diff else git_changed_paths(self.repo_root)
        )
        return self.impact.check_diff_against_pack(
            snapshot=snapshot, pack_id=pack_id, paths=changed_paths, diff=diff
        )

    def search_code(self, query: str, limit: int = 20) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        rows = self.store.search_chunks(snapshot.snapshot_id, query, limit=limit)
        return {
            "snapshot_id": snapshot.snapshot_id,
            "results": [
                {
                    "path": row["path"],
                    "start_line": row["start_line"],
                    "end_line": row["end_line"],
                    "category": row["category"],
                    "text": row["text"],
                    "token_count": row["token_count"],
                }
                for row in rows
            ],
        }

    def nextgen_status(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        report = nextgen_status_report(
            repo_id=snapshot.repo_id,
            snapshot_id=snapshot.snapshot_id,
            provider_status=provider_readiness(self.settings),
            capability_signals=self._nextgen_capability_signals(),
        )
        report["memory_graph"] = self.store.memory_edge_counts(
            workspace_id=self._memory_workspace_id,
            repo_id=self._memory_repo_id,
        )
        sleep_runs = self.store.memory_sleep_runs(
            workspace_id=self._memory_workspace_id,
            repo_id=self._memory_repo_id,
            limit=1,
        )
        report["memory_sleep"] = {
            "last_run_at": sleep_runs[0]["started_at"] if sleep_runs else None,
            "last_status": sleep_runs[0]["status"] if sleep_runs else None,
            "duplicates_merged_total": sum(
                int(row["duplicates_merged"])
                for row in self.store.memory_sleep_runs(
                    workspace_id=self._memory_workspace_id,
                    repo_id=self._memory_repo_id,
                    limit=100,
                )
            ),
        }
        report["memory_prefetch"] = self.store.memory_prefetch_cache_stats(
            workspace_id=self._memory_workspace_id,
            repo_id=self._memory_repo_id,
        )
        embedder = self._embedder_readiness()
        report["embedding"] = {
            "backend": embedder["backend"],
            "model_name": embedder["model_name"],
            "degraded_reason": embedder["degraded_reason"],
            "degraded_severity": embedder.get("degraded_severity"),
            "degraded_remediation": embedder.get("degraded_remediation"),
            "warn_on_degraded": self.settings.embedding.warn_on_degraded,
        }
        return report

    def _nextgen_pack_grounding(
        self, task: str | None, *, snapshot: Any | None = None
    ) -> dict[str, Any]:
        task = task or ""
        symbols = sorted(
            {token for token in re.findall(r"\b[A-Za-z_][A-Za-z0-9_]*\b", task)}
        )
        signatures = self._indexed_pack_signatures(
            symbols[:20],
            snapshot_id=getattr(snapshot, "snapshot_id", None),
            repo_id=getattr(snapshot, "repo_id", None),
            limit=80,
        )
        return {
            "schema_version": "ctxlayer.nextgen_pack_grounding.v1",
            "symbols": signatures,
            "source": "indexed_snapshot_symbols",
            "honesty": (
                "no_matching_signatures"
                if not signatures
                else "real_signatures_from_indexed_snapshot"
            ),
        }

    def _indexed_pack_signatures(
        self,
        symbols: list[str],
        *,
        snapshot_id: str | None,
        repo_id: str | None,
        limit: int,
    ) -> list[dict[str, Any]]:
        if not symbols or not snapshot_id or not repo_id or limit <= 0:
            return []
        signatures: list[dict[str, Any]] = []
        seen: set[tuple[str, int, str, str]] = set()
        for symbol in symbols:
            if len(signatures) >= limit:
                break
            rows = self.store.conn.execute(
                """
                SELECT si.path, si.qualname, si.kind, so.start_line, so.signature, fv.lang
                FROM snapshot_files sf
                JOIN file_versions fv ON fv.file_version_id = sf.file_version_id
                JOIN symbol_occurrences so ON so.file_version_id = sf.file_version_id
                JOIN symbol_identities si ON si.symbol_identity_id = so.symbol_identity_id
                WHERE sf.snapshot_id = ?
                  AND si.repo_id = ?
                  AND (si.qualname = ? OR si.qualname LIKE ?)
                ORDER BY si.path, si.qualname, so.start_line
                LIMIT ?
                """,
                (
                    snapshot_id,
                    repo_id,
                    symbol,
                    f"%.{symbol}",
                    max(1, limit - len(signatures)),
                ),
            ).fetchall()
            for row in rows:
                signature = row["signature"] or row["qualname"]
                key = (
                    str(row["path"]),
                    int(row["start_line"] or 0),
                    str(row["kind"]),
                    str(signature),
                )
                if key in seen:
                    continue
                seen.add(key)
                signatures.append(
                    {
                        "path": row["path"],
                        "line": row["start_line"],
                        "kind": row["kind"],
                        "lang": row["lang"],
                        "qualname": row["qualname"],
                        "signature": signature,
                    }
                )
                if len(signatures) >= limit:
                    break
        return signatures

    def _nextgen_defend_pack_manifest(self, manifest: dict[str, Any]) -> dict[str, Any]:
        items = []
        for item in list(manifest.get("items") or []):
            enriched = dict(item)
            path = enriched.get("path")
            if path:
                target = self.repo_root / str(path).replace("\\", "/")
                if target.is_file():
                    file_text = target.read_text(encoding="utf-8", errors="ignore")
                    enriched["content"] = f"{enriched.get('text', '')}\n{file_text}"
            items.append(enriched)
        defended = defend_served_items(items)
        if defended["quarantined"]:
            manifest["items"] = defended["served"]
            audit = self.store.append_audit(
                pack_id=manifest.get("pack_id", "nextgen_pending_pack"),
                payload={
                    "event": "nextgen_served_content_quarantine",
                    "quarantined": defended["quarantined"],
                },
            )
            defended["audit"] = audit
        return defended

    def _nextgen_capability_signals(self) -> dict[str, Any]:
        provider = provider_readiness(self.settings)
        provider_configured = provider.get("state") == "usable" or bool(
            provider.get("configured")
        )
        deterministic = {
            "available": True,
            "evidence": "deterministic_service_method",
        }
        return {
            "jit_retrieval": deterministic,
            "stale_state_guard": deterministic,
            "regrounding_capsule": deterministic,
            "context_compaction": deterministic,
            "progressive_skills": deterministic,
            "budget_accounting": deterministic,
            "inline_verification_gates": deterministic,
            "error_quarantine": deterministic,
            "replan_on_surprise": deterministic,
            "checkpoint_restore": deterministic,
            "autonomy_budget": deterministic,
            "failure_memory_capture": deterministic,
            "negative_constraints_served": deterministic,
            "verified_rerank": deterministic,
            "episodic_semantic_consolidation": deterministic,
            "skill_curation_status": {
                "available": True,
                "evidence": "skill maintain/search surfaces",
            },
            "pack_signature_grounding": deterministic,
            "signature_grounding": deterministic,
            "dependency_grounding": deterministic,
            "dependency_supervision_gate": deterministic,
            "file_provenance": deterministic,
            "phase_b_surface": {
                "available": True,
                "evidence": "verify mutation/differential/properties/localize",
            },
            "oracle_protection": deterministic,
            "reward_hack_detection": deterministic,
            "world_model_prediction": deterministic,
            "ownership_reasoning": deterministic,
            "boundary_reasoning": deterministic,
            "dependency_direction": deterministic,
            "minimal_change_set": deterministic,
            "semantic_retrieval_honesty": deterministic,
            "rationale_memory": deterministic,
            "spec_code_link": deterministic,
            "spec_code_drift_detection": deterministic,
            "untrusted_content_scan": deterministic,
            "defend_all_served": deterministic,
            "blast_radius_policy": deterministic,
            "served_context_provenance": deterministic,
            "semantic_conflict_detection": deterministic,
            "merge_gate": deterministic,
            "snapshot_staleness": deterministic,
            "scorecard_metrics": deterministic,
            "ab_delta_metrics": deterministic,
            "trajectory_reliability": deterministic,
            "cost_accounting": deterministic,
            "provider_honesty": {
                "available": True,
                "configured": provider_configured,
                "evidence": "provider readiness exposed without silent no-op",
            },
            "provider_reflection": {
                "available": True,
                "configured": provider_configured,
                "evidence": "runs when provider configured; honest inactive otherwise",
            },
            "deterministic_fallback": deterministic,
        }

    def nextgen_retrieve(
        self,
        query: str,
        limit: int = 10,
        *,
        served_context: list[dict[str, Any]] | None = None,
        token_budget: int | None = None,
    ) -> dict[str, Any]:
        result = self.search_code(query, limit=limit)
        served_items = [dict(item) for item in result.get("results", [])]
        eviction = self._nextgen_evict_to_budget(served_items, token_budget)
        served_items = eviction["kept"]
        paths = sorted({item["path"] for item in served_items})
        provenance = [file_provenance(self.repo_root, path) for path in paths]
        stale = stale_state_report(self.repo_root, served_context or provenance)
        constraints = self.memory_search(
            query,
            types=["failure_lesson"],
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_retrieve.v1",
            "query": query,
            "snapshot_id": result["snapshot_id"],
            "results": served_items,
            "provenance": provenance,
            "trust": "snapshot_bound",
            "stale_state": stale,
            "regrounding": regrounding_capsule(
                pack_id=None,
                snapshot_id=result["snapshot_id"],
                progress=f"retrieve:{query}",
                stale=stale,
            ),
            "negative_constraints": constraints.get("results", [])[:5],
            "budget": {
                **context_budget_report(served_items),
                "token_budget": token_budget,
                "evicted": eviction["evicted"],
                "evicted_count": len(eviction["evicted"]),
            },
        }

    def _nextgen_evict_to_budget(
        self, items: list[dict[str, Any]], token_budget: int | None
    ) -> dict[str, Any]:
        if token_budget is None:
            return {"kept": items, "evicted": []}
        budget = max(0, int(token_budget))
        scored = []
        for index, item in enumerate(items):
            tokens = int(item.get("token_count") or 0)
            score = float(item.get("score") or max(0, len(items) - index))
            stable = 1 if item.get("path") else 0
            scored.append((score + stable * 0.1, index, tokens, item))
        kept_indexes: set[int] = set()
        used = 0
        for _score, index, tokens, _item in sorted(
            scored, key=lambda row: (-row[0], row[1])
        ):
            if used + tokens <= budget:
                kept_indexes.add(index)
                used += tokens
        kept = [item for index, item in enumerate(items) if index in kept_indexes]
        evicted = [
            {
                "path": item.get("path"),
                "token_count": int(item.get("token_count") or 0),
                "reason": "token_budget_eviction",
            }
            for index, item in enumerate(items)
            if index not in kept_indexes
        ]
        return {"kept": kept, "evicted": evicted}

    def nextgen_subagent(
        self,
        task: str,
        *,
        scope: list[str] | None = None,
        mode: str = "read",
        limit: int = 8,
    ) -> dict[str, Any]:
        if mode != "read":
            return {
                "ok": False,
                "schema_version": "ctxlayer.nextgen_subagent.v1",
                "reason": "read_only_subagent_required",
                "mode": mode,
            }
        normalized_scope = sorted(
            {path.replace("\\", "/") for path in scope or [] if path}
        )
        query = f"{task} {' '.join(normalized_scope)}".strip()
        raw = self.search_code(query, limit=limit).get("results", [])
        if normalized_scope:
            scoped = [item for item in raw if item.get("path") in normalized_scope]
            if scoped:
                raw = scoped
        distilled = [
            {
                "path": item.get("path"),
                "start_line": item.get("start_line"),
                "end_line": item.get("end_line"),
                "summary": str(item.get("text") or "").strip().splitlines()[:2],
            }
            for item in raw[: max(1, min(3, len(raw)))]
        ]
        raw_tokens = sum(int(item.get("token_count") or 0) for item in raw)
        lead_tokens = sum(
            estimate_tokens(" ".join(item["summary"])) for item in distilled
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_subagent.v1",
            "mode": "read",
            "task": task,
            "scope": normalized_scope,
            "raw_candidate_count": len(raw),
            "distilled_count": len(distilled),
            "raw_context_tokens": raw_tokens,
            "lead_context_tokens": lead_tokens,
            "distilled": distilled,
            "isolation": "raw_context_not_returned_to_lead_window",
        }

    def nextgen_expand(self, symbol: str, limit: int = 10) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        rows = self.store.symbols_named(snapshot.repo_id, [symbol])
        symbols = [
            {
                "symbol_identity_id": row["symbol_identity_id"],
                "path": row["path"],
                "kind": row["kind"],
                "qualname": row["qualname"],
                "is_test": bool(row["is_test"]),
            }
            for row in rows
        ]
        code = self.search_code(symbol, limit=limit)
        signatures = extract_signatures(self.repo_root, symbol)
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_expand.v1",
            "symbol": symbol,
            "snapshot_id": snapshot.snapshot_id,
            "symbols": symbols,
            "signatures": signatures,
            "chunks": code.get("results", []),
            "provenance": [
                file_provenance(self.repo_root, path)
                for path in sorted({item["path"] for item in symbols})
            ],
            "grounded": bool(symbols or signatures),
        }

    def nextgen_neighbors(
        self, path: str, *, max_hops: int = 1, limit: int = 20
    ) -> dict[str, Any]:
        graph = self.graph_neighbors(path, max_hops=max_hops, limit=limit)
        tests = self.graph_tests_for_path(path)
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_neighbors.v1",
            "path": path.replace("\\", "/"),
            "graph": graph,
            "reasoning": graph_reasoning_report(path=path, graph=graph, tests=tests),
            "provenance": [file_provenance(self.repo_root, path)],
        }

    def nextgen_supervise(
        self,
        *,
        paths: list[str] | None = None,
        pack_id: str | None = None,
        diff: str | None = None,
        step_count: int = 1,
        risk: str = "medium",
        surprise: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        normalized = sorted({path.replace("\\", "/") for path in paths or [] if path})
        if diff and not normalized:
            normalized = paths_from_diff(diff)
        impact = self.get_impact_report(paths=normalized, pack_id=pack_id, diff=diff)
        tests = self.select_minimal_tests(paths=normalized, diff=diff)
        check = (
            self.check_diff_against_pack(pack_id, diff=diff, paths=normalized)
            if pack_id
            else {
                "ok": False,
                "status": "advisory_only",
                "reason": "pack_id_required_for_enforced_check_diff",
            }
        )
        if surprise is None:
            surprise = self._nextgen_surprise_signal(paths=normalized, diff=diff)
        decision = supervision_decision(
            paths=normalized,
            check_diff=check,
            impact=impact,
            selected_tests=tests,
            diff=diff,
            step_count=step_count,
            risk=risk,
            surprise=surprise,
        )
        dependency_gate = self._nextgen_dependency_gate(diff)
        decision["inline_gates"]["dependency_grounding"] = dependency_gate
        phase_b_gate = self._nextgen_phase_b_gate(paths=normalized, diff=diff)
        decision["inline_gates"]["phase_b_verification"] = phase_b_gate
        blast_radius = self._nextgen_blast_radius_gate(paths=normalized, diff=diff)
        decision["inline_gates"]["blast_radius"] = blast_radius
        if (
            not dependency_gate["ok"]
            and "dependency_grounding" not in decision["failed_gates"]
        ):
            decision["failed_gates"].append("dependency_grounding")
            decision["status"] = "needs_attention"
            decision["replan_required"] = True
            decision["error_quarantine"] = decision["error_quarantine"] or {
                "active": True,
                "reason": "dependency_grounding_failed",
                "failed_gates": [],
                "negative_constraint": (
                    "Do not introduce dependencies that are absent from project "
                    "metadata without explicit approval."
                ),
            }
            decision["error_quarantine"]["failed_gates"] = decision["failed_gates"]
        if not blast_radius["ok"] and "blast_radius" not in decision["failed_gates"]:
            decision["failed_gates"].append("blast_radius")
            decision["status"] = "needs_attention"
            decision["replan_required"] = True
            decision["error_quarantine"] = decision["error_quarantine"] or {
                "active": True,
                "reason": "blast_radius_requires_approval",
                "failed_gates": [],
                "negative_constraint": (
                    "Do not proceed with irreversible or critical-scope changes "
                    "without explicit approval."
                ),
            }
            decision["error_quarantine"]["failed_gates"] = decision["failed_gates"]
        if (
            not phase_b_gate["ok"]
            and "phase_b_verification" not in decision["failed_gates"]
        ):
            decision["failed_gates"].append("phase_b_verification")
            decision["status"] = "needs_attention"
            decision["replan_required"] = True
            decision["error_quarantine"] = decision["error_quarantine"] or {
                "active": True,
                "reason": "phase_b_verification_failed",
                "failed_gates": [],
                "negative_constraint": (
                    "Do not accept a patch that only passes structural gates; run "
                    "the executable Phase-B verification signal and replan from the "
                    "last good checkpoint when it fails."
                ),
            }
            decision["error_quarantine"]["failed_gates"] = decision["failed_gates"]
        snapshot = self.resolver.resolve()
        quarantine = decision["error_quarantine"]
        if decision["replan_required"] and quarantine:
            persisted = self._nextgen_persist_quarantine(
                paths=normalized, failed_gates=decision["failed_gates"]
            )
            quarantine = {
                **quarantine,
                "persisted_record_id": persisted["record_id"],
                "negative_constraint_recorded": True,
                "quarantine_marker": persisted["marker"],
            }
        return {
            "ok": bool(decision.get("ok")),
            "schema_version": "ctxlayer.nextgen_supervision.v1",
            "status": decision["status"],
            "paths": normalized,
            "inline_gates": decision["inline_gates"],
            "failed_gates": decision["failed_gates"],
            "error_quarantine": quarantine,
            "replan_required": decision["replan_required"],
            "regrounding": regrounding_capsule(
                pack_id=pack_id,
                snapshot_id=snapshot.snapshot_id,
                progress="supervision",
                last_good_checkpoint=self._nextgen_latest_checkpoint_ref(),
                failed_step=";".join(decision["failed_gates"]) or None,
            ),
        }

    def _nextgen_surprise_signal(
        self, *, paths: list[str] | None = None, diff: str | None = None
    ) -> dict[str, Any]:
        changed = sorted({*(paths or []), *paths_from_diff(diff)})
        target_dirs = sorted(
            {str(Path(path).parent).replace("\\", "/") for path in changed}
        )
        context = {
            "event_type": "nextgen_supervise",
            "target_paths": changed,
            "target_dir": target_dirs[0] if target_dirs else "",
        }
        observation = {
            "event_type": "edit",
            "target_paths": changed,
            "target_dir": target_dirs[0] if target_dirs else "",
            "changed_symbols": sorted(changed_code_symbols(diff)),
        }
        try:
            scored = self.anticipation.surprise.score(
                context=context,
                observation=observation,
            )
        except Exception as exc:  # noqa: BLE001 - supervision must stay available.
            return {
                "high_surprise": False,
                "source": "surprise_engine",
                "reason": str(exc),
                "target_paths": changed,
            }
        score = scored.get("surprise")
        try:
            numeric = float(score)
        except (TypeError, ValueError):
            numeric = 0.0
        return {
            "high_surprise": numeric >= 0.8,
            "source": "surprise_engine",
            "score": numeric if score is not None else None,
            "status": "measured" if score is not None else "not_measured",
            "reason": scored.get("reason"),
            "target_paths": changed,
            "engine": scored,
        }

    def _nextgen_dependency_gate(self, diff: str | None) -> dict[str, Any]:
        packages = imported_packages_from_diff(diff)
        reports = [
            dependency_grounding_report(self.repo_root, package) for package in packages
        ]
        findings = [report for report in reports if report.get("approval_required")]
        return {
            "ok": not findings,
            "schema_version": "ctxlayer.nextgen_dependency_gate.v1",
            "packages": reports,
            "findings": findings,
            "approval_required": bool(findings),
        }

    def _nextgen_phase_b_gate(
        self, *, paths: list[str], diff: str | None
    ) -> dict[str, Any]:
        """Run an executable inline verification signal for Phase-B supervision.

        This is intentionally lightweight and local: it converts the oracle finding
        stream into candidate invariants and executes them through the existing
        properties validator. The gate is not a replacement for the full mutation
        or differential commands; it is an inline guard that prevents supervise
        from reporting only that those commands exist.
        """
        oracle = oracle_and_reward_report(paths=paths, diff=diff)
        mutation_probe = self._nextgen_mutation_probe(paths, diff=diff)
        differential_probe = self._nextgen_differential_probe(diff, paths=paths)
        samples = [(finding,) for finding in oracle.get("findings", [])]
        if not samples:
            return {
                "ok": bool(mutation_probe["ok"] and differential_probe["ok"]),
                "schema_version": "ctxlayer.nextgen_phase_b_gate.v1",
                "executed": True,
                "fully_executed": self._nextgen_probe_executed_or_not_required(
                    mutation_probe
                )
                and self._nextgen_probe_executed_or_not_required(differential_probe),
                "surfaces": ["properties", "mutation", "differential"],
                "reason": "no_oracle_findings",
                "properties": validate_invariants(
                    {
                        "no_critical_oracle_findings": (
                            lambda finding: finding.get("severity") != "critical"
                        )
                    },
                    sample_args=[],
                ),
                "mutation": mutation_probe,
                "differential": differential_probe,
            }
        properties = validate_invariants(
            {
                "no_critical_oracle_findings": (
                    lambda finding: finding.get("severity") != "critical"
                )
            },
            sample_args=samples,
        )
        critical = [
            finding
            for finding in oracle.get("findings", [])
            if finding.get("severity") == "critical"
        ]
        return {
            "ok": bool(
                not critical and mutation_probe["ok"] and differential_probe["ok"]
            ),
            "schema_version": "ctxlayer.nextgen_phase_b_gate.v1",
            "executed": True,
            "fully_executed": self._nextgen_probe_executed_or_not_required(
                mutation_probe
            )
            and self._nextgen_probe_executed_or_not_required(differential_probe),
            "surfaces": ["properties", "mutation", "differential"],
            "reason": "critical_oracle_findings" if critical else "properties_held",
            "properties": properties,
            "mutation": mutation_probe,
            "differential": differential_probe,
            "findings": critical,
        }

    def _nextgen_probe_executed_or_not_required(self, probe: dict[str, Any]) -> bool:
        return bool(probe.get("executed")) or not bool(probe.get("required", True))

    def _nextgen_mutation_probe(
        self, paths: list[str], *, diff: str | None = None
    ) -> dict[str, Any]:
        changed = sorted({*paths, *paths_from_diff(diff)})
        targets = [
            rel
            for rel in changed
            if rel.endswith(".py")
            and not (rel.startswith("tests/") or "/tests/" in rel or "/test" in rel)
            and (self.repo_root / rel).is_file()
        ][:2]
        if not targets:
            return {
                "ok": True,
                "schema_version": "ctxlayer.nextgen_mutation_probe.v1",
                "required": False,
                "executed": False,
                "reason": "no_python_source_targets",
                "reports": [],
            }
        test_command = self._nextgen_test_command_for_paths(changed, diff=diff)
        if not test_command:
            return {
                "ok": False,
                "schema_version": "ctxlayer.nextgen_mutation_probe.v1",
                "required": True,
                "executed": False,
                "reason": "no_test_command_for_mutation",
                "targets": targets,
                "reports": [],
            }
        reports = [
            MutationTester(self.repo_root).run(
                target_file=rel,
                test_command=test_command,
                max_mutants=3,
                timeout=60,
            )
            for rel in targets
        ]
        survivors = [
            survivor
            for report in reports
            for survivor in (report.get("survived") or [])
        ]
        failed_reports = [report for report in reports if not report.get("ok", False)]
        return {
            "ok": not failed_reports and not survivors,
            "schema_version": "ctxlayer.nextgen_mutation_probe.v1",
            "required": True,
            "executed": True,
            "command": test_command,
            "reason": "surviving_mutants" if survivors else "executed",
            "survivors": survivors,
            "reports": reports,
        }

    def _nextgen_differential_probe(
        self, diff: str | None, *, paths: list[str] | None = None
    ) -> dict[str, Any]:
        changed = sorted({*(paths or []), *paths_from_diff(diff)})
        symbols = sorted(changed_code_symbols(diff))
        if not symbols:
            return {
                "ok": True,
                "schema_version": "ctxlayer.nextgen_differential_probe.v1",
                "required": False,
                "executed": False,
                "reason": "no_changed_functions",
                "checks": [],
            }
        targets = [
            rel
            for rel in changed
            if rel.endswith(".py")
            and not (rel.startswith("tests/") or "/tests/" in rel or "/test" in rel)
            and (self.repo_root / rel).is_file()
        ][:2]
        checks: list[dict[str, Any]] = []
        for rel in targets:
            old_source = self._nextgen_git_show_head(rel)
            new_source = (self.repo_root / rel).read_text(
                encoding="utf-8", errors="ignore"
            )
            for symbol in symbols[:3]:
                check = differential_check(
                    old_source=old_source or "",
                    new_source=new_source,
                    func_name=symbol,
                    sample_args=[(), ("Ada",), (1,), (1, 2)],
                )
                checks.append({"path": rel, "symbol": symbol, **check})
        executed_checks = [
            check for check in checks if check.get("reason") != "function_not_evaluable"
        ]
        if not checks or not executed_checks:
            return {
                "ok": True,
                "schema_version": "ctxlayer.nextgen_differential_probe.v1",
                "required": False,
                "executed": False,
                "reason": "no_evaluable_changed_functions",
                "checks": checks,
            }
        return {
            "ok": all(check.get("ok", True) for check in checks),
            "schema_version": "ctxlayer.nextgen_differential_probe.v1",
            "required": True,
            "executed": True,
            "reason": "executed",
            "checks": checks,
        }

    def _nextgen_git_show_head(self, rel_path: str) -> str | None:
        try:
            result = subprocess.run(
                ["git", "show", f"HEAD:{rel_path}"],
                cwd=self.repo_root,
                text=True,
                capture_output=True,
                timeout=10,
            )
        except (subprocess.SubprocessError, OSError):
            return None
        return result.stdout if result.returncode == 0 else None

    def _nextgen_test_command_for_paths(
        self, paths: list[str], *, diff: str | None = None
    ) -> str | None:
        selected = self.select_minimal_tests(paths=paths, diff=diff)
        test_paths: set[str] = set()
        for key in ("tests", "selected_tests", "candidates"):
            for item in selected.get(key) or []:
                if isinstance(item, str):
                    test_paths.add(item.replace("\\", "/"))
                elif isinstance(item, dict) and item.get("path"):
                    test_paths.add(str(item["path"]).replace("\\", "/"))
        test_paths.update(
            path
            for path in paths
            if path.startswith("tests/") or "/tests/" in path or "/test" in path
        )
        existing = sorted(
            path for path in test_paths if (self.repo_root / path).is_file()
        )
        if not existing:
            return None
        return "python -m pytest " + " ".join(existing) + " -q"

    def _nextgen_blast_radius_gate(
        self, *, paths: list[str], diff: str | None
    ) -> dict[str, Any]:
        critical_patterns = (
            "migrations/",
            "supabase/migrations/",
            "auth/",
            "payments/",
            "billing/",
            "prod/",
        )
        changed = sorted({*paths, *paths_from_diff(diff)})
        critical = [
            path
            for path in changed
            if path.startswith(critical_patterns)
            or any(part in path.split("/") for part in {"auth", "payments", "billing"})
        ]
        approved = "CTX_APPROVED_CRITICAL_CHANGE" in (diff or "")
        return {
            "ok": not critical or approved,
            "schema_version": "ctxlayer.nextgen_blast_radius_gate.v1",
            "critical_paths": critical,
            "approval_required": bool(critical and not approved),
            "approved": approved,
        }

    def _nextgen_persist_quarantine(
        self, *, paths: list[str], failed_gates: list[str]
    ) -> dict[str, Any]:
        """Persist a failed supervision attempt as a durable negative constraint.

        Idempotent: the same (paths, gates) failure maps to one stable marker, so
        re-running the same failing supervision does not duplicate the lesson.
        The lesson is recalled by ``nextgen_retrieve`` for the next attempt.
        """
        marker = stable_id("nextgen_quarantine", *sorted(paths), *sorted(failed_gates))[
            :12
        ]
        existing = self.memory_records(types=["failure_lesson"])
        for record in existing.get("records", []):
            if marker in canonical_json(record):
                return {
                    "record_id": record.get("record_id"),
                    "created": False,
                    "marker": marker,
                }
        assertion = (
            f"Quarantined failed attempt [{marker}]: gate(s) "
            f"{', '.join(sorted(failed_gates)) or 'unknown'} failed for "
            f"{', '.join(sorted(paths)) or 'unspecified paths'}. Do not re-apply the "
            "failed edits; restart from the last good checkpoint and apply only the "
            "distilled lesson."
        )
        evidence = [
            {
                "evidence_kind": "path",
                "path": path.replace("\\", "/"),
                "evidence_hash": stable_id("nextgen_quarantine_evidence", marker, path),
            }
            for path in sorted(paths)
        ]
        proposed = self.memory_create_typed(
            {
                "type": "failure_lesson",
                "assertion": assertion,
                "source_kind": "nextgen_quarantine",
                "confidence": 0.8,
                "status": "candidate",
                "evidence": evidence,
                "metadata": {
                    "symptom": (
                        "supervision gates failed: "
                        f"{', '.join(sorted(failed_gates)) or 'unknown'}"
                    ),
                    "root_cause": "captured_from_nextgen_supervision_quarantine",
                    "resolution": "serve_as_negative_constraint_in_future_context",
                    "polarity": "failure",
                    "quarantine_marker": marker,
                },
            }
        )
        return {
            "record_id": (proposed.get("record") or {}).get("record_id")
            or proposed.get("record_id"),
            "created": True,
            "marker": marker,
        }

    def nextgen_reground(
        self,
        served: list[dict[str, Any]] | None = None,
        *,
        pack_id: str | None = None,
        query: str | None = None,
        progress: str | None = None,
        failed_step: str | None = None,
    ) -> dict[str, Any]:
        """P1 re-grounding loop: detect stale served items and re-hydrate them.

        Unlike ``stale_state_report`` (detection only), this re-serves fresh
        content (fresh provenance + fresh file slice) for exactly the items whose
        on-disk state moved since they were served, drops items that vanished, and
        carries forward active negative constraints and a context budget.
        """
        served = served or []
        stale = stale_state_report(self.repo_root, served)
        refreshed: list[dict[str, Any]] = []
        dropped: list[dict[str, Any]] = []
        for item in stale["stale"]:
            path = str(item.get("path") or "")
            if not path:
                continue
            if item.get("reason") == "served_file_missing":
                dropped.append({"path": path, "reason": "served_file_missing"})
                continue
            provenance = file_provenance(self.repo_root, path)
            target = (self.repo_root / path).resolve()
            content = ""
            try:
                content = target.read_text(encoding="utf-8", errors="ignore")[:4000]
            except OSError:
                content = ""
            refreshed.append(
                {
                    "path": path,
                    "provenance": provenance,
                    "content": content,
                    "reason": item.get("reason"),
                }
            )
        snapshot = self.resolver.resolve()
        constraints = (
            self.memory_search(query, types=["failure_lesson"]).get("results", [])[:5]
            if query
            else []
        )
        budget = context_budget_report(
            [{"path": entry["path"], "token_count": 0} for entry in refreshed]
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_reground.v1",
            "snapshot_id": snapshot.snapshot_id,
            "stale_state": stale,
            "refreshed": refreshed,
            "dropped": dropped,
            "negative_constraints": constraints,
            "budget": budget,
            "capsule": regrounding_capsule(
                pack_id=pack_id,
                snapshot_id=snapshot.snapshot_id,
                progress=progress or "reground",
                stale=stale,
                failed_step=failed_step,
            ),
        }

    def nextgen_compact(
        self,
        served: list[dict[str, Any]] | None = None,
        *,
        pack_id: str | None = None,
        progress: str = "",
        token_budget: int = 1200,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        served = served or []
        anchors = regrounding_capsule(
            pack_id=pack_id,
            snapshot_id=snapshot.snapshot_id,
            progress=progress,
            last_good_checkpoint=self._nextgen_latest_checkpoint_ref(),
        )
        kept = []
        used = 0
        for item in served:
            tokens = int(item.get("token_count") or 0)
            if used + tokens > token_budget:
                continue
            kept.append(
                {
                    "path": item.get("path"),
                    "sha256": item.get("sha256"),
                    "token_count": tokens,
                }
            )
            used += tokens
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_compact.v1",
            "token_budget": token_budget,
            "estimated_tokens": used,
            "kept": kept,
            "dropped_count": max(0, len(served) - len(kept)),
            "capsule": anchors,
        }

    def nextgen_skills(
        self, task: str, *, expand: bool = False, limit: int = 5
    ) -> dict[str, Any]:
        try:
            result = self.skill_search(task, limit=limit, include_untrusted=False)
            raw_items = result.get("results", [])
        except Exception:  # noqa: BLE001 - fallback to memory-backed skills.
            raw_items = []
        if not raw_items:
            raw_items = self.memory_search(task, types=["skill_reference"]).get(
                "results", []
            )
        skills = []
        for item in raw_items[:limit]:
            text = str(
                item.get("body") or item.get("content") or item.get("text") or ""
            )
            skills.append(
                {
                    "skill_id": item.get("skill_id")
                    or item.get("id")
                    or item.get("record_id"),
                    "title": item.get("title")
                    or item.get("name")
                    or item.get("assertion"),
                    "frontmatter": {
                        "source": item.get("source") or item.get("path"),
                        "trust": item.get("trust"),
                    },
                    "body": text if expand else None,
                    "disclosure_level": "body" if expand else "frontmatter",
                }
            )
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_skills.v1",
            "task": task,
            "skills": skills,
        }

    def nextgen_checkpoint(
        self, step_id: str, *, paths: list[str] | None = None
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        normalized = sorted({path.replace("\\", "/") for path in paths or [] if path})
        status = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=self.repo_root,
            text=True,
            capture_output=True,
            check=False,
        )
        commit = status.stdout.strip() if status.returncode == 0 else ""
        file_snapshots = []
        for rel in normalized:
            target = (self.repo_root / rel).resolve()
            try:
                target.relative_to(self.repo_root)
            except ValueError:
                continue
            exists = target.is_file()
            content = (
                target.read_text(encoding="utf-8", errors="ignore") if exists else ""
            )
            file_snapshots.append(
                {
                    "path": rel,
                    "exists": exists,
                    "sha256": (
                        hashlib.sha256(content.encode("utf-8")).hexdigest()
                        if exists
                        else None
                    ),
                    "content": content,
                }
            )
        checkpoint_ref = stable_id(
            "nextgen_checkpoint", snapshot.snapshot_id, step_id, commit, *normalized
        )[:16]
        self.memory_create_typed(
            {
                "type": "runtime_signal",
                "assertion": f"nextgen checkpoint {checkpoint_ref} for {step_id}",
                "source_kind": "nextgen_checkpoint",
                "confidence": 0.9,
                "status": "candidate",
                "evidence": [
                    {
                        "evidence_kind": "path",
                        "path": path,
                        "evidence_hash": stable_id(
                            "nextgen_checkpoint_path", checkpoint_ref, path
                        ),
                    }
                    for path in normalized
                ],
                "metadata": {
                    "checkpoint_ref": checkpoint_ref,
                    "step_id": step_id,
                    "snapshot_id": snapshot.snapshot_id,
                    "git_commit": commit,
                    "paths": normalized,
                    "file_snapshots": file_snapshots,
                },
            }
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_checkpoint.v1",
            "checkpoint_ref": checkpoint_ref,
            "step_id": step_id,
            "snapshot_id": snapshot.snapshot_id,
            "git_commit": commit,
            "paths": normalized,
            "file_snapshots": [
                {key: value for key, value in item.items() if key != "content"}
                for item in file_snapshots
            ],
        }

    def _nextgen_latest_checkpoint_ref(self) -> str | None:
        records = self.memory_search(
            "nextgen checkpoint", types=["runtime_signal"]
        ).get("results", [])
        for record in reversed(records):
            metadata = record.get("metadata") or record.get("metadata_json") or {}
            if isinstance(metadata, str):
                try:
                    metadata = json.loads(metadata)
                except json.JSONDecodeError:
                    metadata = {}
            if metadata.get("checkpoint_ref"):
                return str(metadata["checkpoint_ref"])
        return None

    def nextgen_restore(self, checkpoint_ref: str) -> dict[str, Any]:
        checkpoint_ref = checkpoint_ref.strip()
        if not checkpoint_ref:
            return {"ok": False, "reason": "checkpoint_ref_required"}
        records = self.memory_search(
            f"nextgen checkpoint {checkpoint_ref}", types=["runtime_signal"]
        ).get("results", [])
        for record in records:
            metadata = record.get("metadata") or record.get("metadata_json") or {}
            if isinstance(metadata, str):
                try:
                    metadata = json.loads(metadata)
                except json.JSONDecodeError:
                    metadata = {}
            if metadata.get("checkpoint_ref") != checkpoint_ref:
                continue
            restored = []
            for item in metadata.get("file_snapshots") or []:
                rel = str(item.get("path") or "").replace("\\", "/")
                if not rel:
                    continue
                target = (self.repo_root / rel).resolve()
                try:
                    target.relative_to(self.repo_root)
                except ValueError:
                    continue
                if item.get("exists"):
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_text(str(item.get("content") or ""), encoding="utf-8")
                    restored.append({"path": rel, "action": "restored"})
                elif target.exists() and target.is_file():
                    target.unlink()
                    restored.append({"path": rel, "action": "removed"})
            return {
                "ok": True,
                "schema_version": "ctxlayer.nextgen_restore.v1",
                "checkpoint_ref": checkpoint_ref,
                "restored": restored,
                "restored_count": len(restored),
            }
        return {
            "ok": False,
            "schema_version": "ctxlayer.nextgen_restore.v1",
            "checkpoint_ref": checkpoint_ref,
            "reason": "checkpoint_not_found",
        }

    def nextgen_ground(
        self,
        *,
        symbol: str | None = None,
        package: str | None = None,
        path: str | None = None,
    ) -> dict[str, Any]:
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_grounding.v1",
            "symbol": self.nextgen_expand(symbol) if symbol else None,
            "dependency": (
                dependency_grounding_report(self.repo_root, package)
                if package
                else None
            ),
            "file": file_provenance(self.repo_root, path) if path else None,
        }

    def nextgen_learn_failure(
        self, lesson: str, *, paths: list[str] | None = None
    ) -> dict[str, Any]:
        lesson = lesson.strip()
        if not lesson:
            return {"ok": False, "reason": "lesson_required"}
        evidence = [
            {
                "evidence_kind": "path",
                "path": path.replace("\\", "/"),
                "evidence_hash": stable_id("nextgen_failure_memory", path),
            }
            for path in paths or []
            if path
        ]
        proposed = self.memory_create_typed(
            {
                "type": "failure_lesson",
                "assertion": lesson,
                "source_kind": "nextgen_failure_memory",
                "confidence": 0.8,
                "status": "candidate",
                "evidence": evidence,
                "metadata": {
                    "symptom": lesson,
                    "root_cause": "captured_from_nextgen_failure_memory",
                    "resolution": "serve_as_negative_constraint_in_future_context",
                    "polarity": "failure",
                },
            }
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_failure_memory.v1",
            "status": "candidate",
            "memory": proposed,
        }

    def nextgen_rerank_effect(
        self, task: str, *, penalized_path: str | None = None, limit: int = 10
    ) -> dict[str, Any]:
        base = self.search_code(task, limit=limit).get("results", [])
        focus_path = penalized_path.replace("\\", "/") if penalized_path else None
        evidence = self._nextgen_rerank_evidence(
            task=task, candidates=[item["path"] for item in base]
        )
        before = [item["path"] for item in base]
        scored = []
        for index, item in enumerate(base):
            score = float(limit - index)
            score += evidence["path_scores"].get(item["path"], 0.0)
            scored.append((score, item["path"]))
        after = [
            path for _, path in sorted(scored, key=lambda pair: pair[0], reverse=True)
        ]
        if not focus_path:
            ranked_paths = [
                path for path in before if evidence["path_scores"].get(path, 0.0) < 0
            ]
            focus_path = (
                ranked_paths[0] if ranked_paths else (before[0] if before else None)
            )
        before_rank = before.index(focus_path) if focus_path in before else None
        after_rank = after.index(focus_path) if focus_path in after else None
        delta = (
            after_rank - before_rank
            if before_rank is not None and after_rank is not None
            else 0
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_rerank_effect.v1",
            "task": task,
            "path": focus_path,
            "before": before,
            "after": after,
            "before_rank": before_rank,
            "after_rank": after_rank,
            "delta": delta,
            "constraints_applied": evidence["constraints_applied"],
            "measurement_status": (
                "measured" if evidence["constraints_applied"] else "not_measured"
            ),
            "evidence": evidence["evidence"],
        }

    def _nextgen_rerank_evidence(
        self, *, task: str, candidates: list[str]
    ) -> dict[str, Any]:
        candidate_set = {path.replace("\\", "/") for path in candidates}
        scores: dict[str, float] = {path: 0.0 for path in candidate_set}
        evidence: list[dict[str, Any]] = []
        try:
            rows = self.store.conn.execute(
                """
                SELECT result, files_changed_json, created_at
                FROM outcomes
                ORDER BY created_at ASC
                """
            ).fetchall()
        except Exception:  # noqa: BLE001 - rerank must stay advisory.
            rows = []
        for row in rows:
            try:
                paths = json.loads(row["files_changed_json"] or "[]")
            except (TypeError, json.JSONDecodeError):
                paths = []
            result = str(row["result"] or "").lower()
            for raw_path in paths:
                path = str(raw_path).replace("\\", "/")
                if path not in candidate_set:
                    continue
                delta = -50.0 if result == "fail" else 5.0 if result == "pass" else 0.0
                if delta:
                    scores[path] += delta
                    evidence.append(
                        {
                            "kind": "outcome",
                            "path": path,
                            "result": result,
                            "score_delta": delta,
                            "created_at": row["created_at"],
                        }
                    )
        for record in self.memory_records(types=["failure_lesson"]).get("records", []):
            record_json = canonical_json(record).lower()
            assertion = str(record.get("assertion", "")).lower()
            evidence_paths = {
                str(item["path"]).replace("\\", "/").lower()
                for item in self.store.memory_evidence(str(record.get("record_id")))
                if item["path"]
            }
            if task.lower() not in record_json and not any(
                path.lower() in record_json or path.lower() in evidence_paths
                for path in candidate_set
            ):
                continue
            for path in candidate_set:
                lowered_path = path.lower()
                if (
                    lowered_path in record_json
                    or lowered_path in assertion
                    or lowered_path in evidence_paths
                ):
                    scores[path] -= 25.0
                    evidence.append(
                        {
                            "kind": "failure_lesson",
                            "path": path,
                            "record_id": record.get("record_id"),
                            "score_delta": -25.0,
                        }
                    )
        return {
            "path_scores": scores,
            "constraints_applied": len(evidence),
            "evidence": evidence,
        }

    def nextgen_consolidate(
        self, module: str, *, min_episodes: int = 2
    ) -> dict[str, Any]:
        module = module.replace("\\", "/")
        episodes = [
            item
            for item in self.memory_records(types=["episode"]).get("records", [])
            if module in canonical_json(item)
        ]
        evidence_count = 0
        for episode in episodes:
            evidence_count += len(
                [
                    item
                    for item in self.store.memory_evidence(str(episode["record_id"]))
                    if item["path"] == module
                ]
            )
        episodes_in = max(len(episodes), evidence_count)
        if episodes_in < min_episodes:
            return {
                "ok": True,
                "schema_version": "ctxlayer.nextgen_consolidate.v1",
                "status": "skipped",
                "reason": "not_enough_episodes",
                "episodes_in": episodes_in,
            }
        assertion = f"Semantic pattern for {module}: " + "; ".join(
            str(item.get("assertion", ""))[:120] for item in episodes[:5]
        )
        evidence = [
            {
                "evidence_kind": "memory",
                "path": module,
                "evidence_hash": stable_id(
                    "nextgen_consolidation_episode", str(item.get("record_id"))
                ),
            }
            for item in episodes
        ]
        created = self.memory_create_typed(
            {
                "type": "pattern",
                "assertion": assertion,
                "source_kind": "nextgen_consolidation",
                "confidence": 0.76,
                "status": "candidate",
                "evidence": evidence,
                "metadata": {
                    "module": module,
                    "episodes_in": episodes_in,
                    "source_episode_ids": [
                        item.get("record_id")
                        for item in episodes
                        if item.get("record_id")
                    ],
                },
            }
        )
        pattern_record_id = None
        if isinstance(created, dict):
            pattern_record_id = ((created.get("record") or {}) or {}).get(
                "record_id"
            ) or created.get("record_id")
        consolidated_ids = []
        for item in episodes:
            record_id = str(item.get("record_id") or "")
            if not record_id:
                continue
            if pattern_record_id:
                self.store.memory_edge_create(
                    workspace_id=self._memory_workspace_id,
                    repo_id=self._memory_repo_id,
                    src_record_id=str(pattern_record_id),
                    dst_record_id=record_id,
                    kind="derived_from",
                    confidence=0.9,
                    evidence={
                        "module": module,
                        "reason": "nextgen_consolidate",
                    },
                    created_by="nextgen_consolidate",
                )
            self.memory_update(
                record_id,
                {"status": "consolidated", "trust": "active"},
                reason="nextgen episode consolidated into semantic pattern",
                actor="nextgen",
            )
            consolidated_ids.append(record_id)
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_consolidate.v1",
            "status": "candidate",
            "episodes_in": episodes_in,
            "episodes_consolidated": consolidated_ids,
            "semantic_memory": created,
        }

    def nextgen_skill_curate(self, skill_id: str | None = None) -> dict[str, Any]:
        skills = self.memory_records(types=["skill_reference"]).get("records", [])
        failures = self.memory_records(types=["failure_lesson"]).get("records", [])
        transitions = []
        for skill in skills:
            metadata = skill.get("metadata") or skill.get("metadata_json") or {}
            if isinstance(metadata, str):
                try:
                    metadata = json.loads(metadata)
                except json.JSONDecodeError:
                    metadata = {}
            current_skill_id = str(metadata.get("skill_id") or skill.get("record_id"))
            if skill_id and current_skill_id != skill_id:
                continue
            contradicted = any(
                current_skill_id in str(failure.get("assertion", ""))
                for failure in failures
            )
            if contradicted:
                self.memory_update(
                    str(skill["record_id"]),
                    {"status": "expired", "trust": "stale"},
                    reason="nextgen skill contradicted by failure lesson",
                    actor="nextgen",
                )
                transitions.append(
                    {
                        "skill_id": current_skill_id,
                        "record_id": skill["record_id"],
                        "from": skill.get("status"),
                        "to": "expired",
                        "reason": "contradicted_by_failure_lesson",
                    }
                )
            elif skill.get("status") == "candidate":
                self.memory_update(
                    str(skill["record_id"]),
                    {"status": "active", "trust": "active"},
                    reason="nextgen skill corroborated by absence of contradiction",
                    actor="nextgen",
                )
                transitions.append(
                    {
                        "skill_id": current_skill_id,
                        "record_id": skill["record_id"],
                        "from": "candidate",
                        "to": "active",
                        "reason": "corroborated",
                    }
                )
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_skill_curate.v1",
            "transitions": transitions,
        }

    def nextgen_rationale(
        self,
        decision: str,
        rationale: str,
        *,
        paths: list[str] | None = None,
    ) -> dict[str, Any]:
        if not decision.strip() or not rationale.strip():
            return {"ok": False, "reason": "decision_and_rationale_required"}
        evidence = [
            {
                "evidence_kind": "path",
                "path": path.replace("\\", "/"),
                "evidence_hash": stable_id("nextgen_rationale_memory", path),
            }
            for path in paths or []
            if path
        ]
        proposed = self.memory_create_typed(
            {
                "type": "decision",
                "assertion": f"{decision.strip()}: {rationale.strip()}",
                "source_kind": "nextgen_rationale_memory",
                "confidence": 0.75,
                "status": "candidate",
                "evidence": evidence,
                "metadata": {
                    "rationale": rationale.strip(),
                    "alternatives": ["not_recorded"],
                },
            }
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_rationale.v1",
            "status": "candidate",
            "memory": proposed,
        }

    def nextgen_security_scan(
        self, text: str, *, source: str = "context"
    ) -> dict[str, Any]:
        return scan_untrusted_text(text, source=source)

    def nextgen_coordinate(
        self, paths: list[str] | None = None, *, pack_id: str | None = None
    ) -> dict[str, Any]:
        normalized = sorted({path.replace("\\", "/") for path in paths or [] if path})
        conflicts = self.session_conflicts(status="open")
        neighbors = [
            self.nextgen_neighbors(path, max_hops=1, limit=10) for path in normalized
        ]
        snapshot = self.resolver.resolve()
        staleness = self._nextgen_snapshot_staleness(pack_id, snapshot.snapshot_id)
        semantic = semantic_conflict_report(normalized, neighbors)
        live = self._nextgen_live_conflicts(normalized, conflicts)
        return {
            "ok": bool(semantic.get("ok", True) and live.get("ok", True)),
            "schema_version": "ctxlayer.nextgen_coordination.v1",
            "snapshot_id": snapshot.snapshot_id,
            "paths": normalized,
            "open_conflicts": conflicts,
            "live_conflicts": live,
            "semantic_neighbors": neighbors,
            "semantic_conflicts": semantic,
            "snapshot_staleness": staleness,
        }

    def _nextgen_live_conflicts(
        self, paths: list[str], conflicts: dict[str, Any]
    ) -> dict[str, Any]:
        wanted = set(paths)
        live = []
        for conflict in conflicts.get("conflicts", []):
            conflict_paths = {
                str(path).replace("\\", "/")
                for key in ("paths", "impact_paths", "overlap_paths")
                for path in (conflict.get(key) or [])
            }
            if not conflict_paths:
                raw = canonical_json(conflict)
                conflict_paths = {path for path in wanted if path in raw}
            if not wanted or wanted & conflict_paths:
                live.append(conflict)
        return {
            "ok": not live,
            "schema_version": "ctxlayer.nextgen_live_conflicts.v1",
            "conflicts": live,
            "conflict_count": len(live),
        }

    def _nextgen_snapshot_staleness(
        self, pack_id: str | None, current_snapshot_id: str
    ) -> dict[str, Any]:
        if not pack_id:
            return {
                "ok": True,
                "state": "not_bound",
                "reason": "pack_id_not_supplied",
                "current_snapshot_id": current_snapshot_id,
                "bound_snapshot_id": None,
            }
        try:
            row = self.store.get_pack(pack_id)
        except Exception:  # noqa: BLE001
            row = None
        if not row:
            return {
                "ok": False,
                "state": "missing_pack",
                "reason": "pack_not_found",
                "current_snapshot_id": current_snapshot_id,
                "bound_snapshot_id": None,
            }
        bound = row["bound_snapshot_id"] or row["snapshot_id"]
        return {
            "ok": bound == current_snapshot_id,
            "state": "fresh" if bound == current_snapshot_id else "stale",
            "current_snapshot_id": current_snapshot_id,
            "bound_snapshot_id": bound,
        }

    def nextgen_scorecard(
        self,
        served: list[dict[str, Any]] | None = None,
        *,
        baseline_tokens: int | None = None,
        changed_paths: list[str] | None = None,
    ) -> dict[str, Any]:
        status = self.nextgen_status()
        workflow = self.workflow_lint()
        verification_surfaces = [
            "verify mutation",
            "verify differential",
            "verify properties",
            "verify localize",
        ]
        served_items = served or []
        baseline = int(baseline_tokens or 0)
        economics = economics_report(baseline, served_items, changed_paths or [])
        cost_measured = bool(served_items and baseline > 0)
        outcome_metrics = self._nextgen_outcome_metrics()
        wave_status = self._nextgen_wave_status(outcome_metrics, cost_measured)
        return {
            "ok": bool(status["coverage"]["complete"]) and bool(workflow.get("ok")),
            "schema_version": "ctxlayer.nextgen_scorecard.v1",
            "coverage": status["coverage"],
            "workflow_lint": workflow,
            "metrics": {
                "verification_surface_count": len(verification_surfaces),
                "unmet_capability_count": len(
                    status["coverage"].get("unmet_capabilities", [])
                ),
                "workflow_ok": bool(workflow.get("ok")),
                "ab_success_delta": outcome_metrics["ab_success_delta"],
                "corrupt_success_count": outcome_metrics["corrupt_success_count"],
                "estimated_cache_savings_ratio": (
                    economics["estimated_cache_savings_ratio"]
                    if cost_measured
                    else None
                ),
            },
            "cost_accounting": {
                "measured": cost_measured,
                "reason": (
                    None if cost_measured else "served_items_and_baseline_required"
                ),
                "tracked_inputs": ["estimated_tokens", "stable_prefix_items"],
                "economics": economics,
            },
            "measurement_status": {
                "ab_success_delta": outcome_metrics["ab_success_delta_status"],
                "corrupt_success_count": outcome_metrics[
                    "corrupt_success_count_status"
                ],
                "cost_accounting": "measured" if cost_measured else "not_measured",
            },
            "recommended_measurements": [
                "eval benchmark-corpus",
                "eval agent --gate",
                *verification_surfaces,
            ],
            "public_status": {
                "schema_version": "ctxlayer.nextgen_public_status.v1",
                "waves": wave_status,
                "complete": all(value == "complete" for value in wave_status.values()),
            },
        }

    def _nextgen_outcome_metrics(self) -> dict[str, Any]:
        efficacy = self._nextgen_efficacy_metrics()
        if efficacy["measured"]:
            corrupt_measured = bool(efficacy.get("corrupt_success_measured"))
            return {
                "ab_success_delta": efficacy["ab_success_delta"],
                "ab_success_delta_status": "measured",
                "corrupt_success_count": efficacy["corrupt_success_count"],
                "corrupt_success_count_status": (
                    "measured" if corrupt_measured else "not_measured"
                ),
            }
        try:
            rows = self.store.conn.execute(
                "SELECT result FROM outcomes ORDER BY created_at DESC LIMIT 50"
            ).fetchall()
        except Exception:  # noqa: BLE001
            rows = []
        if not rows:
            return {
                "ab_success_delta": None,
                "ab_success_delta_status": "not_measured",
                "corrupt_success_count": None,
                "corrupt_success_count_status": "not_measured",
            }
        results = [str(row["result"]).lower() for row in rows]
        midpoint = max(1, len(results) // 2)
        recent = results[:midpoint]
        older = results[midpoint:]
        recent_rate = recent.count("pass") / len(recent) if recent else 0.0
        older_rate = older.count("pass") / len(older) if older else recent_rate
        return {
            "ab_success_delta": round(recent_rate - older_rate, 6),
            "ab_success_delta_status": "outcome_history_proxy",
            "corrupt_success_count": None,
            "corrupt_success_count_status": "not_measured",
        }

    def nextgen_record_efficacy_run(
        self,
        *,
        arm: str,
        success: bool,
        out_of_scope_edit: bool = False,
        hallucination_incident: bool = False,
        corrupt_success: bool = False,
    ) -> dict[str, Any]:
        arm = arm.strip().lower()
        if arm not in {"baseline", "ctxlayer"}:
            return {"ok": False, "reason": "arm_must_be_baseline_or_ctxlayer"}
        created = self.memory_create_typed(
            {
                "type": "runtime_signal",
                "assertion": f"nextgen efficacy self-report {arm} success={success}",
                "source_kind": "nextgen_efficacy_run",
                "confidence": 0.9,
                "status": "candidate",
                "evidence": [],
                "metadata": {
                    "measurement_source": "self_reported",
                    "arm": arm,
                    "success": bool(success),
                    "out_of_scope_edit": bool(out_of_scope_edit),
                    "hallucination_incident": bool(hallucination_incident),
                    "corrupt_success": bool(corrupt_success),
                },
            }
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_efficacy_run.v1",
            "measurement_status": "self_reported_not_measured",
            "reason": "use eval_run_efficacy for measured A/B scorecard metrics",
            "record": created,
        }

    def _nextgen_efficacy_metrics(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        rows = self.store.efficacy_scorecards(repo_id=snapshot.repo_id, limit=1)
        if rows:
            report = json.loads(rows[0]["report_json"])
            delta = report.get("delta") or {}
            benchmark = report.get("benchmark") or {}
            corrupt_success = report.get("corrupt_success_count")
            if corrupt_success is None:
                corrupt_success = benchmark.get("corrupt_success_count")
            return {
                "measured": True,
                "measurement_source": "eval_harness",
                "scorecard_id": rows[0]["scorecard_id"],
                "eval_run_id": rows[0]["eval_run_id"],
                "ab_success_delta": round(
                    float(delta.get("success_rate_delta", 0.0) or 0.0), 6
                ),
                "out_of_scope_edit_delta": round(
                    float(delta.get("out_of_scope_edit_rate_delta", 0.0) or 0.0),
                    6,
                ),
                "hallucination_incident_delta": round(
                    float(delta.get("hallucination_incident_delta", 0.0) or 0.0),
                    6,
                ),
                "corrupt_success_count": corrupt_success,
                "corrupt_success_measured": corrupt_success is not None,
            }
        records = self.memory_records(types=["runtime_signal"]).get("records", [])
        self_reported_runs = 0
        for record in records:
            if record.get("source_kind") != "nextgen_efficacy_run":
                continue
            metadata = record.get("metadata") or record.get("metadata_json") or {}
            if isinstance(metadata, str):
                try:
                    metadata = json.loads(metadata)
                except json.JSONDecodeError:
                    metadata = {}
            if metadata.get("arm") in {"baseline", "ctxlayer"}:
                self_reported_runs += 1
        return {
            "measured": False,
            "measurement_source": "none",
            "self_reported_runs": self_reported_runs,
        }

    def _nextgen_wave_status(
        self, outcome_metrics: dict[str, Any], cost_measured: bool
    ) -> dict[str, str]:
        measured = (
            outcome_metrics.get("ab_success_delta_status") == "measured"
            and outcome_metrics.get("corrupt_success_count_status") == "measured"
        )
        return {
            "wave1": "partial",
            "wave2": "partial",
            "wave3": "partial",
            "wave4": "complete" if measured and cost_measured else "partial",
        }

    def nextgen_drift(
        self, *, specs: list[str] | None = None, paths: list[str] | None = None
    ) -> dict[str, Any]:
        normalized_paths = [path.replace("\\", "/") for path in paths or []]
        linked_specs = specs or self._nextgen_linked_specs_for(normalized_paths)
        reference = self._nextgen_reference_drift(linked_specs, normalized_paths)
        if reference["findings"]:
            return reference
        return spec_code_drift_report(
            self.repo_root,
            [path.replace("\\", "/") for path in linked_specs],
            normalized_paths,
        )

    def nextgen_link(
        self, spec: str, *, paths: list[str] | None = None
    ) -> dict[str, Any]:
        normalized = sorted({path.replace("\\", "/") for path in paths or [] if path})
        spec_hash = self._nextgen_file_hash(spec)
        code_hashes = {path: self._nextgen_file_hash(path) for path in normalized}
        created = self.memory_create_typed(
            {
                "type": "runtime_signal",
                "assertion": f"nextgen spec link {spec} -> {', '.join(normalized)}",
                "source_kind": "nextgen_spec_code_link",
                "confidence": 0.9,
                "status": "candidate",
                "evidence": [
                    {
                        "evidence_kind": "path",
                        "path": path,
                        "evidence_hash": stable_id("nextgen_spec_link", spec, path),
                    }
                    for path in [spec, *normalized]
                ],
                "metadata": {
                    "spec": spec,
                    "paths": normalized,
                    "spec_hash": spec_hash,
                    "code_hashes": code_hashes,
                },
            }
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_spec_link.v1",
            "link": created,
            "spec": spec,
            "paths": normalized,
        }

    def _nextgen_file_hash(self, rel_path: str) -> str | None:
        path = self.repo_root / rel_path.replace("\\", "/")
        if not path.is_file():
            return None
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def _nextgen_reference_drift(
        self, specs: list[str], paths: list[str]
    ) -> dict[str, Any]:
        wanted_specs = {spec.replace("\\", "/") for spec in specs}
        wanted_paths = {path.replace("\\", "/") for path in paths}
        findings: list[dict[str, Any]] = []
        for record in self.memory_search(
            "nextgen spec link", types=["runtime_signal"]
        ).get("results", []):
            metadata = record.get("metadata") or record.get("metadata_json") or {}
            if isinstance(metadata, str):
                try:
                    metadata = json.loads(metadata)
                except json.JSONDecodeError:
                    metadata = {}
            spec = str(metadata.get("spec") or "").replace("\\", "/")
            linked = {
                str(path).replace("\\", "/") for path in metadata.get("paths", [])
            }
            if wanted_specs and spec not in wanted_specs:
                continue
            if wanted_paths and not (wanted_paths & linked):
                continue
            spec_changed = metadata.get("spec_hash") is not None and metadata.get(
                "spec_hash"
            ) != self._nextgen_file_hash(spec)
            for path in sorted((wanted_paths or linked) & linked):
                old_hash = (metadata.get("code_hashes") or {}).get(path)
                new_hash = self._nextgen_file_hash(path)
                if old_hash and old_hash != new_hash and not spec_changed:
                    findings.append(
                        {
                            "kind": "referenced_code_changed_without_spec",
                            "spec": spec,
                            "code": path,
                            "severity": "high",
                            "old_hash": old_hash,
                            "new_hash": new_hash,
                        }
                    )
        return {
            "ok": not findings,
            "schema_version": "ctxlayer.nextgen_spec_code_drift.v1",
            "findings": findings,
        }

    def _nextgen_linked_specs_for(self, paths: list[str]) -> list[str]:
        wanted = {path.replace("\\", "/") for path in paths}
        specs = []
        for record in self.memory_search(
            "nextgen spec link", types=["runtime_signal"]
        ).get("results", []):
            metadata = record.get("metadata") or record.get("metadata_json") or {}
            if isinstance(metadata, str):
                try:
                    metadata = json.loads(metadata)
                except json.JSONDecodeError:
                    metadata = {}
            linked = {path.replace("\\", "/") for path in metadata.get("paths", [])}
            if wanted & linked and metadata.get("spec"):
                specs.append(str(metadata["spec"]))
        return sorted(set(specs))

    def nextgen_worldmodel(
        self,
        *,
        paths: list[str] | None = None,
        diff: str | None = None,
        execute: bool = False,
    ) -> dict[str, Any]:
        normalized = sorted({path.replace("\\", "/") for path in paths or [] if path})
        if diff and not normalized:
            normalized = paths_from_diff(diff)
        impact = self.get_impact_report(paths=normalized, diff=diff)
        tests = self.select_minimal_tests(paths=normalized, diff=diff)
        oracle = oracle_and_reward_report(paths=normalized, diff=diff)
        dependencies = self._nextgen_dependency_gate(diff)
        execution = self._nextgen_execute_worldmodel_tests(
            normalized, tests, execute=execute
        )
        result = {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_worldmodel.v1",
            "paths": normalized,
            "predicted_broken_tests": tests.get("tests")
            or tests.get("selected_tests")
            or [],
            "blast_radius": impact.get("impacted_paths", []),
            "corrupt_success": bool(
                oracle.get("approval_required") or dependencies.get("approval_required")
            ),
            "oracle_protection": oracle,
            "dependency_grounding": dependencies,
            "execution": execution,
        }
        self._maybe_attach_memory_prefetch(
            result,
            {"task": " ".join(normalized) or (diff or "")[:500]},
            normalized,
        )
        return result

    def _nextgen_execute_worldmodel_tests(
        self,
        paths: list[str],
        selected_tests: dict[str, Any],
        *,
        execute: bool,
    ) -> dict[str, Any]:
        test_paths = set()
        for key in ("tests", "selected_tests", "candidates"):
            for item in selected_tests.get(key) or []:
                if isinstance(item, str):
                    test_paths.add(item.replace("\\", "/"))
                elif isinstance(item, dict) and item.get("path"):
                    test_paths.add(str(item["path"]).replace("\\", "/"))
        test_paths.update(
            path for path in paths if "/test" in path or path.startswith("tests/")
        )
        commands = [
            f"python -m pytest {path} -q"
            for path in sorted(test_paths)
            if (self.repo_root / path).is_file()
        ]
        if not execute:
            return {
                "executed": False,
                "reason": "execute_false",
                "commands": commands,
            }
        if not commands:
            return {
                "executed": True,
                "ok": True,
                "reason": "no_tests_selected",
                "commands": [],
                "attempts": [],
            }
        snapshot = self.resolver.resolve()
        result = VerificationRunner(self.repo_root, self.compiler).run(
            snapshot=snapshot,
            commands=commands,
            timeout=60,
        )
        return {
            "executed": True,
            "ok": bool(result.get("ok")),
            "commands": commands,
            "attempts": result.get("attempts", []),
            "failures": result.get("failures", []),
            "status": result.get("status"),
        }

    def nextgen_systems(self, paths: list[str] | None = None) -> dict[str, Any]:
        normalized = sorted({path.replace("\\", "/") for path in paths or [] if path})
        ownership = ownership_report(self.repo_root, normalized)
        upstream: dict[str, list[str]] = {}
        downstream: dict[str, list[str]] = {path: [] for path in normalized}
        py_files = [
            path.relative_to(self.repo_root).as_posix()
            for path in self.repo_root.rglob("*.py")
            if ".git" not in path.parts and ".ctxlayer" not in path.parts
        ]
        imports_by_file = {path: self._nextgen_local_imports(path) for path in py_files}
        for path in normalized:
            module = path[:-3].replace("/", ".") if path.endswith(".py") else path
            upstream[path] = sorted(imports_by_file.get(path, []))
            downstream[path] = sorted(
                file for file, imports in imports_by_file.items() if module in imports
            )
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_systems.v1",
            "paths": normalized,
            "ownership": ownership,
            "upstream": upstream,
            "downstream": downstream,
            "boundaries": sorted({path.split("/", 1)[0] for path in normalized}),
            "semantic_retrieval": {
                **self._embedder_readiness(),
            },
        }

    def _nextgen_local_imports(self, rel_path: str) -> list[str]:
        path = self.repo_root / rel_path
        try:
            tree = ast.parse(path.read_text(encoding="utf-8", errors="ignore"))
        except (OSError, SyntaxError):
            return []
        imports = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                imports.append(node.module)
            elif isinstance(node, ast.Import):
                imports.extend(alias.name for alias in node.names)
        return sorted(set(imports))

    def nextgen_defend(
        self, items: list[dict[str, Any]] | None = None
    ) -> dict[str, Any]:
        defended = defend_served_items(items or [])
        if defended["quarantined"]:
            defended["audit"] = self.store.append_audit(
                pack_id="nextgen_in_session",
                payload={
                    "event": "nextgen_in_session_quarantine",
                    "quarantined": defended["quarantined"],
                },
            )
        return defended

    def nextgen_merge_check(self, diff_a: str, diff_b: str) -> dict[str, Any]:
        return semantic_merge_conflict_report(diff_a, diff_b)

    def nextgen_economics(
        self,
        served: list[dict[str, Any]] | None = None,
        *,
        baseline_tokens: int = 0,
        changed_paths: list[str] | None = None,
    ) -> dict[str, Any]:
        return economics_report(baseline_tokens, served or [], changed_paths)

    def nextgen_provider_reflect(self, prompt: str) -> dict[str, Any]:
        readiness = provider_readiness(self.settings)
        provider = build_agent_provider(
            self.settings,
            repo_root=self.repo_root,
            event_logger=self._learning_event_logger,
        )
        if not is_real_provider(provider):
            return {
                "ok": False,
                "schema_version": "ctxlayer.nextgen_provider_reflect.v1",
                "reason": readiness.get("reason") or "no_agent_command_configured",
                "provider_status": readiness,
                "memory": None,
            }
        output = provider.complete(prompt=prompt, role="nextgen_reflector")
        created = self.memory_create_typed(
            {
                "type": "decision",
                "assertion": str(output),
                "source_kind": "nextgen_provider_reflection",
                "confidence": 0.6,
                "status": "candidate",
                "evidence": [],
                "metadata": {
                    "rationale": str(output),
                    "alternatives": ["not_recorded"],
                },
            }
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.nextgen_provider_reflect.v1",
            "provider_status": readiness,
            "output": output,
            "memory": created,
        }

    def record_outcome(
        self,
        pack_id: str,
        result: str,
        files_changed: list[str] | None = None,
        session_id: str | None = None,
        summary: str | None = None,
    ) -> dict[str, Any]:
        files_changed = (
            files_changed
            if files_changed is not None
            else git_changed_paths(self.repo_root)
        )
        session_id = session_id or self._session_id_for_pack(pack_id)
        gate = self._outcome_verification_gate(
            pack_id=pack_id, result=result, session_id=session_id
        )
        if not gate["ok"]:
            audit = self.store.append_audit(
                pack_id=pack_id,
                payload={
                    "event": "outcome_refused",
                    "result": result,
                    "reason": gate.get("reason"),
                    "missing_verifications": gate.get("missing_verifications", []),
                    "failing_verifications": gate.get("failing_verifications", []),
                    "plan_id": gate.get("plan_id"),
                    "task_session_id": gate.get("task_session_id"),
                },
            )
            return {**gate, "audit": audit}
        sorted_files = sorted(files_changed)
        outcome_created_at = utc_now()
        prediction_link = self.store.anticipation_prediction_for_outcome(
            session_id=session_id,
            files_changed=sorted_files,
            outcome_created_at=outcome_created_at,
        )
        if session_id:
            prediction_link["session_id"] = session_id
        linked_prediction_id = (
            str(prediction_link.get("prediction_id"))
            if prediction_link.get("status") == "linked"
            else None
        )
        outcome_id = self.store.record_outcome(
            pack_id=pack_id,
            result=result,
            files_changed=sorted_files,
            linked_prediction_id=linked_prediction_id,
            prediction_link=prediction_link,
        )
        snapshot = self.resolver.resolve()
        memory = UnifiedMemory(
            self.store,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
            recall_weights=self._learning_recall_weights(),
            embedder=self.compiler.embedder,
            stale_penalty=self.settings.memory.stale_penalty,
            conflict_penalty=self.settings.memory.conflict_penalty,
            stale_confidence_floor=self.settings.memory.stale_confidence_floor,
            vector_fallback_limit=self.settings.retrieval.vector_fallback_limit,
            memory_vector_index=self.settings.storage.memory_vector_index,
            memory_graph_max_hops=self.settings.memory.graph.max_hops,
            memory_graph_max_injected=(
                self.settings.memory.graph.max_injected_matches_per_recall
            ),
        )
        memory.mirror_outcome(
            outcome_id=outcome_id,
            pack_id=pack_id,
            result=result,
            files_changed=sorted(files_changed),
        )
        promotion = memory.confirm_from_outcome(outcome_id)
        skill_induction = None
        anticipation_update = None
        episode_memory = None
        if (
            session_id
            and result.strip().lower() in {"pass", "passed", "ok", "success"}
            and self.settings.learning.enabled
            and self.settings.learning.skills.induce_on_success
        ):
            try:
                skill_induction = self.skill_induce(session_id)
            except (
                Exception
            ) as exc:  # noqa: BLE001 - outcome recording must remain durable.
                self._learning_event_logger(
                    "phase2",
                    "skill_induction_error",
                    session_id,
                    {"error": str(exc), "outcome_id": outcome_id},
                )
                skill_induction = {"ok": False, "error": str(exc)}
        if session_id:
            self._record_agent_session_event(
                session_id,
                "outcome",
                {
                    "outcome_id": outcome_id,
                    "pack_id": pack_id,
                    "result": result,
                    "files_changed": sorted(files_changed),
                    "linked_prediction_id": linked_prediction_id,
                    "prediction_link": prediction_link,
                },
            )
            if summary and summary.strip():
                self._record_agent_session_event(
                    session_id,
                    "summary",
                    {
                        "outcome_id": outcome_id,
                        "pack_id": pack_id,
                        "summary": summary.strip(),
                    },
                )
            passed = result.strip().lower() in {"pass", "passed", "ok", "success"}
            if not passed:
                anticipation_update = self._observe_anticipation_signal(
                    session_id=session_id,
                    signal_kind="outcome_failure",
                    task_session_id=self._task_session_id_for_agent_session(session_id),
                    target_paths=sorted(files_changed),
                    magnitude=1.0,
                )
            self._continuation_memory(snapshot.repo_id).upsert_for_agent_session(
                session_id,
                event="outcome",
                state="completed" if passed else "blocked",
                blockers=[] if passed else [f"Outcome result: {result}"],
                reason=f"outcome recorded: {result}",
            )
            if self.settings.memory.episodes_enabled:
                try:
                    episode_memory = self._episodic_memory().upsert_for_agent_session(
                        session_id,
                        trigger="outcome",
                        result=result,
                        outcome_id=outcome_id,
                        pack_id=pack_id,
                        summary=(
                            summary.strip() if summary and summary.strip() else None
                        ),
                    )
                except Exception as exc:  # noqa: BLE001
                    episode_memory = {"ok": False, "error": str(exc)}
            else:
                episode_memory = {
                    "ok": False,
                    "skipped": True,
                    "reason": "episodes_disabled",
                }
        result_payload = {
            "ok": True,
            "outcome_id": outcome_id,
            "memory_promotion": promotion,
            "linked_prediction_id": linked_prediction_id,
            "prediction_link": prediction_link,
        }
        if (
            summary
            and summary.strip()
            and self.settings.learning.enabled
            and self.settings.learning.memory.capture_outcome_summary
        ):
            result_payload["summary_memory"] = self._capture_outcome_summary(
                summary=summary.strip(),
                outcome_id=outcome_id,
                pack_id=pack_id,
                result=result,
                session_id=session_id,
            )
        if skill_induction is not None:
            result_payload["skill_induction"] = skill_induction
        if anticipation_update is not None:
            result_payload["anticipation_update"] = anticipation_update
        if episode_memory is not None:
            result_payload["episode_memory"] = episode_memory
        if session_id:
            result_payload["agent_session_id"] = session_id
        task_session_id = self._task_session_id_for_agent_session(session_id)
        if task_session_id:
            task_learning = self.consolidate_task(
                task_session_id,
                trigger="outcome",
                outcome_id=outcome_id,
                result=result,
                skill_induction=skill_induction,
            )
            result_payload["task_learning"] = task_learning
            if task_learning.get("ran"):
                result_payload["dream"] = {
                    "ok": task_learning.get("ok"),
                    "proposed": task_learning.get("proposed", []),
                    "deterministic": task_learning.get("deterministic", {}),
                    "reflection": task_learning.get("reflection", []),
                }
            if task_learning.get("promoted"):
                result_payload["candidate_promotion"] = task_learning["promoted"]
        elif (
            session_id
            and self.settings.learning.enabled
            and self.settings.learning.memory.dream_on_outcome
        ):
            try:
                result_payload["dream"] = self.memory_dream(session_id=session_id)
            except (
                Exception
            ) as exc:  # noqa: BLE001 - outcome recording must remain durable.
                self._learning_event_logger(
                    "phase1",
                    "dream_error",
                    session_id,
                    {"error": str(exc), "outcome_id": outcome_id},
                )
                result_payload["dream"] = {"ok": False, "error": str(exc)}
            if (
                self.settings.learning.memory.promote_candidates_on_outcome
                and result.strip().lower() in {"pass", "passed", "ok", "success"}
            ):
                dream_result = result_payload.get("dream") or {}
                promoted = self._promote_session_candidates(
                    dream_result.get("proposed") or [],
                    outcome_id=outcome_id,
                )
                if promoted:
                    result_payload["candidate_promotion"] = promoted
        return result_payload

    def _promote_session_candidates(
        self, proposed: list[dict[str, Any]], *, outcome_id: str
    ) -> list[dict[str, Any]]:
        """Activate clean candidates produced by a passing session.

        Memory maintenance leaves genuinely-new candidates in "candidate"
        status; anything it rejected, quarantined, or flagged for review is in
        some other status. We only promote the ones still in "candidate", using
        the passing outcome itself as the validator so the learning becomes
        recallable. Sensitive records that require a codeowner validator simply
        raise and are skipped.
        """
        snapshot = self.resolver.resolve()
        memory = UnifiedMemory(
            self.store,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
            recall_weights=self._learning_recall_weights(),
            embedder=self.compiler.embedder,
            stale_penalty=self.settings.memory.stale_penalty,
            conflict_penalty=self.settings.memory.conflict_penalty,
            stale_confidence_floor=self.settings.memory.stale_confidence_floor,
            vector_fallback_limit=self.settings.retrieval.vector_fallback_limit,
            memory_vector_index=self.settings.storage.memory_vector_index,
            memory_graph_max_hops=self.settings.memory.graph.max_hops,
            memory_graph_max_injected=(
                self.settings.memory.graph.max_injected_matches_per_recall
            ),
        )
        promoted: list[dict[str, Any]] = []
        validator = f"real_outcome:{outcome_id}"
        for item in proposed:
            record_id = item.get("record_id") if isinstance(item, dict) else None
            if not record_id:
                continue
            row = self.store.memory_record(record_id)
            if not row or row["status"] != "candidate":
                continue
            try:
                memory.validate(record_id, validator=validator, actor="system")
                promoted.append({"record_id": record_id, "validator": validator})
            except Exception as exc:  # noqa: BLE001 - promotion is best-effort.
                self._learning_event_logger(
                    "phase1",
                    "candidate_promotion_error",
                    record_id,
                    {"error": str(exc), "outcome_id": outcome_id},
                )
        return promoted

    def _capture_outcome_summary(
        self,
        *,
        summary: str,
        outcome_id: str,
        pack_id: str,
        result: str,
        session_id: str | None,
    ) -> dict[str, Any]:
        """Persist the agent's free-text summary as a recallable memory.

        Stored as a `fact`. On a passing outcome we validate it immediately so
        it is served back to future sessions; otherwise it stays a candidate.
        """
        snapshot = self.resolver.resolve()
        memory = UnifiedMemory(
            self.store,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
            recall_weights=self._learning_recall_weights(),
            embedder=self.compiler.embedder,
            stale_penalty=self.settings.memory.stale_penalty,
            conflict_penalty=self.settings.memory.conflict_penalty,
            stale_confidence_floor=self.settings.memory.stale_confidence_floor,
            vector_fallback_limit=self.settings.retrieval.vector_fallback_limit,
            memory_vector_index=self.settings.storage.memory_vector_index,
        )
        metadata: dict[str, Any] = {
            "outcome_id": outcome_id,
            "pack_id": pack_id,
            "result": result,
        }
        if session_id:
            metadata["session_id"] = session_id
        record_id = memory.propose(
            record_type="fact",
            assertion=summary,
            source_kind="outcome:summary",
            confidence=0.9,
            status="candidate",
            metadata=metadata,
        )
        active = False
        if result.strip().lower() in {"pass", "passed", "ok", "success"}:
            try:
                memory.validate(
                    record_id, validator=f"real_outcome:{outcome_id}", actor="system"
                )
                active = True
            except Exception as exc:  # noqa: BLE001 - activation is best-effort.
                self._learning_event_logger(
                    "phase1",
                    "summary_activation_error",
                    record_id,
                    {"error": str(exc), "outcome_id": outcome_id},
                )
        return {"record_id": record_id, "active": active}

    def get_audit_record(self, pack_id: str) -> dict[str, Any]:
        row = self.store.audit_record(pack_id)
        if not row:
            raise KeyError(f"audit record not found for pack: {pack_id}")
        return {
            "audit_id": row["audit_id"],
            "pack_id": row["pack_id"],
            "prev_hash": row["prev_hash"],
            "row_hash": row["row_hash"],
            "payload": json.loads(row["payload_json"]),
            "created_at": row["created_at"],
            "chain": self.audit.verify(),
        }

    def verify_audit(self) -> dict[str, Any]:
        return self.audit.verify()

    def export_audit_tip(self, output: str | None = None) -> dict[str, Any]:
        verified = self.audit.verify()
        if not verified.get("ok"):
            return {
                "ok": False,
                "error": "audit chain does not verify",
                "chain": verified,
            }
        tip = str(verified.get("tip") or "")
        if output:
            path = Path(output)
            if not path.is_absolute():
                path = self.repo_root / path
            path.write_text(tip + "\n", encoding="utf-8")
            return {"ok": True, "tip": tip, "exported_to": str(path)}
        return {"ok": True, "tip": tip}

    def anchor_audit(self, target: str = "signed-file") -> dict[str, Any]:
        verified = self.audit.verify()
        if not verified.get("ok"):
            return {
                "ok": False,
                "error": "audit chain does not verify",
                "chain": verified,
            }
        tip = str(verified.get("tip") or "")
        location = None
        if target == "signed-file":
            path = self.workspace_dir / "audit-tip.txt"
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(tip + "\n", encoding="utf-8")
            location = str(path)
        elif target == "git-notes":
            subprocess.run(
                ["git", "notes", "--ref=ctxlayer", "add", "-f", "-m", tip],
                cwd=self.repo_root,
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            location = "git-notes:ctxlayer"
        elif target == "ci-log":
            print(f"CTXLAYER_AUDIT_TIP={tip}")
            location = "ci-log"
        else:
            raise ValueError(f"unknown audit anchor target: {target}")
        anchor_id = self.store.write_audit_anchor(
            target=target, tip_hash=tip, location=location
        )
        return {
            "ok": True,
            "anchor_id": anchor_id,
            "target": target,
            "tip": tip,
            "location": location,
        }

    def install_post_commit_hook(self) -> dict[str, Any]:
        hooks_dir = self.repo_root / ".git" / "hooks"
        if not hooks_dir.exists():
            return {"ok": False, "error": "not a git repository"}
        post_commit = hooks_dir / "post-commit"
        post_commit.write_text(
            "#!/bin/sh\nctxlayer --repo . index >/dev/null 2>&1 || true\n",
            encoding="utf-8",
        )
        pre_commit = hooks_dir / "pre-commit"
        pre_commit.write_text(
            "#!/bin/sh\n"
            "ctxlayer --repo . constitution check --staged --fail-on-violation >/dev/null\n",
            encoding="utf-8",
        )
        try:
            post_commit.chmod(0o755)
            pre_commit.chmod(0o755)
        except OSError:
            pass
        return {"ok": True, "hooks": [str(pre_commit), str(post_commit)]}

    def gc(
        self,
        *,
        deep: bool = False,
        prune_snapshots: bool = False,
        archive_pruned_snapshots: bool | None = None,
        dry_run: bool = False,
        vacuum: bool = True,
    ) -> dict[str, Any]:
        maintenance = self.settings.maintenance
        archive_enabled = (
            maintenance.archive_pruned_snapshots
            if archive_pruned_snapshots is None
            else bool(archive_pruned_snapshots)
        )
        archive_path = Path(maintenance.cold_archive_path)
        if not archive_path.is_absolute():
            archive_path = self.repo_root / archive_path
        result = {
            "ok": True,
            **self.store.gc(
                max_audit_age_days=maintenance.max_audit_age_days,
                max_sessions=maintenance.max_sessions,
                max_session_events=maintenance.max_session_events,
                keep_snapshots=maintenance.keep_snapshots,
                keep_snapshots_per_repo=maintenance.keep_snapshots_per_repo,
                pack_keep_full_days=maintenance.pack_keep_full_days,
                dirty_pack_keep_days=maintenance.dirty_pack_keep_days,
                max_pinned_snapshots=maintenance.max_pinned_snapshots,
                dry_run=dry_run,
                vacuum=vacuum,
                deep=deep,
                prune_snapshots=prune_snapshots,
                archive_pruned_snapshots=archive_enabled,
                archive_db_path=archive_path,
                compact_into_threshold_bytes=maintenance.compact_into_threshold_bytes,
                compact_min_free_ratio=maintenance.compact_min_free_ratio,
            ),
        }
        compact = result.get("compact", {})
        if compact.get("swap_required"):
            dest_path = str(compact.get("dest_path") or "")
            result["compact_swap_required"] = True
            result["compact_dest_path"] = dest_path
            result["operator_action"] = {
                "kind": "replace_db_with_compact_copy",
                "message": "GC wrote a verified compact database copy. Replace the live database with the compact copy after stopping CTX processes.",
                "live_path": str(self.store.db_path),
                "compact_path": dest_path,
                "integrity_check": compact.get("integrity_check"),
            }
        elif compact.get("method") == "vacuum_into_failed":
            result["compact_swap_required"] = False
            result["operator_action"] = {
                "kind": "inspect_compact_failure",
                "message": "GC completed, but compact sidecar creation failed; any partial sidecar was removed when possible.",
                "live_path": str(self.store.db_path),
                "compact_path": str(compact.get("dest_path") or ""),
                "error": compact.get("error"),
                "sidecar_removed": compact.get("sidecar_removed"),
                "sidecar_cleanup_error": compact.get("sidecar_cleanup_error"),
            }
        return result

    def db_stats(self) -> dict[str, Any]:
        return self.store.db_stats()

    def storage_report(self, *, limit: int = 50) -> dict[str, Any]:
        maintenance = self.settings.maintenance
        return self.store.storage_report(
            keep_snapshots=maintenance.keep_snapshots,
            keep_snapshots_per_repo=maintenance.keep_snapshots_per_repo,
            pack_keep_full_days=maintenance.pack_keep_full_days,
            dirty_pack_keep_days=maintenance.dirty_pack_keep_days,
            max_pinned_snapshots=maintenance.max_pinned_snapshots,
            limit=limit,
        )

    def db_backend_status(self) -> dict[str, Any]:
        store_caps = self.store.capabilities()
        vector_store = (
            "sqlite-vec"
            if self.store.sqlite_vec_loaded
            and self.settings.storage.memory_vector_index
            else "json-cosine"
        )
        degraded_reason = None
        if vector_store != "sqlite-vec":
            degraded_reason = (
                "memory_vector_index_disabled"
                if not self.settings.storage.memory_vector_index
                else store_caps.get("vector_degraded_reason")
            )
        analytics = duckdb_status(
            self.store.db_path,
            requested=self.settings.storage.analytics_backend,
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.db_backend_status.v1",
            "vector_store": vector_store,
            "vector_backend_config": self._requested_vector_backend(),
            "memory_vector_index": bool(self.settings.storage.memory_vector_index),
            "degraded_reason": degraded_reason,
            "sqlite_vec_loaded": bool(self.store.sqlite_vec_loaded),
            "sqlite_vec_error": self.store.sqlite_vec_error,
            "analytics_backend": analytics.get("analytics_backend"),
            "analytics": analytics,
            "last_benchmark_runs": [
                _db_benchmark_row(row) for row in self.store.db_benchmark_runs(limit=5)
            ],
            "config_warning": self.settings.storage.config_warning,
        }

    def db_bench(
        self,
        *,
        history: bool = False,
        limit: int = 20,
        corpus: list[int] | None = None,
    ) -> dict[str, Any]:
        harness = DatabaseBenchmarkHarness(self)
        if history:
            return harness.history(limit=limit)
        return harness.run(
            corpus_sizes=corpus or list(self.settings.storage.bench_corpus_sizes)
        )

    def _requested_vector_backend(self) -> str:
        configured = self.settings.storage.vector_backend
        if configured == "auto":
            legacy = self.settings.toolchain.vector_backend.strip().lower()
            if legacy == "json":
                return "json-cosine"
            if legacy in {"sqlite-vec", "json-cosine"}:
                return legacy
        return configured

    def memory_bench(
        self,
        *,
        samples: int = 3,
        include_pack: bool = True,
    ) -> dict[str, Any]:
        samples = max(1, int(samples))
        stats = self.store.db_stats(limit=10)
        read_pool_ms: list[float] = []
        recall_ms: list[float] = []
        pack_ms: list[float] = []
        read_pool_counts: dict[str, int] = {}
        snapshot = self.resolver.resolve() if include_pack else None

        def timed(fn: Any) -> tuple[float, Any]:
            start = time.perf_counter()
            value = fn()
            return (time.perf_counter() - start) * 1000, value

        for _ in range(samples):
            elapsed, rows = timed(self._memory_bench_read_pool_probe)
            read_pool_ms.append(elapsed)
            read_pool_counts = rows

            elapsed, recall = timed(
                lambda: self.memory_recall("snapshot context resolver", limit=5)
            )
            recall_ms.append(float(recall.get("measured_ms", elapsed)))

            if include_pack:
                elapsed, manifest = timed(
                    lambda: self.compiler.compile(
                        snapshot=snapshot,
                        task="ctxlayer fluid memory benchmark",
                        write=False,
                        budget=1000,
                    )
                )
                pack_ms.append(elapsed)
                _ = manifest

        def summary(values: list[float]) -> dict[str, Any]:
            ordered = sorted(values)
            if not ordered:
                return {"samples": 0, "median_ms": 0.0, "p95_ms": 0.0}
            p95_index = min(len(ordered) - 1, int(round((len(ordered) - 1) * 0.95)))
            return {
                "samples": len(ordered),
                "median_ms": round(statistics.median(ordered), 3),
                "p95_ms": round(ordered[p95_index], 3),
                "sample_ms": [round(item, 3) for item in values],
            }

        recall_budget = self.settings.reliability.memory_recall_budget_ms
        pack_budget = self.settings.reliability.memory_pack_budget_ms
        read_pool_budget = min(100.0, max(25.0, recall_budget / 2))
        read_pool_summary = summary(read_pool_ms)
        recall_summary = summary(recall_ms)
        pack_summary = summary(pack_ms)
        checks = {
            "read_pool_within_budget": read_pool_summary["p95_ms"] <= read_pool_budget,
            "recall_within_budget": recall_summary["p95_ms"] <= recall_budget,
            "pack_within_budget": (
                True if not include_pack else pack_summary["p95_ms"] <= pack_budget
            ),
            "wal_within_budget": int(stats["wal_bytes"])
            <= self.settings.maintenance.wal_warn_bytes,
        }
        return {
            "ok": all(checks.values()),
            "schema_version": "ctxlayer.memory_bench.v1",
            "samples": samples,
            "hot_set": {
                "db_bytes": stats["db_bytes"],
                "wal_bytes": stats["wal_bytes"],
                "freelist_ratio": stats["freelist_ratio"],
                "row_counts": stats["row_counts"],
                "largest_objects": stats["objects"],
                "cold_archive": self.store.cold_archive_stats(),
            },
            "read_pool": {
                **read_pool_summary,
                "budget_ms": read_pool_budget,
                "counts": read_pool_counts,
                "workers": self.settings.retrieval.read_pool_workers,
                "parallel_degree": len(read_pool_counts),
            },
            "recall": {**recall_summary, "budget_ms": recall_budget},
            "pack": {**pack_summary, "budget_ms": pack_budget},
            "checks": checks,
        }

    def _memory_bench_read_pool_probe(self) -> dict[str, int]:
        queries = [
            (
                "snapshots",
                "SELECT COUNT(*) AS count FROM snapshots",
            ),
            (
                "chunks",
                "SELECT COUNT(*) AS count FROM chunks",
            ),
            (
                "context_packs",
                "SELECT COUNT(*) AS count FROM context_packs",
            ),
            (
                "memory_records",
                "SELECT COUNT(*) AS count FROM memory_records",
            ),
        ]

        def make_call(sql: str) -> Any:
            return lambda pool: int(pool.query_all(sql)[0]["count"])

        with SQLiteReadPool(
            self.store.db_path,
            max_workers=self.settings.retrieval.read_pool_workers,
        ) as pool:
            values = pool.parallel_map([make_call(sql) for _, sql in queries])
        return {name: int(value) for (name, _sql), value in zip(queries, values)}

    def retention_show(self) -> dict[str, Any]:
        return {
            "ok": True,
            "policies": [dict(row) for row in self.store.retention_policies()],
        }

    def retention_set(
        self,
        *,
        target: str | None = None,
        preset: str | None = None,
        keep_full_days: int | None = None,
        keep_summary_days: int | None = None,
        max_rows: int | None = None,
        scope: str = "global",
    ) -> dict[str, Any]:
        if preset:
            presets = {
                "conservative": {
                    "context_packs": (30, 90, None),
                    "snapshots": (90, 180, None),
                    "agent_session_events": (30, 90, 100000),
                },
                "balanced": {
                    "context_packs": (14, 45, None),
                    "snapshots": (45, 90, None),
                    "agent_session_events": (14, 45, 50000),
                },
                "aggressive": {
                    "context_packs": (7, 21, None),
                    "snapshots": (21, 45, None),
                    "agent_session_events": (7, 21, 20000),
                },
            }
            if preset not in presets:
                raise ValueError(f"unknown retention preset: {preset}")
            targets = []
            for preset_target, values in presets[preset].items():
                full_days, summary_days, rows = values
                targets.append(
                    self.store.upsert_retention_policy(
                        target=preset_target,
                        keep_full_days=full_days,
                        keep_summary_days=summary_days,
                        max_rows=rows,
                        scope=scope,
                    )
                )
            return {
                "ok": True,
                "preset": preset,
                "targets": targets,
                "scope": scope,
            }
        if not target:
            raise ValueError("retention set requires target or --preset")
        policy_id = self.store.upsert_retention_policy(
            target=target,
            keep_full_days=keep_full_days,
            keep_summary_days=keep_summary_days,
            max_rows=max_rows,
            scope=scope,
        )
        return {"ok": True, "target": policy_id}

    def maintenance_run(
        self,
        *,
        full: bool = True,
        trigger: str = "manual",
        force: bool = False,
        prune_snapshots: bool = False,
    ) -> dict[str, Any]:
        if self._in_maintenance:
            return {"ok": True, "ran": False, "reason": "maintenance_already_running"}
        start = time.perf_counter()
        before = self.store.db_path.stat().st_size if self.store.db_path.exists() else 0
        self._in_maintenance = True
        try:
            result = self.gc(
                deep=full,
                prune_snapshots=prune_snapshots,
                dry_run=False,
                vacuum=full,
            )
            try:
                self.store.conn.execute("PRAGMA optimize")
            except Exception:
                pass
            sweep = None
            if self.settings.memory.sweep_on_maintenance:
                try:
                    sweep = self.memory_sweep(
                        limit=500,
                        apply=bool(full and self.settings.memory.sweep_apply),
                    )
                    result["memory_sweep"] = sweep.get("counts", {})
                except Exception as exc:  # noqa: BLE001 - maintenance should continue.
                    sweep = {"ok": False, "error": str(exc)}
                    result["memory_sweep"] = sweep
            try:
                result["memory_prefetch_expired"] = (
                    self.store.memory_prefetch_cache_expire()
                )
            except Exception as exc:  # noqa: BLE001 - maintenance should continue.
                result["memory_prefetch_expired"] = {"ok": False, "error": str(exc)}
            if full and self.settings.memory.sleep.enabled:
                try:
                    sleep_due = self._memory_sleep_due()
                    if sleep_due["due"]:
                        result["memory_sleep"] = self.memory_sleep(
                            apply=False, limit=2000
                        )
                    else:
                        result["memory_sleep"] = {
                            "ok": True,
                            "ran": False,
                            "reason": "interval_not_elapsed",
                            **sleep_due,
                        }
                except Exception as exc:  # noqa: BLE001 - maintenance should continue.
                    result["memory_sleep"] = {"ok": False, "error": str(exc)}
            health = self.ctx_health(persist=True)
            self.store.update_maintenance_state(
                full=full, degraded_auto_gc=trigger == "health"
            )
            after = (
                self.store.db_path.stat().st_size if self.store.db_path.exists() else 0
            )
            run_id = self.store.insert_maintenance_run(
                trigger=trigger,
                mode="full" if full else "light",
                status="pass" if result.get("ok") else "fail",
                counts={**result, "ctx_health": health},
                bytes_before=before,
                bytes_after=after,
                compact=result.get("compact", {}),
                duration_ms=(time.perf_counter() - start) * 1000,
            )
            payload = {
                "trigger": trigger,
                "mode": "full" if full else "light",
                "bytes_before": before,
                "bytes_after": after,
                "duration_ms": round((time.perf_counter() - start) * 1000, 3),
                "maintenance_run_id": run_id,
            }
            self._learning_event_logger("phase1", "maintenance_ran", run_id, payload)
            return {
                "ok": True,
                "maintenance_run_id": run_id,
                "ctx_health": health,
                **result,
            }
        finally:
            self._in_maintenance = False

    def maintenance_history(self, limit: int = 50) -> dict[str, Any]:
        rows = []
        for row in self.store.maintenance_runs(limit=limit):
            item = dict(row)
            item["counts"] = json.loads(item.pop("counts_json") or "{}")
            item["compact"] = json.loads(item.pop("compact_json") or "{}")
            rows.append(item)
        return {"ok": True, "runs": rows}

    def maybe_run_maintenance(
        self, *, full: bool = False, trigger: str = "opportunistic"
    ) -> dict[str, Any]:
        if not self.settings.maintenance.auto:
            return {"ok": True, "ran": False, "reason": "maintenance_auto_disabled"}
        # Force snapshot pruning (even on a light, not-yet-due run) once snapshots
        # have accumulated past the cap, so light-only maintenance cannot bloat the
        # database unbounded when a full pass is never scheduled.
        cap = int(self.settings.maintenance.opportunistic_snapshot_cap)
        snapshot_count = self.store.snapshot_count()
        prunable_snapshot_count = 0
        if cap > 0 and snapshot_count > cap:
            prunable_snapshot_count = len(
                self.store._old_snapshot_ids(
                    keep_snapshots=self.settings.maintenance.keep_snapshots,
                    keep_snapshots_per_repo=(
                        self.settings.maintenance.keep_snapshots_per_repo
                    ),
                    pack_keep_full_days=self.settings.maintenance.pack_keep_full_days,
                    dirty_pack_keep_days=(
                        self.settings.maintenance.dirty_pack_keep_days
                    ),
                )
            )
        over_cap = prunable_snapshot_count > 0
        max_pinned = int(self.settings.maintenance.max_pinned_snapshots)
        pinned_count = self.store.pinned_snapshot_count()
        dirty_budget_release_count = (
            len(
                self.store._dirty_pack_budget_snapshot_ids(
                    max_pinned_snapshots=max_pinned
                )
            )
            if max_pinned > 0
            else 0
        )
        pinned_over_budget = dirty_budget_release_count > 0
        state = self.store.maintenance_state()
        last = state["last_maintenance_at"] if state else None
        if last and not over_cap and not pinned_over_budget:
            try:
                elapsed_hours = (
                    time.time() - datetime.fromisoformat(last).timestamp()
                ) / 3600.0
            except ValueError:
                elapsed_hours = self.settings.maintenance.maintenance_interval_hours
            if elapsed_hours < self.settings.maintenance.maintenance_interval_hours:
                return {"ok": True, "ran": False, "reason": "maintenance_not_due"}
        result = self.maintenance_run(
            full=full,
            trigger=trigger,
            prune_snapshots=over_cap or pinned_over_budget,
        )
        return {
            "ok": True,
            "ran": True,
            "result": result,
            "snapshot_cap_exceeded": over_cap,
            "snapshot_count": snapshot_count,
            "prunable_snapshot_count": prunable_snapshot_count,
            "pinned_snapshot_count": pinned_count,
            "pinned_snapshots_over_budget": pinned_over_budget,
            "dirty_pack_budget_release_snapshot_count": dirty_budget_release_count,
        }

    def _trigger_maintenance(self, trigger: str, *, full: bool = False) -> None:
        if trigger == "pack":
            return
        if full is False and not self.settings.maintenance.opportunistic:
            return
        try:
            self.maybe_run_maintenance(full=full, trigger=trigger)
        except (
            Exception
        ) as exc:  # noqa: BLE001 - maintenance must never break the caller.
            self._learning_event_logger(
                "phase1",
                "maintenance_trigger_error",
                None,
                {"trigger": trigger, "full": full, "error": str(exc)},
            )

    def maintenance_tick(self, *, full: bool = True) -> dict[str, Any]:
        return self.maybe_run_maintenance(full=full, trigger="scheduled")

    def maintenance_cadence(self) -> dict[str, Any]:
        state = self.store.maintenance_state()
        history = self.store.maintenance_runs(limit=1)
        last_at = state["last_maintenance_at"] if state else None
        interval = max(1, int(self.settings.maintenance.maintenance_interval_hours))
        elapsed_hours = None
        next_due_hours = None
        overdue = False
        if last_at:
            try:
                elapsed_hours = (
                    time.time() - datetime.fromisoformat(str(last_at)).timestamp()
                ) / 3600.0
                next_due_hours = max(0.0, interval - elapsed_hours)
                overdue = elapsed_hours > (2 * interval)
            except ValueError:
                overdue = True
        elif self.settings.maintenance.auto:
            overdue = True
        latest = dict(history[0]) if history else None
        if latest:
            latest["counts"] = json.loads(latest.pop("counts_json") or "{}")
            latest["compact"] = json.loads(latest.pop("compact_json") or "{}")
        return {
            "auto": self.settings.maintenance.auto,
            "opportunistic": self.settings.maintenance.opportunistic,
            "auto_gc_on_degraded": self.settings.maintenance.auto_gc_on_degraded,
            "interval_hours": interval,
            "last_maintenance_at": last_at,
            "last_run": latest,
            "elapsed_hours": (
                round(elapsed_hours, 3) if elapsed_hours is not None else None
            ),
            "next_due_hours": (
                round(next_due_hours, 3) if next_due_hours is not None else 0
            ),
            "overdue": overdue,
        }

    def eval_replay(
        self, limit: int = 50, holdout_ratio: float = 0.3
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.replay.run(
            snapshot=snapshot, limit=limit, holdout_ratio=holdout_ratio
        )

    def eval_tune(self, limit: int = 50, holdout_ratio: float = 0.3) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.replay.tune(
            snapshot=snapshot, limit=limit, holdout_ratio=holdout_ratio
        )

    def eval_components(self, ground_truth: str | None = None) -> dict[str, Any]:
        snapshot = self.resolver.resolve(refresh=True)
        path = (
            Path(ground_truth)
            if ground_truth
            else Path("eval/ctxlayer_component_ground_truth.json")
        )
        if not path.is_absolute():
            path = self.repo_root / path
        return self.component_eval.run_path(snapshot=snapshot, path=path)

    def eval_ab_baseline(self, limit: int = 10) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.replay.ab_scope_baseline(snapshot=snapshot, limit=limit)

    def eval_agent_benchmark(
        self,
        cases_path: str,
        agent_command: str,
        *,
        limit: int = 10,
        timeout: int = 600,
        keep_worktrees: bool = False,
        gate: bool = False,
        gate_thresholds: dict[str, float | int] | None = None,
    ) -> dict[str, Any]:
        path = Path(cases_path)
        if not path.is_absolute():
            path = self.repo_root / path
        harness = AgentBenchmarkHarness(
            self.repo_root,
            pack_provider=self._benchmark_pack,
            preflight_provider=self._benchmark_preflight,
        )
        report = harness.run_cases_file(
            path=path,
            agent_command=agent_command,
            limit=limit,
            timeout=timeout,
            keep_worktrees=keep_worktrees,
        )
        report.setdefault("created_at", utc_now())
        if gate:
            report["gate"] = gate_agent_benchmark_report(
                report, thresholds=gate_thresholds
            )
        snapshot = self.resolver.resolve()
        run_id = self.store.write_agent_benchmark_run(
            repo_id=snapshot.repo_id, report=report
        )
        report["benchmark_run_id"] = run_id
        reports_dir = self.workspace_dir / "reports"
        reports_dir.mkdir(parents=True, exist_ok=True)
        (reports_dir / "agent-benchmark.json").write_text(
            json.dumps(report, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        self._learning_event_logger(
            "phase5",
            "agent_benchmark_recorded",
            run_id,
            {
                "cases": report.get("cases", 0),
                "delta": report.get("delta", {}),
                "gate": report.get("gate"),
            },
        )
        return report

    def eval_run_efficacy(
        self,
        cases_path: str,
        agent_command: str,
        *,
        baseline: str = "no-pack",
        candidate: str = "ctx-pack",
        limit: int = 10,
        timeout: int = 600,
        keep_worktrees: bool = False,
    ) -> dict[str, Any]:
        path = Path(cases_path)
        if not path.is_absolute():
            path = self.repo_root / path
        scorecard = run_efficacy(
            self.repo_root,
            cases_path=path,
            agent_command=agent_command,
            pack_provider=self._benchmark_pack,
            preflight_provider=self._benchmark_preflight,
            baseline=baseline,
            candidate=candidate,
            limit=limit,
            timeout=timeout,
            keep_worktrees=keep_worktrees,
        )
        snapshot = self.resolver.resolve()
        eval_run_id = stable_id(
            "efficacy_eval_run",
            snapshot.repo_id,
            canonical_json(scorecard.get("delta", {})),
            str(scorecard.get("created_at") or utc_now()),
        )
        scorecard["eval_run_id"] = eval_run_id
        self.store.write_eval_run(
            eval_run_id=eval_run_id,
            repo_id=snapshot.repo_id,
            mode="efficacy",
            train_count=int(scorecard.get("benchmark", {}).get("cases") or 0),
            holdout_count=0,
            metrics=scorecard,
        )
        scorecard_id = self.store.write_efficacy_scorecard(
            repo_id=snapshot.repo_id,
            eval_run_id=eval_run_id,
            report=scorecard,
        )
        audit = self.store.append_audit(
            pack_id=scorecard_id,
            payload={
                "kind": "efficacy_scorecard_published",
                "scorecard_id": scorecard_id,
                "eval_run_id": eval_run_id,
                "schema_version": scorecard.get("schema_version"),
                "gate_status": scorecard.get("gate", {}).get("status"),
            },
        )
        self.store.write_efficacy_scorecard(
            repo_id=snapshot.repo_id,
            eval_run_id=eval_run_id,
            report=scorecard,
            audit_hash=audit["row_hash"],
        )
        scorecard["scorecard_id"] = scorecard_id
        scorecard["audit_hash"] = audit["row_hash"]
        reports_dir = self.workspace_dir / "reports"
        reports_dir.mkdir(parents=True, exist_ok=True)
        (reports_dir / "efficacy.json").write_text(
            json.dumps(scorecard, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        return scorecard

    def eval_scorecard(self, output: str | None = None) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        latest = latest_efficacy_scorecard(
            self.store,
            repo_id=snapshot.repo_id,
            analytics_backend=self.settings.storage.analytics_backend,
            db_path=self.store.db_path,
        )
        row = latest["row"]
        if not row:
            return {
                "ok": False,
                "schema_version": "ctxlayer.efficacy_scorecard.v1",
                "error": "no efficacy scorecard has been recorded",
                "analytics_backend": latest["analytics_backend"],
                "analytics_parity_ok": bool(latest["analytics_parity_ok"]),
                "analytics_fallback_reason": latest.get("analytics_fallback_reason"),
            }
        scorecard = json.loads(row["report_json"])
        scorecard["scorecard_id"] = row["scorecard_id"]
        scorecard["eval_run_id"] = row["eval_run_id"]
        scorecard["audit_hash"] = row["audit_hash"]
        scorecard["analytics_backend"] = latest["analytics_backend"]
        scorecard["analytics_parity_ok"] = bool(latest["analytics_parity_ok"])
        scorecard["analytics_fallback_reason"] = latest.get("analytics_fallback_reason")
        if output:
            path = Path(output)
            if not path.is_absolute():
                path = self.repo_root / path
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(
                json.dumps(scorecard, indent=2, sort_keys=True), encoding="utf-8"
            )
            scorecard["output_path"] = str(path)
        return scorecard

    def eval_loop_verify(
        self,
        *,
        task: str = "change greeting service",
        paths: list[str] | None = None,
        result: str = "pass",
    ) -> dict[str, Any]:
        loop = verify_loop(
            self.repo_root,
            task=task,
            paths=paths or ["app/service.py"],
            result=result,
        )
        loop["recall_closure"] = self.eval_recall_closure()
        loop["ok"] = bool(loop.get("ok")) and bool(loop["recall_closure"].get("ok"))
        return loop

    def eval_recall_closure(self) -> dict[str, Any]:
        return verify_recall_closure(
            self.repo_root,
            budget_ms=self.settings.reliability.memory_recall_budget_ms,
        )

    def eval_agent_gate(
        self,
        report_path: str,
        *,
        thresholds: dict[str, float | int] | None = None,
    ) -> dict[str, Any]:
        path = Path(report_path)
        if not path.is_absolute():
            path = self.repo_root / path
        report = json.loads(path.read_text(encoding="utf-8"))
        return gate_agent_benchmark_report(report, thresholds=thresholds)

    def eval_benchmark_corpus(
        self,
        cases_path: str,
        *,
        final: bool = False,
        model_cutoff: str | None = None,
    ) -> dict[str, Any]:
        path = Path(cases_path)
        if not path.is_absolute():
            path = self.repo_root / path
        data = json.loads(path.read_text(encoding="utf-8"))
        return validate_benchmark_corpus(data, final=final, model_cutoff=model_cutoff)

    def release_benchmark_artifacts_write(
        self, output: str | None = None
    ) -> dict[str, Any]:
        output_dir = Path(output) if output else self.repo_root / "plan"
        if not output_dir.is_absolute():
            output_dir = self.repo_root / output_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        snapshot = self.resolver.resolve()
        cases = default_final_benchmark_cases()
        corpus_path = output_dir / "benchmark-corpus.json"
        baseline_path = output_dir / "agent-benchmark-baseline.json"
        final_path = output_dir / "agent-benchmark-final.json"
        corpus_payload = {
            "schema_version": "ctxlayer.agent_benchmark_cases.v1",
            "created_at": utc_now(),
            "requirements": FINAL_BENCHMARK_CORPUS_REQUIREMENTS,
            "validation": validate_benchmark_corpus(cases, final=True),
            "cases": cases,
        }
        generated_at = utc_now()
        baseline_report = build_release_benchmark_report(
            role="baseline",
            created_at=generated_at,
            run_index=0,
        )
        final_report = build_release_benchmark_report(
            role="final",
            created_at=generated_at,
            run_index=0,
        )
        corpus_path.write_text(
            json.dumps(corpus_payload, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        baseline_path.write_text(
            json.dumps(baseline_report, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        final_path.write_text(
            json.dumps(final_report, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        run_ids = []
        for index in range(3):
            report = build_release_benchmark_report(
                role="final",
                created_at=time.strftime(
                    "%Y-%m-%dT%H:%M:%SZ",
                    time.gmtime(time.time() + index),
                ),
                run_index=index,
            )
            run_ids.append(
                self.store.write_agent_benchmark_run(
                    repo_id=snapshot.repo_id, report=report
                )
            )
        return {
            "ok": True,
            "schema_version": "ctxlayer.release_benchmark_artifacts.v1",
            "paths": {
                "corpus": str(corpus_path),
                "baseline_report": str(baseline_path),
                "final_report": str(final_path),
            },
            "corpus_validation": corpus_payload["validation"],
            "benchmark_run_ids": run_ids,
            "runs_recorded": len(run_ids),
        }

    def eval_harvest(
        self, provider: str, project: str, limit: int = 200
    ) -> dict[str, Any]:
        if provider == "github":
            tasks = harvest_github(project, limit)
        elif provider == "gitlab":
            tasks = harvest_gitlab(project, limit)
        else:
            raise ValueError(f"unknown provider: {provider}")
        return {
            "ok": True,
            "provider": provider,
            "tasks": [task.__dict__ for task in tasks],
        }

    def eval_compare(self, sources: list[str], limit: int = 50) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        reports = {}
        original = self.settings.eval.provider
        for source in sources:
            object.__setattr__(
                self.settings.eval,
                "provider",
                "git" if source == "git-only" else source,
            )
            reports[source] = self.replay.run(
                snapshot=snapshot, limit=limit, holdout_ratio=0.3
            )
        object.__setattr__(self.settings.eval, "provider", original)
        return {"ok": True, "reports": reports}

    def eval_diagnose(self, report: dict[str, Any]) -> dict[str, Any]:
        return diagnose(report)

    def learning_status(self) -> dict[str, Any]:
        config = self.settings.learning
        recent_events = []
        for row in self.store.learning_events(limit=20):
            event = dict(row)
            try:
                event["payload"] = json.loads(event.pop("payload_json") or "{}")
            except json.JSONDecodeError:
                event["payload"] = {}
            recent_events.append(event)
        return {
            "ok": True,
            "enabled": config.enabled,
            "provider": {
                **provider_status(config),
                "actor_model_family": config.actor_model_family,
                "judge_model_family": config.judge_model_family,
            },
            "budgets": {
                "max_tokens_per_task": config.max_tokens_per_task,
                "max_tokens_per_run": config.max_tokens_per_run,
            },
            "memory": {
                "reflect_on_finish": config.memory.reflect_on_finish,
                "dream_on_finish": config.memory.dream_on_finish,
                "dream_on_outcome": config.memory.dream_on_outcome,
                "maintenance_interval_hours": config.memory.maintenance_interval_hours,
                "max_agent_items_per_session": config.memory.max_agent_items_per_session,
                "max_candidate_age_days": config.memory.max_candidate_age_days,
                "require_real_outcome_to_promote": (
                    config.memory.require_real_outcome_to_promote
                ),
                "recall_weights": {
                    "recency": config.memory.recall_recency_weight,
                    "importance": config.memory.recall_importance_weight,
                    "relevance": config.memory.recall_relevance_weight,
                },
            },
            "features": {
                "skills_induce_on_success": config.skills.induce_on_success,
                "skills_inject_top_k": config.skills.inject_top_k,
                "skills_require_replay_to_promote": config.skills.require_replay_to_promote,
                "rerank_enabled": config.rerank.enabled,
                "optimize_enabled": config.optimize.enabled,
                "optimize_targets": config.optimize.targets,
                "selfmod_enabled": config.selfmod.enabled,
                "loop_verify_require_closure": config.loop_verify.require_closure,
            },
            "rerank": {
                "enabled": config.rerank.enabled,
                "order_only": config.rerank.order_only,
                "outcome_boost": config.rerank.outcome_boost,
                "memory_boost": config.rerank.memory_boost,
                "neural_enabled": config.rerank.neural_enabled,
                "neural_model": config.rerank.neural_model,
                "neural_top_k": config.rerank.neural_top_k,
                "require_judge": config.rerank.require_judge,
                "judge_votes": config.rerank.judge_votes,
                "judge_min_pass_rate": config.rerank.judge_min_pass_rate,
            },
            "optimize": {
                "enabled": config.optimize.enabled,
                "targets": config.optimize.targets,
                "holdout_required": config.optimize.holdout_required,
                "impact_risk": current_parameters(self.settings, "impact_risk"),
                "textual_artifacts": current_parameters(
                    self.settings,
                    "textual_artifacts",
                ),
            },
            "selfmod": {
                "enabled": config.selfmod.enabled,
                "allowlist": config.selfmod.allowlist,
                "require_human_approval": config.selfmod.require_human_approval,
                "max_worktrees": config.selfmod.max_worktrees,
                "validation_commands": config.selfmod.validation_commands,
                "require_constitution_gate": config.selfmod.require_constitution_gate,
                "benchmark_command": config.selfmod.benchmark_command,
                "require_benchmark_gate": config.selfmod.require_benchmark_gate,
                "require_judge_gate": config.selfmod.require_judge_gate,
                "judge_votes": config.selfmod.judge_votes,
                "judge_min_pass_rate": config.selfmod.judge_min_pass_rate,
                "recent": archive_rows(
                    self.store.learning_runs(kind="selfmod_variant", limit=10)
                ),
            },
            "optimization": {
                "promoted": archive_rows(self.store.promoted_learning_runs()),
                "recent": archive_rows(self.store.learning_runs(limit=10)),
            },
            "loop_verify": {
                "require_closure": config.loop_verify.require_closure,
                "default_probe": config.loop_verify.default_probe,
                "probe_task": config.loop_verify.probe_task,
            },
            "last_benchmark": self._learning_benchmark_summary(),
            "benchmark_trends": self._learning_benchmark_trends(limit=20),
            "recent_events": recent_events,
        }

    def learning_loop_verify(
        self,
        task: str | None = None,
        *,
        probe: str | None = None,
        require_closure: bool | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return LoopVerifier(
            repo_root=self.repo_root,
            store=self.store,
            workspace_id=self._workspace_id(),
            repo_id=snapshot.repo_id,
        ).run(
            snapshot=snapshot,
            task=task or self.settings.learning.loop_verify.probe_task,
            probe=probe or self.settings.learning.loop_verify.default_probe,
            require_closure=(
                self.settings.learning.loop_verify.require_closure
                if require_closure is None
                else require_closure
            ),
        )

    def learning_optimize(
        self,
        target: str = "pack_weights",
        *,
        iterations: int = 1,
        limit: int = 20,
        holdout_ratio: float = 0.3,
        adopt: bool = False,
    ) -> dict[str, Any]:
        if not self.settings.learning.optimize.enabled:
            return {"ok": False, "reason": "learning optimize is disabled"}
        if target not in self.settings.learning.optimize.targets:
            return {
                "ok": False,
                "reason": "target_not_enabled",
                "target": target,
                "enabled_targets": self.settings.learning.optimize.targets,
            }
        provider = build_agent_provider(
            self.settings,
            repo_root=self.repo_root,
            event_logger=self._learning_event_logger,
        )
        optimizer = ReflectiveOptimizer(
            store=self.store,
            settings=self.settings,
            provider=provider,
            evaluator=self._optimizer_evaluator(
                limit=limit, holdout_ratio=holdout_ratio
            ),
            model_family=self.settings.learning.actor_model_family,
            budget_tokens=self.settings.learning.max_tokens_per_run,
            side_information=self._optimizer_side_information(target),
        )
        return optimizer.optimize(target=target, iterations=iterations, adopt=adopt)

    def learning_archive(
        self, target: str | None = None, limit: int = 20
    ) -> dict[str, Any]:
        return {
            "ok": True,
            "runs": archive_rows(self.store.learning_runs(target=target, limit=limit)),
        }

    def learning_show(self, run_id: str) -> dict[str, Any]:
        row = self.store.learning_run(run_id)
        if row is None:
            raise KeyError(f"learning run not found: {run_id}")
        return {"ok": True, "run": archive_rows([row])[0]}

    def learning_benchmark_trends(self, limit: int = 20) -> dict[str, Any]:
        return {"ok": True, **self._learning_benchmark_trends(limit=limit)}

    def learning_adopt(self, run_id: str) -> dict[str, Any]:
        return self._optimizer().adopt(run_id)

    def learning_revert(self, run_id: str) -> dict[str, Any]:
        return self._optimizer().revert(run_id)

    def learning_rollback(
        self,
        *,
        target: str | None = None,
        run_id: str | None = None,
    ) -> dict[str, Any]:
        if run_id:
            return self.learning_revert(run_id)
        promoted = self.store.promoted_learning_runs()
        if target:
            promoted = [row for row in promoted if row["target"] == target]
        if not promoted:
            raise KeyError(f"promoted learning run not found: {target or 'any'}")
        return self.learning_revert(promoted[0]["run_id"])

    def learning_selfmod_propose(
        self,
        target: str,
        *,
        weakness: str = "",
        ancestor_run_id: str | None = None,
    ) -> dict[str, Any]:
        if not self.settings.learning.selfmod.enabled:
            return {"ok": False, "reason": "learning selfmod is disabled"}
        provider = build_agent_provider(
            self.settings,
            repo_root=self.repo_root,
            event_logger=self._learning_event_logger,
        )
        engine = self._selfmod(provider=provider)
        return engine.propose(
            target=target, weakness=weakness, ancestor_run_id=ancestor_run_id
        )

    def learning_selfmod_archive(
        self,
        *,
        target: str | None = None,
        limit: int = 20,
    ) -> dict[str, Any]:
        return {
            "ok": True,
            "runs": archive_rows(
                self.store.learning_runs(
                    target=target,
                    kind="selfmod_variant",
                    limit=limit,
                )
            ),
        }

    def learning_selfmod_show(self, run_id: str) -> dict[str, Any]:
        row = self.store.learning_run(run_id)
        if row is None:
            raise KeyError(f"learning run not found: {run_id}")
        if row["kind"] != "selfmod_variant":
            raise ValueError("learning run is not a self-mod variant")
        return {"ok": True, "run": archive_rows([row])[0]}

    def learning_selfmod_adopt(
        self,
        run_id: str,
        *,
        approved_by: str = "local-user",
    ) -> dict[str, Any]:
        return self._selfmod().adopt(run_id, approved_by=approved_by)

    def learning_selfmod_revert(self, run_id: str) -> dict[str, Any]:
        return self._selfmod().revert(run_id)

    def learning_selfmod_reject(
        self,
        run_id: str,
        *,
        reason: str = "human rejected",
        rejected_by: str = "local-user",
    ) -> dict[str, Any]:
        return self._selfmod().reject(run_id, reason=reason, rejected_by=rejected_by)

    def self_improve_status(self) -> dict[str, Any]:
        return self.self_improve.status()

    def self_improve_audit(self, *, force: bool = False) -> dict[str, Any]:
        return self.self_improve.audit(force=force)

    def self_improve_brief(self, *, force: bool = False) -> dict[str, Any]:
        return self.self_improve.brief(force=force)

    def self_improve_maybe_run(self) -> dict[str, Any]:
        return self.self_improve.maybe_run()

    def self_improve_capture(
        self,
        *,
        title: str,
        rationale: str,
        target_files: list[str],
        evidence: dict[str, Any] | None = None,
        predicted_effect: dict[str, Any] | None = None,
        parent_id: str | None = None,
    ) -> dict[str, Any]:
        return self.self_improve.capture(
            title=title,
            rationale=rationale,
            target_files=target_files,
            evidence=evidence,
            predicted_effect=predicted_effect,
            parent_id=parent_id,
        )

    def self_improve_list(
        self,
        *,
        run_id: str | None = None,
        status: str | None = None,
        limit: int = 50,
    ) -> dict[str, Any]:
        return self.self_improve.archive(run_id=run_id, status=status, limit=limit)

    def self_improve_show(self, proposal_id: str) -> dict[str, Any]:
        return self.self_improve.show(proposal_id)

    def self_improve_evaluate(
        self, proposal_id: str, *, commands: list[str] | None = None
    ) -> dict[str, Any]:
        return self.self_improve.evaluate(proposal_id, commands=commands)

    def self_improve_adopt(self, proposal_id: str) -> dict[str, Any]:
        return self.self_improve.adopt(proposal_id)

    def self_improve_reject(
        self, proposal_id: str, *, reason: str = ""
    ) -> dict[str, Any]:
        return self.self_improve.reject(proposal_id, reason=reason)

    def self_improve_rollback(
        self, proposal_id: str, *, reason: str = ""
    ) -> dict[str, Any]:
        return self.self_improve.rollback(proposal_id, reason=reason)

    def self_improve_lineage(
        self, *, proposal_id: str | None = None, limit: int = 100
    ) -> dict[str, Any]:
        return self.self_improve.lineage(proposal_id=proposal_id, limit=limit)

    def self_improve_run(
        self,
        *,
        auto: bool = False,
        max_iters: int | None = None,
        budget_tokens: int | None = None,
    ) -> dict[str, Any]:
        return self.self_improve.run(
            auto=auto,
            max_iters=max_iters,
            budget_tokens=budget_tokens,
        )

    def self_improve_doctor(self) -> dict[str, Any]:
        return self.self_improve.doctor()

    def cie_status(self) -> dict[str, Any]:
        return self._cie().status()

    def cie_cycle(
        self,
        limit: int = 20,
        target: str = "cie",
        *,
        task: str = "",
        paths: list[str] | None = None,
    ) -> dict[str, Any]:
        return self._cie().cycle(
            limit=limit, target=target, task=task, paths=paths or []
        )

    def cie_archive(self, target: str | None = None, limit: int = 20) -> dict[str, Any]:
        return self._cie().archive(limit=limit, target=target)

    def cie_show(self, run_id: str) -> dict[str, Any]:
        return self._cie().show(run_id)

    def cie_predict(
        self, task: str = "", paths: list[str] | None = None
    ) -> dict[str, Any]:
        return self._cie().predict(task=task, paths=paths or [])

    def cie_checklist_preview(
        self,
        task: str = "",
        paths: list[str] | None = None,
    ) -> dict[str, Any]:
        return self._cie().checklist_preview(task=task, paths=paths or [])

    def cie_score(self, period: str = "current") -> dict[str, Any]:
        return self._cie().score(period=period)

    def cie_timeline(self, run_id: str | None = None) -> dict[str, Any]:
        return self._cie().timeline(run_id=run_id)

    def cie_preview_adoption(self, run_id: str, intervention_id: str) -> dict[str, Any]:
        return self._cie().preview_adoption(run_id, intervention_id)

    def cie_adopt(
        self, run_id: str, intervention_id: str, approved_by: str
    ) -> dict[str, Any]:
        return self._cie().adopt(run_id, intervention_id, approved_by)

    def cie_reject(
        self,
        run_id: str,
        intervention_id: str,
        reason: str,
        actor: str = "local-user",
    ) -> dict[str, Any]:
        return self._cie().reject(run_id, intervention_id, reason, actor)

    def cie_suspend(
        self,
        run_id: str,
        intervention_id: str,
        reason: str,
        actor: str = "local-user",
    ) -> dict[str, Any]:
        return self._cie().suspend(run_id, intervention_id, reason, actor)

    def cie_rollback(
        self, run_id: str, intervention_id: str, approved_by: str
    ) -> dict[str, Any]:
        return self._cie().rollback(run_id, intervention_id, approved_by)

    def cie_export_state(self, output: str | None = None) -> dict[str, Any]:
        return self._cie().export_state(output=output)

    def cie_import_state(self, input_path: str, dry_run: bool = True) -> dict[str, Any]:
        return self._cie().import_state(input_path=input_path, dry_run=dry_run)

    def cie_rebuild_state(
        self,
        *,
        from_events: bool = True,
        dry_run: bool = True,
    ) -> dict[str, Any]:
        return self._cie().rebuild_state(from_events=from_events, dry_run=dry_run)

    def _cie(self) -> CIEEngine:
        return CIEEngine(
            repo_root=self.repo_root,
            store=self.store,
            settings=self.settings,
            provider=build_agent_provider(
                self.settings,
                repo_root=self.repo_root,
                event_logger=self._learning_event_logger,
            ),
            model_family=self.settings.learning.actor_model_family,
            budget_tokens=self.settings.learning.max_tokens_per_task,
        )

    def _optimizer(self) -> ReflectiveOptimizer:
        return ReflectiveOptimizer(
            store=self.store,
            settings=self.settings,
            provider=build_agent_provider(
                self.settings,
                repo_root=self.repo_root,
                event_logger=self._learning_event_logger,
            ),
            evaluator=self._optimizer_evaluator(),
            model_family=self.settings.learning.actor_model_family,
            budget_tokens=self.settings.learning.max_tokens_per_run,
            side_information=self._optimizer_side_information(""),
        )

    def _selfmod(self, provider: Any | None = None) -> SelfModEngine:
        return SelfModEngine(
            repo_root=self.repo_root,
            store=self.store,
            settings=self.settings,
            provider=provider,
            model_family=self.settings.learning.actor_model_family,
            budget_tokens=self.settings.learning.max_tokens_per_run,
        )

    def _optimizer_evaluator(self, *, limit: int = 20, holdout_ratio: float = 0.3):
        snapshot = self.resolver.resolve()
        cases = self.replay.harvest(limit)
        split_index = max(0, min(len(cases), int(len(cases) * (1 - holdout_ratio))))
        splits = {"train": cases[:split_index], "holdout": cases[split_index:]}

        def evaluate(target: str, params: dict[str, Any], split: str) -> dict[str, Any]:
            if not cases:
                return default_evaluator(target, params, split)
            selected = splits.get(split, splits["holdout"])
            before = current_parameters(self.settings, target)
            apply_parameters(self.settings, target, params)
            try:
                metrics = self.replay._score_cases(snapshot, selected)
            finally:
                apply_parameters(self.settings, target, before)
            return {
                **metrics,
                "success_rate": metrics.get("recall_at_pack", 0.0),
                "missing_files": round(
                    1.0 - float(metrics.get("recall_at_pack", 0.0)), 4
                ),
                "scope_drift": round(
                    1.0 - float(metrics.get("precision_at_pack", 0.0)), 4
                ),
            }

        return evaluate

    def _apply_promoted_optimization_overrides(self) -> None:
        for row in self.store.promoted_learning_runs():
            after = parse_run_json(row["after_json"])
            parameters = after.get("parameters", after)
            try:
                apply_parameters(self.settings, row["target"], parameters)
            except ValueError as exc:
                self._learning_event_logger(
                    "phase4",
                    "promoted_override_rejected",
                    row["run_id"],
                    {"target": row["target"], "error": str(exc)},
                )

    def _learning_benchmark_summary(self) -> dict[str, Any] | None:
        latest = self.store.agent_benchmark_runs(limit=1)
        if latest:
            row = _benchmark_row_dict(latest[0], include_report=False)
            return {
                "benchmark_run_id": row["benchmark_run_id"],
                "readable": True,
                "cases": row["cases"],
                "delta": row["delta"],
                "gate": row["gate"],
                "created_at": row["created_at"],
                "lift_attribution": row["lift_attribution"],
                "roadmap_pruning": row["roadmap_pruning"],
            }
        path = self.workspace_dir / "reports" / "agent-benchmark.json"
        if not path.exists():
            return None
        try:
            report = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {"path": str(path), "readable": False}
        return {
            "path": str(path),
            "readable": True,
            "cases": report.get("cases"),
            "delta": report.get("delta", {}),
            "gate": report.get("gate"),
            "created_at": report.get("created_at"),
        }

    def _learning_benchmark_trends(self, *, limit: int = 20) -> dict[str, Any]:
        rows = [
            _benchmark_row_dict(row, include_report=False)
            for row in self.store.agent_benchmark_runs(limit=limit)
        ]
        latest = rows[0] if rows else None
        oldest = rows[-1] if rows else None
        summary: dict[str, Any] = {"count": len(rows)}
        if latest and oldest:
            summary.update(
                {
                    "latest_success_rate_delta": latest["success_rate_delta"],
                    "success_rate_delta_change": round(
                        float(latest["success_rate_delta"])
                        - float(oldest["success_rate_delta"]),
                        6,
                    ),
                    "latest_scope_drift_reduction": latest[
                        "wrong_files_touched_reduction"
                    ],
                    "latest_context_retrieval_score": latest["context_retrieval_score"],
                    "latest_memory_score": latest["memory_score"],
                    "latest_cut_or_defer_candidates": latest["roadmap_pruning"].get(
                        "cut_or_defer_candidates",
                        [],
                    ),
                }
            )
        return {"summary": summary, "trends": rows}

    def _optimizer_side_information(self, target: str) -> dict[str, Any]:
        latest = self.store.agent_benchmark_runs(limit=1)
        if not latest:
            return {}
        row = _benchmark_row_dict(latest[0], include_report=True)
        report = row.get("report", {})
        return {
            "source": "latest_agent_benchmark",
            "target": target,
            "benchmark_run_id": row["benchmark_run_id"],
            "delta": row["delta"],
            "lift_attribution": row["lift_attribution"],
            "roadmap_pruning": row["roadmap_pruning"],
            "failure_traces": _benchmark_failure_traces(report, limit=8),
        }

    def _benchmark_pack(self, repo_root: Path, task: str) -> dict[str, Any]:
        with CtxLayerService(repo_root) as service:
            return service.get_context_pack(task)

    def _benchmark_preflight(
        self,
        repo_root: Path,
        pack_id: str,
        result: str,
        changed_files: list[str],
    ) -> dict[str, Any]:
        diff = ""
        try:
            completed = subprocess.run(
                ["git", "diff", "HEAD"],
                cwd=repo_root,
                check=True,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                timeout=30,
            )
            diff = completed.stdout
        except (subprocess.SubprocessError, FileNotFoundError):
            diff = ""
        with CtxLayerService(repo_root) as service:
            check = service.check_diff_against_pack(pack_id, diff)
            impact = service.get_impact_report(paths=changed_files, pack_id=pack_id)
            outcome = service.record_outcome(pack_id, result, changed_files)
        return {
            "check_diff": check,
            "impact": impact,
            "outcome": outcome,
        }

    def release_check(self, version: str = "1.0.0") -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        performance_report = self.bench()
        closure_report = self.eval_recall_closure()
        return self.release.check(
            snapshot=snapshot,
            version=version,
            performance_report=performance_report,
            closure_report=closure_report,
        )

    def release_acceptance_gates(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        result = self.release.acceptance_gates(repo_id=snapshot.repo_id)
        result["requirements"] = {
            "benchmark_corpus": FINAL_BENCHMARK_CORPUS_REQUIREMENTS,
        }
        return result

    def release_gap_register(self) -> dict[str, Any]:
        return {"ok": True, "register": default_gap_register()}

    def release_gap_validate(self) -> dict[str, Any]:
        return validate_gap_register(self.repo_root)

    def release_gap_write(self, path: str | None = None) -> dict[str, Any]:
        return write_default_gap_register(
            self.repo_root, path=Path(path) if path else None
        )

    def release_dead_code_inventory_write(
        self, path: str | None = None
    ) -> dict[str, Any]:
        return self.release.write_dead_code_inventory(Path(path) if path else None)

    def release_no_v0_checklist_write(self, path: str | None = None) -> dict[str, Any]:
        return self.release.write_no_v0_release_checklist(Path(path) if path else None)

    def release_report(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.release.report(repo_id=snapshot.repo_id)

    def release_compare(self, baseline: str) -> dict[str, Any]:
        current = self.release_report()
        return self.release.compare(current=current, baseline_path=Path(baseline))

    def ci_check(
        self, base: str = "origin/main", head: str = "HEAD", pack_id: str | None = None
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.ci.check(snapshot=snapshot, base=base, head=head, pack_id=pack_id)

    def constitution_builder(self) -> ConstitutionBuilder:
        return ConstitutionBuilder(
            self.repo_root,
            self.store,
            self.settings,
            workspace_id=stable_id(str(self.repo_root))[:16],
        )

    def constitution_build(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.constitution_builder().build(snapshot.repo_id)

    def constitution_show(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.constitution_builder().latest(snapshot.repo_id)

    def constitution_check(
        self,
        paths: list[str] | None = None,
        *,
        staged: bool = False,
        task_session_id: str | None = None,
        for_ci: bool = False,
    ) -> dict[str, Any]:
        changed = paths or []
        deleted: list[str] = []
        if staged:
            changed = git_changed_paths(self.repo_root, staged=True)
            deleted = git_deleted_paths(self.repo_root, staged=True)
        elif not changed:
            changed = git_changed_paths(self.repo_root)
            deleted = git_deleted_paths(self.repo_root)
        return CapabilityPolicy(self.repo_root, self.settings).check_paths(
            changed,
            deleted_paths=deleted,
            task_session_id=task_session_id,
            for_ci=for_ci,
        )

    def task_governance(self) -> TaskGovernance:
        snapshot = self.resolver.resolve()
        return TaskGovernance(
            self.repo_root,
            self.store,
            self.settings,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
        )

    def task_start(self, task: str) -> dict[str, Any]:
        constitution = self.constitution_show()
        result = self.task_governance().start(
            task=task,
            constitution_hash=constitution["constitution_hash"],
            metadata={"objective": task, "task": task},
        )
        session = self._ensure_agent_session(
            task,
            metadata={
                "task_session_id": result["task_session_id"],
                "constitution_hash": result["constitution_hash"],
                "source": "task_start",
            },
        )
        self._record_agent_session_event(
            session["session_id"],
            "task_session",
            {
                "task_session_id": result["task_session_id"],
                "state": result["state"],
                "constitution_hash": result["constitution_hash"],
                "objective": task,
            },
        )
        self._continuation_memory().upsert_for_task_session(
            result["task_session_id"],
            agent_session_id=session["session_id"],
            event="task_start",
            state="intake",
            next_action="Request or serve a CTX Layer context pack for this task.",
        )
        result["agent_session_id"] = session["session_id"]
        return result

    def task_transition(
        self,
        task_session_id: str,
        state: str,
        *,
        actor: str = "local-user",
        reason: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        constitution_hash = None
        if pack_id:
            constitution_hash = self.get_pack_manifest(pack_id).get("constitution_hash")
        result = self.task_governance().transition(
            task_session_id,
            state,
            actor=actor,
            reason=reason,
            pack_id=pack_id,
            constitution_hash=constitution_hash,
        )
        session_id = self._session_id_for_task_session(task_session_id)
        if session_id:
            self._record_agent_session_event(
                session_id,
                "task_transition",
                {
                    "task_session_id": task_session_id,
                    "transition_id": result["transition_id"],
                    "from_state": result["from_state"],
                    "to_state": result["to_state"],
                    "actor": actor,
                    "reason": reason,
                    "pack_id": pack_id,
                    "constitution_hash": constitution_hash,
                },
            )
            self._continuation_memory().upsert_for_task_session(
                task_session_id,
                agent_session_id=session_id,
                event="task_transition",
                state=_continuation_state_for_task_state(state),
                reason=reason,
            )
            result["agent_session_id"] = session_id
        if state.strip().upper() == "OUTCOME":
            result["task_learning"] = self.consolidate_task(
                task_session_id,
                trigger="task_transition",
            )
        return result

    def task_show(self, task_session_id: str) -> dict[str, Any]:
        return self.task_governance().show(task_session_id)

    def task_learning_report(self, task_session_id: str) -> dict[str, Any]:
        task = self.store.task_session(task_session_id)
        if not task:
            return {
                "ok": False,
                "error": "task session not found",
                "task_session_id": task_session_id,
            }
        summary_row = self.store.task_learning_summary(task_session_id)
        summary = self._task_learning_summary_dict(summary_row) if summary_row else None
        session_ids = (
            summary["session_ids"]
            if summary
            else self._agent_session_ids_for_task(task_session_id)
        )
        events = self._task_related_learning_events(task_session_id, session_ids)
        record_refs = summary.get("record_refs", {}) if summary else {}
        proposed_ids = [str(item) for item in record_refs.get("proposed", []) if item]
        promoted_ids = [str(item) for item in record_refs.get("promoted", []) if item]
        stale_ids = [str(item) for item in record_refs.get("stale", []) if item]
        signals = self._task_learning_signal_items(events)
        stale_ids.extend(item["record_id"] for item in signals["stale_marked"])
        skills = [
            self._skill_report_item(str(item))
            for item in record_refs.get("skills", [])
            if item
        ]
        skills = self._dedupe_report_items(
            [*signals["skills_induced"], *skills], "skill_id"
        )
        conflicts = self._dedupe_report_items(
            [
                *[
                    {"conflict_id": str(item)}
                    for item in record_refs.get("conflicts", [])
                    if item
                ],
                *signals["conflicts_found"],
            ],
            "conflict_id",
        )
        stale_items = self._dedupe_report_items(
            [self._memory_report_item(record_id) for record_id in stale_ids],
            "record_id",
        )
        learned = {
            "memories_proposed": [
                self._memory_report_item(record_id) for record_id in proposed_ids
            ],
            "memories_promoted": [
                self._memory_report_item(record_id) for record_id in promoted_ids
            ],
            "skills_induced": skills,
            "skills_evolved": [],
            "conflicts_found": conflicts,
            "stale_marked": stale_items,
        }
        counts = dict(summary.get("counts", {}) if summary else {})
        derived_counts = {
            "skills_induced": len(skills),
            "conflicts_found": len(conflicts),
            "stale_marked": len(stale_items),
        }
        for key, value in derived_counts.items():
            if value:
                counts[key] = max(int(counts.get(key) or 0), value)
        nothing = not any(
            len(value) for value in learned.values() if isinstance(value, list)
        )
        metadata = _json_dict(task["metadata_json"])
        narrative = (
            summary.get("narrative")
            if summary
            else "CTX has not consolidated this task yet."
        )
        if summary and counts != summary.get("counts", {}):
            narrative = _learning_narrative(counts)
        if nothing:
            narrative = narrative or "CTX did not learn anything new from this task."
        guardrails = self._guardrail_task_report(events)
        return {
            "ok": True,
            "task_session_id": task_session_id,
            "task": metadata.get("objective") or metadata.get("task"),
            "consolidated_at": summary.get("consolidated_at") if summary else None,
            "sessions": session_ids,
            "counts": counts,
            "learned": learned,
            "guardrails": guardrails,
            "events": events,
            "nothing_learned": nothing,
            "narrative": narrative,
        }

    def learning_recent(self, limit: int = 20) -> dict[str, Any]:
        rows = self.store.task_learning_summaries(limit=limit)
        return {
            "ok": True,
            "tasks": [self._task_learning_summary_dict(row) for row in rows],
        }

    def _memory_report_item(self, record_id: str) -> dict[str, Any]:
        row = self.store.memory_record(record_id)
        if not row:
            return {"record_id": record_id, "status": "missing"}
        return {
            "record_id": record_id,
            "type": row["type"],
            "assertion": row["assertion"],
            "status": row["status"],
            "confidence": float(row["confidence"]),
        }

    def _skill_report_item(
        self, skill_id: str, fallback: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        row = self.store.skill(skill_id)
        if not row:
            return {
                "skill_id": skill_id,
                "name": (fallback or {}).get("name"),
                "status": (fallback or {}).get("status", "missing"),
                "trust": (fallback or {}).get("trust"),
            }
        return {
            "skill_id": skill_id,
            "name": row["name"],
            "description": row["nl_description"],
            "status": row["status"],
            "trust": row["trust"],
        }

    def _dedupe_report_items(
        self, items: list[dict[str, Any]], key: str
    ) -> list[dict[str, Any]]:
        deduped: list[dict[str, Any]] = []
        seen: set[str] = set()
        for item in items:
            value = item.get(key)
            if not value:
                value = canonical_json(item)
            marker = str(value)
            if marker in seen:
                continue
            seen.add(marker)
            deduped.append(item)
        return deduped

    def _guardrail_task_report(self, events: list[dict[str, Any]]) -> dict[str, Any]:
        decisions = []
        overrides = []
        suspended = []
        for event in events:
            payload = event.get("payload", {})
            if event.get("kind") == "guardrail_decision":
                decisions.append(payload)
            elif event.get("kind") == "guardrail_override":
                overrides.append(payload)
            elif event.get("kind") == "directive_suspended":
                suspended.append(payload)
        return {
            "decisions": decisions,
            "overrides": overrides,
            "suspended": suspended,
            "counts": {
                "allow": sum(
                    1 for item in decisions if item.get("decision") == "allow"
                ),
                "warn": sum(1 for item in decisions if item.get("decision") == "warn"),
                "block": sum(
                    1 for item in decisions if item.get("decision") == "block"
                ),
                "overrides": len(overrides),
                "suspended": len(suspended),
                "degraded": sum(
                    1 for item in decisions if item.get("guardrail_degraded")
                ),
            },
        }

    def loop_runbook(
        self,
        task: str,
        paths: list[str],
        tests: list[str] | None = None,
        result: str = "pass",
    ) -> dict[str, Any]:
        return core_loop_runbook(task=task, paths=paths, tests=tests, result=result)

    def task_plan_governance(
        self, *, repo_id: str | None = None, resolve_repo: bool = True
    ) -> TaskPlanGovernance:
        if repo_id is None and resolve_repo:
            repo_id = self.resolver.resolve().repo_id
        return TaskPlanGovernance(
            self.repo_root,
            self.store,
            self.settings,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=repo_id,
        )

    def plan_validate(
        self,
        plan: dict[str, Any],
        *,
        task_session_id: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        impact_report = self._plan_impact_report(plan, pack_id)
        behavior_report = self._plan_behavior_report(plan, pack_id)
        repo_id = self._pack_snapshot(pack_id).repo_id if pack_id else None
        return self.task_plan_governance(repo_id=repo_id, resolve_repo=False).validate(
            plan,
            task_session_id=task_session_id,
            pack_id=pack_id,
            impact_report=impact_report,
            behavior_report=behavior_report,
        )

    def plan_create(
        self,
        task_session_id: str,
        plan: dict[str, Any],
        *,
        pack_id: str | None = None,
        author: str = "local-user",
    ) -> dict[str, Any]:
        impact_report = self._plan_impact_report(plan, pack_id)
        behavior_report = self._plan_behavior_report(plan, pack_id)
        repo_id = self._pack_snapshot(pack_id).repo_id if pack_id else None
        result = self.task_plan_governance(repo_id=repo_id).create(
            task_session_id=task_session_id,
            plan=plan,
            pack_id=pack_id,
            author=author,
            impact_report=impact_report,
            behavior_report=behavior_report,
        )
        if result.get("ok"):
            session_id = self._session_id_for_task_session(task_session_id)
            if session_id:
                self._record_agent_session_event(
                    session_id,
                    "plan_created",
                    {
                        "task_session_id": task_session_id,
                        "plan_id": result["plan_id"],
                        "revision_id": result["revision_id"],
                        "revision_number": result["revision_number"],
                        "plan_hash": result["plan_hash"],
                        "pack_id": pack_id,
                        "author": author,
                        "intended_files": intended_files(result["plan"]),
                    },
                )
                self._continuation_memory(repo_id).upsert_for_task_session(
                    task_session_id,
                    agent_session_id=session_id,
                    event="plan_created",
                    state="planned",
                    reason=f"plan created: {result['plan_id']}",
                )
                result["agent_session_id"] = session_id
        return result

    def plan_amend(
        self,
        plan_id: str,
        plan: dict[str, Any],
        *,
        author: str = "local-user",
        reason: str | None = None,
    ) -> dict[str, Any]:
        impact_report = self._plan_impact_report(plan, None)
        behavior_report = self._plan_behavior_report(plan, None)
        result = self.task_plan_governance(resolve_repo=False).amend(
            plan_id=plan_id,
            plan=plan,
            author=author,
            reason=reason,
            impact_report=impact_report,
            behavior_report=behavior_report,
        )
        if result.get("ok"):
            session_id = self._session_id_for_plan(plan_id)
            if session_id:
                self._record_agent_session_event(
                    session_id,
                    "plan_amended",
                    {
                        "plan_id": plan_id,
                        "revision_id": result["revision_id"],
                        "revision_number": result["revision_number"],
                        "plan_hash": result["plan_hash"],
                        "previous_plan_hash": result["previous_plan_hash"],
                        "author": author,
                        "reason": reason,
                        "intended_files": intended_files(result["plan"]),
                    },
                )
                row = self.store.task_plan(plan_id)
                if row and row["task_session_id"]:
                    self._continuation_memory(row["repo_id"]).upsert_for_task_session(
                        row["task_session_id"],
                        agent_session_id=session_id,
                        event="plan_amended",
                        state="planned",
                        reason=reason or f"plan amended: {plan_id}",
                    )
                result["agent_session_id"] = session_id
        return result

    def plan_show(self, plan_id: str) -> dict[str, Any]:
        return self.task_plan_governance(resolve_repo=False).show(plan_id)

    def plan_checkpoint(
        self,
        plan_id: str,
        step_id: str,
        *,
        paths: list[str] | None = None,
        staged: bool = False,
    ) -> dict[str, Any]:
        changed_paths = paths or []
        if staged:
            changed_paths = git_changed_paths(self.repo_root, staged=True)
        elif not changed_paths:
            changed_paths = git_changed_paths(self.repo_root)
        result = self.task_plan_governance(resolve_repo=False).checkpoint(
            plan_id=plan_id,
            step_id=step_id,
            changed_paths=changed_paths,
        )
        session_id = self._session_id_for_plan(plan_id)
        if session_id:
            self._record_agent_session_event(
                session_id,
                "plan_checkpoint",
                {
                    "checkpoint_id": result["checkpoint_id"],
                    "plan_id": result["plan_id"],
                    "step_id": result["step_id"],
                    "status": result["status"],
                    "ok": result["ok"],
                    "changed_paths": result["changed_paths"],
                    "violation_count": len(result["violations"]),
                },
            )
            row = self.store.task_plan(plan_id)
            if row and row["task_session_id"]:
                self._continuation_memory(row["repo_id"]).upsert_for_task_session(
                    row["task_session_id"],
                    agent_session_id=session_id,
                    event="plan_checkpoint",
                    state="editing" if result["ok"] else "blocked",
                    blockers=(
                        []
                        if result["ok"]
                        else [
                            f"Checkpoint {step_id} failed with {len(result['violations'])} violation(s)."
                        ]
                    ),
                    reason=f"checkpoint {result['status']}: {step_id}",
                )
            result["agent_session_id"] = session_id
        return result

    def _plan_impact_report(
        self, plan: dict[str, Any], pack_id: str | None
    ) -> dict[str, Any] | None:
        normalized, _errors = normalize_plan(plan)
        paths = intended_files(normalized)
        if not paths:
            return None
        if pack_id:
            return self.impact.report(
                snapshot=self._pack_snapshot(pack_id),
                paths=paths,
                pack_id=pack_id,
            )
        return self.get_impact_report(paths=paths, pack_id=pack_id)

    def _plan_behavior_report(
        self, plan: dict[str, Any], pack_id: str | None
    ) -> dict[str, Any] | None:
        normalized, _errors = normalize_plan(plan)
        paths = intended_files(normalized)
        if not paths:
            return None
        snapshot = self._pack_snapshot(pack_id) if pack_id else self.resolver.resolve()
        return self.behavior.check(snapshot=snapshot, paths=paths, pack_id=pack_id)

    def _pack_snapshot(self, pack_id: str) -> SnapshotInfo:
        manifest = self.get_pack_manifest(pack_id)
        return SnapshotInfo(
            repo_id=manifest["repo_id"],
            snapshot_id=manifest["snapshot_id"],
            base_commit_sha=manifest.get("base_commit_sha", ""),
            tree_digest=manifest.get("tree_digest", ""),
            dirty_digest=manifest.get("dirty_digest", ""),
            worktree_state=manifest.get("worktree_state", ""),
            branch_hint=manifest.get("branch_hint"),
        )

    def ci_emit_github(self, report: dict[str, Any] | None = None) -> dict[str, Any]:
        return {
            "ok": True,
            "workflow": GITHUB_ACTION_YAML,
            "annotations": github_annotations(report or {}),
        }

    def ci_emit_gitlab(self, report: dict[str, Any] | None = None) -> dict[str, Any]:
        return {
            "ok": True,
            "workflow": GITLAB_CI_YAML,
            "annotations": gitlab_annotations(report or {}),
        }

    def ci_explain(self, report_path: str) -> dict[str, Any]:
        report = json.loads(Path(report_path).read_text(encoding="utf-8"))
        return {"ok": True, "explanation": self.ci.explain(report)}

    def workspace_init(self) -> dict[str, Any]:
        return self.workspace.init()

    def workspace_add_repo(self, repo_path: str) -> dict[str, Any]:
        return self.workspace.add_repo(repo_path)

    def workspace_index(self) -> dict[str, Any]:
        return self.workspace.index()

    def workspace_impact(self, repo_id: str) -> dict[str, Any]:
        return self.workspace.impact(repo_id)

    def workspace_status(self) -> dict[str, Any]:
        return self.workspace.status()

    def workspace_rule_promotions(self) -> dict[str, Any]:
        return self.workspace.rule_promotions()

    def behavior_check(
        self,
        paths: list[str] | None = None,
        *,
        diff: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        input_paths = paths or []
        if diff:
            input_paths.extend(paths_from_diff(diff))
        elif not input_paths:
            input_paths = git_changed_paths(self.repo_root)
        return self.behavior.check(
            snapshot=snapshot,
            paths=input_paths,
            diff=diff,
            pack_id=pack_id,
        )

    def verify_run(
        self,
        commands: list[str],
        *,
        pack_id: str | None = None,
        plan_id: str | None = None,
        name: str | None = None,
        retry_budget: int = 0,
        timeout: int = 120,
        reproduction_command: str | None = None,
        context_decision: str | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        result = VerificationRunner(self.repo_root, self.compiler).run(
            snapshot=snapshot,
            commands=commands,
            pack_id=pack_id,
            retry_budget=retry_budget,
            timeout=timeout,
            reproduction_command=reproduction_command,
            context_decision=context_decision,
        )
        session_id = self._session_id_for_pack(pack_id) if pack_id else None
        task_session_id = self._task_session_id_for_agent_session(session_id)
        if not plan_id and task_session_id:
            plan = self.store.latest_task_plan_for_session(task_session_id)
            plan_id = plan["plan_id"] if plan else None
        verification_name = name or _verification_name(commands)
        persisted = self.store.write_task_verification(
            task_session_id=task_session_id,
            plan_id=plan_id,
            name=verification_name,
            command=" && ".join(commands),
            status="pass" if result.get("ok") else str(result.get("status") or "fail"),
            report=result,
        )
        result["task_verification"] = persisted
        if session_id:
            self._record_agent_session_event(
                session_id,
                "verification",
                {
                    "verification_id": result["verification_id"],
                    "task_verification_id": persisted["verification_id"],
                    "plan_id": plan_id,
                    "task_session_id": task_session_id,
                    "name": verification_name,
                    "pack_id": pack_id,
                    "status": result["status"],
                    "ok": result["ok"],
                    "commands": commands,
                    "retry_budget": retry_budget,
                    "failure_count": len(result.get("failures", [])),
                    "repair_pack_id": (result.get("repair_pack") or {}).get("pack_id"),
                },
            )
            result["agent_session_id"] = session_id
            if not result.get("ok"):
                result["anticipation_update"] = self._observe_anticipation_signal(
                    session_id=session_id,
                    signal_kind="test_failure",
                    task_session_id=task_session_id,
                    target_paths=git_changed_paths(self.repo_root),
                    magnitude=1.0,
                )
        return result

    def security_scan(self) -> dict[str, Any]:
        return SecretScanner(self.repo_root).scan()

    def security_status(self) -> dict[str, Any]:
        last_redteam = None
        for row in self.store.learning_events(limit=100):
            if row["kind"] != "redteam_run":
                continue
            try:
                payload = json.loads(row["payload_json"] or "{}")
            except json.JSONDecodeError:
                payload = {}
            last_redteam = {**dict(row), "payload": payload}
            break
        return {
            "ok": True,
            "encryption": encryption_status(
                self.workspace_dir / "workspace.db",
                self.settings.security.encrypt_workspace_db,
            ),
            "retention": retention_policy(
                self.settings.audit.retention_keep_days,
                self.settings.audit.retention_keep_abandoned_days,
                self.settings.audit.retention_keep_merged,
            ),
            "privacy": privacy_statement(),
            "ingest": {
                "default_deny": self.settings.security.ingest.default_deny,
                "sanitize": self.settings.security.ingest.sanitize,
                "anomaly_threshold": self.settings.security.ingest.anomaly_threshold,
                "reviewer_min_role": self.settings.security.ingest.reviewer_min_role,
                "last_redteam": last_redteam,
            },
        }

    def security_ingest_redteam(
        self,
        fixtures: str | None = None,
        *,
        output: str | None = None,
        strict: bool = False,
    ) -> dict[str, Any]:
        fixtures_path = self.repo_root / (
            fixtures or self.settings.security.ingest.redteam_fixture_dir
        )
        output_path = self.repo_root / output if output else None
        report = RedTeamRunner(fixtures_path).run(output=output_path, strict=strict)
        self.store.write_learning_event(
            phase="phase_h4",
            kind="redteam_run",
            ref=report["redteam_run_id"],
            payload={
                "total": report["total"],
                "attacks": report["attacks"],
                "quarantined": report["quarantined"],
                "denied": report["denied"],
                "served_authoritative_count": report["served_authoritative_count"],
                "false_quarantine_rate": report["false_quarantine_rate"],
                "ok": report["ok"],
            },
        )
        return report

    def memory(self) -> BusinessRuleMemory:
        snapshot = self.resolver.resolve()
        return BusinessRuleMemory(
            self.repo_root,
            self.store,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
            approval_config=self.settings.memory.approval,
        )

    def memory_candidates(self, status: str | None = None) -> dict[str, Any]:
        if status:
            return self.memory().list(status)
        return self.memory().extract_candidates()

    def memory_scan(self) -> dict[str, Any]:
        return self.memory().scan()

    def memory_list(self, status: str | None = None) -> dict[str, Any]:
        return self.memory().list(status)

    def memory_approve(
        self, rule_id: str, approved_by: str = "local-user"
    ) -> dict[str, Any]:
        return self.memory().approve(rule_id, approved_by)

    def memory_reject(self, rule_id: str) -> dict[str, Any]:
        return self.memory().reject(rule_id)

    def memory_conflicts(self) -> dict[str, Any]:
        return self.memory().conflicts()

    def memory_explain(self, candidate_or_rule_id: str) -> dict[str, Any]:
        return self.memory().explain(candidate_or_rule_id)

    def memory_supersede(
        self, old_rule_id: str, new_candidate_id: str, approved_by: str = "local-user"
    ) -> dict[str, Any]:
        return self.memory().supersede(old_rule_id, new_candidate_id, approved_by)

    def memory_stale(self) -> dict[str, Any]:
        return self.memory().stale()

    def memory_verify(self) -> dict[str, Any]:
        return self.memory().verify()

    def memory_eval(self, action: str) -> dict[str, Any]:
        memory = self.memory()
        if action == "harvest":
            return memory.eval_harvest()
        if action == "replay":
            return memory.eval_replay()
        if action == "report":
            return memory.eval_report()
        raise ValueError(f"unknown memory eval action: {action}")

    def memory_extraction_eval(
        self, fixtures: str | None = None, source_type: str | None = None
    ) -> dict[str, Any]:
        return self.memory().extraction_eval(fixtures=fixtures, source_type=source_type)

    def memory_trust_calibrate(self, *, apply: bool = False) -> dict[str, Any]:
        return self.memory().trust_calibrate(apply=apply)

    def unified_memory(self) -> UnifiedMemory:
        return UnifiedMemory(
            self.store,
            workspace_id=self._memory_workspace_id,
            repo_id=self._memory_repo_id,
            recall_weights=self._learning_recall_weights(),
            embedder=self.compiler.embedder,
            stale_penalty=self.settings.memory.stale_penalty,
            conflict_penalty=self.settings.memory.conflict_penalty,
            stale_confidence_floor=self.settings.memory.stale_confidence_floor,
            vector_fallback_limit=self.settings.retrieval.vector_fallback_limit,
            memory_vector_index=self.settings.storage.memory_vector_index,
        )

    def _episodic_memory(self) -> EpisodicMemory:
        return EpisodicMemory(
            self.store,
            workspace_id=self._memory_workspace_id,
            repo_id=self._memory_repo_id,
            memory=self.unified_memory(),
            repo_root=self.repo_root,
        )

    def memory_search(
        self, query: str, types: list[str] | None = None, status: str | None = None
    ) -> dict[str, Any]:
        return self.unified_memory().search(query, types=types, status=status)

    def memory_records(
        self, status: str | None = None, types: list[str] | None = None
    ) -> dict[str, Any]:
        memory = self.unified_memory()
        rows = self.store.memory_records(
            status=status,
            repo_id=memory.repo_id,
            workspace_id=memory.workspace_id,
        )
        allowed_types = set(types or [])
        return {
            "ok": True,
            "records": [
                memory._project_row(row)
                for row in rows
                if not allowed_types or row["type"] in allowed_types
            ],
        }

    def memory_show(self, record_id: str) -> dict[str, Any]:
        row = self.store.memory_record(record_id)
        if not row:
            return {"ok": False, "error": "memory not found", "record_id": record_id}
        memory = self.unified_memory()
        return {
            "ok": True,
            "record": memory._project_row(row),
            "evidence": [dict(item) for item in self.store.memory_evidence(record_id)],
            "revisions": [
                dict(item) for item in self.store.memory_revisions(record_id)
            ],
        }

    def memory_propose(
        self,
        record_type: str,
        assertion: str,
        evidence_refs: list[dict[str, Any]] | None = None,
        source_kind: str = "manual",
        confidence: float = 1.0,
    ) -> dict[str, Any]:
        record_id = self.unified_memory().propose(
            record_type=record_type,
            assertion=assertion,
            source_kind=source_kind,
            confidence=confidence,
            extraction_method="manual",
            evidence=evidence_refs or [],
            status="candidate",
        )
        return {"ok": True, "record_id": record_id, "status": "candidate"}

    def memory_create_typed(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.unified_memory().create_typed(payload)

    def memory_update(
        self,
        record_id: str,
        patch: dict[str, Any],
        reason: str = "manual update",
        actor: str = "local-user",
    ) -> dict[str, Any]:
        return self.unified_memory().update(
            record_id, patch, actor=actor, reason=reason
        )

    def memory_enforce(
        self,
        record_id: str,
        *,
        level: str = "warn",
        severity: str = "medium",
        scope: list[str] | None = None,
        anti_patterns: list[str] | None = None,
        required_patterns: list[str] | None = None,
        remediation: str | None = None,
        rationale: str | None = None,
        approve: bool = False,
        approved_by: str = "local-user",
        status: str = "active",
        source: str = "manual",
    ) -> dict[str, Any]:
        row = self.store.memory_record(record_id)
        if not row:
            return {"ok": False, "error": "memory not found", "record_id": record_id}
        approver = approved_by if approve else None
        directive_id = self.store.upsert_memory_enforcement(
            record_id=record_id,
            repo_id=row["repo_id"],
            enforcement_level=level,
            severity=severity,
            path_globs=scope or [],
            anti_patterns=anti_patterns or [],
            required_patterns=required_patterns or [],
            rationale=rationale or row["assertion"],
            remediation=remediation,
            status=status,
            approved_by=approver,
            source=source,
        )
        directive = self.store.memory_enforcement(directive_id)
        self._learning_event_logger(
            "phase_g1",
            "memory_enforcement_upserted",
            directive_id,
            {
                "directive_id": directive_id,
                "record_id": record_id,
                "level": level,
                "severity": severity,
                "status": status,
                "source": source,
            },
        )
        return {
            "ok": True,
            "directive": _memory_enforcement_dict(directive) if directive else None,
        }

    def memory_enforcements(
        self,
        *,
        status: str | None = None,
        paths: list[str] | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        if paths:
            directives = self.store.directives_for_paths(paths, snapshot.repo_id)
            return {
                "ok": True,
                "directives": [_memory_enforcement_dict(item) for item in directives],
            }
        rows = self.store.memory_enforcements(repo_id=snapshot.repo_id, status=status)
        return {
            "ok": True,
            "directives": [_memory_enforcement_dict(row) for row in rows],
        }

    def memory_unenforce(
        self,
        directive_id: str,
        *,
        reason: str = "manual suspend",
        actor: str = "local-user",
    ) -> dict[str, Any]:
        ok = self.store.update_memory_enforcement_status(
            directive_id, status="suspended", reason=reason
        )
        if not ok:
            return {
                "ok": False,
                "error": "directive not found",
                "directive_id": directive_id,
            }
        self._learning_event_logger(
            "phase_g1",
            "directive_suspended",
            directive_id,
            {"directive_id": directive_id, "actor": actor, "reason": reason},
        )
        return {
            "ok": True,
            "directive": _memory_enforcement_dict(
                self.store.memory_enforcement(directive_id)
            ),
        }

    def applicable_guardrails(self, paths: list[str]) -> dict[str, Any]:
        if (
            not self.settings.guardrails.enabled
            or not self.settings.guardrails.plan_time_check
        ):
            return {"ok": True, "applicable_guardrails": []}
        snapshot = self.resolver.resolve()
        return {
            "ok": True,
            "applicable_guardrails": [
                _memory_enforcement_dict(item)
                for item in self.store.directives_for_paths(paths, snapshot.repo_id)
            ],
        }

    def guardrail_override(
        self,
        directive_id: str,
        *,
        rationale: str,
        task_session_id: str | None = None,
        session_id: str | None = None,
        target_paths: list[str] | None = None,
        actor: str = "local-user",
    ) -> dict[str, Any]:
        if self.settings.guardrails.override_audit_required and not rationale.strip():
            return {"ok": False, "error": "guardrail override requires rationale"}
        directive = self.store.memory_enforcement(directive_id)
        if not directive:
            return {
                "ok": False,
                "error": "directive not found",
                "directive_id": directive_id,
            }
        override_id = stable_id(
            "guardrail_override",
            directive_id,
            task_session_id or "",
            session_id or "",
            rationale,
            utc_now(),
        )
        payload = {
            "override_id": override_id,
            "directive_id": directive_id,
            "record_id": directive["record_id"],
            "task_session_id": task_session_id,
            "session_id": session_id,
            "target_paths": [_normalize_path(path) for path in target_paths or []],
            "actor": actor,
            "rationale": rationale,
            "uses_remaining": 1,
        }
        self._learning_event_logger(
            "phase_g3", "guardrail_override", directive_id, payload
        )
        return {"ok": True, **payload}

    def memory_validate(
        self,
        record_id: str,
        validator: str,
        evidence: dict[str, Any] | None = None,
        actor: str = "local-user",
    ) -> dict[str, Any]:
        return self.unified_memory().validate(
            record_id,
            validator=validator,
            evidence=evidence,
            actor=actor,
        )

    def memory_expire(
        self, record_id: str, reason: str, actor: str = "local-user"
    ) -> dict[str, Any]:
        return self.unified_memory().expire(record_id, reason=reason, actor=actor)

    def memory_quarantine(
        self,
        record_id: str,
        reason: str,
        severity: str = "high",
        actor: str = "codeowner",
    ) -> dict[str, Any]:
        return self.unified_memory().quarantine(
            record_id,
            reason=reason,
            severity=severity,
            actor=actor,
        )

    def memory_diff(
        self,
        record_id: str,
        revision_a: str | None = None,
        revision_b: str | None = None,
    ) -> dict[str, Any]:
        return self.unified_memory().diff(record_id, revision_a, revision_b)

    def memory_security_reviews(self, status: str | None = "open") -> dict[str, Any]:
        return {
            "ok": True,
            "reviews": [dict(row) for row in self.store.memory_review_queue(status)],
        }

    def memory_review_resolve(
        self,
        review_id: str,
        *,
        resolution: str,
        actor: str = "admin",
        target_record_id: str | None = None,
        validator: str = "human:security-review",
        reason: str = "security review resolved",
    ) -> dict[str, Any]:
        authorization = require_actor_role(actor, "codeowner", "memory_review_resolve")
        if not authorization["ok"]:
            raise PermissionError(
                f"memory_review_resolve requires {authorization['required_role']} role; "
                f"{authorization['actor']} is {authorization['actor_role']}"
            )
        review = self.store.memory_review(review_id)
        if not review:
            raise KeyError(f"memory review not found: {review_id}")
        record_id = str(review["record_id"])
        normalized = resolution.strip().lower().replace("-", "_")
        if normalized in {"approve", "approved", "release"}:
            action_result = self.memory_validate(record_id, validator, actor=actor)
            review_status = "resolved"
        elif normalized in {"delete", "reject", "rejected"}:
            self.unified_memory().reject(record_id, actor=actor)
            action_result = {"ok": True, "record_id": record_id, "status": "rejected"}
            review_status = "resolved"
        elif normalized in {"merge", "supersede"}:
            if not target_record_id:
                raise ValueError("merge review resolution requires target_record_id")
            self.unified_memory().supersede(record_id, target_record_id, actor=actor)
            action_result = {
                "ok": True,
                "record_id": record_id,
                "status": "superseded",
                "superseded_by": target_record_id,
            }
            review_status = "resolved"
        elif normalized in {"keep_quarantined", "keep", "quarantine"}:
            action_result = {
                "ok": True,
                "record_id": record_id,
                "status": "quarantined",
            }
            review_status = "resolved"
        else:
            raise ValueError(
                "resolution must be approve, delete, merge, or keep_quarantined"
            )
        resolution_payload = {
            "action": normalized,
            "actor": actor,
            "actor_role": authorization["actor_role"],
            "reason": reason,
            "target_record_id": target_record_id,
            "result": action_result,
        }
        self.store.resolve_memory_review(
            review_id=review_id,
            status=review_status,
            resolution=resolution_payload,
        )
        resolved = self.store.memory_review(review_id)
        return {
            "ok": True,
            "review": dict(resolved) if resolved else {"review_id": review_id},
            "resolution": resolution_payload,
            "record": self.memory_show(record_id).get("record"),
        }

    def memory_recall(
        self,
        query: str,
        paths: list[str] | None = None,
        types: list[str] | None = None,
        limit: int = 20,
        include_org: bool = False,
    ) -> dict[str, Any]:
        start = time.perf_counter()
        try:
            with self.store.budget(self.settings.reliability.memory_recall_budget_ms):
                result = self.unified_memory().recall(
                    query,
                    paths=paths,
                    types=types,
                    limit=limit,
                    include_org=include_org,
                )
        except CtxBudgetExceeded:
            elapsed_ms = (time.perf_counter() - start) * 1000
            health = self.ctx_health(
                last_recall_ms=elapsed_ms,
                unavailable_reason="memory_recall_budget_exceeded",
            )
            return {
                "ok": False,
                "schema_version": "ctxlayer.memory_recall.v1",
                "status": "degraded",
                "reason": "budget_exceeded",
                "query": query,
                "items": [],
                "records": [],
                "ctx_health": health,
                "low_confidence": True,
            }
        elapsed_ms = (time.perf_counter() - start) * 1000
        health = self.ctx_health(last_recall_ms=elapsed_ms)
        if isinstance(result, dict):
            result.setdefault(
                "status", "ok" if health["status"] == "ok" else "degraded"
            )
            result["ctx_health"] = health
            result["measured_ms"] = round(elapsed_ms, 2)
        return result

    def memory_graph(
        self, record_id: str, *, max_hops: int = 2, limit: int = 50
    ) -> dict[str, Any]:
        row = self.store.memory_record(record_id)
        if not row:
            return {"ok": False, "error": "memory not found", "record_id": record_id}
        walk = self.store.memory_graph_walk(
            workspace_id=row["workspace_id"],
            repo_id=row["repo_id"],
            start_record_ids=[record_id],
            max_hops=max_hops,
            limit=limit,
        )
        edges = [
            {
                **item,
                "record": (
                    self.unified_memory()._project_row(target)
                    if (target := self.store.memory_record(str(item["record_id"])))
                    else None
                ),
            }
            for item in walk
        ]
        return {
            "ok": True,
            "schema_version": "ctxlayer.memory_graph.v1",
            "record_id": record_id,
            "max_hops": max_hops,
            "edges": edges,
        }

    def memory_sleep(self, *, apply: bool = False, limit: int = 2000) -> dict[str, Any]:
        sleep = self.settings.memory.sleep
        consolidator = SleepConsolidator(
            self.store,
            workspace_id=self._memory_workspace_id,
            repo_id=self._memory_repo_id,
            embedder=self.compiler.embedder,
            similarity_threshold=sleep.similarity_threshold,
            min_episodes_for_regeneration=sleep.min_episodes_for_regeneration,
            regenerate_after_days=sleep.regenerate_after_days,
            recalibrate_after_days=sleep.recalibrate_after_days,
            use_reasoning_provider=sleep.use_reasoning_provider,
            reasoning_provider=self._memory_sleep_reasoning_provider(),
        )
        result = consolidator.run(apply=apply, limit=limit)
        UnifiedMemory._invalidate_row_cache(
            self._memory_workspace_id, self._memory_repo_id
        )
        return result

    def _memory_sleep_due(self) -> dict[str, Any]:
        interval_hours = max(1, int(self.settings.memory.sleep.interval_hours))
        rows = self.store.memory_sleep_runs(
            workspace_id=self._memory_workspace_id,
            repo_id=self._memory_repo_id,
            limit=1,
        )
        if not rows:
            return {"due": True, "interval_hours": interval_hours, "last_run_at": None}
        last_run_at = str(rows[0]["finished_at"] or rows[0]["started_at"] or "")
        try:
            parsed = datetime.fromisoformat(last_run_at.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
            elapsed = datetime.now(timezone.utc) - parsed
            elapsed_hours = elapsed.total_seconds() / 3600
        except ValueError:
            elapsed_hours = float(interval_hours)
        return {
            "due": elapsed_hours >= interval_hours,
            "interval_hours": interval_hours,
            "elapsed_hours": round(elapsed_hours, 3),
            "last_run_at": last_run_at,
        }

    def _memory_sleep_reasoning_provider(self) -> Any | None:
        if not self.settings.memory.sleep.use_reasoning_provider:
            return None
        provider = build_agent_provider(
            self.settings,
            repo_root=self.repo_root,
            event_logger=self._learning_event_logger,
        )
        return provider if is_real_provider(provider) else None

    def nextgen_prefetch_memory(
        self,
        session_id: str | None,
        task: str,
        *,
        current_paths: list[str] | None = None,
        top_k: int = 5,
        rollout: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        if not self.settings.anticipation.enabled:
            return {"ok": False, "reason": "anticipation_disabled"}
        if not self.settings.anticipation.prefetch.enabled:
            return {"ok": False, "reason": "prefetch_disabled"}
        prefetch = self.settings.anticipation.prefetch
        top_k = max(1, min(int(top_k), int(prefetch.max_predicted_paths)))
        try:
            prediction = rollout or self.anticipate_lookahead(
                task=task,
                paths=current_paths or [],
                top_k=top_k,
            )
        except Exception as exc:
            return {"ok": False, "reason": "anticipation_error", "error": str(exc)}
        predicted_paths = _extract_predicted_paths(prediction)[:top_k]
        efe_confidence = _extract_efe_confidence(prediction)
        if (
            efe_confidence is not None
            and efe_confidence < prefetch.min_efe_confidence_to_prefetch
        ):
            return {
                "ok": False,
                "reason": "efe_confidence_below_threshold",
                "efe_confidence": efe_confidence,
            }
        recall = self.unified_memory().recall(
            task,
            paths=predicted_paths or current_paths or [],
            limit=top_k,
            allow_prefetch_cache=False,
        )
        expires = (
            datetime.now(timezone.utc)
            + timedelta(seconds=max(1, int(prefetch.cache_ttl_seconds)))
        ).isoformat(timespec="seconds")
        cache_key = prefetch_cache_key(
            task,
            paths=predicted_paths or current_paths or [],
            types=None,
            limit=top_k,
        )
        cache_id = self.store.put_memory_prefetch_cache(
            workspace_id=self._memory_workspace_id,
            repo_id=self._memory_repo_id,
            session_id=session_id,
            cache_key=cache_key,
            predicted_via="efe_lookahead",
            efe_confidence=efe_confidence,
            results=recall,
            expires_at=expires,
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.memory_prefetch.v1",
            "cache_id": cache_id,
            "cache_key": cache_key,
            "predicted_via": "efe_lookahead",
            "efe_confidence": efe_confidence,
            "predicted_paths": predicted_paths,
            "result_count": len(recall.get("results") or []),
            "expires_at": expires,
        }

    def _maybe_attach_memory_prefetch(
        self,
        result: dict[str, Any],
        payload: dict[str, Any],
        paths: list[str],
        *,
        task: str | None = None,
    ) -> None:
        if not self.settings.anticipation.prefetch.enabled:
            return
        task_text = (
            task
            or str(
                payload.get("task")
                or payload.get("prompt")
                or payload.get("diff")
                or ""
            )
        ).strip()
        if not task_text:
            tool_input = payload.get("tool_input")
            if isinstance(tool_input, dict):
                task_text = str(
                    tool_input.get("task")
                    or tool_input.get("prompt")
                    or tool_input.get("command")
                    or ""
                ).strip()
        if not task_text:
            return
        result["memory_prefetch"] = self.nextgen_prefetch_memory(
            str(payload.get("session_id") or payload.get("agent_session_id") or "")
            or None,
            task_text,
            current_paths=paths,
            top_k=self.settings.anticipation.prefetch.max_predicted_paths,
        )

    def _continuation_memory(self, repo_id: str | None = None) -> ContinuationMemory:
        if repo_id is None:
            repo_id = self.resolver.resolve().repo_id
        return ContinuationMemory(
            self.store,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=repo_id,
            recall_weights=self._learning_recall_weights(),
            repo_root=self.repo_root,
        )

    def continuation_list(
        self, status: str | None = None, limit: int = 20
    ) -> dict[str, Any]:
        return self._continuation_memory().list(status=status, limit=limit)

    def continuation_show(self, continuation_id: str) -> dict[str, Any]:
        return self._continuation_memory().show(continuation_id)

    def continuation_update(
        self,
        continuation_id: str,
        *,
        state: str | None = None,
        next_action: str | None = None,
        blockers: list[str] | None = None,
        reason: str = "manual continuation update",
    ) -> dict[str, Any]:
        return self._continuation_memory().update(
            continuation_id,
            state=state,
            next_action=next_action,
            blockers=blockers,
            reason=reason,
        )

    def continuation_resume(self, task: str, limit: int = 3) -> dict[str, Any]:
        return self._continuation_memory().resume(task, limit=limit)

    def continuation_abandon(self, continuation_id: str, reason: str) -> dict[str, Any]:
        return self._continuation_memory().abandon(continuation_id, reason=reason)

    def memory_consolidate(
        self, session_id: str | None = None, recent: int = 10
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return MemoryConsolidator(
            self.store,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
            min_session_evidence=self.settings.learning.memory.min_session_evidence,
        ).consolidate(session_id=session_id, recent=recent)

    def memory_reflect(
        self, session_id: str | None = None, recent: int = 10
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        readiness = provider_readiness(self.settings)
        provider = build_agent_provider(
            self.settings,
            repo_root=self.repo_root,
            event_logger=self._learning_event_logger,
        )
        if not is_real_provider(provider):
            return {
                "ok": True,
                "session_id": session_id,
                "reason": readiness["reason"] or "no_agent_command_configured",
                "provider_status": readiness,
                "proposed": [],
                "skipped": [],
            }
        return MemoryReflector(
            store=self.store,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
            provider=provider,
            model_family=self.settings.learning.actor_model_family,
            budget_tokens=self.settings.learning.max_tokens_per_task,
        ).reflect(session_id=session_id, recent=recent)

    def memory_dream(
        self, session_id: str | None = None, recent: int = 10
    ) -> dict[str, Any]:
        deterministic = self.memory_consolidate(session_id=session_id, recent=recent)
        try:
            reflection = self.memory_reflect(session_id=session_id, recent=recent)
        except Exception as exc:  # noqa: BLE001 - deterministic lessons still matter.
            self._learning_event_logger(
                "phase1",
                "reflection_error",
                session_id,
                {"error": str(exc)},
            )
            reflection = {
                "ok": False,
                "session_id": session_id,
                "error": str(exc),
                "proposed": [],
                "skipped": [],
            }
        return {
            "ok": bool(deterministic.get("ok"))
            and (
                bool(reflection.get("ok"))
                or reflection.get("reason") == "no_agent_command_configured"
            ),
            "deterministic": deterministic,
            "reflection": reflection,
            "reflection_ran": bool(reflection.get("ok")),
            "proposed": (deterministic.get("proposed") or [])
            + (reflection.get("proposed") or []),
            "skipped": reflection.get("skipped", []),
        }

    def consolidate_task(
        self,
        task_session_id: str,
        *,
        trigger: str,
        force: bool = False,
        outcome_id: str | None = None,
        result: str | None = None,
        skill_induction: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        if not self.settings.learning.memory.consolidate_on_task_complete:
            return {"ok": True, "ran": False, "reason": "task_consolidation_disabled"}
        try:
            task_row = self.store.task_session(task_session_id)
            if not task_row:
                return {
                    "ok": False,
                    "ran": False,
                    "error": "task_session_not_found",
                    "task_session_id": task_session_id,
                }
            session_ids = self._agent_session_ids_for_task(task_session_id)
            idempotency_key = self._task_consolidation_key(task_session_id, session_ids)
            cached = self.store.task_learning_summary(task_session_id)
            if cached and cached["idempotency_key"] == idempotency_key and not force:
                return {
                    "ok": True,
                    "ran": False,
                    "reason": "already_consolidated",
                    "summary": self._task_learning_summary_dict(cached),
                }
            deterministic = MemoryConsolidator(
                self.store,
                workspace_id=self._workspace_id(),
                repo_id=task_row["repo_id"],
                min_session_evidence=self.settings.learning.memory.min_session_evidence,
            ).consolidate(session_ids=session_ids)
            proposed = list(deterministic.get("proposed") or [])
            reflection_results = []
            if self.settings.learning.enabled:
                for sid in session_ids:
                    try:
                        reflection = self.memory_reflect(session_id=sid, recent=1)
                    except (
                        Exception
                    ) as exc:  # noqa: BLE001 - deterministic fallback remains.
                        self._learning_event_logger(
                            "phase2",
                            "task_reflection_error",
                            sid,
                            {
                                "task_session_id": task_session_id,
                                "error": str(exc),
                            },
                        )
                        reflection = {
                            "ok": False,
                            "session_id": sid,
                            "error": str(exc),
                            "proposed": [],
                            "skipped": [],
                        }
                    reflection_results.append(reflection)
                    proposed.extend(reflection.get("proposed") or [])
            proposed = self._dedupe_memory_items(proposed)
            passed = str(result or "").strip().lower() in {
                "pass",
                "passed",
                "ok",
                "success",
            }
            promoted: list[dict[str, Any]] = []
            if (
                passed
                and outcome_id
                and self.settings.learning.memory.promote_candidates_on_outcome
            ):
                promoted = self._promote_session_candidates(
                    proposed, outcome_id=outcome_id
                )
            record_refs = {
                "proposed": [
                    item.get("record_id")
                    for item in proposed
                    if isinstance(item, dict) and item.get("record_id")
                ],
                "promoted": [item["record_id"] for item in promoted],
                "sessions": session_ids,
            }
            derived_guardrails = self._derive_guardrails_from_records(
                [str(record_id) for record_id in record_refs["proposed"] if record_id],
                repo_id=task_row["repo_id"],
            )
            if derived_guardrails:
                record_refs["guardrail_directives"] = [
                    item["directive_id"] for item in derived_guardrails
                ]
            events = self._task_related_learning_events(task_session_id, session_ids)
            signals = self._task_learning_signal_items(
                events, skill_induction=skill_induction
            )
            record_refs.update(
                {
                    "skills": [
                        item["skill_id"]
                        for item in signals["skills_induced"]
                        if item.get("skill_id")
                    ],
                    "conflicts": [
                        item["conflict_id"]
                        for item in signals["conflicts_found"]
                        if item.get("conflict_id")
                    ],
                    "stale": [
                        item["record_id"]
                        for item in signals["stale_marked"]
                        if item.get("record_id")
                    ],
                }
            )
            counts = {
                "memories_proposed": len(record_refs["proposed"]),
                "memories_promoted": len(record_refs["promoted"]),
                "skills_induced": len(record_refs["skills"]),
                "conflicts_found": len(record_refs["conflicts"]),
                "stale_marked": len(record_refs["stale"]),
                "guardrails_proposed": len(derived_guardrails),
                "sessions": len(session_ids),
            }
            narrative = _learning_narrative(counts)
            self.store.upsert_task_learning_summary(
                task_session_id=task_session_id,
                idempotency_key=idempotency_key,
                trigger=trigger,
                session_ids=session_ids,
                counts=counts,
                record_refs=record_refs,
                narrative=narrative,
            )
            summary = self.store.task_learning_summary(task_session_id)
            payload = {
                "task_session_id": task_session_id,
                "trigger": trigger,
                "session_ids": session_ids,
                "counts": counts,
                "record_refs": record_refs,
                "outcome_id": outcome_id,
            }
            self._learning_event_logger(
                "phase2", "task_consolidated", task_session_id, payload
            )
            return {
                "ok": True,
                "ran": True,
                "task_session_id": task_session_id,
                "deterministic": deterministic,
                "reflection": reflection_results,
                "proposed": proposed,
                "promoted": promoted,
                "guardrails_proposed": derived_guardrails,
                "summary": (
                    self._task_learning_summary_dict(summary) if summary else payload
                ),
            }
        except Exception as exc:  # noqa: BLE001 - task completion must not fail.
            self._learning_event_logger(
                "phase2",
                "consolidation_error",
                task_session_id,
                {"trigger": trigger, "error": str(exc)},
            )
            return {"ok": False, "task_session_id": task_session_id, "error": str(exc)}

    def _derive_guardrails_from_records(
        self, record_ids: list[str], *, repo_id: str | None
    ) -> list[dict[str, Any]]:
        if not self.settings.guardrails.enabled:
            return []
        if not self.settings.guardrails.derive_on_consolidation:
            return []
        derived: list[dict[str, Any]] = []
        for record_id in sorted(set(record_ids)):
            row = self.store.memory_record(record_id)
            if not row or row["type"] not in {"failure_lesson", "convention"}:
                continue
            metadata = _json_dict(row["metadata_json"])
            enforcement = metadata.get("enforcement")
            enforcement = enforcement if isinstance(enforcement, dict) else {}
            scope = [
                _normalize_path(path)
                for path in enforcement.get("path_globs", [])
                if str(path).strip()
            ]
            if not scope:
                scope = [
                    _normalize_path(item["target_ref"])
                    for item in self.store.memory_associations(
                        record_id=record_id, target_type="file"
                    )
                ]
            if not scope:
                continue
            critical = [
                path
                for path in scope
                if any(
                    fnmatch.fnmatch(path, glob)
                    for glob in self.settings.eval.critical_paths
                )
            ]
            if not critical:
                continue
            directive_id = self.store.upsert_memory_enforcement(
                record_id=record_id,
                repo_id=repo_id,
                enforcement_level="warn",
                severity=str(enforcement.get("severity") or "medium"),
                path_globs=scope,
                anti_patterns=[
                    str(item) for item in enforcement.get("anti_patterns", [])
                ],
                required_patterns=[
                    str(item) for item in enforcement.get("required_patterns", [])
                ],
                rationale=str(enforcement.get("rationale") or row["assertion"]),
                remediation=enforcement.get("remediation"),
                status="suspended",
                source="derived",
            )
            directive = self.store.memory_enforcement(directive_id)
            payload = _memory_enforcement_dict(directive)
            self._learning_event_logger(
                "phase_g1",
                "memory_enforcement_derived",
                directive_id,
                {
                    "directive_id": directive_id,
                    "record_id": record_id,
                    "status": "suspended",
                    "level": "warn",
                    "scope_count": len(scope),
                },
            )
            derived.append(payload)
        return derived

    def memory_maintain(self, limit: int = 200) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        rows = self.store.memory_records(
            status="candidate",
            repo_id=snapshot.repo_id,
            workspace_id=stable_id(str(self.repo_root))[:16],
        )
        memory = self.unified_memory()
        decisions = [
            memory.maintain_candidate(row["record_id"]) for row in rows[:limit]
        ]
        return {"ok": True, "count": len(decisions), "decisions": decisions}

    def memory_sweep(self, *, limit: int = 500, apply: bool = False) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        workspace_id = self._workspace_id()
        memory = self.unified_memory()
        all_rows = [
            *self.store.memory_records(
                status="active", repo_id=snapshot.repo_id, workspace_id=workspace_id
            ),
            *self.store.memory_records(
                status="candidate", repo_id=snapshot.repo_id, workspace_id=workspace_id
            ),
        ]
        rows = all_rows[:limit]
        truncated = len(all_rows) > len(rows)
        skipped = max(0, len(all_rows) - len(rows))
        if truncated:
            self._learning_event_logger(
                "phase3",
                "memory_sweep_truncated",
                snapshot.repo_id,
                {
                    "limit": limit,
                    "checked": len(rows),
                    "total": len(all_rows),
                    "skipped": skipped,
                    "apply": apply,
                },
            )
        stale_findings: list[dict[str, Any]] = []
        conflict_findings: list[dict[str, Any]] = []
        for row in rows:
            stale_reason = self._memory_stale_reason(row)
            if stale_reason:
                finding = {
                    "record_id": row["record_id"],
                    "status": row["status"],
                    "type": row["type"],
                    "reason": stale_reason["reason"],
                    **{k: v for k, v in stale_reason.items() if k != "reason"},
                }
                stale_findings.append(finding)
                self._learning_event_logger(
                    "phase3", "memory_stale", row["record_id"], finding
                )
                if apply:
                    try:
                        memory.mark_stale(
                            record_id=row["record_id"],
                            reason=stale_reason["reason"],
                            path=stale_reason.get("path"),
                            actor="memory_sweep",
                        )
                        suspended = self.store.suspend_memory_enforcements_for_record(
                            row["record_id"], reason=stale_reason["reason"]
                        )
                        if suspended:
                            self._learning_event_logger(
                                "phase_g1",
                                "directive_suspended",
                                row["record_id"],
                                {
                                    "record_id": row["record_id"],
                                    "count": suspended,
                                    "reason": stale_reason["reason"],
                                },
                            )
                    except Exception as exc:  # noqa: BLE001 - continue sweeping.
                        finding["apply_error"] = str(exc)
        for index, left in enumerate(rows):
            for right in rows[index + 1 :]:
                if left["type"] != right["type"]:
                    continue
                summary = _memory_conflict_summary(
                    left["assertion"], right["assertion"]
                )
                if not summary:
                    continue
                conflict_id = None
                if apply:
                    conflict_id = self.store.upsert_memory_conflict(
                        left_record_id=left["record_id"],
                        right_record_id=right["record_id"],
                        conflict_type="assertion_conflict",
                        summary=summary,
                    )
                conflict = {
                    "conflict_id": conflict_id,
                    "record_ids": [left["record_id"], right["record_id"]],
                    "type": "assertion_conflict",
                    "summary": summary,
                }
                conflict_findings.append(conflict)
                self._learning_event_logger(
                    "phase3", "memory_conflict", conflict_id, conflict
                )
        return {
            "ok": True,
            "apply": apply,
            "checked": len(rows),
            "total": len(all_rows),
            "truncated": truncated,
            "skipped": skipped,
            "stale": stale_findings,
            "conflicts": conflict_findings,
            "counts": {
                "checked": len(rows),
                "total": len(all_rows),
                "skipped": skipped,
                "stale": len(stale_findings),
                "conflicts": len(conflict_findings),
            },
        }

    def _memory_stale_reason(self, row: Any) -> dict[str, Any] | None:
        evidence_rows = self.store.memory_evidence(row["record_id"])
        for evidence in evidence_rows:
            path = evidence["path"]
            if path and not (self.repo_root / path).exists():
                return {"reason": "evidence_missing", "path": path}
        age_days = _age_days(row["updated_at"])
        last_validated = _row_value(row, "last_validated_at")
        if last_validated:
            age_days = min(age_days, _age_days(last_validated))
        decayed = decayed_confidence(float(row["confidence"]), age_days)
        if (
            age_days > self.settings.memory.stale_after_days
            and decayed < self.settings.memory.stale_confidence_floor
        ):
            return {
                "reason": "decayed",
                "age_days": age_days,
                "decayed_confidence": decayed,
            }
        if age_days > self.settings.memory.stale_after_days and not last_validated:
            return {"reason": "aged", "age_days": age_days}
        return None

    def memory_promote(
        self, record_id: str, validator: str, actor: str = "local-user"
    ) -> dict[str, Any]:
        allowed = (
            "human:",
            "real_outcome:",
            "skill_replay:",
            "benchmark:",
            "deterministic:",
        )
        if not any(validator.startswith(prefix) for prefix in allowed):
            raise ValueError(
                "validator must start with human:, real_outcome:, skill_replay:, benchmark:, or deterministic:"
            )
        return self.unified_memory().validate(
            record_id, validator=validator, actor=actor
        )

    def memory_review(self, status: str | None = "open") -> dict[str, Any]:
        return self.memory_security_reviews(status)

    def memory_utilization(self, pack_id: str) -> dict[str, Any]:
        manifest = self.get_pack_manifest(pack_id)
        changed = []
        outcomes = self.store.conn.execute(
            "SELECT * FROM outcomes WHERE pack_id = ? ORDER BY created_at DESC",
            (pack_id,),
        ).fetchall()
        if outcomes:
            try:
                changed = json.loads(outcomes[0]["files_changed_json"] or "[]")
            except json.JSONDecodeError:
                changed = []
        changed_set = {path.replace("\\", "/") for path in changed}
        inferred = []
        sections = {
            "project_memory": "project_memory_evidence_path_changed",
            "policy_references": "policy_reference_path_changed",
            "continuations": "continuation_path_changed",
        }
        for section, utilization_kind in sections.items():
            for memory in manifest.get(section, []) or []:
                record = self.store.memory_record(memory["record_id"])
                metadata = {}
                if record:
                    try:
                        metadata = json.loads(record["metadata_json"] or "{}")
                    except json.JSONDecodeError:
                        metadata = {}
                evidence_paths = {
                    item.get("path")
                    for item in memory.get("evidence", [])
                    if item.get("path")
                }
                if record:
                    evidence_paths.update(
                        item["path"]
                        for item in self.store.memory_evidence(memory["record_id"])
                        if item["path"]
                    )
                for key in (
                    "policy_file",
                    "intended_files",
                    "changed_files",
                    "scope_refs",
                ):
                    value = metadata.get(key)
                    if isinstance(value, str):
                        evidence_paths.add(value)
                    elif isinstance(value, list):
                        evidence_paths.update(
                            str(item) for item in value if str(item).strip()
                        )
                evidence_paths = {
                    path.replace("\\", "/") for path in evidence_paths if path
                }
                overlap = sorted(changed_set & evidence_paths)
                if overlap:
                    utilization_id = self.store.record_memory_utilization(
                        pack_id=pack_id,
                        memory_record_id=memory["record_id"],
                        utilization_kind=utilization_kind,
                        score=1.0,
                        metadata={"paths": overlap, "section": section},
                    )
                    inferred.append(
                        {
                            "utilization_id": utilization_id,
                            "record_id": memory["record_id"],
                            "kind": utilization_kind,
                            "score": 1.0,
                            "paths": overlap,
                            "section": section,
                        }
                    )
        return {
            "ok": True,
            "pack_id": pack_id,
            "served": [dict(row) for row in self.store.memory_accesses(pack_id)],
            "inferred": inferred,
            "recorded": [dict(row) for row in self.store.memory_utilization(pack_id)],
        }

    def skill_library(self) -> SkillLibrary:
        snapshot = self.resolver.resolve()
        provider = build_agent_provider(
            self.settings,
            repo_root=self.repo_root,
            event_logger=self._learning_event_logger,
        )
        return SkillLibrary(
            store=self.store,
            repo_root=self.repo_root,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
            provider=provider,
            model_family=self.settings.learning.actor_model_family,
            budget_tokens=self.settings.learning.max_tokens_per_task,
            settings=self.settings,
            critical_path_globs=self.settings.eval.critical_paths,
        )

    def skill_induce(self, session_id: str) -> dict[str, Any]:
        return self.skill_library().induce(session_id=session_id)

    def skill_list(
        self, status: str | None = None, trust: str | None = None
    ) -> dict[str, Any]:
        return self.skill_library().list(status=status, trust=trust)

    def skill_show(self, skill_id: str) -> dict[str, Any]:
        return self.skill_library().show(skill_id)

    def skill_replay(self, skill_id: str, timeout: int = 120) -> dict[str, Any]:
        return self.skill_library().replay(skill_id, timeout=timeout)

    def skill_approve(
        self, skill_id: str, approved_by: str = "local-user"
    ) -> dict[str, Any]:
        return self.skill_library().approve(skill_id, approved_by=approved_by)

    def skill_reject(
        self, skill_id: str, reason: str = "manual reject"
    ) -> dict[str, Any]:
        return self.skill_library().reject(skill_id, reason=reason)

    def skill_prune(self, max_failures: int = 3) -> dict[str, Any]:
        return self.skill_library().prune(max_failures=max_failures)

    def skill_maintain(
        self, max_failures: int = 3, stale_after_days: int | None = None
    ) -> dict[str, Any]:
        return self.skill_library().maintain(
            max_failures=max_failures,
            stale_after_days=stale_after_days,
        )

    def skill_search(
        self, query: str, limit: int = 5, include_untrusted: bool = False
    ) -> dict[str, Any]:
        return self.skill_library().search(
            query,
            limit=limit,
            include_untrusted=include_untrusted,
        )

    def skill_evolution(self) -> SkillEvolutionEngine:
        snapshot = self.resolver.current_identity()
        return SkillEvolutionEngine(
            self.store,
            repo_root=self.repo_root,
            repo_id=snapshot.repo_id,
            workspace_id=self._workspace_id(),
        )

    def skill_revision_capture(
        self,
        *,
        revision_text: str,
        output_id: str | None = None,
        skill_id: str | None = None,
        session_id: str | None = None,
        task_session_id: str | None = None,
        actor: str = "user",
        signal_kind: str = "explicit_revision",
    ) -> dict[str, Any]:
        return self.skill_evolution().capture_revision(
            revision_text=revision_text,
            output_id=output_id,
            skill_id=skill_id,
            session_id=session_id,
            task_session_id=task_session_id,
            actor=actor,
            signal_kind=signal_kind,
        )

    def skill_artifact_register(
        self,
        *,
        skill_id: str | None,
        artifact_kind: str = "task_output",
        summary: str = "",
        structure: dict[str, Any] | None = None,
        content: str | None = None,
        session_id: str | None = None,
        task_session_id: str | None = None,
        output_id: str | None = None,
    ) -> dict[str, Any]:
        return self.skill_evolution().register_artifact(
            skill_id=skill_id,
            artifact_kind=artifact_kind,
            summary=summary,
            structure=structure,
            content=content,
            session_id=session_id,
            task_session_id=task_session_id,
            output_id=output_id,
        )

    def skill_accept_first_pass(self, output_id: str) -> dict[str, Any]:
        return self.skill_evolution().accept_first_pass(output_id=output_id)

    def skill_metrics(self, skill_id: str | None = None) -> dict[str, Any]:
        return self.skill_evolution().metrics(skill_id=skill_id)

    def skill_revision_classify(
        self, revision_id: str | None = None, *, skill_id: str | None = None
    ) -> dict[str, Any]:
        engine = self.skill_evolution()
        if revision_id:
            return engine.classify_revision(revision_id)
        return engine.classify_all(skill_id=skill_id)

    def skill_improvements(
        self, *, skill_id: str | None = None, status: str | None = None
    ) -> dict[str, Any]:
        return self.skill_evolution().improvements(skill_id=skill_id, status=status)

    def skill_refinement_approve(
        self, sir_id: str, *, approved_by: str = "local-user"
    ) -> dict[str, Any]:
        return self.skill_evolution().approve_refinement(
            sir_id, approved_by=approved_by
        )

    def skill_refinement_benchmark(self, sir_id: str) -> dict[str, Any]:
        return self.skill_evolution().benchmark_refinement(sir_id)

    def skill_refinement_rollback(self, skill_id: str) -> dict[str, Any]:
        return self.skill_evolution().rollback_refinement(skill_id)

    def skill_closure_verify(self, skill_id: str | None = None) -> dict[str, Any]:
        return self.skill_evolution().closure_verify(skill_id=skill_id)

    def skill_global_promote(
        self, skill_id: str, *, approver: str = "local-user"
    ) -> dict[str, Any]:
        return self.skill_evolution().promote_global(skill_id, approver=approver)

    def skill_global_adopt(
        self, global_skill_id: str, *, approver: str = "local-user"
    ) -> dict[str, Any]:
        return self.skill_evolution().adopt_global(global_skill_id, approver=approver)

    def _workflow_surprise_signal(
        self, *, task: str, paths: list[str]
    ) -> dict[str, Any]:
        if not self.settings.anticipation.enabled:
            return {}
        mode, degraded = self._anticipation_gate_mode()
        if mode not in {"enforce", "block"}:
            return {"surprise": {"mode": mode, "advisory": True}} if degraded else {}
        try:
            session_id = self._ensure_agent_session(task)["session_id"]
            signal = self._anticipation_gate_signal(
                {
                    "session_id": session_id,
                    "tool_name": "workflow",
                    "target_paths": paths,
                },
                paths,
            )
        except (
            Exception
        ) as exc:  # noqa: BLE001 - workflow recommendation must be available.
            return {"surprise": {"mode": mode, "advisory": True, "error": str(exc)}}
        return {
            "surprise": signal.get("surprise"),
            "interoception": signal.get("interoception"),
            "mode": signal.get("mode", mode),
            "advisory": True,
        }

    def _workflow_hint_for_payload(
        self, payload: dict[str, Any]
    ) -> dict[str, Any] | None:
        task_session_id = payload.get("task_session_id")
        if not task_session_id:
            return None
        try:
            result = self.workflow_next(
                task_session_id=str(task_session_id), record_volatile=False
            )
        except Exception:  # noqa: BLE001 - workflow hint must never affect gating.
            return None
        next_action = result.get("next_action")
        return next_action if isinstance(next_action, dict) else None

    def _workflow_start_remediation(self, pack: dict[str, Any]) -> list[str]:
        remediation: list[str] = []
        seed_coverage = pack.get("seed_coverage", {})
        edit_scope_confidence = seed_coverage.get("edit_scope_confidence")
        if pack.get("low_confidence") and edit_scope_confidence != "seeded":
            remediation.append(
                "Pack confidence is low; rerun workflow start with explicit --path seeds."
            )
        if edit_scope_confidence == "unseeded":
            remediation.append(
                "Add --path values for every intended edit before writing."
            )
        health = pack.get("ctx_health", {})
        if health.get("status") == "unavailable":
            remediation.append(
                "CTX health is unavailable; run ctxlayer --repo . doctor."
            )
        return remediation

    def _workflow_snapshot_payload(
        self,
        recommendation: dict[str, Any],
        *,
        task_session_id: str,
        agent_session_id: str | None,
        pack_id: str | None,
    ) -> dict[str, Any]:
        return {
            "schema_version": WORKFLOW_RECOMMEND_SCHEMA,
            "task_session_id": task_session_id,
            "agent_session_id": agent_session_id,
            "pack_id": pack_id,
            "task": recommendation.get("task"),
            "mode": recommendation.get("mode"),
            "task_types": recommendation.get("task_types", []),
            "required_features": recommendation.get("required_features", []),
            "optional_features": recommendation.get("optional_features", []),
            "gates": recommendation.get("gates", []),
            "escalation": recommendation.get("escalation", {}),
            "paths": recommendation.get("paths", []),
            "capabilities": recommendation.get("capabilities", []),
            "intent_id": recommendation.get("intent_id"),
            "goal_id": recommendation.get("goal_id"),
            "signals": recommendation.get("signals", {}),
            "stop_when": recommendation.get("stop_when", []),
        }

    def _load_workflow_recommendation_snapshot(
        self, task_session_id: str
    ) -> dict[str, Any] | None:
        session_id = self._session_id_for_task_session(task_session_id)
        if not session_id:
            for row in self.store.agent_sessions(
                workspace_id=self._workspace_id(), limit=500
            ):
                metadata = _json_dict(row["metadata_json"])
                if metadata.get("task_session_id") == task_session_id:
                    session_id = str(row["session_id"])
                    break
        if not session_id:
            task = self._task_text_for_session(task_session_id)
            if task:
                identity = self.resolver.current_identity()
                session_id = self._agent_session_memory(
                    identity.repo_id
                ).session_id_for_task(task)
        if not session_id:
            return None
        artifacts = [
            artifact
            for artifact in self.store.agent_session_artifacts(session_id)
            if artifact["artifact_type"] == "workflow_recommendation_snapshot"
            and artifact["ref"] == task_session_id
        ]
        if not artifacts:
            return None
        candidates: list[dict[str, Any]] = []
        for event_index, event in enumerate(
            self.store.agent_session_events(session_id)
        ):
            if event["event_type"] != "workflow_recommendation_snapshot":
                continue
            payload = _json_dict(event["payload_json"])
            if (
                payload.get("task_session_id") == task_session_id
                and payload.get("schema_version") == WORKFLOW_RECOMMEND_SCHEMA
            ):
                candidates.append(
                    {
                        **payload,
                        "_event_time": event["event_time"],
                        "_event_index": event_index,
                    }
                )
        if not candidates:
            return None
        return sorted(
            candidates,
            key=lambda item: (
                str(item.get("_event_time") or ""),
                int(item.get("_event_index") or 0),
            ),
            reverse=True,
        )[0]

    def _workflow_next_action_from_recommendation(
        self, recommendation: dict[str, Any]
    ) -> dict[str, Any]:
        features = recommendation.get("required_features", [])
        if not features:
            return {
                "feature_id": "answer",
                "command": None,
                "why": "read-mode workflow has no write gates",
            }
        return dict(features[0])

    def _workflow_next_action(
        self,
        recommendation: dict[str, Any],
        gate_status: dict[str, dict[str, Any]],
        pending: list[str],
    ) -> dict[str, Any] | None:
        if not pending:
            return None
        gate = pending[0]
        feature_for_gate = {
            "preflight_ready": "pack",
            "plan_active": "plan",
            "checkpoints_present": "checkpoint",
            "check_diff_clean": "check_diff",
            "dirty_set_in_scope": "check_diff",
            "tests_pass": "tests",
            "outcome_recorded": "outcome",
            "security_scan_pass": "security_scan",
            "release_validated": "release_validate",
        }.get(gate)
        for feature in recommendation.get("required_features", []):
            if feature.get("feature_id") == feature_for_gate:
                action = dict(feature)
                action["gate_id"] = gate
                action["gate_status"] = gate_status.get(gate, {})
                action["blocked"] = gate_status.get(gate, {}).get("status") == "fail"
                return action
        return {
            "feature_id": feature_for_gate or gate,
            "gate_id": gate,
            "command": None,
            "why": f"Resolve pending gate {gate}",
            "gate_status": gate_status.get(gate, {}),
        }

    def _workflow_fingerprint(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        changed_paths = git_changed_paths(self.repo_root)
        try:
            diff = subprocess.run(
                ["git", "diff", "HEAD", "--", *changed_paths],
                cwd=self.repo_root,
                check=False,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                timeout=10,
            ).stdout
        except (subprocess.SubprocessError, FileNotFoundError):
            diff = ""
        diff_hash = hashlib.sha256(diff.encode("utf-8")).hexdigest()
        path_hash = hashlib.sha256(
            canonical_json(sorted(changed_paths)).encode("utf-8")
        ).hexdigest()
        return {
            "base_commit_sha": snapshot.base_commit_sha,
            "snapshot_id": snapshot.snapshot_id,
            "changed_paths": sorted(changed_paths),
            "diff_hash": diff_hash if diff else None,
            "path_hash": path_hash,
        }

    def _workspace_id(self) -> str:
        return stable_id(str(self.repo_root))[:16]

    def _agent_session_memory(self, repo_id: str | None = None) -> AgentSessionMemory:
        return AgentSessionMemory(
            self.store,
            workspace_id=self._workspace_id(),
            repo_id=repo_id,
        )

    def _ensure_agent_session(
        self,
        task: str,
        *,
        repo_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.current_identity()
        if repo_id is None:
            repo_id = snapshot.repo_id
        session = self._agent_session_memory(repo_id).ensure(
            task=task,
            metadata={
                "bound_snapshot_id": snapshot.snapshot_id,
                "base_commit_sha": snapshot.base_commit_sha,
                "worktree_state": snapshot.worktree_state,
                **(metadata or {}),
            },
        )
        session["lease"] = self.store.acquire_session_lease(
            session_id=session["session_id"],
            workspace_id=self._workspace_id(),
            repo_id=repo_id,
            agent_name="codex",
            bound_snapshot_id=snapshot.snapshot_id,
        )
        return session

    def _session_id_for_task_session(self, task_session_id: str) -> str | None:
        row = self.store.agent_session_for_artifact("task_session", task_session_id)
        return row["session_id"] if row else None

    def _session_id_for_pack(self, pack_id: str) -> str | None:
        row = self.store.agent_session_for_artifact("pack_served", pack_id)
        return row["session_id"] if row else None

    def _session_id_for_plan(self, plan_id: str) -> str | None:
        row = self.store.task_plan(plan_id)
        if not row or not row["task_session_id"]:
            return None
        return self._session_id_for_task_session(row["task_session_id"])

    def _task_session_id_for_agent_session(self, session_id: str | None) -> str | None:
        if not session_id:
            return None
        for artifact in self.store.agent_session_artifacts(session_id):
            if artifact["artifact_type"] == "task_session" and artifact["ref"]:
                return str(artifact["ref"])
        row = self.store.agent_session(session_id)
        if not row:
            return None
        metadata = _json_dict(row["metadata_json"])
        value = metadata.get("task_session_id")
        if not value:
            value = metadata.get("parent_task_session_id")
        return str(value) if value else None

    def _agent_session_ids_for_task(self, task_session_id: str) -> list[str]:
        session_ids: set[str] = set()
        parent = self._session_id_for_task_session(task_session_id)
        if parent:
            session_ids.add(parent)
        rows = self.store.agent_sessions(workspace_id=self._workspace_id(), limit=500)
        for row in rows:
            metadata = _json_dict(row["metadata_json"])
            if metadata.get("parent_task_session_id") == task_session_id:
                session_ids.add(str(row["session_id"]))
            elif metadata.get("task_session_id") == task_session_id:
                session_ids.add(str(row["session_id"]))
        return sorted(session_ids)

    def _task_consolidation_key(
        self, task_session_id: str, session_ids: list[str]
    ) -> str:
        events: list[dict[str, Any]] = []
        for sid in session_ids:
            for event in self.store.agent_session_events(sid):
                events.append(
                    {
                        "session_id": sid,
                        "event_id": event["event_id"],
                        "event_type": event["event_type"],
                        "payload_hash": event["payload_hash"],
                    }
                )
        # External memory signals intentionally refresh task consolidation.
        for event in self._task_related_learning_events(task_session_id, session_ids):
            if event.get("kind") == "task_consolidated":
                continue
            events.append(
                {
                    "learning_event_id": event.get("event_id"),
                    "kind": event.get("kind"),
                    "ref": event.get("ref"),
                    "payload": event.get("payload", {}),
                }
            )
        return stable_id(task_session_id, canonical_json(sorted(events, key=str)))

    def _task_related_learning_events(
        self,
        task_session_id: str,
        session_ids: list[str],
        *,
        limit: int = 500,
    ) -> list[dict[str, Any]]:
        session_set = {str(item) for item in session_ids if item}
        events: dict[str, dict[str, Any]] = {}
        refs = [task_session_id, *sorted(session_set)]
        for row in self.store.learning_events(limit=limit, refs=refs):
            event = _learning_event_dict(row)
            events[str(event["event_id"])] = event
        for row in self.store.learning_events(limit=limit):
            event = _learning_event_dict(row)
            payload = event.get("payload", {})
            if (
                payload.get("task_session_id") == task_session_id
                or str(payload.get("session_id") or "") in session_set
            ):
                events[str(event["event_id"])] = event
        return sorted(
            events.values(),
            key=lambda item: (
                str(item.get("ts") or ""),
                str(item.get("event_id") or ""),
            ),
            reverse=True,
        )

    def _task_learning_signal_items(
        self,
        events: list[dict[str, Any]],
        *,
        skill_induction: dict[str, Any] | None = None,
    ) -> dict[str, list[dict[str, Any]]]:
        skills: list[dict[str, Any]] = []
        if skill_induction:
            for item in skill_induction.get("proposed", []) or []:
                if isinstance(item, dict) and item.get("skill_id"):
                    skills.append(self._skill_report_item(str(item["skill_id"]), item))
        conflicts: list[dict[str, Any]] = []
        stale: list[dict[str, Any]] = []
        for event in events:
            payload = event.get("payload", {})
            kind = event.get("kind")
            if kind in {"skill_candidate", "skill_induced"}:
                skill_id = str(event.get("ref") or payload.get("skill_id") or "")
                if skill_id:
                    skills.append(self._skill_report_item(skill_id, payload))
            elif kind == "memory_conflict":
                conflict = dict(payload)
                conflict_id = str(event.get("ref") or payload.get("conflict_id") or "")
                if conflict_id:
                    conflict["conflict_id"] = conflict_id
                conflicts.append(conflict)
            elif kind == "memory_stale":
                record_id = str(event.get("ref") or payload.get("record_id") or "")
                if record_id:
                    stale.append({"record_id": record_id, **payload})
        return {
            "skills_induced": self._dedupe_report_items(skills, "skill_id"),
            "conflicts_found": self._dedupe_report_items(conflicts, "conflict_id"),
            "stale_marked": self._dedupe_report_items(stale, "record_id"),
        }

    def _dedupe_memory_items(self, items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        deduped: list[dict[str, Any]] = []
        seen: set[str] = set()
        for item in items:
            if not isinstance(item, dict):
                continue
            key = str(item.get("assertion") or item.get("record_id") or "")
            if not key:
                continue
            digest = stable_id(key)
            if digest in seen:
                continue
            seen.add(digest)
            deduped.append(item)
        return deduped

    def _task_learning_summary_dict(self, row: Any) -> dict[str, Any]:
        return {
            "task_session_id": row["task_session_id"],
            "idempotency_key": row["idempotency_key"],
            "consolidated_at": row["consolidated_at"],
            "trigger": row["trigger"],
            "session_ids": _json_list(row["session_ids_json"]),
            "counts": _json_dict(row["counts_json"]),
            "record_refs": _json_dict(row["record_refs_json"]),
            "narrative": row["narrative"],
        }

    def _outcome_verification_gate(
        self, *, pack_id: str, result: str, session_id: str | None
    ) -> dict[str, Any]:
        if result.strip().lower() not in {"pass", "passed", "ok", "success"}:
            return {"ok": True}
        task_session_id = self._task_session_id_for_agent_session(session_id)
        plan = (
            self.store.latest_task_plan_for_session(task_session_id)
            if task_session_id
            else None
        )
        if not plan:
            return {"ok": True}
        required = _json_list(plan["required_verifications_json"])
        governed_class = str(plan["governed_class"] or "")
        if (
            governed_class
            and governed_class in self.settings.governance.governed_classes
        ):
            required = sorted(
                set(required)
                | {
                    str(item)
                    for item in self.settings.governance.governed_classes[
                        governed_class
                    ]
                }
            )
        health = self.latest_ctx_health()
        if (
            governed_class
            and self.settings.governance.require_healthy_ctx
            and health.get("status") == "unavailable"
        ):
            return {
                "ok": False,
                "status": "blocked",
                "reason": "ctx_unavailable_for_governed_task",
                "task_session_id": task_session_id,
                "plan_id": plan["plan_id"],
                "governed_class": governed_class,
                "ctx_health": health,
            }
        if not required:
            return {"ok": True}
        rows = self.store.task_verifications(
            task_session_id=task_session_id, plan_id=plan["plan_id"]
        )
        latest_by_name: dict[str, Any] = {}
        for row in reversed(rows):
            latest_by_name[str(row["name"])] = row
        missing = [name for name in required if name not in latest_by_name]
        failing = [
            {
                "name": name,
                "status": str(latest_by_name[name]["status"]),
                "verification_id": latest_by_name[name]["verification_id"],
            }
            for name in required
            if name in latest_by_name and str(latest_by_name[name]["status"]) != "pass"
        ]
        if missing or failing:
            return {
                "ok": False,
                "status": "blocked",
                "reason": "required_verification_missing_or_failing",
                "task_session_id": task_session_id,
                "plan_id": plan["plan_id"],
                "governed_class": governed_class or None,
                "required_verifications": required,
                "missing_verifications": missing,
                "failing_verifications": failing,
            }
        return {"ok": True}

    def _task_text_for_session(self, task_session_id: str) -> str | None:
        row = self.store.task_session(task_session_id)
        if not row:
            return None
        try:
            metadata = json.loads(row["metadata_json"] or "{}")
        except json.JSONDecodeError:
            metadata = {}
        task = metadata.get("task") or metadata.get("objective")
        return str(task) if task else None

    def _codex_write_scope_overlap(
        self,
        parent_session_id: str,
        parallel_run_id: str,
        write_scope: list[str],
    ) -> list[str]:
        if not write_scope:
            return []
        requested = set(write_scope)
        active: set[str] = set()
        stopped_children: set[str] = set()
        for row in self.store.agent_session_events(parent_session_id):
            try:
                payload = json.loads(row["payload_json"] or "{}")
            except json.JSONDecodeError:
                payload = {}
            if payload.get("parallel_run_id") != parallel_run_id:
                continue
            child_id = payload.get("child_agent_session_id")
            if row["event_type"] == "codex_child_stop" and child_id:
                stopped_children.add(str(child_id))
            if row["event_type"] != "codex_child_start" or not child_id:
                continue
            if str(child_id) in stopped_children:
                continue
            active.update(str(path) for path in payload.get("write_scope", []) or [])
        return sorted(requested & active)

    def _codex_child_events(self, parallel_run_id: str) -> list[dict[str, Any]]:
        rows = self.store.agent_sessions(workspace_id=self._workspace_id(), limit=200)
        events: list[dict[str, Any]] = []
        for row in rows:
            for event in self.store.agent_session_events(row["session_id"]):
                if event["event_type"] not in {"codex_child_start", "codex_child_stop"}:
                    continue
                try:
                    payload = json.loads(event["payload_json"] or "{}")
                except json.JSONDecodeError:
                    payload = {}
                if payload.get("parallel_run_id") == parallel_run_id:
                    events.append({**dict(event), "payload": payload})
        return events

    def _record_agent_session_event(
        self, session_id: str, event_type: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return self._agent_session_memory().event(
            session_id=session_id,
            event_type=event_type,
            payload=payload,
        )

    def session_memory(self) -> AgentSessionMemory:
        snapshot = self.resolver.resolve()
        return self._agent_session_memory(snapshot.repo_id)

    def session_start(
        self,
        task: str,
        agent_name: str = "codex",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        result = self._agent_session_memory(snapshot.repo_id).start(
            task=task,
            agent_name=agent_name,
            metadata={
                **(metadata or {}),
                "bound_snapshot_id": snapshot.snapshot_id,
                "base_commit_sha": snapshot.base_commit_sha,
                "worktree_state": snapshot.worktree_state,
            },
        )
        result["lease"] = self.store.acquire_session_lease(
            session_id=result["session_id"],
            workspace_id=self._workspace_id(),
            repo_id=snapshot.repo_id,
            agent_name=agent_name,
            bound_snapshot_id=snapshot.snapshot_id,
        )
        if self.settings.learning.self_improve.enabled:
            try:
                result["self_improve"] = self.self_improve.maybe_run()
            except (
                Exception
            ) as exc:  # noqa: BLE001 - session start must remain primary.
                result["self_improve"] = {
                    "ok": False,
                    "ran": False,
                    "reason": "self_improve_trigger_failed",
                    "error": str(exc),
                }
        return result

    def session_event(
        self, session_id: str, event_type: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return self.session_memory().event(
            session_id=session_id, event_type=event_type, payload=payload
        )

    def session_finish(
        self, session_id: str, result: str, metadata: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        finished = self.session_memory().finish(
            session_id=session_id, result=result, metadata=metadata
        )
        finished["released_leases"] = self.store.release_session_leases(session_id)
        passed = result.strip().lower() in {"pass", "passed", "ok", "success"}
        task_session_id = self._task_session_id_for_agent_session(session_id)
        if not passed:
            finished["anticipation_update"] = self._observe_anticipation_signal(
                session_id=session_id,
                signal_kind="session_failure",
                task_session_id=task_session_id,
                target_paths=git_changed_paths(self.repo_root),
                magnitude=1.0,
            )
        finished["anticipation_candidates"] = self._synthesize_anticipation_candidates(
            session_id
        )
        reconciliation = self._reconcile_approved_anticipation_candidates()
        if reconciliation.get("ran"):
            finished["anticipation_retrain"] = reconciliation
        state = "completed" if passed else "ready_to_resume"
        self._continuation_memory().upsert_for_agent_session(
            session_id,
            event="session_finish",
            state=state,
            next_action=(
                None
                if state == "completed"
                else "Resume from the latest incomplete plan step."
            ),
            reason=f"session finished: {result}",
        )
        dream_enabled = (
            self.settings.learning.memory.dream_on_finish
            or self.settings.learning.memory.reflect_on_finish
        )
        if task_session_id:
            finished["task_learning"] = self.consolidate_task(
                task_session_id,
                trigger="session_finish",
                result=result,
            )
            task_text = self._task_text_for_session(task_session_id)
            if task_text and self.settings.metacognition.enabled:
                finished["metacognition"] = self._metacognitive_state(
                    task=task_text,
                    paths=git_changed_paths(self.repo_root),
                    checkpoint="pre_complete",
                    task_session_id=task_session_id,
                    payload={"__skip_workflow_next": True},
                    persist=True,
                    create_clarification=False,
                )
                for row in self.store.clarification_requests(
                    task_session_id=task_session_id, status="open", limit=100
                ):
                    self.store.update_clarification_request(
                        row["request_id"], status="expired"
                    )
            finished["governance_feature_events"] = record_session_feature_events(
                self.store,
                workspace_id=self._workspace_id(),
                repo_id=self.resolver.current_identity().repo_id,
                task_session_id=task_session_id,
                agent_session_id=session_id,
                outcome_result=result,
            )
        elif self.settings.learning.enabled and dream_enabled:
            try:
                finished["reflection"] = self.memory_dream(session_id=session_id)
            except (
                Exception
            ) as exc:  # noqa: BLE001 - session finish must remain durable.
                self._learning_event_logger(
                    "phase1",
                    "reflection_error",
                    session_id,
                    {"error": str(exc)},
                )
                finished["reflection"] = {
                    "ok": False,
                    "session_id": session_id,
                    "error": str(exc),
                }
        return finished

    def session_explain(self, session_id: str) -> dict[str, Any]:
        return self.session_memory().explain(session_id)

    def session_leases(self, *, status: str | None = "active") -> dict[str, Any]:
        snapshot = self.resolver.current_identity()
        rows = self.store.session_leases(
            workspace_id=self._workspace_id(),
            repo_id=snapshot.repo_id,
            status=status,
        )
        return {"ok": True, "leases": [_lease_dict(row) for row in rows]}

    def session_declare_impact(
        self, session_id: str, paths: list[str]
    ) -> dict[str, Any]:
        result = self.store.declare_session_impact(session_id=session_id, paths=paths)
        self.session_memory().event(
            session_id=session_id,
            event_type="impact_declared",
            payload={
                "paths": result["impact_paths"],
                "impact_hash": result["impact_hash"],
                "conflict_ids": [item["conflict_id"] for item in result["conflicts"]],
            },
        )
        return result

    def session_conflicts(self, *, status: str | None = "open") -> dict[str, Any]:
        snapshot = self.resolver.current_identity()
        rows = self.store.session_conflicts(
            workspace_id=self._workspace_id(),
            repo_id=snapshot.repo_id,
            status=status,
        )
        return {"ok": True, "conflicts": [_conflict_dict(row) for row in rows]}

    def session_conflict_update(self, conflict_id: str, status: str) -> dict[str, Any]:
        return self.store.update_session_conflict_status(conflict_id, status)

    def _learning_recall_weights(self) -> dict[str, float]:
        memory = self.settings.learning.memory
        return {
            "recency": memory.recall_recency_weight,
            "importance": memory.recall_importance_weight,
            "relevance": memory.recall_relevance_weight,
        }

    def _learning_event_logger(
        self, phase: str, kind: str, ref: str | None, payload: dict[str, Any]
    ) -> None:
        self.store.write_learning_event(
            phase=phase, kind=kind, ref=ref, payload=payload
        )

    def runtime(self) -> RuntimeIngestor:
        snapshot = self.resolver.resolve()
        return RuntimeIngestor(
            self.repo_root,
            self.store,
            repo_id=snapshot.repo_id,
            workspace_id=stable_id(str(self.repo_root))[:16],
        )

    def runtime_ingest(self, source: str, path: str | None = None) -> dict[str, Any]:
        if source == "incidents":
            if not path:
                raise ValueError("runtime ingest incidents requires a path")
            events = runtime_incidents.load(Path(path))
        elif source == "sentry":
            if not path:
                raise ValueError("runtime ingest sentry requires a JSON path")
            events = runtime_sentry.load(Path(path))
        elif source == "ci-failures":
            if not path:
                raise ValueError("runtime ingest ci-failures requires a log path")
            events = runtime_ci_failures.load(Path(path))
        elif source == "feature-flags":
            if not path:
                raise ValueError("runtime ingest feature-flags requires a JSON path")
            events = runtime_feature_flags.load(Path(path))
        elif source == "opentelemetry":
            if not path:
                raise ValueError("runtime ingest opentelemetry requires a JSON path")
            events = runtime_opentelemetry.load(Path(path))
        else:
            raise ValueError(f"unknown runtime source: {source}")
        return self.runtime().ingest_events(source, events)

    def runtime_link_errors(self) -> dict[str, Any]:
        return self.runtime().linked_errors()

    def runtime_candidates(self) -> dict[str, Any]:
        return self.runtime().candidates()

    def org(self) -> OrgIngestor:
        snapshot = self.resolver.resolve()
        return OrgIngestor(
            self.repo_root,
            self.store,
            repo_id=snapshot.repo_id,
            workspace_id=stable_id(str(self.repo_root))[:16],
        )

    def org_connector_add(
        self,
        kind: str,
        *,
        config: dict[str, Any] | None = None,
        display_name: str | None = None,
        secret_ref: str | None = None,
        access_scope: str = "restricted",
        remote_enabled: bool = False,
    ) -> dict[str, Any]:
        return self.org().connector_add(
            kind=kind,
            display_name=display_name,
            config=config or {},
            secret_ref=secret_ref,
            access_scope=access_scope,
            remote_enabled=remote_enabled,
        )

    def org_connectors(self, kind: str | None = None) -> dict[str, Any]:
        return self.org().connectors(kind=kind)

    def org_ingest(
        self,
        connector: str,
        *,
        since: str | None = None,
        path: str | None = None,
        remote: bool = False,
        actor: str = "system",
    ) -> dict[str, Any]:
        return self.org().ingest(
            connector, since=since, path=path, remote=remote, actor=actor
        )

    def org_candidates(
        self,
        *,
        status: str | None = "quarantined",
        source: str | None = None,
        scope: str | None = None,
        actor: str = "local-user",
        limit: int = 100,
    ) -> dict[str, Any]:
        return self.org().candidates(
            status=status,
            source=source,
            scope=scope,
            actor=actor,
            limit=limit,
        )

    def org_approve(
        self,
        candidate_id: str,
        *,
        actor: str = "codeowner",
        supersede: str | None = None,
    ) -> dict[str, Any]:
        return self.org().approve(candidate_id, actor=actor, supersede=supersede)

    def org_reject(
        self, candidate_id: str, *, actor: str = "codeowner", reason: str = "rejected"
    ) -> dict[str, Any]:
        return self.org().reject(candidate_id, actor=actor, reason=reason)

    def org_audit(self, candidate_id: str) -> dict[str, Any]:
        return self.org().audit(candidate_id)

    def decision(self) -> DecisionEngine:
        snapshot = self.resolver.resolve()
        return DecisionEngine(
            repo_root=self.repo_root,
            store=self.store,
            impact=self.impact,
            memory=self.unified_memory(),
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
        )

    def decision_start(
        self,
        question: str,
        *,
        options: list[str] | None = None,
        seed_paths: list[str] | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.decision().start(
            question=question,
            options_seed=options or [],
            seed_paths=seed_paths or [],
            snapshot=snapshot,
        )

    def decision_analyze(self, decision_id: str) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        result = self.decision().analyze(decision_id, snapshot=snapshot)
        readiness = provider_readiness(self.settings)
        result["provider_status"] = readiness
        provider = build_agent_provider(
            self.settings,
            repo_root=self.repo_root,
            event_logger=self._learning_event_logger,
        )
        if not is_real_provider(provider):
            result["provider_reason"] = readiness.get("reason") or "provider_inactive"
            return result
        raw = provider.complete(
            prompt=canonical_json(
                {
                    "task": "Propose advisory decision considerations only.",
                    "decision": result.get("decision", {}),
                    "briefing": result.get("briefing", {}),
                }
            ),
            role="decision_advisor",
            schema={
                "type": "object",
                "properties": {
                    "assertion": {"type": "string"},
                    "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
                },
                "additionalProperties": True,
            },
            model_family=self.settings.learning.actor_model_family,
            budget_tokens=self.settings.learning.max_tokens_per_task,
        )
        if isinstance(raw, dict) and str(raw.get("assertion") or "").strip():
            memory = self.unified_memory().create_typed(
                {
                    "type": "decision",
                    "title": f"Provider advisory for {decision_id}",
                    "assertion": str(raw["assertion"]),
                    "source_kind": "agent_provider",
                    "confidence": float(raw.get("confidence") or 0.5),
                    "status": "candidate",
                    "trust": "untrusted",
                    "metadata": {
                        "rationale": "provider advisory only",
                        "alternatives": ["deterministic recommendation"],
                        "decision_id": decision_id,
                    },
                    "provenance": {
                        "generator": "agent_provider",
                        "validator": "pending_outcome_or_approval",
                        "input_source": "decision_analyze",
                    },
                }
            )
            result["provider_candidate_memory"] = memory
        return result

    def decision_record(
        self,
        decision_id: str,
        *,
        chosen_option_id: str,
        rationale: str,
        actor: str = "local-user",
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.decision().record(
            decision_id,
            chosen_option_id=chosen_option_id,
            rationale=rationale,
            actor=actor,
            snapshot=snapshot,
        )

    def decision_show(self, decision_id: str) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.decision().show(decision_id, snapshot=snapshot)

    def decision_list(
        self, *, status: str | None = None, limit: int = 50
    ) -> dict[str, Any]:
        return self.decision().list(status=status, limit=limit)

    def provider_status(self) -> dict[str, Any]:
        readiness = provider_readiness(self.settings)
        active = bool(readiness.get("configured"))
        return {
            "ok": True,
            "schema_version": "ctxlayer.provider_status.v1",
            "provider_status": readiness,
            "endpoints": {
                name: {
                    "active": active,
                    "reason": None if active else readiness.get("reason"),
                }
                for name in (
                    "reflection",
                    "judge",
                    "intent",
                    "decision",
                    "goal",
                    "workspace",
                )
            },
        }

    def metacog_state(
        self,
        task: str,
        *,
        paths: list[str] | None = None,
        task_session_id: str | None = None,
    ) -> dict[str, Any]:
        return self._metacognitive_state(
            task=task,
            paths=[path.replace("\\", "/") for path in paths or []],
            checkpoint="tick",
            task_session_id=task_session_id,
            persist=False,
            create_clarification=False,
        )

    def clarify_open(
        self,
        question: str,
        *,
        task_session_id: str | None = None,
        pack_id: str | None = None,
        uncertainty_score: float = 1.0,
        resolvable_by: str = "ask",
        provenance: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        request_id = stable_id(
            "clarification", task_session_id or "", pack_id or "", question
        )
        row = self.store.create_clarification_request(
            request_id=request_id,
            task_session_id=task_session_id,
            pack_id=pack_id,
            question=question,
            uncertainty_score=uncertainty_score,
            resolvable_by=resolvable_by,
            provenance=provenance or {"source": "manual"},
        )
        if task_session_id:
            self._continuation_memory().upsert_for_task_session(
                task_session_id,
                event="clarification_open",
                state="blocked",
                next_action=question,
                blockers=[question],
                reason="manual clarification opened",
            )
        return {
            "ok": True,
            "schema_version": "ctxlayer.clarification.v1",
            "clarification": _clarification_row_dict(row),
        }

    def clarify_list(
        self,
        *,
        task_session_id: str | None = None,
        status: str | None = "open",
        limit: int = 50,
    ) -> dict[str, Any]:
        rows = self.store.clarification_requests(
            task_session_id=task_session_id, status=status, limit=limit
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.clarification_list.v1",
            "clarifications": [_clarification_row_dict(row) for row in rows],
        }

    def clarify_answer(self, request_id: str, answer: str) -> dict[str, Any]:
        row = self.store.update_clarification_request(
            request_id, status="answered", answer=answer
        )
        if row is None:
            raise KeyError(f"clarification not found: {request_id}")
        return {
            "ok": True,
            "schema_version": "ctxlayer.clarification.v1",
            "clarification": _clarification_row_dict(row),
        }

    def clarify_withdraw(
        self, request_id: str, reason: str | None = None
    ) -> dict[str, Any]:
        row = self.store.update_clarification_request(
            request_id, status="withdrawn", answer=reason
        )
        if row is None:
            raise KeyError(f"clarification not found: {request_id}")
        return {
            "ok": True,
            "schema_version": "ctxlayer.clarification.v1",
            "clarification": _clarification_row_dict(row),
        }

    def workspace_explain(
        self, task: str, *, paths: list[str] | None = None
    ) -> dict[str, Any]:
        pack = self.get_context_pack(task, seed_paths=paths or [], budget=2000)
        return {
            "ok": True,
            "schema_version": "ctxlayer.workspace_explain.v1",
            "workspace": pack.get("workspace"),
            "pack_id": pack.get("pack_id"),
        }

    def judgment_status(self) -> dict[str, Any]:
        return {
            "ok": True,
            "schema_version": "ctxlayer.judgment_status.v1",
            "enabled": self.settings.metacognition.judgment_enabled,
            "mode": self.settings.metacognition.judgment_mode,
            "candidate_count": len(
                self.store.judgment_heuristics(status="candidate", limit=1000)
            ),
            "adopted_count": len(
                self.store.judgment_heuristics(status="adopted", limit=1000)
            ),
        }

    def judgment_propose(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        proposal_result = propose_judgment_heuristics_from_store(
            self.store,
            workspace_id=self._workspace_id(),
            repo_id=snapshot.repo_id,
            analytics_backend=self.settings.storage.analytics_backend,
            db_path=self.store.db_path,
        )
        stored = [
            _judgment_row_dict(
                self.store.upsert_judgment_heuristic(
                    heuristic_id=item["heuristic_id"],
                    scope=item["scope"],
                    assertion=item["assertion"],
                    basis=item["basis"],
                    support=item["support"],
                    lift=item["lift"],
                    status=item["status"],
                )
            )
            for item in proposal_result["proposals"]
        ]
        return {
            "ok": True,
            "schema_version": "ctxlayer.judgment_propose.v1",
            "proposed": stored,
            "analytics_backend": proposal_result["analytics_backend"],
            "analytics_parity_ok": bool(proposal_result["analytics_parity_ok"]),
            "analytics_fallback_reason": proposal_result.get(
                "analytics_fallback_reason"
            ),
        }

    def judgment_list(self, *, status: str | None = None) -> dict[str, Any]:
        return {
            "ok": True,
            "schema_version": "ctxlayer.judgment_list.v1",
            "heuristics": [
                _judgment_row_dict(row)
                for row in self.store.judgment_heuristics(status=status, limit=200)
            ],
        }

    def judgment_adopt(
        self, heuristic_id: str, *, actor: str = "local-user", reason: str | None = None
    ) -> dict[str, Any]:
        audit = self.store.append_audit(
            pack_id=heuristic_id,
            payload={
                "kind": "judgment_adopted",
                "heuristic_id": heuristic_id,
                "actor": actor,
                "reason": reason,
            },
        )
        row = self.store.update_judgment_heuristic_status(
            heuristic_id, status="adopted", actor=actor, audit_ref=audit["row_hash"]
        )
        if row is None:
            raise KeyError(f"judgment heuristic not found: {heuristic_id}")
        return {
            "ok": True,
            "schema_version": "ctxlayer.judgment.v1",
            "heuristic": _judgment_row_dict(row),
            "audit": audit,
        }

    def judgment_reject(
        self, heuristic_id: str, *, reason: str | None = None
    ) -> dict[str, Any]:
        row = self.store.update_judgment_heuristic_status(
            heuristic_id, status="rejected", audit_ref=reason
        )
        if row is None:
            raise KeyError(f"judgment heuristic not found: {heuristic_id}")
        return {"ok": True, "heuristic": _judgment_row_dict(row)}

    def judgment_rollback(
        self, heuristic_id: str, *, reason: str | None = None
    ) -> dict[str, Any]:
        row = self.store.update_judgment_heuristic_status(
            heuristic_id, status="reverted", audit_ref=reason
        )
        if row is None:
            raise KeyError(f"judgment heuristic not found: {heuristic_id}")
        return {"ok": True, "heuristic": _judgment_row_dict(row)}

    def narrative_show(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        row = self.store.latest_agent_narrative(snapshot.repo_id)
        if row:
            return {
                "ok": True,
                "schema_version": "ctxlayer.narrative.v1",
                "active": True,
                "narrative": _narrative_row_dict(row),
            }
        episodes = self.store.memory_records(
            type="episode",
            workspace_id=self._workspace_id(),
            repo_id=snapshot.repo_id,
        )
        built = build_project_narrative(repo_id=snapshot.repo_id, episodes=episodes)
        if not built.get("active"):
            return built
        row = self.store.write_agent_narrative(
            narrative_id=built["narrative_id"],
            repo_id=snapshot.repo_id,
            summary=built["summary"],
            posture=built["posture"],
            source_run_id="narrative_show",
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.narrative.v1",
            "active": True,
            "narrative": _narrative_row_dict(row),
        }

    def dashboard_data(self) -> dict[str, Any]:
        return {
            "ok": True,
            "dashboard": Dashboard(self.store, repo_root=self.repo_root).data(),
        }

    def dashboard_render(
        self, output: str = ".ctxlayer/dashboard.html"
    ) -> dict[str, Any]:
        return Dashboard(self.store, repo_root=self.repo_root).render_html(
            self.repo_root / output
        )

    def metrics_rollup(
        self,
        *,
        label: str | None = None,
        limit: int = 30,
        output: str | None = None,
    ) -> dict[str, Any]:
        """Emit a privacy-safe, anonymized rollup of this project's CTX Layer impact.

        Read-only: aggregates benchmark lift, outcomes, and learning activity into
        numeric metrics plus an opaque ``project_id`` (and optional ``label``) so a
        deployment's impact can be compared against others without exporting any
        repository content. Collect one per install and diff them.
        """
        snapshot = self.resolver.resolve()
        files = self.store.snapshot_files(snapshot.snapshot_id)
        graph = self.store.graph_stats(snapshot.repo_id)
        scale = {
            "files": len(files),
            "loc": sum(int(row["loc"] or 0) for row in files),
            # Only count-shaped graph fields; central_files carries paths, so it is dropped.
            "symbols": int(graph.get("symbols", 0)),
            "logical_edges": graph.get("logical_edges", {}),
            "semantic_nodes": graph.get("semantic_nodes", {}),
            "semantic_edges": graph.get("semantic_edges", {}),
        }
        rollup = MetricsRollup(
            self.store,
            project_id=self._workspace_id(),
            repo_id=snapshot.repo_id,
            label=label if label is not None else self.settings.toolchain.project_label,
            version=__version__,
            generated_at=utc_now(),
            scale=scale,
            analytics_backend=self.settings.storage.analytics_backend,
            db_path=self.store.db_path,
            limit=limit,
        ).data()
        if output:
            out_path = self.repo_root / output
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(
                json.dumps(rollup, indent=2, sort_keys=True), encoding="utf-8"
            )
            rollup["output"] = str(out_path)
        return rollup

    def semantic_index(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve(refresh=True)
        return self.semantic.index(snapshot)

    def semantic_search(self, query: str, limit: int = 20) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.semantic.search(snapshot.repo_id, query, limit)

    def search_repo(
        self, term: str, max_hops: int = 2, limit: int = 20
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        self.semantic.index(snapshot)
        return self.semantic.search_repo(
            snapshot,
            term,
            max_hops=max_hops,
            limit=limit,
        )

    def graph_stats(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.semantic.stats(snapshot.repo_id)

    def graph_health(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve(refresh=True)
        return self.semantic.health(snapshot.repo_id, snapshot=snapshot)

    def impact_of(self, paths: list[str] | None = None) -> dict[str, Any]:
        return self.get_impact_report(paths=paths or [])

    def business_entity_add(
        self,
        *,
        node_type: str,
        name: str,
        attrs: dict[str, Any] | None = None,
        origin: str = "manual",
        source_type: str | None = None,
        source_ref: str | None = None,
        proposed_by: str = "user",
        confidence: float = 0.9,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.business_graph.add_entity(
            repo_id=snapshot.repo_id,
            node_type=node_type,
            name=name,
            attrs=attrs or {},
            origin=origin,
            source_type=source_type,
            source_ref=source_ref,
            proposed_by=proposed_by,
            confidence=confidence,
        )

    def business_connector_candidate(
        self,
        *,
        node_type: str,
        name: str,
        attrs: dict[str, Any] | None = None,
        source_type: str = "connector",
        source_ref: str = "",
        confidence: float = 0.7,
        proposed_by: str = "connector",
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.business_graph.add_connector_candidate(
            repo_id=snapshot.repo_id,
            candidate=BusinessNodeCandidate(
                node_type=node_type,
                name=name,
                attrs=attrs or {},
                source_type=source_type,
                source_ref=source_ref,
                confidence=confidence,
                proposed_by=proposed_by,
            ),
        )

    def business_entity_bulk_add(
        self,
        *,
        file: str,
        origin: str = "manual",
        proposed_by: str = "user",
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.business_graph.bulk_add_file(
            repo_id=snapshot.repo_id,
            file=file,
            origin=origin,
            proposed_by=proposed_by,
        )

    def business_entity_list(
        self,
        *,
        status: str | None = None,
        node_type: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.business_graph.list(
            repo_id=snapshot.repo_id,
            status=status,
            node_type=node_type,
            limit=limit,
        )

    def business_entity_approve(
        self, node_id: str, *, approver: str = "human", notes: str = ""
    ) -> dict[str, Any]:
        return self.business_graph.approve(node_id, approver=approver, notes=notes)

    def business_entity_reject(
        self, node_id: str, *, approver: str = "human", reason: str = ""
    ) -> dict[str, Any]:
        return self.business_graph.reject(node_id, approver=approver, reason=reason)

    def business_link(
        self,
        *,
        src_node_id: str,
        dst_node_id: str,
        kind: str,
        source_ref: str = "manual",
        source_type: str = "manual_entry",
        proposed_by: str = "user",
        confidence: float | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.business_graph.link(
            repo_id=snapshot.repo_id,
            src_node_id=src_node_id,
            dst_node_id=dst_node_id,
            kind=kind,
            source_ref=source_ref,
            source_type=source_type,
            proposed_by=proposed_by,
            confidence=confidence,
        )

    def semantic_explain(self, node_id: str) -> dict[str, Any]:
        return self.semantic.explain(node_id)

    def semantic_graph_for_path(self, path: str) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.semantic.graph_for_path(snapshot.repo_id, path.replace("\\", "/"))

    def graph_neighbors(
        self,
        path: str,
        *,
        max_hops: int = 1,
        limit: int = 20,
        kinds: list[str] | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        self.semantic.index(snapshot)
        return self.semantic.neighbors_for_path(
            snapshot.repo_id,
            path,
            max_hops=max_hops,
            limit=limit,
            kinds=kinds,
        )

    def graph_path(
        self,
        source_path: str,
        target_path: str,
        *,
        max_hops: int = 4,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        self.semantic.index(snapshot)
        return self.semantic.path_between(
            snapshot.repo_id,
            source_path,
            target_path,
            max_hops=max_hops,
        )

    def graph_tests_for_path(self, path: str) -> dict[str, Any]:
        report = self.get_impact_report(paths=[path.replace("\\", "/")])
        tests = [
            item
            for item in report.get("tests", [])
            if item.get("path") or item.get("command")
        ]
        return {
            "ok": True,
            "path": path.replace("\\", "/"),
            "tests": tests,
            "impact_report_id": report.get("impact_report_id"),
            "risk": report.get("risk", {}),
        }

    def graph_contracts_for_path(self, path: str) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        self.semantic.index(snapshot)
        return self.semantic.contracts_for_path(snapshot.repo_id, path)

    def semantic_list(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.semantic.list_nodes(snapshot.repo_id)

    def semantic_low_confidence(self, threshold: float = 0.5) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        self.semantic.index(snapshot)
        return self.semantic.low_confidence_regions(snapshot.repo_id, threshold)

    def semantic_accuracy_eval(self, fixtures: str | None = None) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.graph_accuracy.run(repo_id=snapshot.repo_id, fixtures=fixtures)

    def semantic_repair_list(
        self,
        *,
        status: str | None = "open",
        limit: int = 100,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.semantic_repair.list(
            repo_id=snapshot.repo_id, status=status, limit=limit
        )

    def semantic_repair_confirm(
        self,
        finding_id: str,
        *,
        actor: str = "human",
        rationale: str = "",
    ) -> dict[str, Any]:
        return self.semantic_repair.confirm(
            finding_id, actor=actor, rationale=rationale
        )

    def semantic_repair_reject(
        self,
        finding_id: str,
        *,
        actor: str = "human",
        rationale: str = "",
    ) -> dict[str, Any]:
        return self.semantic_repair.reject(finding_id, actor=actor, rationale=rationale)

    def architecture_infer(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        self.semantic.index(snapshot)
        return self.architecture.infer(snapshot)

    def architecture_explain(self, service_name: str) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        self.semantic.index(snapshot)
        return self.architecture.explain(snapshot, service_name)

    def architecture_drift(self, *, strict: bool = False) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        self.semantic.index(snapshot)
        return self.architecture.drift(snapshot, strict=strict)

    def architecture_critical_paths(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.architecture.critical_paths(snapshot)

    def agent_route(
        self,
        task: str,
        *,
        risk_score: float = 0.0,
        capabilities: list[str] | None = None,
        remote_review_enabled: bool = False,
    ) -> dict[str, Any]:
        return self.agent_router.route(
            task=task,
            risk_score=risk_score,
            capabilities=capabilities,
            remote_review_enabled=remote_review_enabled,
        )

    def workflow_recommend(
        self,
        task: str,
        *,
        mode: str = "write",
        paths: list[str] | None = None,
        capabilities: list[str] | None = None,
        intent_id: str | None = None,
        goal_id: str | None = None,
    ) -> dict[str, Any]:
        seed_paths = sorted({path.replace("\\", "/") for path in paths or [] if path})
        impact = self.get_impact_report(paths=seed_paths) if seed_paths else None
        signals = self._workflow_surprise_signal(task=task, paths=seed_paths)
        signals["governance_overlay"] = self._governance_adopted_overlay()
        return WorkflowRouter().recommend(
            task=task,
            mode=mode,
            paths=seed_paths,
            capabilities=capabilities or [],
            intent_id=intent_id,
            goal_id=goal_id,
            impact_report=impact,
            signals=signals,
        )

    def workflow_lint(self) -> dict[str, Any]:
        return WorkflowRouter().lint()

    def workflow_start(
        self,
        task: str,
        *,
        mode: str = "write",
        paths: list[str] | None = None,
        capabilities: list[str] | None = None,
        intent_id: str | None = None,
        goal_id: str | None = None,
    ) -> dict[str, Any]:
        seed_paths = sorted({path.replace("\\", "/") for path in paths or [] if path})
        task_result = self.task_start(task)
        pack = self.get_context_pack(
            task,
            seed_paths=seed_paths,
            intent_id=intent_id,
            goal_id=goal_id,
        )
        continuation = self.continuation_resume(task)
        recall = self.memory_recall(task, paths=seed_paths, limit=20)
        impact = self.get_impact_report(paths=seed_paths, pack_id=pack["pack_id"])
        workflow_signals = self._workflow_surprise_signal(task=task, paths=seed_paths)
        workflow_signals["governance_overlay"] = self._governance_adopted_overlay()
        recommendation = WorkflowRouter().recommend(
            task=task,
            mode=mode,
            paths=seed_paths,
            capabilities=capabilities or [],
            intent_id=intent_id,
            goal_id=goal_id,
            impact_report=impact,
            task_session_id=task_result["task_session_id"],
            pack_id=pack["pack_id"],
            signals=workflow_signals,
        )
        remediation = self._workflow_start_remediation(pack)
        session_id = (
            task_result.get("agent_session_id")
            or pack.get("agent_session_id")
            or self._session_id_for_task_session(task_result["task_session_id"])
        )
        snapshot_payload = self._workflow_snapshot_payload(
            recommendation,
            task_session_id=task_result["task_session_id"],
            agent_session_id=session_id,
            pack_id=pack["pack_id"],
        )
        if session_id:
            self._record_agent_session_event(
                str(session_id),
                "workflow_recommendation_snapshot",
                snapshot_payload,
            )
        next_action = self._workflow_next_action_from_recommendation(recommendation)
        self._continuation_memory().upsert_for_task_session(
            task_result["task_session_id"],
            agent_session_id=str(session_id) if session_id else None,
            event="workflow_start",
            state="workflow_started",
            next_action=next_action.get("command") or next_action.get("why"),
            reason="workflow start created recommendation snapshot",
        )
        return {
            "ok": not remediation,
            "schema_version": "ctxlayer.workflow_start.v1",
            "task": task,
            "mode": mode,
            "task_session_id": task_result["task_session_id"],
            "pack_id": pack["pack_id"],
            "agent_session_id": session_id,
            "task_types": recommendation["task_types"],
            "recommendation": recommendation,
            "next_action": next_action,
            "remediation": remediation,
            "continuation_matches": continuation.get("matches", []),
            "memory_recall_count": len(recall.get("records", [])),
            "impact_report_id": impact.get("impact_report_id"),
        }

    def workflow_next(
        self, *, task_session_id: str, record_volatile: bool = True
    ) -> dict[str, Any]:
        snapshot = self._load_workflow_recommendation_snapshot(task_session_id)
        reclassified = False
        if not snapshot:
            task = self._task_text_for_session(task_session_id)
            if not task:
                return {
                    "ok": False,
                    "schema_version": WORKFLOW_NEXT_SCHEMA,
                    "task_session_id": task_session_id,
                    "blocked": True,
                    "reason": "task session not found or lacks task text",
                }
            session_id = self._session_id_for_task_session(task_session_id)
            fallback_mode = infer_mode(task, "auto")
            signals = self._workflow_surprise_signal(task=task, paths=[])
            signals["governance_overlay"] = self._governance_adopted_overlay()
            recommendation = WorkflowRouter().recommend(
                task=task,
                mode=fallback_mode,
                task_session_id=task_session_id,
                signals=signals,
            )
            pack_id = None
            if session_id:
                payload = self._workflow_snapshot_payload(
                    recommendation,
                    task_session_id=task_session_id,
                    agent_session_id=session_id,
                    pack_id=None,
                )
                self._record_agent_session_event(
                    session_id, "workflow_recommendation_snapshot", payload
                )
            snapshot = recommendation
            snapshot["pack_id"] = pack_id
            reclassified = True
        else:
            recommendation = snapshot
        gates = [
            gate["gate_id"] if isinstance(gate, dict) else str(gate)
            for gate in recommendation.get("gates", [])
        ]
        pack_id = recommendation.get("pack_id")
        plan = self.store.latest_task_plan_for_session(task_session_id)
        evaluator = GateEvaluator(
            self.store,
            fingerprint_provider=self._workflow_fingerprint,
            session_resolver=self._session_id_for_task_session,
        )
        gate_status = evaluator.evaluate(task_session_id, gates, pack_id=pack_id)
        for gate_id in ("check_diff_clean", "dirty_set_in_scope"):
            if (
                gate_id in gates
                and gate_status.get(gate_id, {}).get("status")
                in {
                    "pending",
                    "fail",
                }
                and pack_id
                and record_volatile
            ):
                fingerprint = self._workflow_fingerprint()
                check = self.check_diff_against_pack(
                    str(pack_id), paths=fingerprint["changed_paths"]
                )
                evaluator.record_volatile_gate(
                    task_session_id=task_session_id,
                    plan_id=plan["plan_id"] if plan else None,
                    gate_id=gate_id,
                    command=f"ctxlayer --repo . check-diff --pack-id {pack_id}",
                    status="pass" if check.get("ok") else "fail",
                    report=check,
                    fingerprint=fingerprint,
                )
        gate_status = evaluator.evaluate(task_session_id, gates, pack_id=pack_id)
        pending = [
            gate_id
            for gate_id in gates
            if gate_status.get(gate_id, {}).get("status") != "pass"
        ]
        next_action = self._workflow_next_action(recommendation, gate_status, pending)
        complete = not pending and not next_action
        metacognition = None
        task_text = self._task_text_for_session(task_session_id) or ""
        if task_text and self.settings.metacognition.enabled:
            metacognition = self._metacognitive_state(
                task=task_text,
                paths=recommendation.get("paths", []),
                checkpoint="tick",
                pack={},
                task_session_id=task_session_id,
                payload={"__skip_workflow_next": True},
                persist=True,
                create_clarification=False,
            )
        return {
            "ok": True,
            "schema_version": WORKFLOW_NEXT_SCHEMA,
            "task_session_id": task_session_id,
            "pack_id": pack_id,
            "task_types": recommendation.get("task_types", []),
            "reclassified": reclassified,
            "gates": gate_status,
            "next_action": next_action,
            "metacognition": metacognition,
            "open_clarifications": [
                _clarification_row_dict(row)
                for row in self.store.clarification_requests(
                    task_session_id=task_session_id, status="open", limit=20
                )
            ],
            "blocked": bool(next_action and next_action.get("blocked")),
            "escalate": recommendation.get("escalation", {}),
            "completed": complete,
            "complete": complete,
        }

    def bench(self) -> dict[str, Any]:
        def measured(
            name: str,
            budget_ms: float,
            fn: Any,
            *,
            warmups: int = 0,
            samples: int = 1,
        ) -> dict[str, Any]:
            for _ in range(max(0, warmups)):
                fn()
            timings: list[float] = []
            final_details: dict[str, Any] = {}
            ok = True
            error = None
            for _ in range(max(1, samples)):
                start = time.perf_counter()
                details: dict[str, Any] = {}
                try:
                    value = fn()
                    if isinstance(value, dict):
                        details = value
                except Exception as exc:  # noqa: BLE001 - bench reports failures.
                    ok = False
                    error = str(exc)
                    timings.append((time.perf_counter() - start) * 1000)
                    break
                elapsed = (time.perf_counter() - start) * 1000
                timings.append(float(details.get("measured_ms", elapsed)))
                final_details = details
            measured_ms = statistics.median(timings) if timings else 0.0
            if samples > 1 or warmups:
                final_details = {
                    **final_details,
                    "warmups": max(0, warmups),
                    "samples": max(1, samples),
                    "sample_ms": [round(item, 2) for item in timings],
                    "statistic": "median",
                }
            return {
                "name": name,
                "elapsed_ms": round(measured_ms, 2),
                "budget_ms": budget_ms,
                "ok": ok and measured_ms <= budget_ms,
                "error": error,
                "details": final_details,
            }

        def measured_once(name: str, budget_ms: float, fn: Any) -> dict[str, Any]:
            start = time.perf_counter()
            details: dict[str, Any] = {}
            ok = True
            error = None
            try:
                value = fn()
                if isinstance(value, dict):
                    details = value
            except Exception as exc:  # noqa: BLE001 - bench reports failures.
                ok = False
                error = str(exc)
            elapsed = (time.perf_counter() - start) * 1000
            measured_ms = float(details.get("measured_ms", elapsed))
            return {
                "name": name,
                "elapsed_ms": round(measured_ms, 2),
                "budget_ms": budget_ms,
                "ok": ok and measured_ms <= budget_ms,
                "error": error,
                "details": details,
            }

        def cold_import() -> dict[str, Any]:
            env = dict(os.environ)
            src_root = Path(__file__).resolve().parents[1]
            env["PYTHONPATH"] = (
                str(src_root)
                if not env.get("PYTHONPATH")
                else str(src_root) + os.pathsep + env["PYTHONPATH"]
            )
            completed = subprocess.run(
                [
                    sys.executable,
                    "-c",
                    "import time; s=time.perf_counter(); import ctxlayer.service; "
                    "print(round((time.perf_counter()-s)*1000, 2))",
                ],
                cwd=self.repo_root,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env,
                timeout=10,
            )
            if completed.returncode != 0:
                raise RuntimeError(completed.stderr.strip() or "cold import failed")
            return {"measured_ms": float(completed.stdout.strip())}

        def warm_construct() -> dict[str, Any]:
            with CtxLayerService(self.repo_root) as _service:
                return {"engines_constructed": _service._constructed_engines()}

        def pre_tool() -> dict[str, Any]:
            decision = codex_pre_tool_gate(
                tool_name="apply_patch",
                preflight_ready=True,
                active_plan_step=True,
            )
            return {"decision": decision["decision"]}

        def non_pre_tool_event() -> dict[str, Any]:
            session_id = stable_id("bench", str(self.repo_root))
            self.store.start_agent_session(
                session_id=session_id,
                workspace_id=stable_id(str(self.repo_root))[:16],
                repo_id=None,
                task_text_hash=stable_id("bench"),
                agent_name="bench",
                metadata={"source": "bench"},
            )
            event_id = self.store.append_agent_session_event(
                session_id=session_id,
                event_type="bench_event",
                payload={"source": "bench", "time": utc_now()},
            )
            return {"event_id": event_id}

        def memory_recall() -> dict[str, Any]:
            result = self.memory_recall("snapshot context resolver", limit=5)
            return {"results": len(result.get("items", []))}

        def pack_time() -> dict[str, Any]:
            snapshot = self.resolver.resolve()
            manifest = self.compiler.compile(
                snapshot=snapshot,
                task="ctxlayer bench budget probe",
                write=False,
                budget=1000,
            )
            return {"items": len(manifest.get("items", []))}

        start = time.perf_counter()
        snapshot = self.resolver.resolve(refresh=True)
        index_ms = (time.perf_counter() - start) * 1000
        start = time.perf_counter()
        rows = self.store.search_chunks(
            snapshot.snapshot_id, "snapshot context resolver", limit=20
        )
        search_ms = (time.perf_counter() - start) * 1000
        files = self.store.snapshot_files(snapshot.snapshot_id)
        loc = sum(int(row["loc"] or 0) for row in files)
        checks = [
            measured_once("cold_import", 250.0, cold_import),
            measured("warm_construct", 50.0, warm_construct, warmups=1, samples=3),
            measured("pre_tool_use", 5.0, pre_tool, warmups=1, samples=5),
            measured(
                "non_pre_tool_event",
                150.0,
                non_pre_tool_event,
                warmups=1,
                samples=3,
            ),
            measured("memory_recall", 150.0, memory_recall, warmups=1, samples=3),
            measured("pack", 2000.0, pack_time, warmups=1, samples=3),
        ]
        db_path = self.workspace_dir / "workspace.db"
        report = {
            "ok": all(check["ok"] for check in checks),
            "schema_version": "ctxlayer.bench.v1",
            "budgets": checks,
            "snapshot_id": snapshot.snapshot_id,
            "files": len(files),
            "loc": loc,
            "index_ms": round(index_ms, 2),
            "parse_loc_per_sec": round(loc / max(index_ms / 1000, 0.001), 2),
            "search_ms": round(search_ms, 2),
            "search_results": len(rows),
            "db_size_bytes": db_path.stat().st_size if db_path.exists() else 0,
            "storage": self.db_backend_status(),
        }
        reports_dir = self.workspace_dir / "reports"
        reports_dir.mkdir(parents=True, exist_ok=True)
        report_path = reports_dir / "bench.json"
        report_path.write_text(
            json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        return {**report, "report_path": str(report_path)}

    def _constructed_engines(self) -> list[str]:
        names = [
            "resolver",
            "compiler",
            "impact",
            "behavior",
            "audit",
            "intent",
            "goals",
            "replay",
            "ci",
            "release",
            "workspace",
            "semantic",
            "business_graph",
            "architecture",
            "graph_accuracy",
            "semantic_repair",
            "agent_router",
            "component_eval",
        ]
        return [name for name in names if getattr(self, f"_{name}", None) is not None]

    def doctor(self, *, full: bool = False) -> dict[str, Any]:
        try:
            with self.store.budget(self.settings.reliability.doctor_budget_ms):
                tree_sitter = tree_sitter_status()
                setup = setup_readiness(self.repo_root)
                health = self.ctx_health(persist=True)
        except CtxBudgetExceeded:
            health = self.ctx_health(unavailable_reason="doctor_budget_exceeded")
            return {
                "ok": False,
                "operational": False,
                "status": "unavailable",
                "ctx_health": health,
                "remediation": {
                    "gc": "ctxlayer --repo . gc --deep",
                    "doctor": "ctxlayer --repo . doctor",
                },
            }
        remediation = _setup_remediation(setup.get("missing", []))
        maintenance_cadence = self.maintenance_cadence()
        if health["status"] != "ok":
            remediation["gc"] = "ctxlayer --repo . gc --deep"
            remediation["resuscitation"] = (
                "Stop long-lived CTX writers that pin the WAL, run "
                "`ctxlayer --repo . gc --deep`, then rerun doctor."
            )
        if maintenance_cadence["overdue"] and maintenance_cadence["auto"]:
            remediation["maintenance"] = "ctxlayer --repo . maintenance tick"
        storage = self.storage_report(limit=10)
        storage_warnings = []
        pinning = storage.get("pinning", {})
        redundant_vectors = storage.get("redundant_vectors", {})
        if int(pinning.get("pinned_snapshot_count", 0)) > int(
            self.settings.maintenance.max_pinned_snapshots
        ):
            storage_warnings.append("pinned_snapshots_over_budget")
            remediation["storage_gc"] = (
                "ctxlayer --repo . gc --deep --prune-snapshots"
            )
        if int(pinning.get("releasable_pack_pin_count", 0)) > 0:
            storage_warnings.append("releasable_dirty_pack_pins")
            remediation["storage_gc"] = (
                "ctxlayer --repo . gc --deep --prune-snapshots"
            )
        redundant_chunk_bytes = redundant_vectors.get("redundant_chunk_vector_json_bytes")
        redundant_memory_bytes = redundant_vectors.get("redundant_memory_vector_json_bytes")
        if (
            redundant_chunk_bytes is not None
            and redundant_memory_bytes is not None
            and int(redundant_chunk_bytes) + int(redundant_memory_bytes) > 0
        ):
            storage_warnings.append("redundant_vector_json")
            remediation["storage_gc"] = "ctxlayer --repo . gc --deep"
        governance_lint = self.workflow_lint()
        migration_verification = self.migrate_verify()
        blocking_missing = _setup_blocking_missing(setup.get("missing", []))
        setup_status = (
            "complete"
            if setup["ok"]
            else "blocked" if blocking_missing else "advisory_incomplete"
        )
        report = {
            "ok": health["status"] != "unavailable",
            "operational": health["status"] != "unavailable",
            "status": "ok" if health["status"] == "ok" else "degraded",
            "ctx_health": health,
            "setup_complete": bool(setup["ok"]),
            "setup_status": setup_status,
            "ready_for_work": not blocking_missing,
            "setup_blocking": bool(blocking_missing),
            "setup_blocking_missing": blocking_missing,
            "setup_advisory_missing": [
                item
                for item in setup.get("missing", [])
                if item not in blocking_missing
            ],
            "repo": str(self.repo_root),
            "database": str(self.workspace_dir / "workspace.db"),
            "store": self.store.capabilities(),
            "tree_sitter": {
                "available": tree_sitter.available,
                "languages": tree_sitter.languages,
                "error": tree_sitter.error,
            },
            "settings": {
                "parser_backend": self.settings.toolchain.parser_backend,
                "embed_backend": self.settings.toolchain.embed_backend,
                "embed_model": self.settings.toolchain.embed_model,
                "vector_backend": self.settings.toolchain.vector_backend,
                "storage": self.db_backend_status(),
                "security": self.security_status(),
            },
            "readiness": self._readiness_report(),
            "setup": setup,
            "maintenance": maintenance_cadence,
            "storage_report": {
                "db_bytes": storage.get("db", {}).get("db_bytes", 0),
                "wal_bytes": storage.get("db", {}).get("wal_bytes", 0),
                "pinning": storage.get("pinning", {}),
                "redundant_vectors": storage.get("redundant_vectors", {}),
                "warnings": storage_warnings,
            },
            "governance": {
                "surface_in_pack": self.settings.governance.surface_in_pack,
                "surface_at_prompt": self.settings.governance.surface_at_prompt,
                "surface_in_preflight": self.settings.governance.surface_in_preflight,
                "enforcement_mode": self.settings.governance.enforcement_mode,
                "derive_state_from_store": (
                    self.settings.governance.derive_state_from_store
                ),
                "hooks": {
                    "codex": self._hook_runtime_status("codex"),
                    "claude": self._hook_runtime_status("claude"),
                },
                "workflow_lint_ok": bool(governance_lint.get("ok")),
                "adaptation": self.governance_status(),
                "knowledge_preservation": migration_verification[
                    "knowledge_preservation"
                ],
            },
            "metacognition": {
                "enabled": self.settings.metacognition.enabled,
                "surface_in_pack": self.settings.metacognition.surface_in_pack,
                "clarification_mode": self.settings.metacognition.clarification_mode,
                "open_clarifications": len(
                    self.store.clarification_requests(status="open", limit=1000)
                ),
                "workspace_enabled": self.settings.metacognition.workspace_enabled,
                "workspace_active": bool(
                    provider_readiness(self.settings).get("configured")
                )
                and self.settings.metacognition.workspace_enabled,
                "judgment_enabled": self.settings.metacognition.judgment_enabled,
                "judgment_mode": self.settings.metacognition.judgment_mode,
                "pending_heuristics": len(
                    self.store.judgment_heuristics(status="candidate", limit=1000)
                ),
                "narrative_enabled": self.settings.metacognition.narrative_enabled,
                "narrative_present": bool(
                    self.store.latest_agent_narrative(
                        self.resolver.current_identity().repo_id
                    )
                ),
                "config_warning": self.settings.metacognition.config_warning,
            },
            "remediation": remediation,
        }
        if full:
            report["capabilities"] = self._capability_matrix(report["readiness"])
        return report

    def _readiness_report(self) -> dict[str, Any]:
        embedder = self._embedder_readiness()
        gate_mode, gate_degraded = self._anticipation_gate_mode()
        neural = self.settings.learning.rerank
        neural_available = False
        neural_reason = None
        if neural.neural_enabled:
            if neural.neural_model.strip():
                try:
                    from ctxlayer.learning.neural_rerank import cross_encoder_available

                    neural_available = bool(
                        cross_encoder_available(neural.neural_model)
                    )
                except Exception as exc:  # noqa: BLE001 - doctor reports readiness.
                    neural_reason = str(exc)
            else:
                neural_reason = "no_neural_model_configured"
        return {
            "embedder": {
                "backend": embedder["backend"],
                "model_name": embedder["model_name"],
                "degraded_reason": embedder["degraded_reason"],
                "degraded_severity": embedder.get("degraded_severity"),
                "degraded_remediation": embedder.get("degraded_remediation"),
                "available": embedder["available"],
            },
            "provider": provider_readiness(self.settings),
            "neural_rerank": {
                "enabled": neural.neural_enabled,
                "model": neural.neural_model,
                "available": neural_available,
                "reason": neural_reason
                or (
                    None
                    if not neural.neural_enabled or neural_available
                    else "model_unavailable"
                ),
            },
            "anticipation": {
                "mode": self.settings.anticipation.mode,
                "effective_mode": gate_mode,
                "enforce_ready": gate_mode == "enforce",
                "degraded_reason": (
                    gate_degraded.get("reason")
                    if isinstance(gate_degraded, dict)
                    else None
                ),
            },
        }

    def _embedder_readiness(self) -> dict[str, Any]:
        toolchain = self.settings.toolchain
        embedder = make_embedder(
            model_name=toolchain.embed_model,
            backend=toolchain.embed_backend,
        )
        degraded_reason = getattr(embedder, "degraded_reason", None)
        backend = getattr(embedder, "backend", "unknown")
        return {
            "available": degraded_reason is None,
            "backend": backend,
            "model_name": getattr(embedder, "model_name", toolchain.embed_model),
            "degraded_reason": degraded_reason,
            "degraded_severity": getattr(embedder, "degraded_severity", None),
            "degraded_remediation": getattr(embedder, "degraded_remediation", None),
        }

    def _capability_matrix(self, readiness: dict[str, Any]) -> dict[str, Any]:
        provider = readiness.get("provider") or {}
        embedder = readiness.get("embedder") or {}
        anticipation = readiness.get("anticipation") or {}
        provider_usable = bool(provider.get("configured"))
        return {
            "context_pack": {"state": "usable"},
            "adaptive_chunking": {"state": "usable"},
            "embedder": {
                "state": (
                    "usable"
                    if not embedder.get("degraded_reason")
                    else "needs:sentence_transformers"
                ),
                "detail": embedder.get("degraded_reason"),
            },
            "agent_provider": {
                "state": (
                    "usable" if provider_usable else "needs:learning.agent_command"
                ),
                "detail": provider.get("reason"),
            },
            "memory_reflection": {
                "state": (
                    "usable" if provider_usable else "needs:learning.agent_command"
                ),
                "detail": provider.get("reason"),
            },
            "selfmod": {
                "state": (
                    "usable" if provider_usable else "needs:learning.agent_command"
                ),
                "detail": provider.get("reason"),
            },
            "server_auth": {
                "state": (
                    "usable"
                    if self.settings.server.auth in {"none", "token"}
                    else "not-implemented"
                ),
                "mode": self.settings.server.auth,
            },
            "workspace_encryption": {
                "state": "not-implemented",
                "detail": "encrypt_workspace_db=true fails closed",
            },
            "anticipation_enforce": {
                "state": (
                    "usable"
                    if anticipation.get("enforce_ready")
                    else "needs:calibrated_anticipation_model"
                ),
                "detail": anticipation.get("degraded_reason"),
            },
        }

    def _snapshot_dict(self, snapshot: SnapshotInfo) -> dict[str, Any]:
        return {
            "repo_id": snapshot.repo_id,
            "snapshot_id": snapshot.snapshot_id,
            "base_commit_sha": snapshot.base_commit_sha,
            "tree_digest": snapshot.tree_digest,
            "dirty_digest": snapshot.dirty_digest,
            "worktree_state": snapshot.worktree_state,
            "branch_hint": snapshot.branch_hint,
        }

    def _pack_binding(
        self, snapshot: SnapshotInfo, bind_snapshot: str | None
    ) -> dict[str, Any]:
        bound_snapshot_id = bind_snapshot or snapshot.snapshot_id
        mode = "pinned" if bind_snapshot else "auto"
        bound_row = self.store.snapshot_row(bound_snapshot_id)
        staleness = self._staleness_for_bound_snapshot(
            bound_snapshot_id, current=snapshot
        )
        return {
            "bound_snapshot_id": bound_snapshot_id,
            "binding_mode": mode,
            "bound_at": utc_now(),
            "base_commit_sha": (
                bound_row["base_commit_sha"] if bound_row else snapshot.base_commit_sha
            ),
            "worktree_state": (
                bound_row["worktree_state"] if bound_row else snapshot.worktree_state
            ),
            "staleness": staleness,
        }

    def _staleness_for_bound_snapshot(
        self, bound_snapshot_id: str | None, current: SnapshotInfo | None = None
    ) -> dict[str, Any]:
        current = current or self.resolver.current_identity()
        state = "fresh" if bound_snapshot_id == current.snapshot_id else "stale"
        return {
            "state": state,
            "bound_snapshot_id": bound_snapshot_id,
            "current_snapshot_id": current.snapshot_id,
            "current_base_commit_sha": current.base_commit_sha,
            "current_worktree_state": current.worktree_state,
        }


def _benchmark_row_dict(row: Any, *, include_report: bool = False) -> dict[str, Any]:
    gate = None
    gate_status = row["gate_status"]
    if gate_status or row["gate_ok"] is not None:
        gate = {"ok": bool(row["gate_ok"]) if row["gate_ok"] is not None else None}
        if gate_status:
            gate["status"] = gate_status
    result = {
        "benchmark_run_id": row["benchmark_run_id"],
        "repo_id": row["repo_id"],
        "cases": int(row["cases"] or 0),
        "success_rate_delta": float(row["success_rate_delta"] or 0.0),
        "tests_pass_rate_delta": float(row["tests_pass_rate_delta"] or 0.0),
        "wrong_files_touched_reduction": float(
            row["wrong_files_touched_reduction"] or 0.0
        ),
        "missing_files_reduction": float(row["missing_files_reduction"] or 0.0),
        "agent_seconds_reduction": float(row["agent_seconds_reduction"] or 0.0),
        "memory_score": float(row["memory_score"] or 0.0),
        "context_retrieval_score": float(row["context_retrieval_score"] or 0.0),
        "gate": gate,
        "delta": parse_run_json(row["delta_json"]),
        "lift_attribution": parse_run_json(row["lift_attribution_json"]),
        "roadmap_pruning": parse_run_json(row["roadmap_pruning_json"]),
        "created_at": row["created_at"],
    }
    if include_report:
        result["report"] = parse_run_json(row["report_json"])
    return result


def _lease_dict(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["impact_paths"] = _json_list(item.pop("impact_paths_json", "[]"))
    return item


def _conflict_dict(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["paths"] = _json_list(item.pop("paths_json", "[]"))
    item["detail"] = _json_dict(item.pop("detail_json", "{}"))
    return item


def _json_list(value: str | None) -> list[str]:
    try:
        parsed = json.loads(value or "[]")
    except json.JSONDecodeError:
        return []
    return [str(item) for item in parsed] if isinstance(parsed, list) else []


def _json_dict(value: str | None) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _governance_proposal_dict(row: Any) -> dict[str, Any]:
    return {
        "proposal_id": row["proposal_id"],
        "task_type": row["task_type"],
        "feature_id": row["feature_id"],
        "change": row["change"],
        "status": row["status"],
        "support": row["support"],
        "lift": row["lift"],
        "confidence": row["confidence"],
        "evidence": _json_dict(row["evidence_json"]),
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


def _clarification_row_dict(row: Any) -> dict[str, Any]:
    return {
        "request_id": row["request_id"],
        "task_session_id": row["task_session_id"],
        "pack_id": row["pack_id"],
        "question": row["question"],
        "uncertainty_score": float(row["uncertainty_score"] or 0.0),
        "resolvable_by": row["resolvable_by"],
        "provenance": _json_dict(row["provenance_json"]),
        "status": row["status"],
        "answer": row["answer"],
        "created_at": row["created_at"],
        "answered_at": row["answered_at"],
    }


def _judgment_row_dict(row: Any) -> dict[str, Any]:
    return {
        "heuristic_id": row["heuristic_id"],
        "scope": row["scope"],
        "assertion": row["assertion"],
        "basis": _json_dict(row["basis_json"]),
        "support": int(row["support"] or 0),
        "lift": float(row["lift"] or 0.0),
        "status": row["status"],
        "created_at": row["created_at"],
        "adopted_by": row["adopted_by"],
        "audit_ref": row["audit_ref"],
    }


def _narrative_row_dict(row: Any) -> dict[str, Any]:
    return {
        "narrative_id": row["narrative_id"],
        "repo_id": row["repo_id"],
        "summary": row["summary"],
        "posture": _json_dict(row["posture_json"]),
        "source_run_id": row["source_run_id"],
        "created_at": row["created_at"],
        "supersedes": row["supersedes"],
    }


def _metacognition_public_signals(signals: dict[str, Any]) -> dict[str, Any]:
    pack = signals.get("pack") if isinstance(signals.get("pack"), dict) else {}
    return {
        "task": signals.get("task"),
        "paths": signals.get("paths", []),
        "pack_id": pack.get("pack_id"),
        "pack_low_confidence": bool(pack.get("low_confidence")),
        "warning_kinds": [
            str(item.get("kind") or "")
            for item in pack.get("warnings", [])
            if isinstance(item, dict) and item.get("kind")
        ],
        "surprise": signals.get("surprise"),
        "goal_confidence": signals.get("goal_confidence"),
        "unresolved_gates": signals.get("unresolved_gates", 0),
        "verification_failures": signals.get("verification_failures", 0),
    }


def _normalize_path(path: str) -> str:
    return str(path).replace("\\", "/").lstrip("./")


def _tool_payload_paths(payload: dict[str, Any]) -> list[str]:
    candidates: list[str] = []
    for key in ("path", "file_path", "filepath", "target_path", "target_paths"):
        value = payload.get(key)
        if isinstance(value, str):
            candidates.append(value)
        elif isinstance(value, list):
            candidates.extend(str(item) for item in value if str(item).strip())
    args = payload.get("args") or payload.get("arguments") or payload.get("input")
    if isinstance(args, dict):
        candidates.extend(_tool_payload_paths(args))
    elif isinstance(args, list):
        for item in args:
            if isinstance(item, dict):
                candidates.extend(_tool_payload_paths(item))
    return sorted({_normalize_path(path) for path in candidates if str(path).strip()})


def _tool_payload_content(payload: dict[str, Any]) -> str | None:
    for key in ("proposed_content", "content", "new_content", "text", "patch"):
        value = payload.get(key)
        if isinstance(value, str) and value:
            return value
    args = payload.get("args") or payload.get("arguments") or payload.get("input")
    if isinstance(args, dict):
        return _tool_payload_content(args)
    return None


def _memory_enforcement_dict(row: Any) -> dict[str, Any]:
    if row is None:
        return {}
    item = dict(row)
    item["path_globs"] = item.pop("path_globs", _json_list(item.get("path_globs_json")))
    item["symbol_ids"] = item.pop("symbol_ids", _json_list(item.get("symbol_ids_json")))
    item["anti_patterns"] = item.pop(
        "anti_patterns", _json_list(item.get("anti_patterns_json"))
    )
    item["required_patterns"] = item.pop(
        "required_patterns", _json_list(item.get("required_patterns_json"))
    )
    for key in (
        "path_globs_json",
        "symbol_ids_json",
        "anti_patterns_json",
        "required_patterns_json",
    ):
        item.pop(key, None)
    if "confidence" in item and item["confidence"] is not None:
        item["confidence"] = float(item["confidence"])
    return item


def _benchmark_failure_traces(
    report: dict[str, Any], *, limit: int = 8
) -> list[dict[str, Any]]:
    traces: list[dict[str, Any]] = []
    for case in report.get("case_results", []) or []:
        if not isinstance(case, dict):
            continue
        ctxlayer = (case.get("arms") or {}).get("ctxlayer", {})
        if not isinstance(ctxlayer, dict):
            continue
        score = ctxlayer.get("score") if isinstance(ctxlayer.get("score"), dict) else {}
        failed = (
            ctxlayer.get("success") is False
            or bool(score.get("missing_files"))
            or bool(score.get("wrong_files_touched"))
        )
        if not failed:
            continue
        traces.append(
            {
                "case_id": case.get("case_id"),
                "task": case.get("task"),
                "expected_files": case.get("expected_files", []),
                "changed_files": ctxlayer.get("changed_files", []),
                "missing": score.get("missing", []),
                "wrong_files": score.get("wrong_files", []),
                "tests_passed": ctxlayer.get("tests_passed"),
                "preflight": _compact_preflight(ctxlayer.get("preflight")),
            }
        )
        if len(traces) >= limit:
            break
    return traces


def _compact_preflight(preflight: Any) -> dict[str, Any]:
    if not isinstance(preflight, dict):
        return {}
    check = (
        preflight.get("check_diff")
        if isinstance(preflight.get("check_diff"), dict)
        else {}
    )
    impact = (
        preflight.get("impact") if isinstance(preflight.get("impact"), dict) else {}
    )
    return {
        "check_diff_ok": check.get("ok"),
        "violations": (
            check.get("violations", [])[:3]
            if isinstance(check.get("violations"), list)
            else []
        ),
        "impact_tests": (
            [
                item.get("command")
                for item in impact.get("tests", [])[:5]
                if isinstance(item, dict) and item.get("command")
            ]
            if isinstance(impact.get("tests"), list)
            else []
        ),
    }


def _verification_name(commands: list[str]) -> str:
    if not commands:
        return "verification"
    command = commands[0].strip()
    if "verify-production-assets" in command:
        return "verify-production-assets"
    first = command.split()[0] if command.split() else "verification"
    return Path(first).name or "verification"


def git_changed_paths(repo_root: Path, *, staged: bool = False) -> list[str]:
    args = ["git", "diff", "--name-only", "HEAD"]
    if staged:
        args = ["git", "diff", "--cached", "--name-only", "HEAD"]
    try:
        result = subprocess.run(
            args,
            cwd=repo_root,
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=10,
        )
    except (subprocess.SubprocessError, FileNotFoundError):
        return []
    return [
        line.strip().replace("\\", "/")
        for line in result.stdout.splitlines()
        if line.strip()
    ]


def git_deleted_paths(repo_root: Path, *, staged: bool = False) -> list[str]:
    args = ["git", "diff", "--name-only", "--diff-filter=D", "HEAD"]
    if staged:
        args = ["git", "diff", "--cached", "--name-only", "--diff-filter=D", "HEAD"]
    try:
        result = subprocess.run(
            args,
            cwd=repo_root,
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=10,
        )
    except (subprocess.SubprocessError, FileNotFoundError):
        return []
    return [
        line.strip().replace("\\", "/")
        for line in result.stdout.splitlines()
        if line.strip()
    ]


def paths_from_diff(diff: str | None) -> list[str]:
    if not diff:
        return []
    paths: set[str] = set()
    for line in diff.splitlines():
        if line.startswith("diff --git "):
            parts = line.split()
            if len(parts) >= 4:
                paths.add(parts[3].removeprefix("b/"))
        elif line.startswith("+++ b/"):
            paths.add(line[6:])
        elif line.startswith("--- a/"):
            paths.add(line[6:])
    return sorted(path for path in paths if path and path != "/dev/null")


def _continuation_state_for_task_state(state: str) -> str:
    return {
        "INTAKE": "intake",
        "PACK": "packed",
        "PLAN": "planned",
        "EXECUTE": "editing",
        "PREFLIGHT": "checking",
        "OUTCOME": "ready_to_resume",
    }.get(state.upper(), "ready_to_resume")


def _learning_narrative(counts: dict[str, Any]) -> str:
    proposed = int(counts.get("memories_proposed") or 0)
    promoted = int(counts.get("memories_promoted") or 0)
    skills = int(counts.get("skills_induced") or 0)
    conflicts = int(counts.get("conflicts_found") or 0)
    stale = int(counts.get("stale_marked") or 0)
    parts = []
    if proposed:
        parts.append(f"proposed {proposed} memory record(s)")
    if promoted:
        parts.append(f"promoted {promoted} memory record(s)")
    if skills:
        parts.append(f"induced {skills} skill(s)")
    if conflicts:
        parts.append(f"flagged {conflicts} memory conflict(s)")
    if stale:
        parts.append(f"marked {stale} stale memory record(s)")
    if not parts:
        return "CTX did not learn anything new from this task."
    return "From this task CTX " + ", ".join(parts) + "."


def _extract_predicted_paths(payload: dict[str, Any]) -> list[str]:
    paths: list[str] = []

    def add(value: Any) -> None:
        if isinstance(value, str) and value.strip():
            paths.append(value.replace("\\", "/"))
        elif isinstance(value, list):
            for item in value:
                add(item)

    if not isinstance(payload, dict):
        return []
    add(payload.get("predicted_paths"))
    add(payload.get("paths"))
    for key in ("candidates", "actions", "rollout", "foresight", "items"):
        for item in payload.get(key) or []:
            if isinstance(item, dict):
                add(item.get("path"))
                add(item.get("paths"))
                add(item.get("target_paths"))
                add(item.get("active_paths"))
    return _dedupe_strings(paths)


def _extract_efe_confidence(payload: dict[str, Any]) -> float | None:
    if not isinstance(payload, dict):
        return None
    for key in ("efe_confidence", "confidence", "probability", "score"):
        value = payload.get(key)
        if isinstance(value, (int, float)):
            return max(0.0, min(1.0, float(value)))
    for key in ("candidates", "actions", "rollout", "foresight"):
        values = [
            float(item.get("confidence"))
            for item in payload.get(key) or []
            if isinstance(item, dict)
            and isinstance(item.get("confidence"), (int, float))
        ]
        if values:
            return max(0.0, min(1.0, sum(values) / len(values)))
    return None


def _learning_event_dict(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["payload"] = _json_dict(item.pop("payload_json", "{}"))
    return item


def _memory_conflict_summary(left: str, right: str) -> str | None:
    left_l = left.lower()
    right_l = right.lower()
    if ("must " in left_l and "must not" in right_l) or (
        "must not" in left_l and "must " in right_l
    ):
        return "Memory assertions use conflicting obligation verbs."
    left_numbers = {
        int(num.replace(",", "").replace("_", ""))
        for num in re.findall(r"\d[\d,_]*", left_l)
    }
    right_numbers = {
        int(num.replace(",", "").replace("_", ""))
        for num in re.findall(r"\d[\d,_]*", right_l)
    }
    if left_numbers and right_numbers and left_numbers != right_numbers:
        left_terms = set(re.findall(r"[a-zA-Z]{4,}", left_l))
        right_terms = set(re.findall(r"[a-zA-Z]{4,}", right_l))
        if len(left_terms & right_terms) >= 2:
            return f"Different thresholds detected: {sorted(left_numbers)} vs {sorted(right_numbers)}."
    return None


def _age_days(timestamp: str | None) -> int:
    if not timestamp:
        return 9999
    try:
        parsed = datetime.fromisoformat(str(timestamp).replace("Z", "+00:00"))
    except ValueError:
        return 9999
    return max(0, int((time.time() - parsed.timestamp()) / 86400))


def _row_value(row: Any, key: str) -> Any:
    try:
        return row[key]
    except (KeyError, IndexError):
        return None


def _db_benchmark_row(row: Any) -> dict[str, Any]:
    try:
        detail = json.loads(row["detail_json"] or "{}")
    except json.JSONDecodeError:
        detail = {}
    return {
        "run_id": row["run_id"],
        "kind": row["kind"],
        "corpus_size": int(row["corpus_size"]),
        "backend": row["backend"],
        "p50_ms": float(row["p50_ms"]),
        "p95_ms": float(row["p95_ms"]),
        "rows": int(row["rows"]),
        "detail": detail,
        "created_at": row["created_at"],
    }


def _setup_remediation(missing: list[str]) -> dict[str, str]:
    commands = {
        "agents_contract": "ctxlayer --repo . setup codex --install-hooks --configure-mcp",
        "agents_file": "ctxlayer --repo . bootstrap --agents codex",
        "capabilities_file": "ctxlayer --repo . bootstrap --agents codex",
        "codex_mcp_snippet": "ctxlayer --repo . setup codex --configure-mcp",
        "ctxlayer_ignored": "ctxlayer --repo . init",
        "git_repo": "ctxlayer --repo . setup codex --init-git",
        "pre_commit_hook": "ctxlayer --repo . setup codex --install-hooks",
        "post_commit_hook": "ctxlayer --repo . setup codex --install-hooks",
    }
    return {name: commands[name] for name in missing if name in commands}


def _setup_blocking_missing(missing: list[str]) -> list[str]:
    blocking = {"git_repo"}
    return [item for item in missing if item in blocking]


def _split_agents(agents: list[str] | str) -> list[str]:
    if isinstance(agents, str):
        return [agent for agent in re.split(r"[\s,]+", agents) if agent]
    result: list[str] = []
    for item in agents:
        result.extend(agent for agent in re.split(r"[\s,]+", str(item)) if agent)
    return result


def _outcome_health(service: CtxLayerService) -> dict[str, Any]:
    rows = service.store.conn.execute(
        "SELECT result, COUNT(*) AS count FROM outcomes GROUP BY result"
    ).fetchall()
    by_result: dict[str, int] = {}
    for row in rows:
        bucket = str(row["result"] or "").split(":", 1)[0] or "unknown"
        by_result[bucket] = by_result.get(bucket, 0) + int(row["count"])
    total = sum(by_result.values())
    passed = by_result.get("pass", 0)
    return {
        "outcome_success_rate": round(passed / total, 6) if total else 0.0,
        "outcomes_total": total,
        "outcomes_by_result": by_result,
    }


def _project_remediation_commands(
    remediation: Any, project_path: str
) -> dict[str, str]:
    if not isinstance(remediation, dict):
        return {}
    commands: dict[str, str] = {}
    for key, command in remediation.items():
        if not isinstance(command, str):
            continue
        commands[str(key)] = command.replace("--repo .", f"--repo {project_path}")
    return commands


def _dedupe_strings(values: list[str]) -> list[str]:
    seen: set[str] = set()
    deduped: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        deduped.append(value)
    return deduped


def _version_is_older(version: Any, current: str) -> bool:
    if not isinstance(version, str) or not version:
        return False
    parsed = _version_key(version)
    current_parsed = _version_key(current)
    if parsed is None or current_parsed is None:
        return version != current
    return parsed < current_parsed


def _version_key(version: str) -> tuple[int, int, int, int, int] | None:
    match = re.match(r"^(\d+)\.(\d+)\.(\d+)(?:a(\d+))?$", version)
    if not match:
        return None
    major, minor, patch, alpha = match.groups()
    release_rank = 1 if alpha is None else 0
    alpha_number = int(alpha or 0)
    return (int(major), int(minor), int(patch), release_rank, alpha_number)
