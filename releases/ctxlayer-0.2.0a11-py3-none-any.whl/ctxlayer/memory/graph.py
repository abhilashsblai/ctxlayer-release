from __future__ import annotations

from typing import Any

from ctxlayer.store import SQLiteStore


GRAPH_RECALL_KINDS = (
    "supersedes",
    "contradicts",
    "derived_from",
    "causes",
    "co_occurs_with",
    "relates_to",
)


def write_memory_edge(
    store: SQLiteStore,
    *,
    workspace_id: str,
    repo_id: str | None,
    src_record_id: str,
    dst_record_id: str,
    kind: str,
    confidence: float = 1.0,
    evidence: dict[str, Any] | None = None,
    created_by: str = "deterministic",
) -> str | None:
    if not src_record_id or not dst_record_id or src_record_id == dst_record_id:
        return None
    return store.memory_edge_create(
        workspace_id=workspace_id,
        repo_id=repo_id,
        src_record_id=src_record_id,
        dst_record_id=dst_record_id,
        kind=kind,
        confidence=confidence,
        evidence=evidence or {},
        created_by=created_by,
    )


def memory_graph_signal(
    store: SQLiteStore,
    *,
    workspace_id: str,
    repo_id: str | None,
    record_id: str,
    seed_record_ids: set[str],
    max_hops: int = 2,
) -> dict[str, Any] | None:
    if not record_id or record_id in seed_record_ids:
        return None
    if not seed_record_ids:
        return None
    walk = store.memory_graph_walk(
        workspace_id=workspace_id,
        repo_id=repo_id,
        start_record_ids=seed_record_ids,
        kinds=GRAPH_RECALL_KINDS,
        max_hops=max_hops,
        limit=200,
    )
    matches = [item for item in walk if item.get("record_id") == record_id]
    if not matches:
        return None
    best = max(matches, key=lambda item: float(item.get("confidence", 0.0) or 0.0))
    return {
        "kind": "memory_graph",
        "score": round(min(0.8, float(best.get("confidence", 0.0) or 0.0)), 4),
        "reason": "Memory is linked to a query/path-matched memory record.",
        "matches": matches[:5],
    }
