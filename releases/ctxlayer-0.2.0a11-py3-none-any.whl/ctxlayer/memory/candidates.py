from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from ctxlayer.memory.calibration import TrustCalibrator
from ctxlayer.memory.extraction_eval import ExtractionEvaluator
from ctxlayer.memory.source_scanners import SCANNERS
from ctxlayer.store import SQLiteStore
from ctxlayer.memory.unified import UnifiedMemory

RULE_RE = re.compile(
    r"(?i)\b(?:must|must not|required|requires|never|always|do not|cannot|should not)\b[^.\n]{8,160}"
)


class BusinessRuleMemory:
    def __init__(
        self,
        repo_root: Path,
        store: SQLiteStore,
        workspace_id: str,
        repo_id: str,
        approval_config: Any | None = None,
    ):
        self.repo_root = repo_root
        self.store = store
        self.workspace_id = workspace_id
        self.repo_id = repo_id
        self.approval_config = approval_config
        self.unified = UnifiedMemory(store, workspace_id, repo_id)

    def extract_candidates(self) -> dict[str, Any]:
        candidates = []
        seen: set[str] = set()
        calibrator = TrustCalibrator(self.store, self.repo_id)
        persisted = 0
        suppressed = 0
        for source_type, scanner in SCANNERS.items():
            for candidate in scanner(self.repo_root):
                dedupe_key = f"{source_type}:{candidate.text}"
                if dedupe_key in seen:
                    continue
                seen.add(dedupe_key)
                calibration = calibrator.calibrate_confidence(
                    source_type, candidate.confidence
                )
                has_evidence = bool(candidate.evidence)
                surfaced = (
                    has_evidence
                    and calibration["calibrated_confidence"]
                    >= calibration["confidence_floor"]
                )
                status = "candidate" if surfaced else "suppressed"
                candidate_id = self.store.upsert_business_rule_candidate(
                    workspace_id=self.workspace_id,
                    repo_id=self.repo_id,
                    rule_text=candidate.text,
                    source_type=source_type,
                    confidence=calibration["calibrated_confidence"],
                    raw_score=calibration["raw_score"],
                    calibrated_confidence=calibration["calibrated_confidence"],
                    trust_tier=calibration["trust_tier"],
                    confidence_method=calibration["confidence_method"],
                    status=status,
                )
                persisted += 1
                evidence_payload = []
                for evidence in candidate.evidence:
                    self.store.put_business_rule_candidate_evidence(
                        candidate_id=candidate_id,
                        repo_id=self.repo_id,
                        path=evidence.path,
                        symbol_identity_id=evidence.symbol_identity_id,
                        evidence_kind=evidence.evidence_kind,
                        evidence_hash=evidence.evidence_hash,
                        line_start=evidence.line_start,
                        line_end=evidence.line_end,
                    )
                    evidence_payload.append(
                        {
                            "repo_id": self.repo_id,
                            "path": evidence.path,
                            "symbol_identity_id": evidence.symbol_identity_id,
                            "evidence_kind": evidence.evidence_kind,
                            "evidence_hash": evidence.evidence_hash,
                            "line_start": evidence.line_start,
                            "line_end": evidence.line_end,
                            "source_ref": evidence.path,
                        }
                    )
                item = {
                    "candidate_id": candidate_id,
                    "rule_id": candidate_id,
                    "text": candidate.text,
                    "source_type": source_type,
                    "confidence": calibration["calibrated_confidence"],
                    "raw_score": calibration["raw_score"],
                    "calibrated_confidence": calibration["calibrated_confidence"],
                    "trust_tier": calibration["trust_tier"],
                    "confidence_method": calibration["confidence_method"],
                    "confidence_floor": calibration["confidence_floor"],
                    "status": status,
                    "evidence": evidence_payload,
                }
                if surfaced:
                    self.unified.propose(
                        record_type="business_rule",
                        assertion=candidate.text,
                        source_kind=source_type,
                        confidence=calibration["calibrated_confidence"],
                        scope=_scope_for_evidence(candidate.evidence),
                        evidence=evidence_payload,
                        record_id=candidate_id,
                        status="candidate",
                        metadata={
                            "legacy_candidate_id": candidate_id,
                            "raw_score": calibration["raw_score"],
                            "calibrated_confidence": calibration[
                                "calibrated_confidence"
                            ],
                            "trust_tier": calibration["trust_tier"],
                            "confidence_method": calibration["confidence_method"],
                            "confidence_floor": calibration["confidence_floor"],
                        },
                    )
                    candidates.append(item)
                else:
                    suppressed += 1
        return {
            "ok": True,
            "candidates": candidates,
            "persisted": persisted,
            "suppressed": suppressed,
        }

    scan = extract_candidates

    def list(self, status: str | None = None) -> dict[str, Any]:
        if status in {None, "candidate", "promoted", "suppressed", "all"}:
            return {
                "ok": True,
                "candidates": [
                    dict(row) for row in self.store.business_rule_candidates(status)
                ],
            }
        return {
            "ok": True,
            "rules": [dict(row) for row in self.store.business_rules(status)],
        }

    def explain(self, candidate_or_rule_id: str) -> dict[str, Any]:
        candidate = self.store.business_rule_candidate(candidate_or_rule_id)
        if candidate:
            return {
                "ok": True,
                "type": "candidate",
                "candidate": dict(candidate),
                "evidence": [
                    dict(row)
                    for row in self.store.candidate_evidence(candidate_or_rule_id)
                ],
            }
        rule_rows = [
            dict(row)
            for row in self.store.business_rules()
            if row["rule_id"] == candidate_or_rule_id
        ]
        if not rule_rows:
            unified = self.unified.explain(candidate_or_rule_id)
            if unified:
                return {"ok": True, "type": "memory_record", **unified}
            return {"ok": False, "error": "candidate or rule not found"}
        unified = self.unified.explain(candidate_or_rule_id) or {}
        unified_evidence = unified.get("evidence", [])
        return {
            "ok": True,
            "type": "rule",
            "rule": rule_rows[0],
            "evidence": [
                *[dict(row) for row in self.store.rule_evidence(candidate_or_rule_id)],
                *unified_evidence,
            ],
            "transitions": unified.get("transitions", []),
        }

    def approve(
        self, candidate_id: str, approved_by: str = "local-user"
    ) -> dict[str, Any]:
        candidate = self.store.business_rule_candidate(candidate_id)
        if not candidate:
            unified = self.store.memory_record(candidate_id)
            if not unified:
                raise KeyError(f"candidate not found: {candidate_id}")
            conflicts = self.unified.open_conflicts_for(candidate_id)
            if conflicts:
                return {
                    "ok": False,
                    "candidate_id": candidate_id,
                    "status": "conflict_detected",
                    "conflicts": conflicts,
                }
            self.store.set_memory_record_status(
                record_id=candidate_id,
                status="active",
                actor=approved_by,
                reason="approved generic memory",
            )
            UnifiedMemory._invalidate_row_cache(
                unified["workspace_id"], unified["repo_id"]
            )
            return {"ok": True, "record_id": candidate_id, "status": "active"}
        conflicts = self.unified.open_conflicts_for(candidate_id)
        if conflicts:
            return {
                "ok": False,
                "candidate_id": candidate_id,
                "status": "conflict_detected",
                "conflicts": conflicts,
            }
        evidence_rows = self.store.candidate_evidence(candidate_id)
        scope = evidence_rows[0]["path"] if evidence_rows else "**"
        rule_id = self.store.upsert_business_rule(
            workspace_id=candidate["workspace_id"],
            repo_id=candidate["repo_id"],
            scope_glob=scope,
            rule_text=candidate["rule_text"],
            source_type=candidate["source_type"],
            source_ref=scope or "",
            confidence=float(candidate["confidence"]),
            status="active",
        )
        for evidence in evidence_rows:
            self.store.put_business_rule_evidence(
                rule_id=rule_id,
                repo_id=evidence["repo_id"],
                path=evidence["path"],
                symbol_identity_id=evidence["symbol_identity_id"],
                quote_hash=evidence["evidence_hash"],
                evidence_hash=evidence["evidence_hash"],
                evidence_type=evidence["evidence_kind"],
                line_start=evidence["line_start"],
                line_end=evidence["line_end"],
            )
        self.unified.approve_business_rule(
            candidate_id=candidate_id,
            rule_id=rule_id,
            assertion=candidate["rule_text"],
            source_kind=candidate["source_type"],
            confidence=float(candidate["confidence"]),
            scope=f"path:{scope or '**'}",
            actor=approved_by,
            evidence=[
                {
                    "repo_id": evidence["repo_id"],
                    "path": evidence["path"],
                    "symbol_identity_id": evidence["symbol_identity_id"],
                    "evidence_kind": evidence["evidence_kind"],
                    "evidence_hash": evidence["evidence_hash"],
                    "line_start": evidence["line_start"],
                    "line_end": evidence["line_end"],
                    "source_ref": evidence["path"],
                }
                for evidence in evidence_rows
            ],
        )
        self.store.set_candidate_status(candidate_id, "promoted")
        self.store.record_business_rule_approval(
            rule_id=rule_id,
            approver=approved_by,
            source="manual",
            decision="approve",
        )
        TrustCalibrator(self.store, self.repo_id).recompute(apply=True)
        return {
            "ok": True,
            "candidate_id": candidate_id,
            "rule_id": rule_id,
            "status": "active",
        }

    def reject(self, candidate_id: str) -> dict[str, Any]:
        candidate = self.store.business_rule_candidate(candidate_id)
        self.store.set_candidate_status(candidate_id, "rejected")
        self.unified.reject(candidate_id)
        if candidate:
            self.store.record_business_rule_approval(
                rule_id=candidate_id,
                approver="local-user",
                source="manual",
                decision="reject",
            )
            TrustCalibrator(self.store, self.repo_id).recompute(apply=True)
        return {"ok": True, "candidate_id": candidate_id, "status": "rejected"}

    def supersede(
        self, old_rule_id: str, new_candidate_id: str, approved_by: str = "local-user"
    ) -> dict[str, Any]:
        approved = self.approve(new_candidate_id, approved_by)
        new_rule_id = approved["rule_id"]
        self.store.set_business_rule_status(
            rule_id=old_rule_id, status="superseded", supersedes_rule_id=new_rule_id
        )
        self.unified.supersede(old_rule_id, new_rule_id, approved_by)
        self.store.record_business_rule_approval(
            rule_id=old_rule_id,
            approver=approved_by,
            source="manual",
            decision="supersede",
            notes=f"Superseded by {new_rule_id}",
        )
        TrustCalibrator(self.store, self.repo_id).recompute(apply=True)
        return {"ok": True, "old_rule_id": old_rule_id, "new_rule_id": new_rule_id}

    def conflicts(self) -> dict[str, Any]:
        rules = [dict(row) for row in self.store.business_rules("active")]
        conflicts = []
        for left in rules:
            for right in rules:
                if left["rule_id"] >= right["rule_id"]:
                    continue
                threshold = _threshold_conflict(left["rule_text"], right["rule_text"])
                if threshold:
                    conflicts.append(
                        {
                            "rule_ids": [left["rule_id"], right["rule_id"]],
                            "type": "threshold_conflict",
                            "summary": threshold,
                            "recommended_action": "Review and supersede one rule.",
                        }
                    )
                elif left["scope_glob"] == right["scope_glob"] and _opposes(
                    left["rule_text"], right["rule_text"]
                ):
                    conflicts.append(
                        {
                            "rule_ids": [left["rule_id"], right["rule_id"]],
                            "type": "verb_conflict",
                            "summary": "Rules in the same scope use conflicting obligation verbs.",
                            "recommended_action": "Review and reject or supersede one rule.",
                        }
                    )
        for row in self.store.memory_conflicts("open"):
            conflicts.append(
                {
                    "conflict_id": row["conflict_id"],
                    "rule_ids": [row["left_record_id"], row["right_record_id"]],
                    "type": row["conflict_type"],
                    "summary": row["summary"],
                    "recommended_action": "Review and reject or supersede one memory record.",
                }
            )
        return {
            "status": "conflict_detected" if conflicts else "ok",
            "conflicts": conflicts,
        }

    def stale(self) -> dict[str, Any]:
        stale = []
        for rule in self.store.business_rules("active"):
            evidence = self.store.rule_evidence(rule["rule_id"])
            if not evidence:
                self.unified.mark_stale(
                    record_id=rule["rule_id"],
                    reason="no evidence",
                    actor="memory_stale",
                )
                stale.append({"rule_id": rule["rule_id"], "reason": "no evidence"})
                continue
            for row in evidence:
                path = row["path"]
                if path and not (self.repo_root / path).exists():
                    self.unified.mark_stale(
                        record_id=rule["rule_id"],
                        reason="evidence file deleted",
                        path=path,
                        actor="memory_stale",
                    )
                    stale.append(
                        {
                            "rule_id": rule["rule_id"],
                            "reason": "evidence file deleted",
                            "path": path,
                        }
                    )
        return {"ok": not stale, "stale_rules": stale}

    def verify(self) -> dict[str, Any]:
        conflicts = self.conflicts()
        stale = self.stale()
        return {
            "ok": conflicts["status"] == "ok" and stale["ok"],
            "conflicts": conflicts.get("conflicts", []),
            "stale_rules": stale.get("stale_rules", []),
        }

    def eval_harvest(self) -> dict[str, Any]:
        scan = self.extract_candidates()
        return {"ok": True, "candidate_count": len(scan["candidates"])}

    def eval_replay(self) -> dict[str, Any]:
        report = ExtractionEvaluator(self.repo_root, self.store, self.repo_id).run()
        return {
            "ok": True,
            "memory_eval_run_id": report.get("memory_eval_run_id"),
            "metrics": {
                "rule_candidate_precision": report["totals"]["precision"],
                "rule_candidate_recall": report["totals"]["recall"],
                "rule_candidate_f1": report["totals"]["f1"],
                "per_source": report["per_source"],
            },
            "report": report,
        }

    def eval_report(self) -> dict[str, Any]:
        return self.eval_replay()

    def extraction_eval(
        self, fixtures: str | Path | None = None, source_type: str | None = None
    ) -> dict[str, Any]:
        return ExtractionEvaluator(self.repo_root, self.store, self.repo_id).run(
            fixtures=fixtures,
            source_type=source_type,
        )

    def trust_calibrate(self, *, apply: bool = False) -> dict[str, Any]:
        return TrustCalibrator(self.store, self.repo_id).recompute(apply=apply)


def _opposes(left: str, right: str) -> bool:
    left_l = left.lower()
    right_l = right.lower()
    return ("must " in left_l and "must not" in right_l) or (
        "must not" in left_l and "must " in right_l
    )


def _threshold_conflict(left: str, right: str) -> str | None:
    left_numbers = {
        int(num.replace(",", "").replace("_", ""))
        for num in re.findall(r"\d[\d,_]*", left)
    }
    right_numbers = {
        int(num.replace(",", "").replace("_", ""))
        for num in re.findall(r"\d[\d,_]*", right)
    }
    if left_numbers and right_numbers and left_numbers != right_numbers:
        left_terms = set(re.findall(r"[a-zA-Z]{4,}", left.lower()))
        right_terms = set(re.findall(r"[a-zA-Z]{4,}", right.lower()))
        if len(left_terms & right_terms) >= 2:
            return f"Different thresholds detected: {sorted(left_numbers)} vs {sorted(right_numbers)}."
    return None


def _scope_for_evidence(evidence: list[Any]) -> str:
    if evidence and evidence[0].path:
        return f"path:{evidence[0].path}"
    return "path:**"
