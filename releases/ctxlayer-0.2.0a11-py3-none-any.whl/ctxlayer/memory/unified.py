from __future__ import annotations

import json
import re
import time
from collections import OrderedDict
from datetime import datetime, timezone
from typing import Any

from ctxlayer.memory.decay import decayed_confidence
from ctxlayer.memory.graph import memory_graph_signal, write_memory_edge
from ctxlayer.retrieval.embedder import cosine
from ctxlayer.security.memory_defense import (
    detect_query_injection,
    evaluate_ingest,
    require_actor_role,
    serve_decision,
    trust_aware_rank,
)
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import canonical_json, sha256_text, stable_id, utc_now


SUPPORTED_MEMORY_TYPES = {
    "fact",
    "decision",
    "episode",
    "architectural_decision",
    "convention",
    "preference",
    "gotcha",
    "failure_lesson",
    "workflow",
    "skill_reference",
    "continuation",
    "runtime_signal",
    "outcome",
    "policy_reference",
    "business_rule",
    "org_knowledge",
    "pattern",
}

NON_SERVING_STATUSES = {
    "rejected",
    "expired",
    "quarantined",
    "needs_review",
    "superseded",
}

TYPE_METADATA_REQUIREMENTS: dict[str, dict[str, str]] = {
    "architectural_decision": {
        "rationale": "non_empty_string",
        "alternatives": "non_empty_list",
    },
    "decision": {
        "rationale": "non_empty_string",
        "alternatives": "non_empty_list",
    },
    "failure_lesson": {
        "symptom": "non_empty_string",
        "root_cause": "non_empty_string",
        "resolution": "non_empty_string",
    },
    "policy_reference": {
        "policy_file": "non_empty_string",
        "policy_key": "non_empty_string",
    },
    "preference": {
        "priority": "priority",
    },
    "skill_reference": {
        "skill_id": "non_empty_string",
    },
    "workflow": {
        "steps": "non_empty_list",
    },
}


def prefetch_cache_key(
    query: str,
    *,
    paths: list[str] | set[str] | None = None,
    types: list[str] | set[str] | None = None,
    limit: int | None = None,
) -> str:
    return stable_id(
        "prefetch",
        query.strip().lower(),
        canonical_json(sorted({str(path).replace("\\", "/") for path in paths or []})),
        canonical_json(sorted({str(item) for item in types or []})),
        str(limit or ""),
    )


class UnifiedMemory:
    _ROW_CACHE_TTL_SECONDS = 5.0
    _ROW_CACHE_MAX_ENTRIES = 8
    _ROW_CACHE: OrderedDict[tuple[Any, ...], tuple[float, list[Any]]] = OrderedDict()

    def __init__(
        self,
        store: SQLiteStore,
        workspace_id: str,
        repo_id: str | None,
        recall_weights: dict[str, float] | None = None,
        embedder: Any | None = None,
        stale_penalty: float = 0.5,
        conflict_penalty: float = 0.6,
        stale_confidence_floor: float = 0.0,
        vector_fallback_limit: int = 2000,
        memory_vector_index: bool = True,
        memory_graph_max_hops: int = 2,
        memory_graph_max_injected: int = 10,
    ):
        self.store = store
        self.workspace_id = workspace_id
        self.repo_id = repo_id
        self.embedder = embedder
        # A semantic embedder (sentence-transformers) yields ~0 cosine for
        # unrelated memories, so its scores can anchor graph seeding. The
        # deterministic local hash embedder gives unrelated text a spurious
        # positive cosine, so its vector leg must not drive graph-seed
        # selection or the graph-only injection cap.
        self._vector_is_semantic = (
            getattr(embedder, "backend", "") == "sentence-transformers"
        )
        self.stale_penalty = float(stale_penalty)
        self.conflict_penalty = float(conflict_penalty)
        self.stale_confidence_floor = float(stale_confidence_floor)
        self.vector_fallback_limit = max(1, int(vector_fallback_limit))
        self.memory_vector_index = bool(memory_vector_index)
        self.memory_graph_max_hops = max(0, int(memory_graph_max_hops))
        self.memory_graph_max_injected = max(0, int(memory_graph_max_injected))
        self.recall_weights = recall_weights or {
            "recency": 0.3,
            "importance": 0.4,
            "relevance": 0.3,
        }

    @classmethod
    def _invalidate_row_cache(
        cls, workspace_id: str | None = None, repo_id: str | None = None
    ) -> None:
        if workspace_id is None and repo_id is None:
            cls._ROW_CACHE.clear()
            return
        for key in list(cls._ROW_CACHE):
            if key[0] == workspace_id and key[1] == repo_id:
                cls._ROW_CACHE.pop(key, None)

    def _cached_memory_records(
        self, *, exclude_statuses: set[str] | None = None
    ) -> list[Any]:
        key = (
            self.workspace_id,
            self.repo_id,
            tuple(sorted(exclude_statuses or [])),
        )
        now = time.monotonic()
        cached = self._ROW_CACHE.get(key)
        if cached and now - cached[0] <= self._ROW_CACHE_TTL_SECONDS:
            self._ROW_CACHE.move_to_end(key)
            return cached[1]
        rows = self.store.memory_records(
            status=None,
            exclude_statuses=exclude_statuses,
            repo_id=self.repo_id,
            workspace_id=self.workspace_id,
        )
        self._ROW_CACHE[key] = (now, rows)
        self._ROW_CACHE.move_to_end(key)
        while len(self._ROW_CACHE) > self._ROW_CACHE_MAX_ENTRIES:
            self._ROW_CACHE.popitem(last=False)
        return rows

    def propose(
        self,
        *,
        record_type: str,
        assertion: str,
        source_kind: str,
        confidence: float,
        scope: str | None = None,
        extraction_method: str = "heuristic",
        evidence: list[dict[str, Any]] | None = None,
        record_id: str | None = None,
        status: str = "candidate",
        owner: str | None = None,
        trust: str | None = None,
        provenance: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        title: str | None = None,
        importance: float | None = None,
        applies_when: str | None = None,
        avoid_when: str | None = None,
        expires_at: str | None = None,
        invalidates_when: str | None = None,
        last_validated_at: str | None = None,
    ) -> str:
        self._validate_type(record_type)
        metadata = dict(metadata or {})
        provenance = dict(provenance or {})
        if _is_external_source(source_kind, provenance):
            defense_result = evaluate_ingest(
                assertion,
                actor=owner or provenance.get("actor"),
                source_connector=str(provenance.get("source_connector") or source_kind),
                external=True,
            )
            metadata["defense_result"] = defense_result
            metadata["memory_defense"] = {
                "ok": defense_result["decision"] == "candidate",
                "reason": defense_result["reason"],
                "flagged": sorted(
                    set(defense_result.get("injection_flags", []))
                    | set(defense_result.get("poison_flags", []))
                ),
                "severity": (
                    "critical" if defense_result["decision"] == "deny" else "high"
                ),
            }
            provenance = {
                **provenance,
                "external": True,
                "source_kind": source_kind,
                "source_connector": provenance.get("source_connector")
                or _source_connector(source_kind),
                "serve_authoritative": False,
            }
            assertion = str(defense_result["sanitized_text"])
            trust = "untrusted"
            if defense_result["decision"] in {"deny", "quarantine"}:
                status = "quarantined"
        defense = _memory_defense_for(record_type, assertion, metadata)
        if not defense["ok"]:
            metadata = {**metadata, "memory_defense": defense}
            status = "quarantined"
            trust = "untrusted"
        self._validate_payload(
            record_type=record_type,
            assertion=assertion,
            scope=scope,
            status=status,
            provenance=provenance,
            metadata=metadata or {},
        )
        actual_scope = scope or (
            f"repo:{self.repo_id}" if self.repo_id else "workspace"
        )
        key = subject_key(record_type, assertion, actual_scope)
        actual_record_id = record_id or stable_id(
            self.workspace_id, self.repo_id or "", record_type, key, source_kind
        )
        existing = self.store.memory_record(actual_record_id)
        self.store.upsert_memory_record(
            record_id=actual_record_id,
            workspace_id=self.workspace_id,
            repo_id=self.repo_id,
            scope=actual_scope,
            type=record_type,
            subject_key=key,
            assertion=assertion,
            status=status,
            confidence=confidence,
            source_kind=source_kind,
            extraction_method=extraction_method,
            owner=owner,
            trust=trust,
            title=title,
            importance=importance,
            applies_when=applies_when,
            avoid_when=avoid_when,
            expires_at=expires_at,
            invalidates_when=invalidates_when,
            last_validated_at=last_validated_at,
            provenance=provenance,
            metadata=metadata,
            reason="create" if not existing else "upsert",
        )
        self._invalidate_row_cache(self.workspace_id, self.repo_id)
        if not defense["ok"]:
            self.store.enqueue_memory_review(
                record_id=actual_record_id,
                reason=f"memory defense: {defense['reason']}",
                severity=defense["severity"],
            )
        if not existing:
            self.store.append_memory_transition(
                record_id=actual_record_id,
                from_status=None,
                to_status=status,
                actor="system",
                reason="created",
            )
        for item in evidence or []:
            self.store.put_memory_evidence(
                record_id=actual_record_id,
                repo_id=item.get("repo_id", self.repo_id),
                path=item.get("path"),
                symbol_identity_id=item.get("symbol_identity_id"),
                evidence_kind=item["evidence_kind"],
                evidence_hash=item["evidence_hash"],
                line_start=item.get("line_start"),
                line_end=item.get("line_end"),
                source_ref=item.get("source_ref"),
                metadata=item.get("metadata"),
            )
        self._refresh_memory_vector(actual_record_id)
        if record_type == "business_rule" and status == "candidate":
            self.detect_conflicts(actual_record_id)
        return actual_record_id

    def create_typed(self, payload: dict[str, Any]) -> dict[str, Any]:
        metadata = dict(payload.get("metadata") or payload.get("metadata_json") or {})
        scope_refs = payload.get("scope_refs")
        if scope_refs is not None:
            metadata["scope_refs"] = scope_refs
        record_id = self.propose(
            record_type=str(payload["type"]),
            assertion=str(payload["assertion"]),
            title=payload.get("title"),
            source_kind=str(payload.get("source_kind", "manual")),
            confidence=float(payload.get("confidence", 1.0)),
            importance=float(payload.get("importance", payload.get("confidence", 1.0))),
            scope=payload.get("scope")
            or _scope_from_kind_refs(
                payload.get("scope_kind"), payload.get("scope_refs"), self.repo_id
            ),
            extraction_method=str(payload.get("extraction_method", "manual")),
            evidence=payload.get("evidence", []),
            record_id=payload.get("record_id"),
            status=str(payload.get("status", "candidate")),
            owner=payload.get("owner"),
            trust=payload.get("trust"),
            provenance=payload.get("provenance"),
            metadata=metadata,
            applies_when=payload.get("applies_when"),
            avoid_when=payload.get("avoid_when"),
            expires_at=payload.get("expires_at"),
            invalidates_when=payload.get("invalidates_when"),
            last_validated_at=payload.get("last_validated_at"),
        )
        row = self.store.memory_record(record_id)
        return {
            "ok": True,
            "record": self._project_row(row) if row else {"record_id": record_id},
        }

    def update(
        self, record_id: str, patch: dict[str, Any], *, actor: str, reason: str
    ) -> dict[str, Any]:
        row = self.store.memory_record(record_id)
        if not row:
            raise KeyError(f"memory record not found: {record_id}")
        normalized = self._normalize_patch(row, patch)
        next_type = str(normalized.get("type", row["type"]))
        next_assertion = str(normalized.get("assertion", row["assertion"]))
        next_scope = str(normalized.get("scope", row["scope"]))
        next_status = str(normalized.get("status", row["status"]))
        metadata = _json(normalized.get("metadata_json") or row["metadata_json"])
        provenance = _json(normalized.get("provenance_json") or row["provenance_json"])
        defense = _memory_defense_for(next_type, next_assertion, metadata)
        if not defense["ok"]:
            metadata = {**metadata, "memory_defense": defense}
            normalized["metadata_json"] = canonical_json(metadata)
            normalized["status"] = "quarantined"
            normalized["trust"] = "untrusted"
            next_status = "quarantined"
        self._validate_payload(
            record_type=next_type,
            assertion=next_assertion,
            scope=next_scope,
            status=next_status,
            provenance=provenance,
            metadata=metadata,
        )
        self.store.update_memory_record(
            record_id=record_id,
            patch=normalized,
            actor=actor,
            reason=reason,
        )
        self._invalidate_row_cache(row["workspace_id"], row["repo_id"])
        self._refresh_memory_vector(record_id)
        if not defense["ok"]:
            self.store.enqueue_memory_review(
                record_id=record_id,
                reason=f"memory defense: {defense['reason']}",
                severity=defense["severity"],
            )
        updated = self.store.memory_record(record_id)
        return {"ok": True, "record": self._project_row(updated)}

    def validate(
        self,
        record_id: str,
        *,
        validator: str,
        evidence: dict[str, Any] | None = None,
        actor: str = "local-user",
    ) -> dict[str, Any]:
        row = self.store.memory_record(record_id)
        if not row:
            raise KeyError(f"memory record not found: {record_id}")
        if _requires_codeowner_validation(row):
            _require_actor_role(actor, "codeowner", "memory_validate_sensitive")
        provenance = {
            **_json(row["provenance_json"]),
            "validator": validator,
            "validated_at": utc_now(),
        }
        if evidence:
            provenance["validation_evidence"] = evidence
        self.store.set_memory_record_status(
            record_id=record_id,
            status="active",
            trust="active",
            actor=actor,
            reason=f"validated by {validator}",
            provenance=provenance,
        )
        self.store.update_memory_record(
            record_id=record_id,
            patch={
                "last_validated_at": utc_now(),
                "provenance_json": canonical_json(provenance),
            },
            actor=actor,
            reason=f"validation evidence: {validator}",
        )
        self._invalidate_row_cache(row["workspace_id"], row["repo_id"])
        self._refresh_memory_vector(record_id)
        return {
            "ok": True,
            "record": self._project_row(self.store.memory_record(record_id)),
        }

    def expire(
        self, record_id: str, *, reason: str, actor: str = "system"
    ) -> dict[str, Any]:
        self.store.set_memory_record_status(
            record_id=record_id,
            status="expired",
            actor=actor,
            reason=reason,
        )
        self._invalidate_row_cache(self.workspace_id, self.repo_id)
        return {"ok": True, "record_id": record_id, "status": "expired"}

    def quarantine(
        self,
        record_id: str,
        *,
        reason: str,
        severity: str = "high",
        actor: str = "system",
    ) -> dict[str, Any]:
        row = self.store.memory_record(record_id)
        if not row:
            raise KeyError(f"memory record not found: {record_id}")
        _require_actor_role(actor, "codeowner", "memory_quarantine")
        self.store.set_memory_record_status(
            record_id=record_id,
            status="quarantined",
            trust="untrusted",
            actor=actor,
            reason=reason,
        )
        self._invalidate_row_cache(row["workspace_id"], row["repo_id"])
        review_id = self.store.enqueue_memory_review(
            record_id=record_id,
            reason=reason,
            severity=severity,
        )
        return {
            "ok": True,
            "record_id": record_id,
            "status": "quarantined",
            "review_id": review_id,
        }

    def diff(
        self,
        record_id: str,
        revision_a: str | None = None,
        revision_b: str | None = None,
    ) -> dict[str, Any]:
        revisions = self.store.memory_revisions(record_id)
        if not revisions:
            return {"ok": False, "record_id": record_id, "error": "no revisions"}
        left = self.store.memory_revision(revision_a) if revision_a else revisions[0]
        right = self.store.memory_revision(revision_b) if revision_b else revisions[-1]
        if not left or not right:
            return {"ok": False, "record_id": record_id, "error": "revision not found"}
        before = _json(left["record_json"])
        after = _json(right["record_json"])
        changed = {
            key: {"before": before.get(key), "after": after.get(key)}
            for key in sorted(set(before) | set(after))
            if before.get(key) != after.get(key)
        }
        return {
            "ok": True,
            "record_id": record_id,
            "revision_a": left["revision_id"],
            "revision_b": right["revision_id"],
            "changed": changed,
        }

    def approve_business_rule(
        self,
        *,
        candidate_id: str,
        rule_id: str,
        assertion: str,
        source_kind: str,
        confidence: float,
        scope: str,
        actor: str,
        evidence: list[dict[str, Any]],
    ) -> str:
        candidate = self.store.memory_record(candidate_id)
        if candidate:
            self.store.set_memory_record_status(
                record_id=candidate_id,
                status="approved",
                actor=actor,
                reason=f"approved as {rule_id}",
            )
            self._invalidate_row_cache(candidate["workspace_id"], candidate["repo_id"])
        active_id = self.propose(
            record_type="business_rule",
            assertion=assertion,
            source_kind=source_kind,
            confidence=confidence,
            scope=scope,
            evidence=evidence,
            record_id=rule_id,
            status="active",
            metadata={"legacy_candidate_id": candidate_id, "legacy_rule_id": rule_id},
        )
        return active_id

    def reject(self, record_id: str, actor: str = "local-user") -> None:
        row = self.store.memory_record(record_id)
        if row:
            if _requires_codeowner_validation(row):
                _require_actor_role(actor, "codeowner", "memory_reject_sensitive")
            self.store.set_memory_record_status(
                record_id=record_id,
                status="rejected",
                actor=actor,
                reason="rejected",
            )

    def supersede(
        self, old_record_id: str, new_record_id: str, actor: str = "local-user"
    ) -> None:
        old_row = self.store.memory_record(old_record_id)
        new_row = self.store.memory_record(new_record_id)
        for row in (old_row, new_row):
            if row and _requires_codeowner_validation(row):
                _require_actor_role(actor, "codeowner", "memory_supersede_sensitive")
        if old_row:
            self.store.set_memory_record_status(
                record_id=old_record_id,
                status="superseded",
                actor=actor,
                reason=f"superseded by {new_record_id}",
                superseded_by=new_record_id,
            )

    def mirror_runtime_signal(
        self,
        *,
        runtime_event_id: str,
        source: str,
        title: str,
        message: str,
        path: str | None,
        symbol_identity_id: str | None,
        severity: str,
        event_hash: str,
    ) -> str:
        return self.propose(
            record_type="runtime_signal",
            assertion=message,
            source_kind=f"runtime:{source}",
            confidence=_runtime_confidence(severity),
            scope=f"repo:{self.repo_id}" if self.repo_id else "workspace",
            evidence=[
                {
                    "repo_id": self.repo_id,
                    "path": path,
                    "symbol_identity_id": symbol_identity_id,
                    "evidence_kind": f"runtime:{source}",
                    "evidence_hash": event_hash,
                    "source_ref": runtime_event_id,
                }
            ],
            record_id=runtime_event_id,
            status="active",
            metadata={
                "runtime_event_id": runtime_event_id,
                "severity": severity,
                "title": title,
            },
        )

    def mirror_outcome(
        self,
        *,
        outcome_id: str,
        pack_id: str,
        result: str,
        files_changed: list[str],
    ) -> str:
        return self.propose(
            record_type="outcome",
            assertion=f"Pack {pack_id} completed with result {result}.",
            source_kind="outcome",
            confidence=1.0,
            scope=f"repo:{self.repo_id}" if self.repo_id else "workspace",
            record_id=outcome_id,
            status="active",
            extraction_method="manual",
            metadata={
                "pack_id": pack_id,
                "result": result,
                "files_changed": files_changed,
            },
        )

    def confirm_from_outcome(self, outcome_id: str) -> dict[str, Any]:
        outcome = self.store.outcome(outcome_id)
        if not outcome:
            return {"ok": False, "error": "outcome not found", "outcome_id": outcome_id}
        self._invalidate_row_cache(self.workspace_id, self.repo_id)
        result = str(outcome["result"]).strip().lower()
        if result not in {"pass", "passed", "ok", "success"}:
            return {
                "ok": True,
                "outcome_id": outcome_id,
                "pack_id": outcome["pack_id"],
                "confirmed": [],
                "skipped": [
                    {"reason": "outcome_not_passing", "result": outcome["result"]}
                ],
            }
        confirmed = []
        skipped = []
        for access in self.store.memory_accesses(outcome["pack_id"]):
            row = self.store.memory_record(access["memory_record_id"])
            if not row:
                skipped.append(
                    {
                        "record_id": access["memory_record_id"],
                        "reason": "memory_not_found",
                    }
                )
                continue
            provenance = _json(row["provenance_json"])
            if row["trust"] != "untrusted":
                skipped.append(
                    {"record_id": row["record_id"], "reason": "not_untrusted"}
                )
                continue
            if not str(provenance.get("generator", "")).startswith("agent:"):
                skipped.append(
                    {"record_id": row["record_id"], "reason": "not_agent_generated"}
                )
                continue
            if provenance.get("validator") not in {None, "", "none"}:
                skipped.append(
                    {"record_id": row["record_id"], "reason": "already_validated"}
                )
                continue
            provenance = {
                **provenance,
                "validator": f"real_outcome:{outcome_id}",
                "validated_pack_id": outcome["pack_id"],
                "validated_at": utc_now(),
            }
            new_confidence = min(
                1.0, max(float(row["confidence"]) + 0.15, float(row["confidence"]))
            )
            self.store.set_memory_record_status(
                record_id=row["record_id"],
                status="active",
                actor="system",
                reason=f"confirmed by real outcome {outcome_id}",
                trust="active",
                provenance=provenance,
                confidence=new_confidence,
            )
            self.store.write_learning_event(
                phase="phase1",
                kind="memory_promoted",
                ref=row["record_id"],
                payload={
                    "outcome_id": outcome_id,
                    "pack_id": outcome["pack_id"],
                    "confidence": new_confidence,
                },
            )
            confirmed.append(
                {
                    "record_id": row["record_id"],
                    "validator": provenance["validator"],
                    "confidence": new_confidence,
                }
            )
        return {
            "ok": True,
            "outcome_id": outcome_id,
            "pack_id": outcome["pack_id"],
            "confirmed": confirmed,
            "skipped": skipped,
        }

    def maintain_candidate(self, record_id: str) -> dict[str, Any]:
        row = self.store.memory_record(record_id)
        if not row:
            return {"ok": False, "decision": "NOOP", "reason": "memory_not_found"}
        self._invalidate_row_cache(row["workspace_id"], row["repo_id"])
        metadata = _json(row["metadata_json"])
        defense = metadata.get("memory_defense")
        if row["status"] == "quarantined" or (
            isinstance(defense, dict) and not defense.get("ok", True)
        ):
            if row["status"] != "quarantined":
                self.store.set_memory_record_status(
                    record_id=record_id,
                    status="quarantined",
                    actor="memory_maintenance",
                    reason="maintenance QUARANTINE suspicious memory",
                    trust="untrusted",
                )
            review_id = self.store.enqueue_memory_review(
                record_id=record_id,
                reason="maintenance QUARANTINE suspicious memory",
                severity=(
                    str(defense.get("severity", "high"))
                    if isinstance(defense, dict)
                    else "high"
                ),
            )
            return self._maintenance_event(
                record_id,
                "QUARANTINE",
                {"review_id": review_id, "reason": "suspicious_memory"},
            )
        if row["status"] != "candidate":
            return {"ok": True, "decision": "NOOP", "reason": "not_candidate"}
        peers = [
            item
            for item in self.store.memory_records_by_subject(
                subject_key=row["subject_key"],
                type=row["type"],
                repo_id=row["repo_id"],
                workspace_id=row["workspace_id"],
            )
            if item["record_id"] != record_id
            and item["status"] not in {"rejected", "superseded"}
        ]
        normalized = _normalize_assertion(row["assertion"])
        duplicate = next(
            (
                item
                for item in peers
                if _normalize_assertion(item["assertion"]) == normalized
            ),
            None,
        )
        if duplicate:
            self.store.set_memory_record_status(
                record_id=record_id,
                status="rejected",
                actor="system",
                reason=f"maintenance NOOP duplicate of {duplicate['record_id']}",
            )
            write_memory_edge(
                self.store,
                workspace_id=row["workspace_id"],
                repo_id=row["repo_id"],
                src_record_id=record_id,
                dst_record_id=duplicate["record_id"],
                kind="supersedes",
                confidence=1.0,
                evidence={"reason": "duplicate", "decision": "NOOP"},
                created_by="maintenance",
            )
            return self._maintenance_event(
                record_id,
                "NOOP",
                {"target_record_id": duplicate["record_id"], "reason": "duplicate"},
            )
        if _delete_intent(row["assertion"]):
            deleted = []
            for peer in peers:
                if peer["status"] == "candidate":
                    self.store.set_memory_record_status(
                        record_id=peer["record_id"],
                        status="rejected",
                        actor="system",
                        reason=f"maintenance DELETE requested by {record_id}",
                    )
                    deleted.append(peer["record_id"])
            return self._maintenance_event(
                record_id,
                "DELETE",
                {"deleted_record_ids": deleted, "reason": "delete_intent"},
            )
        evidence_rows = self.store.memory_evidence(record_id)
        if row["source_kind"].startswith("consolidation") and not evidence_rows:
            self.store.set_memory_record_status(
                record_id=record_id,
                status="needs_review",
                actor="memory_maintenance",
                reason="maintenance REVIEW missing evidence",
                trust="untrusted",
            )
            review_id = self.store.enqueue_memory_review(
                record_id=record_id,
                reason="maintenance REVIEW missing evidence",
                severity="medium",
            )
            return self._maintenance_event(
                record_id,
                "REVIEW",
                {"review_id": review_id, "reason": "missing_evidence"},
            )
        if peers:
            active_peers = [item for item in peers if item["status"] == "active"]
            if active_peers:
                # Only sideline the candidate when it genuinely contradicts an
                # active peer. Merely sharing a subject is not a conflict, so we
                # let non-conflicting candidates co-exist (handled by the ADD
                # path below) instead of silently hiding them.
                self.detect_conflicts(record_id)
                open_conflicts = self.open_conflicts_for(record_id)
                if open_conflicts:
                    self._write_contradicts_edges(row, open_conflicts)
                    self.store.set_memory_record_status(
                        record_id=record_id,
                        status="needs_review",
                        actor="memory_maintenance",
                        reason="maintenance REVIEW active memory conflict",
                        trust="untrusted",
                    )
                    review_id = self.store.enqueue_memory_review(
                        record_id=record_id,
                        reason="maintenance REVIEW active memory conflict",
                        severity="high",
                    )
                    return self._maintenance_event(
                        record_id,
                        "REVIEW",
                        {
                            "review_id": review_id,
                            "peer_record_ids": [
                                item["record_id"] for item in active_peers
                            ],
                            "reason": "active_conflict",
                        },
                    )
            strongest = max(peers, key=lambda item: float(item["confidence"]))
            if (
                strongest["status"] == "candidate"
                and float(row["confidence"]) > float(strongest["confidence"]) + 0.05
            ):
                self.store.set_memory_record_status(
                    record_id=strongest["record_id"],
                    status="superseded",
                    actor="system",
                    reason=f"maintenance UPDATE superseded by {record_id}",
                    superseded_by=record_id,
                )
                write_memory_edge(
                    self.store,
                    workspace_id=row["workspace_id"],
                    repo_id=row["repo_id"],
                    src_record_id=record_id,
                    dst_record_id=strongest["record_id"],
                    kind="supersedes",
                    confidence=min(1.0, float(row["confidence"])),
                    evidence={"reason": "higher_confidence", "decision": "UPDATE"},
                    created_by="maintenance",
                )
                return self._maintenance_event(
                    record_id,
                    "UPDATE",
                    {
                        "target_record_id": strongest["record_id"],
                        "reason": "higher_confidence",
                    },
                )
            return self._maintenance_event(
                record_id,
                "ADD",
                {
                    "peer_record_ids": [item["record_id"] for item in peers],
                    "reason": "same_subject",
                },
            )
        return self._maintenance_event(record_id, "ADD", {"reason": "new_subject"})

    def _maintenance_event(
        self, record_id: str, decision: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        event_payload = {"record_id": record_id, "decision": decision, **payload}
        self.store.write_learning_event(
            phase="phase1",
            kind="memory_maintenance",
            ref=record_id,
            payload=event_payload,
        )
        return {"ok": True, "decision": decision, **payload}

    def mark_stale(
        self,
        *,
        record_id: str,
        reason: str,
        path: str | None = None,
        actor: str = "system",
    ) -> None:
        row = self.store.memory_record(record_id)
        if not row:
            return
        metadata = _json(row["metadata_json"])
        metadata["stale_marked_at"] = utc_now()
        metadata["stale_reason"] = reason
        self.store.update_memory_record(
            record_id=record_id,
            patch={"metadata_json": canonical_json(metadata)},
            actor=actor,
            reason=f"stale metadata: {reason}",
        )
        self.store.append_memory_transition(
            record_id=record_id,
            from_status=row["status"],
            to_status=row["status"],
            actor=actor,
            reason=f"stale: {reason}",
        )
        self.store.put_memory_evidence(
            record_id=record_id,
            repo_id=row["repo_id"],
            path=path,
            symbol_identity_id=None,
            evidence_kind="stale_check",
            evidence_hash=sha256_text(
                canonical_json({"reason": reason, "path": path or ""})
            ),
            source_ref=path,
            metadata={"reason": reason},
        )
        self._invalidate_row_cache(row["workspace_id"], row["repo_id"])

    def active_business_rules(self) -> list[dict[str, Any]]:
        rows = self.store.memory_records(
            type="business_rule",
            status="active",
            repo_id=self.repo_id,
            workspace_id=self.workspace_id,
        )
        projected = [self.project_business_rule(row) for row in rows]
        if projected:
            return projected
        return [dict(row) for row in self.store.business_rules("active")]

    def project_business_rule(self, row: Any) -> dict[str, Any]:
        metadata = _json(row["metadata_json"])
        evidence = self.store.memory_evidence(row["record_id"])
        source_ref = evidence[0]["path"] if evidence else row["scope"]
        return {
            "rule_id": metadata.get("legacy_rule_id") or row["record_id"],
            "workspace_id": row["workspace_id"],
            "repo_id": row["repo_id"],
            "scope_glob": _scope_glob(row["scope"]),
            "rule_text": row["assertion"],
            "source_type": row["source_kind"],
            "source_ref": source_ref or "",
            "confidence": row["confidence"],
            "status": row["status"],
            "approved_by": row["owner"],
            "approved_at": None,
            "supersedes_rule_id": row["superseded_by"],
            "updated_at": row["updated_at"],
            "created_at": row["created_at"],
        }

    def explain(self, record_id: str) -> dict[str, Any] | None:
        row = self.store.memory_record(record_id)
        if not row:
            return None
        return {
            "record": dict(row),
            "metadata": _json(row["metadata_json"]),
            "provenance": _json(row["provenance_json"]),
            "evidence": [dict(item) for item in self.store.memory_evidence(record_id)],
            "transitions": [
                dict(item) for item in self.store.memory_transitions(record_id)
            ],
        }

    def search(
        self,
        query: str,
        *,
        types: list[str] | None = None,
        status: str | None = None,
    ) -> dict[str, Any]:
        rows = self.store.memory_search(
            query,
            types=types,
            status=status,
            repo_id=self.repo_id,
            workspace_id=self.workspace_id,
        )
        return {"ok": True, "results": [dict(row) for row in rows]}

    def recall(
        self,
        query: str,
        *,
        paths: list[str] | None = None,
        types: list[str] | None = None,
        limit: int = 20,
        active_only: bool = True,
        include_untrusted_candidates: bool = False,
        include_org: bool = False,
        allow_prefetch_cache: bool = True,
    ) -> dict[str, Any]:
        query_defense = detect_query_injection(query)
        defense_summary: dict[str, Any] = {
            "query": query_defense,
            "excluded": {
                "query_injection": 0,
                "quarantined_or_terminal": 0,
                "expired": 0,
                "unsafe_memory": 0,
                "external_default_deny": 0,
                "org_default_deny": 0,
                "inactive": 0,
            },
        }
        if not query_defense["ok"]:
            defense_summary["excluded"]["query_injection"] = 1
            return {
                "ok": True,
                "query": query,
                "results": [],
                "defense": defense_summary,
                "backend_status": self._memory_vector_backend_status({}, stale_count=0),
            }
        query_terms = _terms(query)
        path_set = {path.replace("\\", "/") for path in paths or []}
        allowed_types = set(types or [])
        if allow_prefetch_cache:
            cache_row = self.store.memory_prefetch_cache_get(
                workspace_id=self.workspace_id,
                repo_id=self.repo_id,
                cache_key=prefetch_cache_key(
                    query, paths=path_set, types=allowed_types, limit=limit
                ),
            )
            if cache_row:
                try:
                    cached = json.loads(cache_row["results_json"] or "{}")
                except json.JSONDecodeError:
                    cached = {}
                if isinstance(cached, dict):
                    cached = dict(cached)
                    cached["served_from_prefetch_cache"] = True
                    cached["predicted_via"] = cache_row["predicted_via"]
                    cached["prefetch_cache_id"] = cache_row["cache_id"]
                    return cached
        exclude_statuses = (
            None if include_untrusted_candidates else set(NON_SERVING_STATUSES)
        )
        rows = self._cached_memory_records(exclude_statuses=exclude_statuses)
        if exclude_statuses:
            status_counts = self.store.memory_status_counts(
                statuses=exclude_statuses,
                repo_id=self.repo_id,
                workspace_id=self.workspace_id,
            )
            defense_summary["excluded"]["quarantined_or_terminal"] = sum(
                int(status_counts.get(status, 0)) for status in exclude_statuses
            )
        vector_scores, vector_backend = self._memory_vector_scores(query, rows)
        graph_seed_ids: set[str] = set()
        for seed_row in rows:
            if allowed_types and seed_row["type"] not in allowed_types:
                continue
            if seed_row["type"] in {"business_rule", "org_knowledge"}:
                continue
            seed_terms = _terms(seed_row["assertion"])
            if query_terms & seed_terms:
                graph_seed_ids.add(seed_row["record_id"])
                continue
            seed_evidence = self.store.memory_evidence(seed_row["record_id"])
            seed_paths = {item["path"] for item in seed_evidence if item["path"]}
            if path_set & seed_paths:
                graph_seed_ids.add(seed_row["record_id"])
                continue
            if (
                self._vector_is_semantic
                and float(vector_scores.get(seed_row["record_id"], 0.0) or 0.0) > 0
            ):
                graph_seed_ids.add(seed_row["record_id"])
        results = []
        graph_injected_count = 0
        for row in rows:
            if row["status"] in NON_SERVING_STATUSES:
                if not exclude_statuses:
                    defense_summary["excluded"]["quarantined_or_terminal"] += 1
                continue
            if _is_expired(row):
                self.store.set_memory_record_status(
                    record_id=row["record_id"],
                    status="expired",
                    actor="memory_recall",
                    reason="expires_at passed",
                )
                self._invalidate_row_cache(row["workspace_id"], row["repo_id"])
                defense_summary["excluded"]["expired"] += 1
                continue
            row_defense = _memory_defense_for(
                row["type"], row["assertion"], _json(row["metadata_json"])
            )
            if not row_defense["ok"]:
                self.store.set_memory_record_status(
                    record_id=row["record_id"],
                    status="quarantined",
                    actor="memory_defense.recall",
                    reason=row_defense["reason"],
                    trust="untrusted",
                )
                self._invalidate_row_cache(row["workspace_id"], row["repo_id"])
                self.store.enqueue_memory_review(
                    record_id=row["record_id"],
                    reason=f"memory defense recall: {row_defense['reason']}",
                    severity=row_defense["severity"],
                )
                defense_summary["excluded"]["unsafe_memory"] += 1
                continue
            metadata = _json(row["metadata_json"])
            provenance = _json(row["provenance_json"])
            serving = serve_decision(metadata.get("defense_result"), provenance)
            org_opted_in = (
                row["type"] == "org_knowledge"
                and include_org
                and row["status"] == "active"
                and bool(provenance.get("approved_external"))
            )
            if (
                not org_opted_in
                and not serving["serve_authoritative"]
                and _is_external_source(row["source_kind"], provenance)
            ):
                defense_summary["excluded"]["external_default_deny"] += 1
                continue
            if active_only and row["status"] != "active":
                if not (
                    include_untrusted_candidates
                    and row["status"] == "candidate"
                    and row["trust"] == "untrusted"
                ):
                    defense_summary["excluded"]["inactive"] += 1
                    continue
            if allowed_types and row["type"] not in allowed_types:
                continue
            if row["type"] == "business_rule":
                continue
            if row["type"] == "org_knowledge" and not include_org:
                defense_summary["excluded"]["org_default_deny"] += 1
                continue
            if active_only and self.stale_confidence_floor > 0:
                age_days_for_floor = _age_days(row["updated_at"])
                if (
                    decayed_confidence(float(row["confidence"]), age_days_for_floor)
                    < self.stale_confidence_floor
                ):
                    defense_summary["excluded"]["expired"] += 1
                    continue
            signals: list[dict[str, Any]] = []
            relevance = 0.0
            assertion_terms = _terms(row["assertion"])
            overlap = query_terms & assertion_terms
            if overlap:
                lexical_score = min(1.0, len(overlap) / max(1, len(query_terms)))
                relevance += lexical_score
                signals.append(
                    {
                        "kind": "lexical",
                        "score": round(lexical_score, 4),
                        "reason": f"Matched task terms: {', '.join(sorted(overlap)[:6])}.",
                    }
                )
            evidence_rows = self.store.memory_evidence(row["record_id"])
            evidence_paths = {item["path"] for item in evidence_rows if item["path"]}
            matched_paths = sorted(path_set & evidence_paths)
            if matched_paths:
                relevance += 1.0
                signals.append(
                    {
                        "kind": "path_overlap",
                        "score": 1.0,
                        "reason": f"Evidence overlaps changed/selected paths: {', '.join(matched_paths[:5])}.",
                    }
                )
            associations = self.store.memory_associations(record_id=row["record_id"])
            associated_paths = {
                item["target_ref"]
                for item in associations
                if item["target_type"] == "file" and item["target_ref"]
            }
            association_matches = sorted(path_set & associated_paths)
            if association_matches:
                relevance += 0.7
                signals.append(
                    {
                        "kind": "association",
                        "score": 0.7,
                        "reason": f"Associated with paths: {', '.join(association_matches[:5])}.",
                    }
                )
            graph_matches = self._graph_proximity_matches(
                start_paths=path_set,
                target_paths=evidence_paths | associated_paths,
            )
            if graph_matches:
                graph_score = min(
                    0.6, max(float(item["confidence"]) for item in graph_matches)
                )
                relevance += graph_score
                signals.append(
                    {
                        "kind": "graph_proximity",
                        "score": round(graph_score, 4),
                        "reason": (
                            "Selected paths are graph-near memory evidence: "
                            + ", ".join(
                                item["target_path"] for item in graph_matches[:5]
                            )
                            + "."
                        ),
                        "matches": graph_matches[:5],
                    }
                )
            vector_score = max(0.0, float(vector_scores.get(row["record_id"], 0.0)))
            if vector_score > 0:
                relevance += min(1.0, vector_score)
                signals.append(
                    {
                        "kind": "vector",
                        "score": round(vector_score, 4),
                        "reason": f"Memory vector similarity {vector_score:.2f}.",
                    }
                )
            graph_signal = memory_graph_signal(
                self.store,
                workspace_id=self.workspace_id,
                repo_id=self.repo_id,
                record_id=row["record_id"],
                seed_record_ids=graph_seed_ids,
                max_hops=self.memory_graph_max_hops,
            )
            if graph_signal:
                anchor_relevance = relevance
                if not self._vector_is_semantic:
                    # Remove the non-semantic embedder's vector noise so a
                    # purely graph-linked memory is still recognised as a
                    # graph-only injection (and counted against the cap).
                    anchor_relevance -= min(1.0, vector_score)
                graph_only_injection = anchor_relevance <= 1e-9
                if (
                    graph_only_injection
                    and graph_injected_count >= self.memory_graph_max_injected
                ):
                    continue
                relevance += float(graph_signal["score"])
                signals.append(graph_signal)
                if graph_only_injection:
                    graph_injected_count += 1
            relevance = min(1.0, relevance)
            metadata = _json(row["metadata_json"])
            polarity = str(metadata.get("polarity", "")).lower()
            near_matching_path = bool(matched_paths or association_matches)
            polarity_weight = (
                1.15
                if polarity == "failure" and near_matching_path
                else 1.05 if polarity == "failure" else 1.0
            )
            importance = min(1.0, float(row["confidence"]) * polarity_weight)
            stored_importance = _row_value(row, "importance")
            if stored_importance is not None:
                importance = min(
                    1.0, max(0.0, float(stored_importance)) * polarity_weight
                )
            age_days = _age_days(row["updated_at"])
            recency = float(decayed_confidence(1.0, age_days))
            weights = _normalized_weights(self.recall_weights)
            score = relevance * (
                weights["recency"] * recency
                + weights["importance"] * importance
                + weights["relevance"] * relevance
            )
            signals.append(
                {
                    "kind": "recency",
                    "score": round(recency, 4),
                    "reason": f"Updated {age_days} day(s) ago.",
                }
            )
            signals.append(
                {
                    "kind": "importance",
                    "score": round(importance, 4),
                    "reason": f"Confidence {float(row['confidence']):.2f}; polarity {polarity or 'neutral'}.",
                }
            )
            signals.append(
                {
                    "kind": "relevance",
                    "score": round(relevance, 4),
                    "reason": "Combined lexical, path, association, graph, and vector relevance.",
                }
            )
            staleness_state = _staleness_state(row)
            if staleness_state == "stale":
                score *= self.stale_penalty
                signals.append(
                    {
                        "kind": "staleness_penalty",
                        "score": round(self.stale_penalty, 4),
                        "reason": "Memory is stale and was down-ranked.",
                    }
                )
            elif staleness_state == "aging":
                score *= 0.85
                signals.append(
                    {
                        "kind": "staleness_penalty",
                        "score": 0.85,
                        "reason": "Memory is aging and was slightly down-ranked.",
                    }
                )
            open_conflicts = self.open_conflicts_for(row["record_id"])
            if open_conflicts:
                score *= self.conflict_penalty
                signals.append(
                    {
                        "kind": "conflict_penalty",
                        "score": round(self.conflict_penalty, 4),
                        "reason": "Memory has unresolved conflicts and was down-ranked.",
                        "conflicts": [
                            {
                                "conflict_id": item["conflict_id"],
                                "record_ids": [
                                    item["left_record_id"],
                                    item["right_record_id"],
                                ],
                                "summary": item["summary"],
                            }
                            for item in open_conflicts[:5]
                        ],
                    }
                )
            if relevance <= 0 and (query_terms or path_set):
                continue
            results.append(
                {
                    "record_id": row["record_id"],
                    "type": row["type"],
                    "title": _row_value(row, "title") or row["assertion"][:80],
                    "text": row["assertion"],
                    "assertion": row["assertion"],
                    "scope": row["scope"],
                    "status": row["status"],
                    "trust": _trust_for(row),
                    "score": round(score, 6),
                    "signals": signals,
                    "evidence": [dict(item) for item in evidence_rows],
                    "why_recalled": (
                        signals[0]["reason"]
                        if signals
                        else "Included by active memory fallback."
                    ),
                    "staleness_state": staleness_state,
                    "provenance_summary": _provenance_summary(provenance),
                    "metadata": metadata,
                    "provenance": provenance,
                }
            )
        ranked = trust_aware_rank(results)
        for item in ranked:
            if "adjusted_score" in item:
                item["signals"].append(
                    {
                        "kind": "trust_aware_rank",
                        "score": item["trust_factor"],
                        "reason": f"Trust-aware recall factor {item['trust_factor']:.2f}.",
                    }
                )
        ranked.sort(
            key=lambda item: (
                -float(item.get("adjusted_score", item["score"])),
                item["type"],
                item["assertion"],
            )
        )
        return {
            "ok": True,
            "query": query,
            "results": ranked[:limit],
            "defense": defense_summary,
            "backend_status": vector_backend,
        }

    def detect_conflicts(self, record_id: str) -> list[dict[str, Any]]:
        candidate = self.store.memory_record(record_id)
        if not candidate:
            return []
        conflicts = []
        for active in self.store.memory_records(
            type=candidate["type"],
            status="active",
            repo_id=candidate["repo_id"],
            workspace_id=candidate["workspace_id"],
        ):
            if active["record_id"] == record_id:
                continue
            summary = _conflict_summary(candidate["assertion"], active["assertion"])
            if not summary:
                continue
            conflict_id = self.store.upsert_memory_conflict(
                left_record_id=record_id,
                right_record_id=active["record_id"],
                conflict_type="assertion_conflict",
                summary=summary,
            )
            conflicts.append(
                {
                    "conflict_id": conflict_id,
                    "record_ids": [record_id, active["record_id"]],
                    "type": "assertion_conflict",
                    "summary": summary,
                }
            )
        return conflicts

    def _write_contradicts_edges(
        self, row: Any, conflicts: list[dict[str, Any]]
    ) -> None:
        record_id = row["record_id"]
        for conflict in conflicts:
            left_id = str(conflict.get("left_record_id") or "")
            right_id = str(conflict.get("right_record_id") or "")
            other_id = right_id if left_id == record_id else left_id
            if not other_id or other_id == record_id:
                continue
            write_memory_edge(
                self.store,
                workspace_id=row["workspace_id"],
                repo_id=row["repo_id"],
                src_record_id=record_id,
                dst_record_id=other_id,
                kind="contradicts",
                confidence=0.85,
                evidence={
                    "conflict_id": conflict.get("conflict_id"),
                    "summary": conflict.get("summary"),
                    "reason": "active_conflict",
                },
                created_by="maintenance",
            )

    def _validate_type(self, record_type: str) -> None:
        if record_type not in SUPPORTED_MEMORY_TYPES:
            raise ValueError(f"unsupported memory type: {record_type}")

    def _validate_payload(
        self,
        *,
        record_type: str,
        assertion: str,
        scope: str | None,
        status: str,
        provenance: dict[str, Any] | None,
        metadata: dict[str, Any],
    ) -> None:
        self._validate_type(record_type)
        if not assertion or not assertion.strip():
            raise ValueError("memory assertion is required")
        if scope is not None and not str(scope).strip():
            raise ValueError("memory scope is required")
        if status in {"active", "approved"} and _agent_generated_without_validator(
            provenance or {}
        ):
            raise ValueError(
                "agent-generated active memory requires provenance.validator"
            )
        if record_type == "policy_reference" and _claims_policy_enforcement(
            assertion, metadata
        ):
            raise ValueError(
                "policy_reference memory may reference policy but cannot enforce it"
            )
        _validate_type_metadata(record_type, metadata)

    def _normalize_patch(self, row: Any, patch: dict[str, Any]) -> dict[str, Any]:
        normalized: dict[str, Any] = {}
        for key, value in patch.items():
            if key == "metadata":
                normalized["metadata_json"] = canonical_json(
                    value if isinstance(value, dict) else {}
                )
            elif key == "provenance":
                normalized["provenance_json"] = canonical_json(
                    value if isinstance(value, dict) else {}
                )
            elif key == "scope_refs":
                metadata = _json(row["metadata_json"])
                metadata["scope_refs"] = value
                normalized["metadata_json"] = canonical_json(metadata)
            else:
                normalized[key] = value
        return normalized

    def _project_row(self, row: Any) -> dict[str, Any]:
        metadata = _json(row["metadata_json"])
        provenance = _json(row["provenance_json"])
        return {
            "record_id": row["record_id"],
            "type": row["type"],
            "title": _row_value(row, "title") or row["assertion"][:80],
            "assertion": row["assertion"],
            "scope": row["scope"],
            "scope_kind": _scope_kind(row["scope"]),
            "scope_refs": metadata.get("scope_refs", _scope_refs(row["scope"])),
            "applies_when": _row_value(row, "applies_when"),
            "avoid_when": _row_value(row, "avoid_when"),
            "confidence": row["confidence"],
            "importance": _row_value(row, "importance"),
            "trust": row["trust"],
            "status": row["status"],
            "source_kind": row["source_kind"],
            "extraction_method": row["extraction_method"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
            "last_validated_at": _row_value(row, "last_validated_at"),
            "expires_at": row["expires_at"],
            "invalidates_when": _row_value(row, "invalidates_when"),
            "superseded_by": row["superseded_by"],
            "owner": row["owner"],
            "provenance": provenance,
            "metadata": metadata,
        }

    def open_conflicts_for(self, record_id: str) -> list[dict[str, Any]]:
        conflicts = []
        for row in self.store.memory_conflicts("open"):
            if record_id in {row["left_record_id"], row["right_record_id"]}:
                conflicts.append(dict(row))
        return conflicts

    def _refresh_memory_vector(self, record_id: str) -> None:
        if self.embedder is None:
            return
        row = self.store.memory_record(record_id)
        if not row or row["status"] in NON_SERVING_STATUSES:
            return
        vector = self.embedder.embed(_memory_vector_text(row))
        self.store.put_memory_vector(
            record_id=record_id,
            dims=int(self.embedder.dims),
            vector=vector,
            model=str(self.embedder.model_name),
        )

    def _memory_vector_scores(
        self, query: str, rows: list[Any]
    ) -> tuple[dict[str, float], dict[str, Any]]:
        if self.embedder is None:
            return {}, self._memory_vector_backend_status(
                {}, stale_count=0, fallback_mode="no_embedder"
            )
        eligible = {
            row["record_id"]: row
            for row in rows
            if row["status"] not in NON_SERVING_STATUSES
        }
        query_vector = self.embedder.embed(query)
        if self.memory_vector_index and self.store.sqlite_vec_loaded:
            stale_count = 0
            existing = {
                row["record_id"]: row
                for row in self.store.memory_vectors(str(self.embedder.model_name))
                if row["record_id"] in eligible
            }
            for record_id, row in list(eligible.items())[: self.vector_fallback_limit]:
                vector = existing.get(record_id)
                if vector is None or str(vector["updated_at"]) < str(row["updated_at"]):
                    stale_count += 1
                    self._refresh_memory_vector(record_id)
            matches = self.store.search_memory_vectors(
                workspace_id=self.workspace_id,
                repo_id=self.repo_id,
                model=str(self.embedder.model_name),
                dims=int(self.embedder.dims),
                vector=query_vector,
                limit=max(1, min(len(eligible) or 1, self.vector_fallback_limit)),
                exclude_statuses=NON_SERVING_STATUSES,
            )
            scores = {
                str(row["record_id"]): float(row.get("_vector_score", 0.0) or 0.0)
                for row in matches
                if str(row["record_id"]) in eligible
            }
            return scores, self._memory_vector_backend_status(
                scores,
                stale_count=stale_count,
                fallback_mode="sqlite-vec",
                fallback_limited=False,
                fallback_limit=None,
                eligible_count=len(eligible),
            )
        eligible_ids = set(list(eligible.keys())[: self.vector_fallback_limit])
        vectors = {
            row["record_id"]: row
            for row in self.store.memory_vectors(str(self.embedder.model_name))
            if row["record_id"] in eligible_ids
        }
        stale_count = 0
        for record_id, row in eligible.items():
            if record_id not in eligible_ids:
                continue
            vector = vectors.get(record_id)
            if vector is None or str(vector["updated_at"]) < str(row["updated_at"]):
                stale_count += 1
                self._refresh_memory_vector(record_id)
        vectors = {
            row["record_id"]: row
            for row in self.store.memory_vectors(str(self.embedder.model_name))
            if row["record_id"] in eligible_ids
        }
        scores: dict[str, float] = {}
        for record_id, vector_row in vectors.items():
            if record_id not in eligible:
                continue
            try:
                vector = json.loads(vector_row["vector_json"] or "[]")
            except json.JSONDecodeError:
                continue
            score = cosine(query_vector, [float(value) for value in vector])
            if score > 0:
                scores[record_id] = score
        return scores, self._memory_vector_backend_status(
            scores,
            stale_count=stale_count,
            fallback_limited=len(eligible) > len(eligible_ids),
            fallback_limit=self.vector_fallback_limit,
            eligible_count=len(eligible),
        )

    def _memory_vector_backend_status(
        self,
        scores: dict[str, float],
        *,
        stale_count: int,
        fallback_mode: str = "hybrid",
        fallback_limited: bool = False,
        fallback_limit: int | None = None,
        eligible_count: int = 0,
    ) -> dict[str, Any]:
        if self.embedder is None:
            return {
                "memory_vector_backend": "unavailable",
                "vector_store": "unavailable",
                "fallback_mode": fallback_mode,
                "indexed_memory_count": 0,
                "stale_vector_count": stale_count,
                "fallback_limited": False,
            }
        if fallback_mode == "sqlite-vec":
            return {
                "memory_vector_backend": "sqlite-vec",
                "vector_store": "sqlite-vec",
                "model": str(self.embedder.model_name),
                "dimensions": int(self.embedder.dims),
                "indexed_memory_count": len(
                    self.store.memory_vectors(str(self.embedder.model_name))
                ),
                "matched_memory_count": len(scores),
                "stale_vector_count": stale_count,
                "fallback_mode": fallback_mode,
                "fallback_limited": False,
                "fallback_limit": None,
                "eligible_memory_count": int(eligible_count),
                "degraded_reason": None,
            }
        return {
            "memory_vector_backend": "json-cosine-bounded",
            "vector_store": "json-cosine",
            "model": str(self.embedder.model_name),
            "dimensions": int(self.embedder.dims),
            "indexed_memory_count": len(
                self.store.memory_vectors(str(self.embedder.model_name))
            ),
            "matched_memory_count": len(scores),
            "stale_vector_count": stale_count,
            "fallback_mode": fallback_mode,
            "fallback_limited": bool(fallback_limited),
            "fallback_limit": fallback_limit or self.vector_fallback_limit,
            "eligible_memory_count": int(eligible_count),
            "degraded_reason": "sqlite_vec_not_loaded_or_memory_index_disabled",
        }

    def _graph_proximity_matches(
        self,
        *,
        start_paths: set[str],
        target_paths: set[str],
    ) -> list[dict[str, Any]]:
        if not self.repo_id or not start_paths or not target_paths:
            return []
        matches: dict[str, dict[str, Any]] = {}
        try:
            walk = self.store.graph_walk(
                repo_id=self.repo_id,
                start_paths=start_paths,
                kinds=("imports", "tests", "calls", "defines", "cochange", "generated"),
                max_hops=2,
                limit=200,
            )
        except Exception:
            return []
        for edge in walk:
            paths = {
                str(node.get("path"))
                for node in (edge.get("from") or {}, edge.get("to") or {})
                if isinstance(node, dict) and node.get("path")
            }
            paths.update(
                str(item)
                for item in edge.get("route") or []
                if str(item) in target_paths
            )
            for target in sorted(paths & target_paths):
                existing = matches.get(target)
                confidence = float(edge.get("confidence", 0.0) or 0.0)
                record = {
                    "target_path": target,
                    "kind": edge.get("kind"),
                    "depth": int(edge.get("depth", 0) or 0),
                    "confidence": round(confidence, 4),
                    "route": edge.get("route") or [],
                }
                if existing is None or confidence > float(existing["confidence"]):
                    matches[target] = record
        return sorted(
            matches.values(),
            key=lambda item: (-float(item["confidence"]), item["target_path"]),
        )


def subject_key(record_type: str, assertion: str, scope: str) -> str:
    terms = sorted(set(re.findall(r"[a-zA-Z][a-zA-Z0-9_]{3,}", assertion.lower())))
    return sha256_text(
        canonical_json({"type": record_type, "scope": scope, "terms": terms[:12]})
    )


def _terms(text: str) -> set[str]:
    return {term for term in re.findall(r"[a-zA-Z][a-zA-Z0-9_]{3,}", text.lower())}


def _trust_for(row: Any) -> str:
    trust = _row_value(row, "trust")
    if trust in {"untrusted", "candidate"}:
        return trust
    if trust == "approved_org_memory":
        return "approved_org_memory"
    if row["type"] == "runtime_signal":
        return "runtime_evidence_active"
    if row["source_kind"].startswith("consolidation"):
        return "approved_consolidated_memory"
    if trust in {"approved", "active"}:
        return "approved_project_memory"
    if trust:
        return str(trust)
    return "approved_project_memory"


def _scope_from_kind_refs(
    scope_kind: str | None, scope_refs: Any, repo_id: str | None
) -> str:
    if scope_kind == "workspace":
        return "workspace"
    if scope_kind == "path" and isinstance(scope_refs, list) and scope_refs:
        return f"path:{scope_refs[0]}"
    if scope_kind and isinstance(scope_refs, list) and scope_refs:
        return f"{scope_kind}:{scope_refs[0]}"
    return f"repo:{repo_id}" if repo_id else "workspace"


def _scope_kind(scope: str) -> str:
    if ":" not in scope:
        return scope
    return scope.split(":", 1)[0]


def _scope_refs(scope: str) -> list[str]:
    if ":" not in scope:
        return []
    return [scope.split(":", 1)[1]]


def _validate_type_metadata(record_type: str, metadata: dict[str, Any]) -> None:
    requirements = TYPE_METADATA_REQUIREMENTS.get(record_type, {})
    missing = [
        key
        for key, kind in requirements.items()
        if not _metadata_value_satisfies(metadata.get(key), kind)
    ]
    if missing:
        raise ValueError(
            f"{record_type} memory requires metadata: {', '.join(sorted(missing))}"
        )


def _metadata_value_satisfies(value: Any, kind: str) -> bool:
    if kind == "non_empty_string":
        return isinstance(value, str) and bool(value.strip())
    if kind == "non_empty_list":
        return isinstance(value, list) and any(str(item).strip() for item in value)
    if kind == "priority":
        if isinstance(value, (int, float)):
            return True
        if isinstance(value, str):
            return value.strip().lower() in {"low", "medium", "high", "critical"}
        return False
    return value is not None


def _is_expired(row: Any) -> bool:
    expires_at = _row_value(row, "expires_at")
    if not expires_at:
        return False
    try:
        parsed = datetime.fromisoformat(str(expires_at).replace("Z", "+00:00"))
    except ValueError:
        return False
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed <= datetime.now(timezone.utc)


def _staleness_state(row: Any) -> str:
    if _is_expired(row):
        return "expired"
    metadata = _json(row["metadata_json"])
    if metadata.get("stale_marked_at") or metadata.get("stale_reason"):
        return "stale"
    last_validated_at = _row_value(row, "last_validated_at")
    if not last_validated_at and row["trust"] in {"active", "approved"}:
        return "unvalidated"
    age_days = _age_days(last_validated_at or row["updated_at"])
    if age_days >= 180:
        return "stale"
    if age_days >= 60:
        return "aging"
    return "fresh"


def _provenance_summary(provenance: dict[str, Any]) -> dict[str, Any]:
    return {
        "generator": provenance.get("generator"),
        "validator": provenance.get("validator"),
        "validated_at": provenance.get("validated_at"),
        "input_source": provenance.get("input_source"),
    }


def _memory_vector_text(row: Any) -> str:
    metadata = _json(row["metadata_json"])
    parts = [
        _row_value(row, "title") or "",
        row["assertion"],
        _row_value(row, "applies_when") or "",
        metadata.get("root_cause", ""),
        metadata.get("resolution", ""),
        " ".join(
            metadata.get("steps", []) if isinstance(metadata.get("steps"), list) else []
        ),
        metadata.get("next_action", ""),
    ]
    return "\n".join(str(part) for part in parts if part)


def _agent_generated_without_validator(provenance: dict[str, Any]) -> bool:
    generator = str(provenance.get("generator", ""))
    validator = str(provenance.get("validator", "none") or "none")
    return generator.startswith("agent:") and validator in {"", "none", "null"}


def _claims_policy_enforcement(assertion: str, metadata: dict[str, Any]) -> bool:
    if metadata.get("enforces") is True:
        return True
    lowered = assertion.lower()
    return any(
        phrase in lowered
        for phrase in (
            "this memory enforces",
            "enforce this policy",
            "must override policy",
            "bypass policy",
        )
    )


def _memory_defense_for(
    record_type: str, assertion: str, metadata: dict[str, Any]
) -> dict[str, Any]:
    injection = detect_query_injection(assertion)
    flagged = list(injection.get("flagged", []))
    if record_type == "preference" and _claims_policy_override(assertion, metadata):
        flagged.append("preference_policy_override")
    if not flagged:
        return {"ok": True, "reason": "clean", "flagged": [], "severity": "info"}
    return {
        "ok": False,
        "reason": "memory_poisoning_suspected",
        "flagged": sorted(set(flagged)),
        "severity": (
            "critical"
            if any(
                item in {"exfiltrate", "preference_policy_override"} for item in flagged
            )
            else "high"
        ),
    }


def _is_external_source(
    source_kind: str | None, provenance: dict[str, Any] | None
) -> bool:
    prov = provenance or {}
    source = str(source_kind or prov.get("source_kind") or "").lower()
    connector = str(prov.get("source_connector") or "").lower()
    return bool(
        prov.get("external")
        or source.startswith("external:")
        or source
        in {"slack", "email", "transcript", "transcripts", "jira", "confluence", "crm"}
        or connector
        in {"slack", "email", "transcript", "transcripts", "jira", "confluence", "crm"}
    )


def _source_connector(source_kind: str | None) -> str | None:
    source = str(source_kind or "").lower()
    if source.startswith("external:"):
        return source.split(":", 1)[1] or None
    return source or None


def _claims_policy_override(assertion: str, metadata: dict[str, Any]) -> bool:
    if metadata.get("overrides_policy") is True:
        return True
    lowered = assertion.lower()
    return any(
        phrase in lowered
        for phrase in (
            "override policy",
            "ignore policy",
            "bypass policy",
            "preference overrides",
            "must override policy",
        )
    )


def _scope_glob(scope: str) -> str:
    if scope.startswith("path:"):
        return scope.removeprefix("path:")
    return "**"


def _json(value: str) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _age_days(timestamp: str | None) -> int:
    if not timestamp:
        return 0
    try:
        value = timestamp.replace("Z", "+00:00")
        parsed = datetime.fromisoformat(value)
    except ValueError:
        return 0
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return max(0, (datetime.now(timezone.utc) - parsed).days)


def _normalized_weights(weights: dict[str, float]) -> dict[str, float]:
    selected = {
        "recency": max(0.0, float(weights.get("recency", 0.3))),
        "importance": max(0.0, float(weights.get("importance", 0.4))),
        "relevance": max(0.0, float(weights.get("relevance", 0.3))),
    }
    total = sum(selected.values())
    if total <= 0:
        return {"recency": 0.3, "importance": 0.4, "relevance": 0.3}
    return {key: value / total for key, value in selected.items()}


def _normalize_assertion(assertion: str) -> str:
    return " ".join(sorted(_terms(assertion)))


def _delete_intent(assertion: str) -> bool:
    text = assertion.lower()
    return any(
        phrase in text for phrase in ("no longer", "obsolete", "do not use", "delete ")
    )


def _row_value(row: Any, key: str) -> Any:
    try:
        return row[key]
    except (IndexError, KeyError):
        return None


def _runtime_confidence(severity: str) -> float:
    return {"critical": 0.8, "high": 0.7, "medium": 0.5, "low": 0.3}.get(
        severity.lower(), 0.5
    )


def _requires_codeowner_validation(row: Any) -> bool:
    return row["type"] in {
        "business_rule",
        "policy_reference",
        "preference",
        "org_knowledge",
    } or row["status"] in {
        "needs_review",
        "quarantined",
    }


def _require_actor_role(actor: str | None, minimum: str, action: str) -> None:
    authorization = require_actor_role(actor, minimum, action)
    if not authorization["ok"]:
        raise PermissionError(
            f"{action} requires {authorization['required_role']} role; "
            f"{authorization['actor']} is {authorization['actor_role']}"
        )


def _conflict_summary(left: str, right: str) -> str | None:
    threshold = _threshold_conflict(left, right)
    if threshold:
        return threshold
    if _opposes(left, right):
        return "Rules use conflicting obligation verbs."
    return None


def _opposes(left: str, right: str) -> bool:
    left_l = left.lower()
    right_l = right.lower()
    return ("must " in left_l and "must not" in right_l) or (
        "must not" in left_l and "must " in right_l
    )


def _threshold_conflict(left: str, right: str) -> str | None:
    left_numbers = {
        int(num.replace(",", "").replace("_", ""))
        for num in re.findall(r"\d[\d,_]*", left)
    }
    right_numbers = {
        int(num.replace(",", "").replace("_", ""))
        for num in re.findall(r"\d[\d,_]*", right)
    }
    if left_numbers and right_numbers and left_numbers != right_numbers:
        left_terms = set(re.findall(r"[a-zA-Z]{4,}", left.lower()))
        right_terms = set(re.findall(r"[a-zA-Z]{4,}", right.lower()))
        if len(left_terms & right_terms) >= 2:
            return f"Different thresholds detected: {sorted(left_numbers)} vs {sorted(right_numbers)}."
    return None
