from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Any

from ctxlayer.memory.decay import decayed_confidence
from ctxlayer.memory.graph import write_memory_edge
from ctxlayer.retrieval.embedder import cosine
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import canonical_json, stable_id, utc_now


def _normalize(text: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", text.lower()))


class SleepConsolidator:
    """Corpus-wide memory maintenance distinct from per-session consolidation."""

    def __init__(
        self,
        store: SQLiteStore,
        *,
        workspace_id: str,
        repo_id: str | None,
        embedder: Any | None = None,
        similarity_threshold: float = 0.85,
        min_episodes_for_regeneration: int = 2,
        regenerate_after_days: int = 14,
        recalibrate_after_days: int = 30,
        use_reasoning_provider: bool = True,
        reasoning_provider: Any | None = None,
    ) -> None:
        self.store = store
        self.workspace_id = workspace_id
        self.repo_id = repo_id
        self.embedder = embedder
        self.similarity_threshold = max(0.0, min(1.0, float(similarity_threshold)))
        self.min_episodes_for_regeneration = max(1, int(min_episodes_for_regeneration))
        self.regenerate_after_days = max(0, int(regenerate_after_days))
        self.recalibrate_after_days = max(0, int(recalibrate_after_days))
        self.reasoning_provider = reasoning_provider if use_reasoning_provider else None

    def run(self, *, apply: bool = False, limit: int = 2000) -> dict[str, Any]:
        run_id = self.store.start_memory_sleep_run(
            workspace_id=self.workspace_id,
            repo_id=self.repo_id,
            apply=apply,
        )
        try:
            rows = self.store.memory_records(
                repo_id=self.repo_id,
                workspace_id=self.workspace_id,
                exclude_statuses={"rejected", "expired", "quarantined", "superseded"},
            )[: max(1, int(limit))]
            duplicate_actions = self._duplicate_actions(rows)
            pattern_actions = self._pattern_regeneration_actions(rows)
            recalibration_actions = self._confidence_recalibration_actions(rows)
            reasoning_provider_used = any(
                action.get("reasoning_provider_used") for action in pattern_actions
            )
            if apply:
                self._apply_duplicate_actions(duplicate_actions)
                self._apply_pattern_actions(pattern_actions)
                self._apply_recalibration_actions(recalibration_actions)
            summary = {
                "duplicate_actions": duplicate_actions,
                "pattern_actions": pattern_actions,
                "recalibration_actions": recalibration_actions,
            }
            self.store.finish_memory_sleep_run(
                run_id,
                status="ok",
                records_scanned=len(rows),
                duplicates_merged=len(duplicate_actions) if apply else 0,
                patterns_regenerated=len(pattern_actions) if apply else 0,
                records_recalibrated=len(recalibration_actions) if apply else 0,
                reasoning_provider_used=reasoning_provider_used,
                summary=summary,
            )
            return {
                "ok": True,
                "schema_version": "ctxlayer.memory_sleep.v1",
                "run_id": run_id,
                "status": "ok",
                "apply": bool(apply),
                "records_scanned": len(rows),
                "duplicates_merged": len(duplicate_actions) if apply else 0,
                "patterns_regenerated": len(pattern_actions) if apply else 0,
                "records_recalibrated": len(recalibration_actions) if apply else 0,
                "reasoning_provider_used": reasoning_provider_used,
                "summary": summary,
            }
        except Exception as exc:
            self.store.finish_memory_sleep_run(
                run_id,
                status="failed",
                error=str(exc),
                summary={"error": str(exc)},
            )
            raise

    def _duplicate_actions(self, rows: list[Any]) -> list[dict[str, Any]]:
        grouped: dict[tuple[str, str], list[Any]] = {}
        for row in rows:
            if row["status"] not in {"candidate", "active"}:
                continue
            key = (row["type"], row["subject_key"])
            grouped.setdefault(key, []).append(row)
        actions: list[dict[str, Any]] = []
        merged_ids: set[str] = set()
        for (_type, _subject), items in grouped.items():
            if len(items) < 2:
                continue
            winner = max(
                items,
                key=lambda row: (float(row["confidence"]), str(row["updated_at"])),
            )
            for row in items:
                if row["record_id"] == winner["record_id"]:
                    continue
                if row["record_id"] in merged_ids:
                    continue
                similarity = self._assertion_similarity(winner, row)
                normalized_match = _normalize(winner["assertion"]) == _normalize(
                    row["assertion"]
                )
                if not normalized_match and similarity < self.similarity_threshold:
                    continue
                actions.append(
                    {
                        "winner_record_id": winner["record_id"],
                        "merged_record_id": row["record_id"],
                        "type": row["type"],
                        "subject_key": row["subject_key"],
                        "similarity": round(similarity, 4),
                        "reason": (
                            "exact_normalized_duplicate"
                            if normalized_match
                            else "embedding_similarity_duplicate"
                        ),
                    }
                )
                merged_ids.add(row["record_id"])
        return actions

    def _pattern_regeneration_actions(self, rows: list[Any]) -> list[dict[str, Any]]:
        by_id = {row["record_id"]: row for row in rows}
        actions: list[dict[str, Any]] = []
        for row in rows:
            if row["type"] != "pattern":
                continue
            metadata = _json(row["metadata_json"])
            if _age_days(metadata.get("last_regenerated_at") or row["updated_at"]) < (
                self.regenerate_after_days
            ):
                continue
            source_ids = [
                str(record_id)
                for record_id in metadata.get("source_episode_ids", [])
                if str(record_id) in by_id
            ]
            if len(source_ids) < self.min_episodes_for_regeneration:
                continue
            source_rows = [by_id[record_id] for record_id in source_ids]
            module = str(metadata.get("module") or row["subject_key"])
            provider_assertion = self._provider_pattern_assertion(module, source_rows)
            assertion = provider_assertion or (
                f"Semantic pattern for {module}: "
                + "; ".join(str(item["assertion"])[:160] for item in source_rows)
            )
            if assertion == row["assertion"]:
                continue
            actions.append(
                {
                    "pattern_record_id": row["record_id"],
                    "source_episode_ids": source_ids,
                    "assertion": assertion,
                    "reason": (
                        "reasoning_provider_regeneration"
                        if provider_assertion
                        else "regenerate_from_all_live_sources"
                    ),
                    "reasoning_provider_used": bool(provider_assertion),
                }
            )
        return actions

    def _confidence_recalibration_actions(
        self, rows: list[Any]
    ) -> list[dict[str, Any]]:
        actions: list[dict[str, Any]] = []
        for row in rows:
            if row["status"] not in {"candidate", "active"}:
                continue
            age_days = _age_days(row["updated_at"])
            if age_days < self.recalibrate_after_days:
                continue
            current = float(row["confidence"])
            recalibrated = decayed_confidence(current, age_days)
            if recalibrated >= current:
                continue
            actions.append(
                {
                    "record_id": row["record_id"],
                    "old_confidence": current,
                    "new_confidence": recalibrated,
                    "age_days": age_days,
                    "reason": "age_decay_recalibration",
                }
            )
        return actions

    def _assertion_similarity(self, left: Any, right: Any) -> float:
        left_text = str(left["assertion"])
        right_text = str(right["assertion"])
        if _normalize(left_text) == _normalize(right_text):
            return 1.0
        if self.embedder is not None:
            try:
                return max(
                    0.0,
                    min(
                        1.0,
                        cosine(
                            self.embedder.embed(left_text),
                            self.embedder.embed(right_text),
                        ),
                    ),
                )
            except Exception:
                pass
        left_terms = set(_normalize(left_text).split())
        right_terms = set(_normalize(right_text).split())
        if not left_terms or not right_terms:
            return 0.0
        return len(left_terms & right_terms) / len(left_terms | right_terms)

    def _provider_pattern_assertion(
        self, module: str, source_rows: list[Any]
    ) -> str | None:
        if self.reasoning_provider is None:
            return None
        prompt = {
            "task": "Regenerate one concise semantic memory pattern from live source episodes.",
            "module": module,
            "episodes": [str(row["assertion"]) for row in source_rows],
        }
        schema = {
            "type": "object",
            "required": ["assertion"],
            "properties": {"assertion": {"type": "string"}},
        }
        try:
            output = self.reasoning_provider.complete(
                prompt=canonical_json(prompt),
                role="memory_sleep_pattern_regeneration",
                schema=schema,
                budget_tokens=2000,
            )
        except Exception:
            return None
        if isinstance(output, dict) and isinstance(output.get("assertion"), str):
            assertion = output["assertion"].strip()
            return assertion or None
        if isinstance(output, str):
            assertion = output.strip()
            return assertion or None
        return None

    def _apply_duplicate_actions(self, actions: list[dict[str, Any]]) -> None:
        for action in actions:
            self.store.update_memory_record(
                record_id=action["merged_record_id"],
                patch={
                    "status": "consolidated",
                    "trust": "active",
                    "superseded_by": action["winner_record_id"],
                },
                actor="sleep_consolidation",
                reason="sleep consolidation duplicate merge",
            )
            write_memory_edge(
                self.store,
                workspace_id=self.workspace_id,
                repo_id=self.repo_id,
                src_record_id=action["winner_record_id"],
                dst_record_id=action["merged_record_id"],
                kind="supersedes",
                confidence=1.0,
                evidence=action,
                created_by="sleep_consolidation",
            )

    def _apply_pattern_actions(self, actions: list[dict[str, Any]]) -> None:
        for action in actions:
            self.store.update_memory_record(
                record_id=action["pattern_record_id"],
                patch={
                    "assertion": action["assertion"],
                    "last_regenerated_at": utc_now(),
                    "metadata_json": json.dumps(
                        {
                            "source_episode_ids": action["source_episode_ids"],
                            "sleep_regeneration_id": stable_id(
                                "sleep_regeneration",
                                action["pattern_record_id"],
                                *action["source_episode_ids"],
                            ),
                        },
                        sort_keys=True,
                    ),
                },
                actor="sleep_consolidation",
                reason="sleep consolidation pattern regeneration",
            )
            for source_id in action["source_episode_ids"]:
                write_memory_edge(
                    self.store,
                    workspace_id=self.workspace_id,
                    repo_id=self.repo_id,
                    src_record_id=action["pattern_record_id"],
                    dst_record_id=source_id,
                    kind="derived_from",
                    confidence=0.9,
                    evidence={"reason": action["reason"]},
                    created_by="sleep_consolidation",
                )

    def _apply_recalibration_actions(self, actions: list[dict[str, Any]]) -> None:
        for action in actions:
            self.store.update_memory_record(
                record_id=action["record_id"],
                patch={"confidence": action["new_confidence"]},
                actor="sleep_consolidation",
                reason="sleep consolidation confidence recalibration",
            )


def _json(raw: str | None) -> dict[str, Any]:
    try:
        value = json.loads(raw or "{}")
    except json.JSONDecodeError:
        return {}
    return value if isinstance(value, dict) else {}


def _age_days(raw: Any) -> int:
    if not raw:
        return 0
    try:
        text = str(raw).replace("Z", "+00:00")
        value = datetime.fromisoformat(text)
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
    except ValueError:
        return 0
    return max(0, (datetime.now(timezone.utc) - value).days)
