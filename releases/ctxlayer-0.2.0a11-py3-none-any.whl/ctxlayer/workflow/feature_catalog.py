from __future__ import annotations

from string import Formatter
from typing import Any

WORKFLOW_RECOMMEND_SCHEMA = "ctxlayer.workflow_recommend.v1"
WORKFLOW_NEXT_SCHEMA = "ctxlayer.workflow_next.v1"

UNRESOLVED_PARAM_BEHAVIOR = "emit placeholder + remediation; never a half-built command"

FEATURE_CATALOG: dict[str, dict[str, Any]] = {
    "pack": {
        "command_template": 'ctxlayer --repo . pack --task "{task}"',
        "mcp_tool": "get_context_pack",
        "purpose": "serve snapshot-pinned context before work proceeds",
        "gate_kind": "durable",
        "required_params": ["task"],
        "optional_params": ["paths", "intent_id", "goal_id"],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "plan": {
        "command_template": (
            "ctxlayer --repo . plan create --task-session-id {task_session_id} "
            "--pack-id {pack_id} --file <plan.json>"
        ),
        "mcp_tool": "plan_create",
        "purpose": "declare intended files, capabilities, tests, and risk before edits",
        "gate_kind": "durable",
        "required_params": ["task_session_id", "pack_id"],
        "optional_params": [],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "checkpoint": {
        "command_template": (
            "ctxlayer --repo . plan checkpoint {plan_id} --step-id <step_id> "
            "--path <changed_path>"
        ),
        "mcp_tool": "plan_checkpoint",
        "purpose": "tie changed files to the active structured plan step",
        "gate_kind": "durable",
        "required_params": ["plan_id"],
        "optional_params": ["paths"],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "impact": {
        "command_template": (
            "git diff --name-only HEAD | ctxlayer --repo . impact --paths-from-stdin"
        ),
        "mcp_tool": "impact_of",
        "purpose": "identify affected code, risk, and tests",
        "gate_kind": "none",
        "required_params": [],
        "optional_params": ["paths"],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "check_diff": {
        "command_template": (
            "git diff HEAD | ctxlayer --repo . check-diff --pack-id {pack_id}"
        ),
        "mcp_tool": "check_diff_against_pack",
        "purpose": "verify changes stayed inside pack and impact scope",
        "gate_kind": "volatile",
        "required_params": ["pack_id"],
        "optional_params": ["paths"],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "tests": {
        "command_template": "<run impact-recommended tests>",
        "mcp_tool": "verify_run",
        "purpose": "persist test or verification evidence for the task",
        "gate_kind": "durable",
        "required_params": [],
        "optional_params": ["plan_id", "pack_id"],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "outcome": {
        "command_template": (
            "ctxlayer --repo . outcome --pack-id {pack_id} --result pass "
            '--summary "<what changed and why>"'
        ),
        "mcp_tool": "record_outcome",
        "purpose": "record durable pass/fail outcome and memory summary",
        "gate_kind": "durable",
        "required_params": ["pack_id"],
        "optional_params": [],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "continuation": {
        "command_template": 'ctxlayer --repo . memory recall --query "{task}"',
        "mcp_tool": "memory_recall",
        "purpose": "resume relevant prior task state or project memory",
        "gate_kind": "none",
        "required_params": ["task"],
        "optional_params": ["paths"],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "agent_route": {
        "command_template": 'ctxlayer --repo . agent route --task "{task}"',
        "mcp_tool": "agent_route",
        "purpose": "route high-risk or multi-agent work for review",
        "gate_kind": "none",
        "required_params": ["task"],
        "optional_params": ["capabilities"],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "decision": {
        "command_template": 'ctxlayer --repo . decision start --question "{task}"',
        "mcp_tool": "decision_start",
        "purpose": "capture trade-off decisions before architecture or policy changes",
        "gate_kind": "none",
        "required_params": ["task"],
        "optional_params": ["paths"],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "security_scan": {
        "command_template": "ctxlayer --repo . security scan",
        "mcp_tool": "security_scan",
        "purpose": "scan security-sensitive changes before outcome",
        "gate_kind": "durable",
        "required_params": [],
        "optional_params": [],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "release_validate": {
        "command_template": "ctxlayer --repo . release validate",
        "mcp_tool": "release_validate",
        "purpose": "validate release readiness and packaging expectations",
        "gate_kind": "durable",
        "required_params": [],
        "optional_params": [],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "workflow_next": {
        "command_template": (
            "ctxlayer --repo . workflow next --task-session-id {task_session_id}"
        ),
        "mcp_tool": "workflow_next",
        "purpose": "project the next CTX action from durable workflow evidence",
        "gate_kind": "none",
        "required_params": ["task_session_id"],
        "optional_params": [],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
}

FEATURE_CATALOG.update(
    {
        "memory_recall": {
            "command_template": 'ctxlayer --repo . memory recall --query "{task}"',
            "mcp_tool": "memory_recall",
            "purpose": "recall project memory with semantic sqlite-vec when available and honest json-cosine fallback when degraded",
            "gate_kind": "none",
            "required_params": ["task"],
            "optional_params": ["paths"],
            "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
        },
        "db_backend_status": {
            "command_template": "ctxlayer --repo . db backend-status",
            "mcp_tool": "db_backend_status",
            "purpose": "inspect retrieval and analytics backend truth before judging recall quality",
            "gate_kind": "none",
            "required_params": [],
            "optional_params": [],
            "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
        },
        "db_bench": {
            "command_template": "ctxlayer --repo . db bench",
            "mcp_tool": "db_bench",
            "purpose": "record storage benchmark evidence for vector recall, analytics, and SQLite write contention",
            "gate_kind": "durable",
            "required_params": [],
            "optional_params": [],
            "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
        },
        "storage_report": {
            "command_template": "ctxlayer --repo . storage-report",
            "mcp_tool": "storage_report",
            "purpose": "explain workspace database size, snapshot pins, dirty pack retention, archive state, and redundant vector JSON",
            "gate_kind": "none",
            "required_params": [],
            "optional_params": [],
            "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
        },
        "gc": {
            "command_template": "ctxlayer --repo . gc --deep --prune-snapshots",
            "mcp_tool": "gc",
            "purpose": "apply retention, unpin stale dirty packs, prune eligible snapshots, archive when enabled, and compact storage",
            "gate_kind": "durable",
            "required_params": [],
            "optional_params": [],
            "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
        },
        "retention": {
            "command_template": "ctxlayer --repo . retention set --preset balanced",
            "mcp_tool": "retention_set",
            "purpose": "configure named storage retention presets for context packs, snapshots, and session events",
            "gate_kind": "durable",
            "required_params": [],
            "optional_params": [],
            "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
        },
        "maintenance_run": {
            "command_template": "ctxlayer --repo . maintenance run",
            "mcp_tool": "maintenance_run",
            "purpose": "run the maintenance lane that now includes storage retention and pinned snapshot budget enforcement",
            "gate_kind": "durable",
            "required_params": [],
            "optional_params": [],
            "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
        },
        "anticipation_consult": {
            "command_template": 'ctxlayer --repo . anticipate consult --task "{task}"',
            "mcp_tool": "anticipation_consult",
            "purpose": "surface foresight before risky or cross-cutting writes",
            "gate_kind": "none",
            "required_params": ["task"],
            "optional_params": ["paths"],
            "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
        },
        "semantic_search": {
            "command_template": 'ctxlayer --repo . semantic search "{task}"',
            "mcp_tool": "semantic_search",
            "purpose": "search semantic code and memory context during investigation",
            "gate_kind": "none",
            "required_params": ["task"],
            "optional_params": ["paths"],
            "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
        },
        "architecture_infer": {
            "command_template": "ctxlayer --repo . architecture infer",
            "mcp_tool": "architecture_infer",
            "purpose": "infer architectural boundaries for cross-cutting work",
            "gate_kind": "none",
            "required_params": [],
            "optional_params": ["paths"],
            "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
        },
        "graph_neighbors": {
            "command_template": "ctxlayer --repo . graph neighbors --path <path>",
            "mcp_tool": "graph_neighbors",
            "purpose": "inspect code dependency graph neighbors",
            "gate_kind": "none",
            "required_params": [],
            "optional_params": ["paths"],
            "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
        },
        "memory_graph_recall": {
            "command_template": "ctxlayer --repo . memory graph <record_id>",
            "mcp_tool": "memory_graph_recall",
            "purpose": "walk memory-to-memory graph edges from a recalled record",
            "gate_kind": "none",
            "required_params": [],
            "optional_params": ["paths"],
            "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
        },
        "memory_prefetch": {
            "command_template": 'ctxlayer --repo . memory prefetch --task "{task}"',
            "mcp_tool": "memory_prefetch",
            "purpose": "prefetch memory from anticipation lookahead",
            "gate_kind": "none",
            "required_params": ["task"],
            "optional_params": ["paths"],
            "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
        },
        "memory_sleep": {
            "command_template": "ctxlayer --repo . memory sleep --apply",
            "mcp_tool": "memory_sleep",
            "purpose": "run corpus-wide memory maintenance outside task-critical flow",
            "gate_kind": "durable",
            "required_params": [],
            "optional_params": [],
            "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
        },
        "memory_dream": {
            "command_template": "ctxlayer --repo . memory dream",
            "mcp_tool": "memory_dream",
            "purpose": "run reflective memory synthesis as a maintenance-lane action",
            "gate_kind": "none",
            "required_params": [],
            "optional_params": [],
            "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
        },
        "selfimprove": {
            "command_template": "ctxlayer --repo . self-improve status",
            "mcp_tool": "self_improve_status",
            "purpose": "inspect self-improvement proposals in the maintenance lane",
            "gate_kind": "none",
            "required_params": [],
            "optional_params": [],
            "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
        },
        "cie": {
            "command_template": "ctxlayer --repo . cie status",
            "mcp_tool": "cie_status",
            "purpose": "inspect capability improvement engine state in the maintenance lane",
            "gate_kind": "none",
            "required_params": [],
            "optional_params": [],
            "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
        },
    }
)

FEATURE_ACTIVATION: dict[str, dict[str, str]] = {
    "pack": {"trigger": "session_start", "condition": "always"},
    "memory_recall": {"trigger": "session_start", "condition": "always"},
    "continuation": {"trigger": "session_start", "condition": "has_prior_context"},
    "workflow_next": {"trigger": "session_start", "condition": "has_task_session"},
    "memory_prefetch": {"trigger": "session_start", "condition": "prefetch_enabled"},
    "plan": {"trigger": "pre_write", "condition": "write_mode"},
    "checkpoint": {"trigger": "pre_write", "condition": "write_mode"},
    "anticipation_consult": {
        "trigger": "pre_write",
        "condition": "risk_high_or_critical_path",
    },
    "decision": {"trigger": "pre_write", "condition": "architecture_or_decision"},
    "impact": {"trigger": "pre_complete", "condition": "write_mode"},
    "check_diff": {"trigger": "pre_complete", "condition": "write_mode"},
    "tests": {"trigger": "pre_complete", "condition": "write_mode"},
    "outcome": {"trigger": "pre_complete", "condition": "write_mode"},
    "security_scan": {"trigger": "pre_complete", "condition": "security_change"},
    "release_validate": {"trigger": "pre_complete", "condition": "release_task"},
    "agent_route": {"trigger": "on_demand", "condition": "risk_high_or_critical_path"},
    "semantic_search": {"trigger": "on_demand", "condition": "investigation"},
    "architecture_infer": {"trigger": "on_demand", "condition": "architecture_task"},
    "graph_neighbors": {"trigger": "on_demand", "condition": "investigation"},
    "memory_graph_recall": {"trigger": "on_demand", "condition": "memory_task"},
    "memory_sleep": {"trigger": "on_demand", "condition": "maintenance_lane"},
    "memory_dream": {"trigger": "on_demand", "condition": "maintenance_lane"},
    "selfimprove": {"trigger": "on_demand", "condition": "maintenance_lane"},
    "cie": {"trigger": "on_demand", "condition": "maintenance_lane"},
}

for _feature_id, _entry in FEATURE_CATALOG.items():
    _entry.setdefault(
        "activation",
        FEATURE_ACTIVATION.get(
            _feature_id, {"trigger": "on_demand", "condition": "manual"}
        ),
    )


def template_params(template: str) -> set[str]:
    return {
        field_name for _, field_name, _, _ in Formatter().parse(template) if field_name
    }


def feature_ids() -> list[str]:
    return sorted(FEATURE_CATALOG)
