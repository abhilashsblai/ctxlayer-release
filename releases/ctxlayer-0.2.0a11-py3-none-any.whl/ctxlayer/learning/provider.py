from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any, Callable, Protocol

from ctxlayer.config import LearningConfig, Settings
from ctxlayer.learning._shell import format_command, run_shell
from ctxlayer.utils import estimate_tokens, stable_id

LearningEventLogger = Callable[[str, str, str | None, dict[str, Any]], None]


class AgentProvider(Protocol):
    def complete(
        self,
        *,
        prompt: str,
        role: str,
        schema: dict[str, Any] | None = None,
        model_family: str | None = None,
        budget_tokens: int | None = None,
    ) -> Any | None: ...


class NullProvider:
    provider_id = "null"

    def complete(
        self,
        *,
        prompt: str,
        role: str,
        schema: dict[str, Any] | None = None,
        model_family: str | None = None,
        budget_tokens: int | None = None,
    ) -> None:
        return None


class EnrichmentBudget:
    """Shared wall-clock budget for provider-backed pack enrichment.

    Started when the pack build begins and consulted before each provider
    call. Once the deadline passes, callers short-circuit and mark the pack
    low-confidence rather than stalling on a slow/hung explicit provider.
    A non-positive budget means "unbounded".
    """

    def __init__(self, seconds: float | None):
        self._deadline = (
            time.perf_counter() + float(seconds)
            if seconds and float(seconds) > 0
            else None
        )
        self.truncated = False

    def remaining(self) -> float | None:
        if self._deadline is None:
            return None
        return self._deadline - time.perf_counter()

    def expired(self) -> bool:
        remaining = self.remaining()
        if remaining is None:
            return False
        if remaining <= 0:
            self.truncated = True
            return True
        return False


class BudgetedProvider:
    """Wrap a provider so cumulative pack-enrichment time stays within budget.

    Before each ``complete`` the remaining budget is checked: once exhausted
    the call short-circuits to ``None`` (like :class:`NullProvider`) and marks
    the budget truncated. When the inner provider exposes a mutable ``timeout``
    (e.g. :class:`CommandAgentProvider`) it is clamped to the remaining budget
    so a single in-flight call cannot overrun it either. The result is a total
    wall-clock bound of roughly the configured budget.
    """

    def __init__(self, inner: AgentProvider, budget: EnrichmentBudget):
        self._inner = inner
        self._budget = budget
        self.provider_id = getattr(inner, "provider_id", "null")

    def complete(
        self,
        *,
        prompt: str,
        role: str,
        schema: dict[str, Any] | None = None,
        model_family: str | None = None,
        budget_tokens: int | None = None,
    ) -> Any | None:
        remaining = self._budget.remaining()
        if remaining is not None and remaining <= 0:
            self._budget.truncated = True
            return None
        if remaining is not None and hasattr(self._inner, "timeout"):
            try:
                self._inner.timeout = max(
                    1, min(int(self._inner.timeout), int(remaining) + 1)
                )
            except (TypeError, ValueError):
                pass
        return self._inner.complete(
            prompt=prompt,
            role=role,
            schema=schema,
            model_family=model_family,
            budget_tokens=budget_tokens,
        )


class CommandAgentProvider:
    def __init__(
        self,
        *,
        command: str,
        repo_root: Path,
        timeout: int = 600,
        max_depth: int = 1,
        max_tokens_per_task: int = 20_000,
        event_logger: LearningEventLogger | None = None,
    ):
        self.command = command
        self.repo_root = repo_root
        self.timeout = timeout
        self.max_depth = max(0, int(max_depth))
        self.max_tokens_per_task = max_tokens_per_task
        self.event_logger = event_logger
        self.provider_id = f"command:{stable_id(command)[:12]}"

    def complete(
        self,
        *,
        prompt: str,
        role: str,
        schema: dict[str, Any] | None = None,
        model_family: str | None = None,
        budget_tokens: int | None = None,
    ) -> Any | None:
        if _learning_kill_switch_enabled():
            self._event(
                "provider", "kill_switch", role, {"provider_id": self.provider_id}
            )
            return None
        depth = _provider_depth()
        if depth >= self.max_depth:
            self._event(
                "provider",
                "depth_guard",
                role,
                {
                    "provider_id": self.provider_id,
                    "depth": depth,
                    "max_depth": self.max_depth,
                },
            )
            return None
        token_budget = budget_tokens or self.max_tokens_per_task
        prompt_tokens = estimate_tokens(prompt)
        if token_budget > 0 and prompt_tokens > token_budget:
            self._event(
                "provider",
                "budget_exceeded",
                role,
                {
                    "provider_id": self.provider_id,
                    "prompt_tokens": prompt_tokens,
                    "budget_tokens": token_budget,
                },
            )
            return None
        with tempfile.TemporaryDirectory(prefix="ctxlayer-learning-") as tmp:
            prompt_path = Path(tmp) / "prompt.txt"
            prompt_path.write_text(prompt, encoding="utf-8")
            rendered = format_command(
                self.command,
                {
                    "prompt_file": str(prompt_path),
                    "repo": str(self.repo_root),
                    "role": role,
                    "model_family": model_family or "",
                    "budget_tokens": str(token_budget),
                },
            )
            env = os.environ.copy()
            env.update(
                {
                    "CTXLAYER_LEARNING_ROLE": role,
                    "CTXLAYER_LEARNING_PROMPT_PATH": str(prompt_path),
                    "CTXLAYER_LEARNING_MODEL_FAMILY": model_family or "",
                    "CTXLAYER_LEARNING_BUDGET_TOKENS": str(token_budget),
                    "CTXLAYER_PROVIDER_DEPTH": str(depth + 1),
                    "CTXLAYER_REASONING_READ_ONLY": "1",
                }
            )
            result = run_shell(
                rendered, cwd=self.repo_root, timeout=self.timeout, env=env
            )
        if result["exit_code"] != 0:
            self._event(
                "provider",
                "command_failed",
                role,
                {
                    "provider_id": self.provider_id,
                    "exit_code": result["exit_code"],
                    "timed_out": result["timed_out"],
                    "stderr": result["stderr"],
                },
            )
            return None
        output = str(result["stdout"]).strip()
        if schema is None:
            return output
        try:
            parsed = json.loads(output)
        except json.JSONDecodeError as exc:
            self._event(
                "provider",
                "schema_drop",
                role,
                {"provider_id": self.provider_id, "reason": f"invalid_json: {exc.msg}"},
            )
            return None
        errors = validate_json_schema(parsed, schema)
        if errors:
            self._event(
                "provider",
                "schema_drop",
                role,
                {
                    "provider_id": self.provider_id,
                    "reason": "schema_validation",
                    "errors": errors,
                },
            )
            return None
        return parsed

    def _event(
        self, phase: str, kind: str, ref: str | None, payload: dict[str, Any]
    ) -> None:
        if self.event_logger:
            self.event_logger(phase, kind, ref, payload)


def build_agent_provider(
    settings: Settings,
    *,
    repo_root: Path,
    event_logger: LearningEventLogger | None = None,
) -> AgentProvider:
    config = settings.learning
    resolved = resolve_provider(config)
    if not resolved["configured"] or _learning_kill_switch_enabled():
        return NullProvider()
    if _ambient_agent_provider_suppressed(resolved.get("source")):
        if event_logger:
            event_logger(
                "provider",
                "ambient_self_recursion_suppressed",
                None,
                {"source": resolved.get("source")},
            )
        return NullProvider()
    return CommandAgentProvider(
        command=str(resolved["command"]),
        repo_root=repo_root,
        timeout=max(1, int(config.provider_timeout_seconds)),
        max_depth=max(1, int(config.provider_max_depth)),
        max_tokens_per_task=config.max_tokens_per_task,
        event_logger=event_logger,
    )


def learning_enabled(config: LearningConfig) -> bool:
    return bool(resolve_provider(config)["configured"])


def provider_status(config: LearningConfig) -> dict[str, Any]:
    readiness = provider_readiness(config)
    kill_switch = _learning_kill_switch_enabled()
    enabled = bool(readiness["configured"])
    return {
        "kind": readiness.get("mode") if enabled else "null",
        "enabled": enabled,
        "configured": readiness["configured"],
        "kill_switch": kill_switch,
        "reason": readiness["reason"],
        "provider_id": readiness["provider_id"] if enabled else "null",
        "mode": readiness.get("mode"),
        "source": readiness.get("source"),
    }


def provider_readiness(config: LearningConfig | Settings) -> dict[str, Any]:
    learning = config.learning if isinstance(config, Settings) else config
    return resolve_provider(learning, include_command=False)


def resolve_provider(
    config: LearningConfig, *, include_command: bool = True
) -> dict[str, Any]:
    command = config.agent_command.strip()
    kill_switch = _learning_kill_switch_enabled()
    mode = "null"
    source = None
    reason = None
    provider_id = "null"
    resolved_command = ""
    if not config.enabled:
        reason = "learning_disabled"
    elif kill_switch:
        reason = "learning_kill_switch_enabled"
    elif command:
        mode = "command"
        source = "learning.agent_command"
        provider_id = f"command:{stable_id(command)[:12]}"
        resolved_command = command
    else:
        agent = _agent_context_provider_command()
        if agent:
            mode = "agent"
            source = agent["source"]
            resolved_command = agent["command"]
            provider_id = f"agent:{stable_id(resolved_command)[:12]}"
        else:
            reason = "no_agent_command_configured"
    configured = bool(resolved_command) and reason is None
    result = {
        "configured": configured,
        "provider_id": provider_id if configured else "null",
        "reason": reason,
        "mode": mode if configured else "null",
        "source": source,
    }
    if include_command:
        result["command"] = resolved_command
    result["read_only_role"] = configured
    result["max_depth"] = max(1, int(config.provider_max_depth))
    result["timeout_seconds"] = max(1, int(config.provider_timeout_seconds))
    return result


def _agent_context_provider_command() -> dict[str, str] | None:
    override = os.environ.get("CTXLAYER_AGENT_COMMAND", "").strip()
    if override:
        return {"command": override, "source": "env:CTXLAYER_AGENT_COMMAND"}
    if _pytest_agent_context_disabled():
        return None
    if not _codex_agent_context_detected():
        return None
    codex = shutil.which("codex")
    if not codex:
        return None
    command = (
        f"{subprocess.list2cmdline([codex])} exec --ephemeral "
        "--skip-git-repo-check --sandbox read-only -C {repo} -"
    )
    return {
        "command": command,
        "source": "agent_context:codex",
    }


def _codex_agent_context_detected() -> bool:
    return any(
        os.environ.get(name, "").strip()
        for name in (
            "CODEX_THREAD_ID",
            "CODEX_PROJECT_DIR",
            "CODEX_MANAGED_BY_NPM",
            "CODEX_MANAGED_PACKAGE_ROOT",
        )
    )


def _pytest_agent_context_disabled() -> bool:
    if os.environ.get("CTXLAYER_ALLOW_AGENT_PROVIDER_IN_TESTS", "").strip():
        return False
    return bool(os.environ.get("PYTEST_CURRENT_TEST", "").strip())


def is_real_provider(provider: AgentProvider | None) -> bool:
    return provider is not None and getattr(provider, "provider_id", "null") != "null"


def validate_json_schema(value: Any, schema: dict[str, Any]) -> list[dict[str, Any]]:
    errors: list[dict[str, Any]] = []
    _validate(value, schema, "$", errors)
    return errors


def _validate(
    value: Any, schema: dict[str, Any], path: str, errors: list[dict[str, Any]]
) -> None:
    expected = schema.get("type")
    if expected and not _matches_type(value, expected):
        errors.append(
            {
                "path": path,
                "message": f"expected {expected}, got {type(value).__name__}",
            }
        )
        return
    enum = schema.get("enum")
    if isinstance(enum, list) and value not in enum:
        errors.append({"path": path, "message": "value is not in enum"})
    if expected == "object":
        if not isinstance(value, dict):
            return
        required = schema.get("required", [])
        if isinstance(required, list):
            for key in required:
                if isinstance(key, str) and key not in value:
                    errors.append(
                        {"path": f"{path}.{key}", "message": "required field missing"}
                    )
        properties = schema.get("properties", {})
        if isinstance(properties, dict):
            for key, child_schema in properties.items():
                if key in value and isinstance(child_schema, dict):
                    _validate(value[key], child_schema, f"{path}.{key}", errors)
        if schema.get("additionalProperties") is False and isinstance(properties, dict):
            allowed = set(properties)
            for key in value:
                if key not in allowed:
                    errors.append(
                        {"path": f"{path}.{key}", "message": "unexpected field"}
                    )
    elif expected == "array":
        if not isinstance(value, list):
            return
        item_schema = schema.get("items")
        if isinstance(item_schema, dict):
            for index, item in enumerate(value):
                _validate(item, item_schema, f"{path}[{index}]", errors)
    elif expected in {"number", "integer"} and isinstance(value, (int, float)):
        minimum = schema.get("minimum")
        maximum = schema.get("maximum")
        if isinstance(minimum, (int, float)) and value < minimum:
            errors.append(
                {"path": path, "message": f"value is below minimum {minimum}"}
            )
        if isinstance(maximum, (int, float)) and value > maximum:
            errors.append(
                {"path": path, "message": f"value is above maximum {maximum}"}
            )


def _matches_type(value: Any, expected: Any) -> bool:
    if isinstance(expected, list):
        return any(_matches_type(value, item) for item in expected)
    if expected == "object":
        return isinstance(value, dict)
    if expected == "array":
        return isinstance(value, list)
    if expected == "string":
        return isinstance(value, str)
    if expected == "number":
        return isinstance(value, int | float) and not isinstance(value, bool)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "null":
        return value is None
    return True


def _ambient_agent_provider_suppressed(source: str | None) -> bool:
    """Guard against synchronously re-entering the agent we run inside.

    When no explicit provider command is configured, ctxlayer auto-detects the
    ambient coding agent (e.g. Codex sets ``CODEX_THREAD_ID``) and would shell
    back out to it as a reasoning oracle. On the pack/preflight critical path
    that spawns a full nested agent turn *inside* the turn already waiting on
    us — a self-recursion that serialises several ``provider_timeout_seconds``
    calls (the cognitive workspace alone runs up to ``workspace_max_rounds``)
    and blows past the caller's timeout, so the pack never returns a pack_id.

    Suppress ambient providers by default. An explicit
    ``learning.agent_command`` / ``CTXLAYER_AGENT_COMMAND`` is a deliberate,
    *different* command and is never suppressed. Set
    ``CTXLAYER_ALLOW_AMBIENT_AGENT_PROVIDER=1`` to opt back in (e.g. for the
    self-improvement engine running outside an interactive agent turn).
    """
    if not source or not str(source).startswith("agent_context:"):
        return False
    return os.environ.get(
        "CTXLAYER_ALLOW_AMBIENT_AGENT_PROVIDER", ""
    ).strip().lower() not in {"1", "true", "yes", "on"}


def _learning_kill_switch_enabled() -> bool:
    return os.environ.get("CTXLAYER_LEARNING_OFF", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def _provider_depth() -> int:
    try:
        return max(0, int(os.environ.get("CTXLAYER_PROVIDER_DEPTH", "0") or "0"))
    except ValueError:
        return 0
