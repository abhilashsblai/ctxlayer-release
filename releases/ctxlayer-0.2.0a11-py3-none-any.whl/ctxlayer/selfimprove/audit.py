from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any

from ctxlayer.selfimprove.contracts import AUDIT_SCHEMA


def collect_self_audit(
    service: Any, *, now: str, previous: dict[str, Any] | None = None
) -> dict[str, Any]:
    snapshot = service.resolver.current_identity()
    doctor = _doctor_summary(service)
    changed_paths = _git_lines(service.repo_root, ["diff", "--name-only", "HEAD"])
    tracked_tests = [
        path
        for path in _git_lines(service.repo_root, ["ls-files"])
        if path.startswith("tests/") and path.endswith(".py")
    ]
    source_files = [
        path
        for path in _git_lines(service.repo_root, ["ls-files", "src/ctxlayer"])
        if Path(path).suffix == ".py"
    ]
    audit = {
        "schema_version": AUDIT_SCHEMA,
        "generated_at": now,
        "run_day": now[:10],
        "repo_id": snapshot.repo_id,
        "snapshot_id": snapshot.snapshot_id,
        "base_commit_sha": snapshot.base_commit_sha,
        "worktree_state": snapshot.worktree_state,
        "signals": {
            "doctor": doctor,
            "changed_path_count": len(changed_paths),
            "changed_paths": changed_paths[:50],
            "tracked_test_count": len(tracked_tests),
            "source_file_count": len(source_files),
        },
        "regressions": _regressions(previous, doctor, len(tracked_tests)),
    }
    return audit


def _doctor_summary(service: Any) -> dict[str, Any]:
    try:
        doctor = service.doctor()
    except Exception as exc:  # noqa: BLE001 - audit must remain advisory.
        return {"ok": False, "error": str(exc)}
    health = doctor.get("ctx_health", {}) if isinstance(doctor, dict) else {}
    return {
        "ok": bool(doctor.get("ok")),
        "status": doctor.get("status"),
        "operational": bool(doctor.get("operational")),
        "ready_for_work": bool(doctor.get("ready_for_work")),
        "setup_complete": bool(doctor.get("setup_complete")),
        "setup_status": doctor.get("setup_status"),
        "ctx_health_status": health.get("status"),
    }


def _regressions(
    previous: dict[str, Any] | None, doctor: dict[str, Any], test_count: int
) -> list[dict[str, Any]]:
    if not previous:
        return []
    previous_signals = previous.get("signals", {})
    findings: list[dict[str, Any]] = []
    previous_tests = int(previous_signals.get("tracked_test_count") or 0)
    if previous_tests and test_count < previous_tests:
        findings.append(
            {
                "kind": "test_count_decreased",
                "severity": "warn",
                "before": previous_tests,
                "after": test_count,
            }
        )
    previous_doctor = previous_signals.get("doctor", {})
    if previous_doctor.get("ok") and not doctor.get("ok"):
        findings.append({"kind": "doctor_regressed", "severity": "warn"})
    return findings


def _git_lines(repo_root: Path, args: list[str]) -> list[str]:
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=repo_root,
            check=False,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=15,
        )
    except (FileNotFoundError, subprocess.SubprocessError):
        return []
    if result.returncode != 0:
        return []
    return [
        line.strip().replace("\\", "/")
        for line in result.stdout.splitlines()
        if line.strip()
    ]
