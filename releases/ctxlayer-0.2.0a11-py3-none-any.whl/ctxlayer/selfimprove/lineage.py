from __future__ import annotations

from typing import Any


def lineage_metrics(proposal: dict[str, Any]) -> dict[str, Any]:
    evaluation = proposal.get("eval") or {}
    flags = (proposal.get("overseer") or {}).get("flags", [])
    return {
        "proposal_status": proposal.get("status"),
        "eval_status": evaluation.get("status"),
        "eval_ok": bool(evaluation.get("ok")),
        "block_flags": sum(1 for item in flags if item.get("severity") == "block"),
    }


def clade_productivity(after_metrics: dict[str, Any]) -> float:
    score = 0.0
    if after_metrics.get("eval_ok"):
        score += 1.0
    score -= float(after_metrics.get("block_flags") or 0)
    return round(score, 3)
