from __future__ import annotations

from .controller import MetacognitiveController

__all__ = ["MetacognitiveController"]
