from __future__ import annotations

from pathlib import Path
from typing import Any

from ctxlayer.learning.provider import AgentProvider, is_real_provider
from ctxlayer.utils import canonical_json, estimate_tokens

WORKSPACE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "missing_paths": {"type": "array", "items": {"type": "string"}},
        "questions": {"type": "array", "items": {"type": "string"}},
    },
    "additionalProperties": True,
}


def run_cognitive_workspace(
    *,
    repo_root: Path,
    task: str,
    pack: dict[str, Any],
    provider: AgentProvider | None,
    max_rounds: int,
    convergence_delta: float,
    budget_tokens: int | None = None,
) -> dict[str, Any]:
    if not is_real_provider(provider):
        return {
            "ok": True,
            "schema_version": "ctxlayer.workspace.v1",
            "active": False,
            "reason": "provider_inactive",
            "rounds": [],
            "converged": False,
        }
    seen_paths = {
        str(item.get("path")) for item in pack.get("items") or [] if item.get("path")
    }
    previous_count = len(seen_paths)
    rounds: list[dict[str, Any]] = []
    converged = False
    for index in range(max(1, int(max_rounds))):
        raw = provider.complete(
            prompt=_workspace_prompt(task, pack, seen_paths),
            role="reasoning_workspace",
            schema=WORKSPACE_SCHEMA,
            budget_tokens=budget_tokens,
        )
        missing_paths = _candidate_paths(raw, repo_root)
        added = []
        for path in missing_paths:
            if path in seen_paths:
                continue
            item = _pack_item_for_path(repo_root, path)
            if item is None:
                continue
            pack.setdefault("items", []).append(item)
            seen_paths.add(path)
            added.append(path)
        delta = (len(seen_paths) - previous_count) / max(1, previous_count)
        rounds.append(
            {
                "round": index + 1,
                "requested_paths": missing_paths,
                "added_paths": added,
                "delta": round(delta, 4),
            }
        )
        if delta <= max(0.0, float(convergence_delta)):
            converged = True
            break
        previous_count = len(seen_paths)
    return {
        "ok": True,
        "schema_version": "ctxlayer.workspace.v1",
        "active": True,
        "reason": None,
        "rounds": rounds,
        "converged": converged,
        "round_count": len(rounds),
        "added_paths": [path for item in rounds for path in item["added_paths"]],
    }


def _workspace_prompt(task: str, pack: dict[str, Any], paths: set[str]) -> str:
    payload = {
        "task": task,
        "current_paths": sorted(paths),
        "warnings": pack.get("warnings", []),
        "instruction": (
            "Return JSON naming only existing repo paths still needed to reason about "
            "the task. Do not propose edits or commands."
        ),
    }
    return canonical_json(payload)


def _candidate_paths(raw: Any, repo_root: Path) -> list[str]:
    values: list[str] = []
    if isinstance(raw, dict):
        for key in ("missing_paths", "paths", "relevant_paths"):
            value = raw.get(key)
            if isinstance(value, list):
                values.extend(str(item) for item in value if item)
    result: list[str] = []
    for value in values:
        normalized = value.replace("\\", "/").lstrip("./")
        if ".." in Path(normalized).parts:
            continue
        if (repo_root / normalized).is_file() and normalized not in result:
            result.append(normalized)
    return result


def _pack_item_for_path(repo_root: Path, path: str) -> dict[str, Any] | None:
    full = repo_root / path
    try:
        text = full.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        return None
    return {
        "path": path,
        "symbol_identity_id": None,
        "category": "workspace_refinement",
        "start_line": 1,
        "end_line": text.count("\n") + 1,
        "text": text,
        "token_count": estimate_tokens(text),
        "score": 0.0,
        "trust_tier": "source",
        "provenance": ["workspace:provider_gap"],
        "owners": [],
        "churn": {},
        "graph_confidence": 1.0,
        "confidence_tier": "high",
        "selection_explanation": {
            "summary": "Added by bounded cognitive workspace from an existing repo path.",
            "signals": [{"kind": "workspace:provider_gap", "score": 0.0}],
            "risk_covered": [],
            "related_rules": [],
        },
    }
