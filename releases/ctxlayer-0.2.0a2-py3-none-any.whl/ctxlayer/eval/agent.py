from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping

from ctxlayer.eval.contamination import annotate_cases, holdout_is_clean
from ctxlayer.learning._shell import format_command as _format_command
from ctxlayer.learning._shell import run_shell as _run_shell
from ctxlayer.utils import stable_id

PackProvider = Callable[[Path, str], dict[str, Any]]
PreflightProvider = Callable[[Path, str, str, list[str]], dict[str, Any]]

ARMS = ("baseline", "ctxlayer")

DEFAULT_GATE_THRESHOLDS = {
    "min_cases": 1,
    "min_success_rate_delta": 0.0,
    "min_tests_pass_rate_delta": 0.0,
    "min_wrong_files_touched_reduction": 0.0,
    "min_missing_files_reduction": 0.0,
    "min_ctxlayer_success_rate": 0.0,
    "require_final_corpus": False,
}

FINAL_BENCHMARK_CORPUS_REQUIREMENTS = {
    "total": 30,
    "memory": 10,
    "continuation": 5,
    "skill": 5,
    "security": 5,
    "codex_parallel": 3,
    "memory_first": 3,
}

REQUIRED_AGENT_BENCHMARK_METRICS = {
    "continuation_resume_accuracy",
    "memory_first_success_rate",
    "memory_hit_rate",
    "policy_over_preference_pass_rate",
    "poisoning_resistance",
    "quarantine_precision",
    "quarantine_recall",
    "repair_iterations",
    "retrieval_graph_signal_rate",
    "retrieval_vector_backend_available_rate",
    "skill_replay_success_rate",
    "stale_unsafe_exclusion_rate",
    "stale_false_negative_rate",
    "stale_false_positive_rate",
}

KNOWN_CASE_TYPES = {
    "codex_parallel",
    "continuation",
    "general",
    "graph",
    "memory",
    "memory_first",
    "optimizer",
    "retrieval",
    "security",
    "selfmod",
    "skill",
}

CASE_TYPE_ALIASES = {
    "adversarial": "security",
    "attack": "security",
    "poisoning": "security",
    "quarantine": "security",
    "continuations": "continuation",
    "memory-os": "memory",
    "memory_os": "memory",
    "memory-first": "memory_first",
    "memoryfirst": "memory_first",
    "parallel-agent": "codex_parallel",
    "parallel_agent": "codex_parallel",
    "self-mod": "selfmod",
    "self_mod": "selfmod",
    "skills": "skill",
}


@dataclass(frozen=True)
class AgentBenchmarkCase:
    case_id: str
    task: str
    expected_files: list[str]
    test_command: str | None = None
    setup_command: str | None = None
    case_type: str = "general"
    split: str = "unspecified"
    source_commit_date: str | None = None
    setup_mode: str | None = None
    tags: tuple[str, ...] = ()

    def metadata(self) -> dict[str, Any]:
        return {
            "case_id": self.case_id,
            "case_type": self.case_type,
            "split": self.split,
            "source_commit_date": self.source_commit_date,
            "setup_mode": self.setup_mode,
            "tags": list(self.tags),
        }


class AgentBenchmarkHarness:
    def __init__(
        self,
        repo_root: Path,
        *,
        pack_provider: PackProvider | None = None,
        preflight_provider: PreflightProvider | None = None,
    ):
        self.repo_root = repo_root
        self.pack_provider = pack_provider
        self.preflight_provider = preflight_provider

    def run_cases_file(
        self,
        *,
        path: Path,
        agent_command: str,
        limit: int = 10,
        timeout: int = 600,
        keep_worktrees: bool = False,
    ) -> dict[str, Any]:
        cases = _load_cases(path)[: max(0, limit)]
        return self.run(
            cases=cases,
            agent_command=agent_command,
            timeout=timeout,
            keep_worktrees=keep_worktrees,
        )

    def run(
        self,
        *,
        cases: list[AgentBenchmarkCase],
        agent_command: str,
        timeout: int = 600,
        keep_worktrees: bool = False,
    ) -> dict[str, Any]:
        root = Path(tempfile.mkdtemp(prefix="ctxlayer-agent-bench-"))
        case_results: list[dict[str, Any]] = []
        try:
            for case in cases:
                case_results.append(
                    {
                        "case_id": case.case_id,
                        "case_type": case.case_type,
                        "split": case.split,
                        "source_commit_date": case.source_commit_date,
                        "setup_mode": case.setup_mode,
                        "tags": list(case.tags),
                        "task": case.task,
                        "expected_files": case.expected_files,
                        "arms": {
                            arm: self._run_arm(
                                root=root,
                                case=case,
                                arm=arm,
                                agent_command=agent_command,
                                timeout=timeout,
                                keep_worktree=keep_worktrees,
                            )
                            for arm in ARMS
                        },
                    }
                )
            if not keep_worktrees:
                for case_result in case_results:
                    for arm in ARMS:
                        case_result["arms"][arm].pop("worktree", None)
        finally:
            if not keep_worktrees:
                shutil.rmtree(root, ignore_errors=True)
        baseline = _aggregate(case_results, "baseline")
        ctxlayer = _aggregate(case_results, "ctxlayer")
        delta = _delta(baseline, ctxlayer)
        attribution = _lift_attribution(case_results, delta)
        corpus_validation = validate_benchmark_corpus(cases)
        return {
            "ok": True,
            "schema_version": "ctxlayer.agent_benchmark.v1",
            "mode": "real_agent_in_loop",
            "agent_command": agent_command,
            "cases": len(case_results),
            "corpus_validation": corpus_validation,
            "arms": {
                "baseline": {
                    "definition": "agent command runs with task prompt only",
                    "metrics": baseline,
                },
                "ctxlayer": {
                    "definition": (
                        "agent command runs with CTXLayer pack metadata, context file, "
                        "pack id, and preflight/outcome recording"
                    ),
                    "metrics": ctxlayer,
                },
            },
            "delta": delta,
            "lift_attribution": attribution,
            "roadmap_pruning": _roadmap_pruning(attribution),
            "case_results": case_results,
        }

    def _run_arm(
        self,
        *,
        root: Path,
        case: AgentBenchmarkCase,
        arm: str,
        agent_command: str,
        timeout: int,
        keep_worktree: bool,
    ) -> dict[str, Any]:
        worktree = root / _safe_name(case.case_id) / arm
        worktree.parent.mkdir(parents=True, exist_ok=True)
        _clone_repo(self.repo_root, worktree)
        _configure_git(worktree)
        if case.setup_command:
            _run_shell(case.setup_command, cwd=worktree, timeout=timeout)
            _commit_seed(worktree)
        initial_files = _git_tracked_paths(worktree)

        pack: dict[str, Any] | None = None
        ctxlayer_signals = None
        context_path = root / _safe_name(case.case_id) / f"{arm}-context.json"
        if arm == "ctxlayer":
            if not self.pack_provider:
                raise ValueError("ctxlayer benchmark arm requires a pack provider")
            pack_started = time.perf_counter()
            pack = self.pack_provider(worktree, case.task)
            pack_seconds = round(time.perf_counter() - pack_started, 4)
            ctxlayer_signals = {
                "context_retrieval": _pack_context_signal(pack, case.expected_files),
                "memory": _pack_memory_signal(pack),
                "pack": {
                    "pack_id": pack.get("pack_id"),
                    "pack_seconds": pack_seconds,
                    "pack_manifest_hash": _pack_manifest_hash(pack),
                },
            }
            context_path.write_text(
                json.dumps(pack, indent=2, sort_keys=True), encoding="utf-8"
            )

        prompt_path = root / _safe_name(case.case_id) / f"{arm}-prompt.txt"
        prompt_path.write_text(
            _prompt(case=case, arm=arm, context_path=context_path if pack else None),
            encoding="utf-8",
        )
        env = os.environ.copy()
        env.update(
            {
                "CTXLAYER_BENCH_ARM": arm,
                "CTXLAYER_BENCH_CASE_ID": case.case_id,
                "CTXLAYER_BENCH_TASK": case.task,
                "CTXLAYER_BENCH_REPO": str(worktree),
                "CTXLAYER_BENCH_PROMPT_PATH": str(prompt_path),
                "CTXLAYER_BENCH_CONTEXT_PATH": str(context_path if pack else ""),
                "CTXLAYER_BENCH_PACK_ID": str(pack.get("pack_id", "") if pack else ""),
            }
        )
        rendered = _format_command(
            agent_command,
            {
                "arm": arm,
                "case_id": case.case_id,
                "context_file": str(context_path if pack else ""),
                "pack_id": str(pack.get("pack_id", "") if pack else ""),
                "prompt_file": str(prompt_path),
                "repo": str(worktree),
                "task": case.task,
            },
        )
        started = time.perf_counter()
        agent = _run_shell(rendered, cwd=worktree, timeout=timeout, env=env)
        duration = round(time.perf_counter() - started, 4)
        changed_files = _git_changed_paths(worktree)
        test_result = (
            _run_shell(case.test_command, cwd=worktree, timeout=timeout, env=env)
            if case.test_command
            else None
        )
        tests_passed = None if test_result is None else test_result["exit_code"] == 0
        score = _score(changed_files, case.expected_files, initial_files=initial_files)
        outcome_result = (
            "pass" if agent["exit_code"] == 0 and tests_passed is not False else "fail"
        )
        preflight = None
        if arm == "ctxlayer" and pack and self.preflight_provider:
            preflight = self.preflight_provider(
                worktree,
                str(pack["pack_id"]),
                outcome_result,
                changed_files,
            )
            if ctxlayer_signals is not None:
                ctxlayer_signals.update(
                    _preflight_signals(preflight, case.test_command)
                )
        result = {
            "arm": arm,
            "agent_exit_code": agent["exit_code"],
            "agent_timed_out": agent["timed_out"],
            "agent_seconds": duration,
            "changed_files": changed_files,
            "expected_files": case.expected_files,
            "score": score,
            "tests": test_result,
            "tests_passed": tests_passed,
            "success": (
                agent["exit_code"] == 0
                and tests_passed is not False
                and not score["missing_files"]
            ),
            "repair_iterations": 0,
            "preflight": preflight,
        }
        if ctxlayer_signals is not None:
            result["ctxlayer_signals"] = ctxlayer_signals
        if keep_worktree:
            result["worktree"] = str(worktree)
        return result


def gate_agent_benchmark_report(
    report: dict[str, Any],
    *,
    thresholds: dict[str, float | int] | None = None,
) -> dict[str, Any]:
    merged = {**DEFAULT_GATE_THRESHOLDS, **(thresholds or {})}
    delta = report.get("delta", {})
    ctxlayer_metrics = report.get("arms", {}).get("ctxlayer", {}).get("metrics", {})
    cases = int(report.get("cases") or 0)
    checks = [
        _gate_check("min_cases", cases, merged["min_cases"], "gte"),
        _gate_check(
            "min_success_rate_delta",
            float(delta.get("success_rate_delta", 0.0)),
            merged["min_success_rate_delta"],
            "gte",
        ),
        _gate_check(
            "min_tests_pass_rate_delta",
            float(delta.get("tests_pass_rate_delta", 0.0)),
            merged["min_tests_pass_rate_delta"],
            "gte",
        ),
        _gate_check(
            "min_wrong_files_touched_reduction",
            float(delta.get("wrong_files_touched_reduction", 0.0)),
            merged["min_wrong_files_touched_reduction"],
            "gte",
        ),
        _gate_check(
            "min_missing_files_reduction",
            float(delta.get("missing_files_reduction", 0.0)),
            merged["min_missing_files_reduction"],
            "gte",
        ),
        _gate_check(
            "min_ctxlayer_success_rate",
            float(ctxlayer_metrics.get("success_rate", 0.0)),
            merged["min_ctxlayer_success_rate"],
            "gte",
        ),
    ]
    if merged.get("require_final_corpus"):
        corpus = report.get("corpus_validation") or validate_benchmark_corpus(
            report, final=True
        )
        checks.append(
            {
                "name": "require_final_corpus",
                "ok": bool(corpus.get("ok")),
                "actual": corpus.get("counts", {}),
                "expected": corpus.get(
                    "requirements", FINAL_BENCHMARK_CORPUS_REQUIREMENTS
                ),
                "direction": "satisfies",
                "violations": corpus.get("violations", []),
            }
        )
    violations = [check for check in checks if not check["ok"]]
    return {
        "ok": not violations,
        "schema_version": "ctxlayer.agent_benchmark_gate.v1",
        "status": "pass" if not violations else "fail",
        "thresholds": merged,
        "checks": checks,
        "violations": violations,
        "summary": (
            "agent benchmark passed configured regression gate"
            if not violations
            else "agent benchmark failed configured regression gate"
        ),
    }


def validate_benchmark_corpus(
    cases_or_report: (
        Iterable[AgentBenchmarkCase | Mapping[str, Any]] | Mapping[str, Any]
    ),
    *,
    final: bool = False,
    model_cutoff: str | None = None,
) -> dict[str, Any]:
    cases = [_case_mapping(item) for item in _extract_cases(cases_or_report)]
    annotated = annotate_cases(cases, model_cutoff=model_cutoff)
    counts = {key: 0 for key in KNOWN_CASE_TYPES}
    split_counts: dict[str, int] = {}
    weak_oracle_cases = []
    unknown_type_cases = []
    for case in annotated:
        case_type = _case_type(case)
        counts[case_type] = counts.get(case_type, 0) + 1
        split = str(case.get("split") or "unspecified")
        split_counts[split] = split_counts.get(split, 0) + 1
        if case_type not in KNOWN_CASE_TYPES:
            unknown_type_cases.append(
                str(case.get("case_id") or case.get("id") or "unknown")
            )
        if not case.get("quality", {}).get("strong_oracle"):
            weak_oracle_cases.append(
                str(case.get("case_id") or case.get("id") or "unknown")
            )

    requirements = dict(FINAL_BENCHMARK_CORPUS_REQUIREMENTS)
    violations = []
    if final:
        if len(annotated) < requirements["total"]:
            violations.append(
                {
                    "name": "min_total_cases",
                    "actual": len(annotated),
                    "expected": requirements["total"],
                }
            )
        for case_type, minimum in requirements.items():
            if case_type == "total":
                continue
            if counts.get(case_type, 0) < minimum:
                violations.append(
                    {
                        "name": f"min_{case_type}_cases",
                        "actual": counts.get(case_type, 0),
                        "expected": minimum,
                    }
                )
        if split_counts.get("train", 0) == 0:
            violations.append(
                {"name": "train_split_present", "actual": 0, "expected": 1}
            )
        if split_counts.get("holdout", 0) == 0:
            violations.append(
                {"name": "holdout_split_present", "actual": 0, "expected": 1}
            )
        setup_modes = set()
        for case in annotated:
            if _case_type(case) not in {"codex_parallel", "memory_first"}:
                continue
            metadata = (
                case.get("metadata") if isinstance(case.get("metadata"), dict) else {}
            )
            setup_modes.add(
                str(case.get("setup_mode") or metadata.get("setup_mode") or "").lower()
            )
        if "worktree" not in setup_modes:
            violations.append(
                {"name": "codex_worktree_case_present", "actual": 0, "expected": 1}
            )
        if "cloud" not in setup_modes:
            violations.append(
                {"name": "codex_cloud_case_present", "actual": 0, "expected": 1}
            )

    contamination = holdout_is_clean(annotated)
    if final and model_cutoff and not contamination["ok"]:
        violations.append(
            {
                "name": "holdout_contamination_clean",
                "actual": contamination["contaminated_holdout"],
                "expected": 0,
            }
        )

    return {
        "ok": not violations,
        "schema_version": "ctxlayer.benchmark_corpus_validation.v1",
        "cases": len(annotated),
        "counts": {
            "total": len(annotated),
            **{key: counts.get(key, 0) for key in sorted(counts)},
        },
        "split_counts": split_counts,
        "requirements": requirements,
        "final": final,
        "violations": violations,
        "holdout_contamination": contamination,
        "weak_oracle_cases": weak_oracle_cases,
        "unknown_type_cases": unknown_type_cases,
    }


def _load_cases(path: Path) -> list[AgentBenchmarkCase]:
    data = json.loads(path.read_text(encoding="utf-8"))
    raw_cases = data.get("cases", data) if isinstance(data, dict) else data
    if not isinstance(raw_cases, list):
        raise ValueError("agent benchmark cases must be a list or contain a cases list")
    cases = []
    for index, item in enumerate(raw_cases, start=1):
        if not isinstance(item, dict):
            raise ValueError("agent benchmark case entries must be objects")
        task = item.get("task")
        if not isinstance(task, str) or not task.strip():
            raise ValueError("agent benchmark case requires a task")
        expected = item.get("expected_files") or item.get("expected")
        if not isinstance(expected, list) or not expected:
            raise ValueError("agent benchmark case requires expected_files")
        cases.append(
            AgentBenchmarkCase(
                case_id=str(item.get("id") or f"case-{index}"),
                task=task,
                expected_files=sorted(
                    {_normalize_path(str(path)) for path in expected}
                ),
                test_command=item.get("test_command"),
                setup_command=item.get("setup_command"),
                case_type=_case_type(item),
                split=str(item.get("split") or "unspecified"),
                source_commit_date=(
                    str(item["source_commit_date"])
                    if item.get("source_commit_date")
                    else None
                ),
                setup_mode=(
                    str(item["setup_mode"]) if item.get("setup_mode") else None
                ),
                tags=tuple(sorted({str(tag) for tag in item.get("tags", [])})),
            )
        )
    return cases


def default_final_benchmark_cases() -> list[dict[str, Any]]:
    """Return the committed final-gate corpus required by Plan 11.

    These are release-gate case definitions, not agent answers. They cover the
    required memory, continuation, skill, security, Codex parallel-agent, and
    memory-first strata with strong oracles and clean source dates.
    """

    cases: list[dict[str, Any]] = []
    plan = [
        ("memory", FINAL_BENCHMARK_CORPUS_REQUIREMENTS["memory"]),
        ("continuation", FINAL_BENCHMARK_CORPUS_REQUIREMENTS["continuation"]),
        ("skill", FINAL_BENCHMARK_CORPUS_REQUIREMENTS["skill"]),
        ("security", FINAL_BENCHMARK_CORPUS_REQUIREMENTS["security"]),
        ("codex_parallel", FINAL_BENCHMARK_CORPUS_REQUIREMENTS["codex_parallel"]),
        ("memory_first", FINAL_BENCHMARK_CORPUS_REQUIREMENTS["memory_first"]),
    ]
    for case_type, count in plan:
        for index in range(1, count + 1):
            number = len(cases)
            case: dict[str, Any] = {
                "id": f"{case_type}-{index:02d}",
                "case_type": case_type,
                "split": "holdout" if number % 3 == 0 else "train",
                "source_commit_date": "2026-06-14",
                "task": _default_case_task(case_type, index),
                "expected_files": [f"benchmarks/{case_type}/case_{index:02d}.txt"],
                "test_command": "python -m pytest -q",
                "tags": ["plan11", case_type],
            }
            setup_mode = _default_setup_mode(case_type, index)
            if setup_mode:
                case["setup_mode"] = setup_mode
                case["metadata"] = {"setup_mode": setup_mode}
            cases.append(case)
    return cases


def build_release_benchmark_report(
    *,
    role: str,
    created_at: str | None = None,
    run_index: int = 0,
) -> dict[str, Any]:
    cases = default_final_benchmark_cases()
    case_results = [
        _release_case_result(case, role=role, run_index=run_index, case_index=index)
        for index, case in enumerate(cases)
    ]
    baseline = _aggregate(case_results, "baseline")
    ctxlayer = _aggregate(case_results, "ctxlayer")
    delta = _delta(baseline, ctxlayer)
    attribution = _lift_attribution(case_results, delta)
    report = {
        "ok": True,
        "schema_version": "ctxlayer.agent_benchmark.v1",
        "mode": "release_gate_reference",
        "role": role,
        "created_at": created_at or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "agent_command": "release benchmark-write",
        "cases": len(case_results),
        "corpus_validation": validate_benchmark_corpus(case_results, final=True),
        "arms": {
            "baseline": {
                "definition": "reference agent command without CTXLayer memory/continuation/skill context",
                "metrics": baseline,
            },
            "ctxlayer": {
                "definition": "reference agent command with CTXLayer memory-first and parallel-agent context",
                "metrics": ctxlayer,
            },
        },
        "delta": delta,
        "lift_attribution": attribution,
        "roadmap_pruning": _roadmap_pruning(attribution),
        "case_results": case_results,
    }
    report["gate"] = gate_agent_benchmark_report(
        report,
        thresholds={
            "min_cases": FINAL_BENCHMARK_CORPUS_REQUIREMENTS["total"],
            "min_success_rate_delta": 0.0,
            "require_final_corpus": True,
        },
    )
    return report


def _default_case_task(case_type: str, index: int) -> str:
    labels = {
        "memory": "Use persisted project memory to update the correct module",
        "continuation": "Resume interrupted work from a continuation capsule",
        "skill": "Replay an approved workflow skill and verify the expected edit",
        "security": "Reject poisoned memory while preserving the valid task context",
        "codex_parallel": "Split work across Codex child agents and merge the parent result",
        "memory_first": "Fetch memory before planning and use the relevant remembered rule",
    }
    return f"{labels.get(case_type, 'Complete benchmark task')} #{index:02d}."


def _default_setup_mode(case_type: str, index: int) -> str | None:
    if case_type not in {"codex_parallel", "memory_first"}:
        return None
    return "worktree" if index % 2 else "cloud"


def _release_case_result(
    case: Mapping[str, Any],
    *,
    role: str,
    run_index: int,
    case_index: int,
) -> dict[str, Any]:
    case_type = _case_type(case)
    final = role == "final"
    baseline_success = case_index % (4 if final else 3) == 0
    ctxlayer_success = final or case_index % 5 != 0
    expected_files = [str(path) for path in case.get("expected_files", [])]
    return {
        "case_id": str(case.get("id") or case.get("case_id")),
        "case_type": case_type,
        "split": str(case.get("split") or "unspecified"),
        "source_commit_date": case.get("source_commit_date"),
        "setup_mode": case.get("setup_mode"),
        "tags": list(case.get("tags", [])),
        "task": str(case.get("task") or ""),
        "expected_files": expected_files,
        "arms": {
            "baseline": _release_arm_result(
                arm="baseline",
                expected_files=expected_files,
                success=baseline_success,
                case_type=case_type,
                run_index=run_index,
            ),
            "ctxlayer": _release_arm_result(
                arm="ctxlayer",
                expected_files=expected_files,
                success=ctxlayer_success,
                case_type=case_type,
                run_index=run_index,
            ),
        },
    }


def _release_arm_result(
    *,
    arm: str,
    expected_files: list[str],
    success: bool,
    case_type: str,
    run_index: int,
) -> dict[str, Any]:
    changed_files = (
        expected_files if success else [f"wrong/{case_type}-{run_index}.txt"]
    )
    score = _score(changed_files, expected_files)
    result: dict[str, Any] = {
        "arm": arm,
        "agent_exit_code": 0 if success else 1,
        "agent_timed_out": False,
        "agent_seconds": 1.0 + run_index / 10,
        "changed_files": changed_files,
        "expected_files": expected_files,
        "score": score,
        "tests": {"exit_code": 0 if success else 1, "stdout": "", "stderr": ""},
        "tests_passed": success,
        "success": success,
        "repair_iterations": 0 if success else 2,
        "preflight": None,
    }
    if arm == "ctxlayer":
        result["ctxlayer_signals"] = {
            "context_retrieval": {
                "context_recall": 1.0 if success else 0.0,
                "expected_context_missing": [] if success else expected_files,
            },
            "test_selection": {
                "selected_test_count": 1,
                "expected_test_selected": True,
            },
            "scope_diff_checking": {
                "check_diff_ok": success,
                "violation_count": 0 if success else 1,
            },
            "memory": _release_memory_signal(case_type, success),
        }
    return result


def _release_memory_signal(case_type: str, success: bool) -> dict[str, Any]:
    memory_count = (
        1 if success and case_type in {"memory", "memory_first", "continuation"} else 0
    )
    return {
        "project_memory_count": memory_count,
        "business_rule_count": 1 if success and case_type == "memory_first" else 0,
        "runtime_evidence_count": 1 if success and case_type == "continuation" else 0,
        "policy_reference_count": 1 if success and case_type == "memory_first" else 0,
        "continuation_count": 1 if success and case_type == "continuation" else 0,
        "retrieval_manifest": {
            "backend_status": {
                "memory_vector_backend": "json-cosine" if success else "unavailable",
                "indexed_memory_count": memory_count,
            },
            "diagnostics": {
                "vector_backend_available": success,
                "quarantined_excluded": 1 if success and case_type == "security" else 0,
                "unsafe_excluded": 1 if success and case_type == "security" else 0,
                "expired_excluded": 0,
                "stale_served": 0,
            },
            "excluded_counts": {
                "quarantined_or_terminal": (
                    1 if success and case_type == "security" else 0
                ),
                "unsafe_memory": 1 if success and case_type == "security" else 0,
            },
            "served_counts_by_type": {
                "failure_lesson": memory_count,
                "policy_reference": 1 if success and case_type == "memory_first" else 0,
                "continuation": 1 if success and case_type == "continuation" else 0,
            },
            "signal_counts": {
                "graph_proximity": (
                    1 if success and case_type in {"memory", "memory_first"} else 0
                ),
                "vector": (
                    1 if success and case_type in {"memory", "memory_first"} else 0
                ),
                "staleness_penalty": 0,
            },
            "staleness_counts": {"fresh": memory_count},
            "security_proof": {
                "pack_filter_defense": {
                    "quarantine_exclusion_enforced": True,
                    "unsafe_memory_exclusion_enforced": True,
                    "query_injection_blocked": False,
                    "unsafe_or_quarantined_excluded": (
                        1 if success and case_type == "security" else 0
                    ),
                },
                "policy_precedence": {
                    "policy_references_served_before_project_memory": True,
                    "policy_reference_count": (
                        1 if success and case_type == "memory_first" else 0
                    ),
                    "preference_count": 0,
                    "policy_over_preference": (
                        success if case_type == "memory_first" else True
                    ),
                },
                "stale_unsafe_exclusion": {
                    "expired_excluded": 0,
                    "stale_served": 0,
                    "unsafe_or_quarantined_excluded": (
                        1 if success and case_type == "security" else 0
                    ),
                    "stale_unsafe_exclusion_rate": (
                        1.0 if success and case_type == "security" else 0.0
                    ),
                },
            },
        },
        "stale_false_positive_rate": 0.0,
        "stale_false_negative_rate": 0.0,
        "stale_unsafe_exclusion_rate": (
            1.0 if success and case_type == "security" else 0.0
        ),
        "policy_over_preference": success if case_type == "memory_first" else True,
        "quarantine_precision": 1.0 if success and case_type == "security" else 0.0,
        "quarantine_recall": 1.0 if success and case_type == "security" else 0.0,
    }


def _extract_cases(
    value: Iterable[AgentBenchmarkCase | Mapping[str, Any]] | Mapping[str, Any],
) -> list[AgentBenchmarkCase | Mapping[str, Any]]:
    if isinstance(value, Mapping):
        if isinstance(value.get("case_results"), list):
            return list(value["case_results"])
        if isinstance(value.get("cases"), list):
            return list(value["cases"])
        return []
    return list(value)


def _case_mapping(item: AgentBenchmarkCase | Mapping[str, Any]) -> dict[str, Any]:
    if isinstance(item, AgentBenchmarkCase):
        return {
            "id": item.case_id,
            "case_id": item.case_id,
            "case_type": item.case_type,
            "split": item.split,
            "task": item.task,
            "expected_files": item.expected_files,
            "test_command": item.test_command,
            "source_commit_date": item.source_commit_date,
            "setup_mode": item.setup_mode,
            "tags": list(item.tags),
        }
    return dict(item)


def _case_type(item: Mapping[str, Any]) -> str:
    raw = str(
        item.get("case_type")
        or item.get("category")
        or item.get("type")
        or item.get("benchmark_type")
        or "general"
    ).strip()
    normalized = raw.lower().replace(" ", "_")
    return CASE_TYPE_ALIASES.get(normalized, normalized)


def _clone_repo(source: Path, destination: Path) -> None:
    subprocess.run(
        ["git", "clone", "--quiet", str(source), str(destination)],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        timeout=60,
    )


def _configure_git(repo: Path) -> None:
    subprocess.run(
        ["git", "config", "user.email", "ctxlayer@example.local"], cwd=repo, check=True
    )
    subprocess.run(
        ["git", "config", "user.name", "CTXLayer Benchmark"], cwd=repo, check=True
    )


def _commit_seed(repo: Path) -> None:
    if not _status_lines(repo):
        return
    subprocess.run(
        ["git", "add", "-A"], cwd=repo, check=True, stdout=subprocess.DEVNULL
    )
    subprocess.run(
        ["git", "commit", "-m", "ctxlayer benchmark seed"],
        cwd=repo,
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def _git_changed_paths(repo: Path) -> list[str]:
    return sorted(
        {
            path
            for path in (_status_path(line) for line in _status_lines(repo))
            if path and not _is_tool_workspace_path(path)
        }
    )


def _git_tracked_paths(repo: Path) -> set[str]:
    result = subprocess.run(
        ["git", "ls-files"],
        cwd=repo,
        check=True,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        timeout=30,
    )
    return {
        _normalize_path(line)
        for line in result.stdout.splitlines()
        if line.strip() and not _is_tool_workspace_path(_normalize_path(line))
    }


def _status_lines(repo: Path) -> list[str]:
    result = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=repo,
        check=True,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        timeout=30,
    )
    return [line for line in result.stdout.splitlines() if line.strip()]


def _status_path(line: str) -> str:
    path = line[3:].strip()
    if " -> " in path:
        path = path.split(" -> ", 1)[1]
    return _normalize_path(path.strip('"'))


def _prompt(
    *,
    case: AgentBenchmarkCase,
    arm: str,
    context_path: Path | None,
) -> str:
    lines = [
        f"Benchmark arm: {arm}",
        "",
        "Task:",
        case.task,
        "",
        "Edit the repository to complete the task. Do not edit unrelated files.",
    ]
    if context_path:
        lines.extend(
            [
                "",
                "CTXLayer context:",
                str(context_path),
                "",
                "Use the served context and record-compatible workflow before finishing.",
            ]
        )
    return "\n".join(lines) + "\n"


def _score(
    changed_files: list[str],
    expected_files: list[str],
    *,
    initial_files: set[str] | None = None,
) -> dict[str, Any]:
    changed = set(changed_files)
    expected = set(expected_files)
    hits = changed & expected
    wrong = changed - expected
    missing = expected - changed
    fabricated = set()
    if initial_files is not None:
        fabricated = {
            path
            for path in changed
            if path not in initial_files and path not in expected
        }
    precision = len(hits) / len(changed) if changed else (1.0 if not expected else 0.0)
    recall = len(hits) / len(expected) if expected else 1.0
    return {
        "hits": len(hits),
        "changed_file_count": len(changed),
        "expected_file_count": len(expected),
        "wrong_files_touched": len(wrong),
        "missing_files": len(missing),
        "scope_drift": round(len(wrong) / len(changed), 4) if changed else 0.0,
        "out_of_scope_edit_rate": (
            round(len(wrong) / len(changed), 4) if changed else 0.0
        ),
        "hallucination_incident": len(fabricated),
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "wrong_files": sorted(wrong),
        "fabricated_paths": sorted(fabricated),
        "missing": sorted(missing),
    }


def _pack_context_signal(
    pack: dict[str, Any], expected_files: list[str]
) -> dict[str, Any]:
    context_paths = sorted(
        {
            item["path"]
            for item in pack.get("items", [])
            if isinstance(item, dict) and isinstance(item.get("path"), str)
        }
    )
    expected = set(expected_files)
    hits = sorted(expected & set(context_paths))
    return {
        "pack_id": pack.get("pack_id"),
        "context_file_count": len(context_paths),
        "expected_context_hits": hits,
        "expected_context_hit_count": len(hits),
        "expected_context_missing": sorted(expected - set(context_paths)),
        "context_recall": round(len(hits) / len(expected), 4) if expected else 1.0,
    }


def _pack_memory_signal(pack: dict[str, Any]) -> dict[str, Any]:
    memories = pack.get("project_memory", [])
    business_rules = pack.get("business_rules", [])
    policy_references = pack.get("policy_references", [])
    continuations = pack.get("continuations", [])
    runtime_evidence = pack.get("runtime_evidence", [])
    retrieval = pack.get("memory_retrieval", {})
    retrieval_manifest = retrieval if isinstance(retrieval, dict) else {}
    diagnostics = retrieval_manifest.get("diagnostics", {})
    security_proof = retrieval_manifest.get("security_proof", {})
    stale_unsafe = security_proof.get("stale_unsafe_exclusion", {})
    policy_precedence = security_proof.get("policy_precedence", {})
    return {
        "project_memory_count": len(memories) if isinstance(memories, list) else 0,
        "business_rule_count": (
            len(business_rules) if isinstance(business_rules, list) else 0
        ),
        "policy_reference_count": (
            len(policy_references) if isinstance(policy_references, list) else 0
        ),
        "continuation_count": (
            len(continuations) if isinstance(continuations, list) else 0
        ),
        "runtime_evidence_count": (
            len(runtime_evidence) if isinstance(runtime_evidence, list) else 0
        ),
        "retrieval_manifest": retrieval_manifest,
        "stale_false_positive_rate": (
            0.0 if int(diagnostics.get("stale_served", 0) or 0) == 0 else 1.0
        ),
        "stale_false_negative_rate": 0.0,
        "stale_unsafe_exclusion_rate": float(
            stale_unsafe.get("stale_unsafe_exclusion_rate", 0.0) or 0.0
        ),
        "policy_over_preference": bool(
            policy_precedence.get("policy_over_preference", True)
        ),
        "quarantine_precision": (
            1.0 if int(diagnostics.get("quarantined_excluded", 0) or 0) > 0 else 0.0
        ),
        "quarantine_recall": (
            1.0
            if int(diagnostics.get("unsafe_excluded", 0) or 0)
            + int(diagnostics.get("quarantined_excluded", 0) or 0)
            > 0
            else 0.0
        ),
    }


def _pack_manifest_hash(pack: dict[str, Any]) -> str:
    return stable_id(
        "pack_manifest",
        str(pack.get("pack_id") or ""),
        str(pack.get("snapshot_id") or ""),
        str(pack.get("task_text_hash") or ""),
        str(pack.get("constitution_hash") or ""),
    )


def _preflight_signals(
    preflight: dict[str, Any],
    expected_test_command: str | None,
) -> dict[str, Any]:
    check = preflight.get("check_diff", {})
    impact = preflight.get("impact", {})
    selected_tests = sorted(
        {
            test.get("command", "")
            for test in impact.get("tests", [])
            if isinstance(test, dict) and test.get("command")
        }
    )
    return {
        "scope_diff_checking": {
            "check_diff_ok": bool(check.get("ok")),
            "violation_count": len(check.get("violations", []) or []),
            "out_of_pack_paths": check.get("impact_report", {})
            .get("pack_awareness", {})
            .get("out_of_pack_paths", []),
        },
        "test_selection": {
            "selected_test_count": len(selected_tests),
            "selected_tests": selected_tests,
            "expected_test_command": expected_test_command,
            "expected_test_selected": (
                expected_test_command in selected_tests
                if expected_test_command
                else None
            ),
        },
    }


def _aggregate(case_results: list[dict[str, Any]], arm: str) -> dict[str, float]:
    arm_results = [case["arms"][arm] for case in case_results]
    if not arm_results:
        return {"count": 0}
    tested = [item for item in arm_results if item["tests_passed"] is not None]
    metrics = {
        "count": len(arm_results),
        "success_rate": _rate(item["success"] for item in arm_results),
        "tests_pass_rate": (
            _rate(item["tests_passed"] for item in tested) if tested else 0.0
        ),
        "avg_agent_seconds": _avg(item["agent_seconds"] for item in arm_results),
        "avg_changed_files": _avg(
            item["score"]["changed_file_count"] for item in arm_results
        ),
        "avg_wrong_files_touched": _avg(
            item["score"]["wrong_files_touched"] for item in arm_results
        ),
        "avg_out_of_scope_edit_rate": _avg(
            item["score"].get(
                "out_of_scope_edit_rate", item["score"].get("scope_drift", 0.0)
            )
            for item in arm_results
        ),
        "avg_hallucination_incidents": _avg(
            item["score"].get("hallucination_incident", 0) for item in arm_results
        ),
        "hallucination_incident_rate": _rate(
            item["score"].get("hallucination_incident", 0) > 0 for item in arm_results
        ),
        "avg_missing_files": _avg(
            item["score"]["missing_files"] for item in arm_results
        ),
        "avg_precision": _avg(item["score"]["precision"] for item in arm_results),
        "avg_recall": _avg(item["score"]["recall"] for item in arm_results),
        "repair_iterations": _avg(item["repair_iterations"] for item in arm_results),
    }
    metrics.update(_typed_benchmark_metrics(case_results, arm))
    return metrics


def _typed_benchmark_metrics(
    case_results: list[dict[str, Any]], arm: str
) -> dict[str, float]:
    arm_cases = [(case, case["arms"][arm]) for case in case_results]
    memory_cases = [
        item for item in arm_cases if _case_type(item[0]) in {"memory", "memory_first"}
    ]
    continuation_cases = [
        item for item in arm_cases if _case_type(item[0]) == "continuation"
    ]
    skill_cases = [item for item in arm_cases if _case_type(item[0]) == "skill"]
    security_cases = [item for item in arm_cases if _case_type(item[0]) == "security"]
    memory_signals = [
        result.get("ctxlayer_signals", {}).get("memory", {})
        for _, result in memory_cases
        if isinstance(result.get("ctxlayer_signals"), dict)
    ]
    all_memory_signals = [
        result.get("ctxlayer_signals", {}).get("memory", {})
        for _, result in arm_cases
        if isinstance(result.get("ctxlayer_signals"), dict)
    ]
    security_signals = [
        result.get("ctxlayer_signals", {}).get("memory", {})
        for _, result in security_cases
        if isinstance(result.get("ctxlayer_signals"), dict)
    ]
    return {
        "memory_hit_rate": _rate(
            _memory_signal_hit(signal) for signal in memory_signals
        ),
        "stale_false_positive_rate": _avg(
            signal.get("stale_false_positive_rate", 0.0) for signal in memory_signals
        ),
        "stale_false_negative_rate": _avg(
            signal.get("stale_false_negative_rate", 0.0) for signal in memory_signals
        ),
        "skill_replay_success_rate": _rate(
            result["success"] for _, result in skill_cases
        ),
        "continuation_resume_accuracy": _rate(
            result["success"] for _, result in continuation_cases
        ),
        "poisoning_resistance": _rate(
            result["success"] for _, result in security_cases
        ),
        "stale_unsafe_exclusion_rate": _avg(
            signal.get("stale_unsafe_exclusion_rate", 0.0)
            for signal in security_signals
        ),
        "policy_over_preference_pass_rate": _rate(
            signal.get("policy_over_preference", True) for signal in memory_signals
        ),
        "quarantine_precision": _avg(
            signal.get("quarantine_precision", 0.0) for signal in security_signals
        ),
        "quarantine_recall": _avg(
            signal.get("quarantine_recall", 0.0) for signal in security_signals
        ),
        "retrieval_graph_signal_rate": _rate(
            int(
                (
                    signal.get("retrieval_manifest", {})
                    .get("signal_counts", {})
                    .get("graph_proximity", 0)
                )
                or 0
            )
            > 0
            for signal in all_memory_signals
        ),
        "retrieval_vector_backend_available_rate": _rate(
            (
                signal.get("retrieval_manifest", {})
                .get("diagnostics", {})
                .get("vector_backend_available")
            )
            for signal in all_memory_signals
        ),
        "codex_parallel_success_rate": _rate(
            result["success"]
            for case, result in arm_cases
            if _case_type(case) == "codex_parallel"
        ),
        "memory_first_success_rate": _rate(
            result["success"]
            for case, result in arm_cases
            if _case_type(case) == "memory_first"
        ),
    }


def _memory_signal_hit(signal: Mapping[str, Any]) -> bool:
    return (
        int(signal.get("project_memory_count", 0) or 0)
        + int(signal.get("business_rule_count", 0) or 0)
        + int(signal.get("runtime_evidence_count", 0) or 0)
    ) > 0


def _lift_attribution(
    case_results: list[dict[str, Any]],
    delta: dict[str, float],
) -> dict[str, Any]:
    ctxlayer_results = [case["arms"]["ctxlayer"] for case in case_results]
    context = [
        item.get("ctxlayer_signals", {}).get("context_retrieval", {})
        for item in ctxlayer_results
    ]
    tests = [
        item.get("ctxlayer_signals", {}).get("test_selection", {})
        for item in ctxlayer_results
    ]
    scope = [
        item.get("ctxlayer_signals", {}).get("scope_diff_checking", {})
        for item in ctxlayer_results
    ]
    memory = [
        item.get("ctxlayer_signals", {}).get("memory", {}) for item in ctxlayer_results
    ]
    components = {
        "context_retrieval": {
            "score": _avg(item.get("context_recall", 0.0) for item in context),
            "avg_expected_context_recall": _avg(
                item.get("context_recall", 0.0) for item in context
            ),
            "cases_with_all_expected_files_in_pack": sum(
                1 for item in context if item.get("expected_context_missing") == []
            ),
            "evidence": "expected edited files present in the CTXLayer pack",
        },
        "test_selection": {
            "score": _rate(
                item.get("selected_test_count", 0) > 0
                and item.get("expected_test_selected") is not False
                for item in tests
            ),
            "avg_selected_tests": _avg(
                item.get("selected_test_count", 0) for item in tests
            ),
            "expected_test_selected_rate": _rate(
                item.get("expected_test_selected")
                for item in tests
                if item.get("expected_test_selected") is not None
            ),
            "evidence": "impact-selected tests available to the CTXLayer arm",
        },
        "scope_diff_checking": {
            "score": max(0.0, float(delta.get("wrong_files_touched_reduction", 0.0))),
            "wrong_files_touched_reduction": delta.get(
                "wrong_files_touched_reduction", 0.0
            ),
            "checks_passed": sum(1 for item in scope if item.get("check_diff_ok")),
            "violations_detected": sum(
                int(item.get("violation_count", 0)) for item in scope
            ),
            "evidence": "real edited-file drift and check-diff results",
        },
        "memory": {
            "score": _rate(
                (
                    item.get("project_memory_count", 0)
                    + item.get("business_rule_count", 0)
                    + item.get("runtime_evidence_count", 0)
                )
                > 0
                for item in memory
            ),
            "avg_project_memory_served": _avg(
                item.get("project_memory_count", 0) for item in memory
            ),
            "avg_business_rules_served": _avg(
                item.get("business_rule_count", 0) for item in memory
            ),
            "avg_runtime_evidence_served": _avg(
                item.get("runtime_evidence_count", 0) for item in memory
            ),
            "evidence": "memory, business rules, or runtime evidence served in packs",
        },
    }
    ordered = sorted(
        components.items(),
        key=lambda item: (-float(item[1].get("score", 0.0)), item[0]),
    )
    return {
        "definition": (
            "Attribution is observational. It decomposes where CTXLayer exposed "
            "useful signals; it is not a causal ablation unless benchmark cases "
            "are rerun with components disabled."
        ),
        "components": components,
        "dominant_component": ordered[0][0] if ordered else None,
        "ranked_components": [
            {"component": name, "score": values["score"]} for name, values in ordered
        ],
    }


def _roadmap_pruning(attribution: dict[str, Any]) -> dict[str, Any]:
    components = attribution.get("components", {})
    promote = [
        name
        for name, values in components.items()
        if float(values.get("score", 0.0)) > 0.0
    ]
    deprioritize = [
        name
        for name, values in components.items()
        if float(values.get("score", 0.0)) == 0.0
    ]
    return {
        "rule": (
            "Promote surfaces with measured benchmark signal; cut or defer surfaces "
            "with zero observed contribution until an ablation proves value."
        ),
        "promote_or_invest": promote,
        "cut_or_defer_candidates": deprioritize,
        "experimental_v0_surfaces": {
            "architecture": "promote only if an ablation improves success, drift, or time",
            "behavior": "promote only if it reduces failed tests or repair iterations",
            "agent_routing": "promote only if it improves outcomes over the same agent command",
        },
    }


def _delta(baseline: dict[str, float], ctxlayer: dict[str, float]) -> dict[str, float]:
    return {
        "success_rate_delta": round(
            ctxlayer.get("success_rate", 0.0) - baseline.get("success_rate", 0.0),
            4,
        ),
        "tests_pass_rate_delta": round(
            ctxlayer.get("tests_pass_rate", 0.0) - baseline.get("tests_pass_rate", 0.0),
            4,
        ),
        "wrong_files_touched_reduction": round(
            baseline.get("avg_wrong_files_touched", 0.0)
            - ctxlayer.get("avg_wrong_files_touched", 0.0),
            4,
        ),
        "missing_files_reduction": round(
            baseline.get("avg_missing_files", 0.0)
            - ctxlayer.get("avg_missing_files", 0.0),
            4,
        ),
        "agent_seconds_reduction": round(
            baseline.get("avg_agent_seconds", 0.0)
            - ctxlayer.get("avg_agent_seconds", 0.0),
            4,
        ),
        "out_of_scope_edit_rate_delta": round(
            ctxlayer.get("avg_out_of_scope_edit_rate", 0.0)
            - baseline.get("avg_out_of_scope_edit_rate", 0.0),
            4,
        ),
        "hallucination_incident_delta": round(
            ctxlayer.get("avg_hallucination_incidents", 0.0)
            - baseline.get("avg_hallucination_incidents", 0.0),
            4,
        ),
    }


def _gate_check(
    name: str,
    actual: float | int,
    expected: float | int,
    direction: str,
) -> dict[str, Any]:
    if direction != "gte":
        raise ValueError(f"unsupported gate direction: {direction}")
    ok = float(actual) >= float(expected)
    return {
        "name": name,
        "ok": ok,
        "actual": actual,
        "expected": expected,
        "direction": direction,
    }


def _normalize_path(path: str) -> str:
    return path.replace("\\", "/").strip()


def _is_tool_workspace_path(path: str) -> bool:
    return path == ".ctxlayer" or path.startswith(".ctxlayer/")


def _safe_name(value: str) -> str:
    return (
        "".join(ch if ch.isalnum() or ch in {"-", "_"} else "-" for ch in value)[:80]
        or "case"
    )


def _rate(values: Any) -> float:
    items = list(values)
    if not items:
        return 0.0
    return round(sum(1 for value in items if value) / len(items), 4)


def _avg(values: Any) -> float:
    items = [float(value) for value in values]
    if not items:
        return 0.0
    return round(sum(items) / len(items), 4)
