from __future__ import annotations

from typing import Any

from ctxlayer.service import CtxLayerService


def run_mcp(service: CtxLayerService) -> None:
    try:
        from mcp.server.fastmcp import FastMCP
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(
            "FastMCP is not installed. Install ctxlayer[mcp] to use MCP mode."
        ) from exc

    mcp = FastMCP("ctxlayer")

    @mcp.tool()
    def resolve_snapshot(branch: str | None = None) -> dict[str, Any]:
        _ = branch
        return service.resolve_snapshot()

    @mcp.tool()
    def snapshot_current() -> dict[str, Any]:
        return service.snapshot_current()

    @mcp.tool()
    def snapshot_lineage(
        snapshot_id: str | None = None, limit: int = 50
    ) -> dict[str, Any]:
        return service.snapshot_lineage(snapshot_id, limit)

    @mcp.tool()
    def get_context_pack(
        task: str | None = None,
        budget: int | None = None,
        seed_paths: list[str] | None = None,
        intent_id: str | None = None,
        goal_id: str | None = None,
        bind_snapshot: str | None = None,
    ) -> dict[str, Any]:
        return service.get_context_pack(
            task,
            budget,
            seed_paths,
            intent_id=intent_id,
            goal_id=goal_id,
            bind_snapshot=bind_snapshot,
        )

    @mcp.tool()
    def intent_start(problem: str, llm_propose: bool = False) -> dict[str, Any]:
        return service.intent_start(problem, llm_propose=llm_propose)

    @mcp.tool()
    def intent_show(intent_id: str) -> dict[str, Any]:
        return service.intent_show(intent_id)

    @mcp.tool()
    def intent_refine(
        intent_id: str,
        evidence: list[str] | None = None,
        select_goal: str | None = None,
    ) -> dict[str, Any]:
        return service.intent_refine(
            intent_id, evidence=evidence, select_goal=select_goal
        )

    @mcp.tool()
    def goal_evaluate(
        intent_id: str,
        candidate_goal_id: str | None = None,
        mode: str | None = None,
    ) -> dict[str, Any]:
        return service.goal_evaluate(
            intent_id, candidate_goal_id=candidate_goal_id, mode=mode
        )

    @mcp.tool()
    def goal_show(goal_id: str) -> dict[str, Any]:
        return service.goal_show(goal_id)

    @mcp.tool()
    def goal_challenge(goal_id: str) -> dict[str, Any]:
        return service.goal_challenge(goal_id)

    @mcp.tool()
    def get_impact_report(
        pack_id: str | None = None,
        paths: list[str] | None = None,
        diff: str | None = None,
        business: bool = False,
    ) -> dict[str, Any]:
        return service.get_impact_report(
            paths=paths, pack_id=pack_id, diff=diff, business=business
        )

    @mcp.tool()
    def impact_of(
        paths: list[str] | None = None, business: bool = False
    ) -> dict[str, Any]:
        return service.get_impact_report(paths=paths or [], business=business)

    @mcp.tool()
    def business_entity_add(
        type: str,
        name: str,
        attrs: dict[str, Any] | None = None,
        origin: str = "manual",
        source_type: str | None = None,
        source_ref: str | None = None,
        confidence: float = 0.9,
    ) -> dict[str, Any]:
        return service.business_entity_add(
            node_type=type,
            name=name,
            attrs=attrs or {},
            origin=origin,
            source_type=source_type,
            source_ref=source_ref,
            confidence=confidence,
        )

    @mcp.tool()
    def business_entity_list(
        status: str | None = None,
        type: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        return service.business_entity_list(status=status, node_type=type, limit=limit)

    @mcp.tool()
    def business_entity_approve(
        node_id: str, approver: str = "human:mcp", notes: str = ""
    ) -> dict[str, Any]:
        return service.business_entity_approve(node_id, approver=approver, notes=notes)

    @mcp.tool()
    def business_entity_reject(
        node_id: str, approver: str = "human:mcp", reason: str = ""
    ) -> dict[str, Any]:
        return service.business_entity_reject(node_id, approver=approver, reason=reason)

    @mcp.tool()
    def business_link(
        src_node_id: str,
        dst_node_id: str,
        kind: str,
        source_ref: str = "manual",
        confidence: float | None = None,
    ) -> dict[str, Any]:
        return service.business_link(
            src_node_id=src_node_id,
            dst_node_id=dst_node_id,
            kind=kind,
            source_ref=source_ref,
            confidence=confidence,
        )

    @mcp.tool()
    def behavior_check(
        paths: list[str] | None = None,
        diff: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        return service.behavior_check(paths=paths, diff=diff, pack_id=pack_id)

    @mcp.tool()
    def check_diff_against_pack(
        pack_id: str, diff: str | None = None
    ) -> dict[str, Any]:
        return service.check_diff_against_pack(pack_id, diff)

    @mcp.tool()
    def search_code(query: str, mode: str = "hybrid") -> dict[str, Any]:
        _ = mode
        return service.search_code(query)

    @mcp.tool()
    def search_repo(term: str, max_hops: int = 2, limit: int = 20) -> dict[str, Any]:
        return service.search_repo(term, max_hops=max_hops, limit=limit)

    @mcp.tool()
    def graph_neighbors(
        path: str, max_hops: int = 1, limit: int = 20
    ) -> dict[str, Any]:
        return service.graph_neighbors(path, max_hops=max_hops, limit=limit)

    @mcp.tool()
    def graph_path(
        source_path: str, target_path: str, max_hops: int = 4
    ) -> dict[str, Any]:
        return service.graph_path(source_path, target_path, max_hops=max_hops)

    @mcp.tool()
    def graph_tests_for_path(path: str) -> dict[str, Any]:
        return service.graph_tests_for_path(path)

    @mcp.tool()
    def graph_contracts_for_path(path: str) -> dict[str, Any]:
        return service.graph_contracts_for_path(path)

    @mcp.tool()
    def refresh_index() -> dict[str, Any]:
        return service.refresh_index()

    @mcp.tool()
    def record_outcome(
        pack_id: str,
        result: str,
        files_changed: list[str] | None = None,
        session_id: str | None = None,
        summary: str | None = None,
    ) -> dict[str, Any]:
        return service.record_outcome(
            pack_id, result, files_changed, session_id, summary=summary
        )

    @mcp.tool()
    def get_pack_manifest(pack_id: str) -> dict[str, Any]:
        return service.get_pack_manifest(pack_id)

    @mcp.tool()
    def reconstruct_pack(pack_id: str, task_text: str | None = None) -> dict[str, Any]:
        return service.reconstruct_pack(pack_id, task_text)

    @mcp.tool()
    def get_audit_record(pack_id: str) -> dict[str, Any]:
        return service.get_audit_record(pack_id)

    @mcp.tool()
    def verify_audit() -> dict[str, Any]:
        return service.verify_audit()

    @mcp.tool()
    def eval_replay(limit: int = 50, holdout_ratio: float = 0.3) -> dict[str, Any]:
        return service.eval_replay(limit, holdout_ratio)

    @mcp.tool()
    def eval_tune(limit: int = 50, holdout_ratio: float = 0.3) -> dict[str, Any]:
        return service.eval_tune(limit, holdout_ratio)

    @mcp.tool()
    def eval_run_efficacy(
        cases_path: str,
        agent_command: str,
        baseline: str = "no-pack",
        candidate: str = "ctx-pack",
        limit: int = 10,
        timeout: int = 600,
        keep_worktrees: bool = False,
    ) -> dict[str, Any]:
        return service.eval_run_efficacy(
            cases_path,
            agent_command,
            baseline=baseline,
            candidate=candidate,
            limit=limit,
            timeout=timeout,
            keep_worktrees=keep_worktrees,
        )

    @mcp.tool()
    def eval_scorecard(output: str | None = None) -> dict[str, Any]:
        return service.eval_scorecard(output)

    @mcp.tool()
    def eval_loop_verify(
        task: str = "change greeting service",
        paths: list[str] | None = None,
        result: str = "pass",
    ) -> dict[str, Any]:
        return service.eval_loop_verify(task=task, paths=paths, result=result)

    @mcp.tool()
    def gc() -> dict[str, Any]:
        return service.gc()

    @mcp.tool()
    def doctor() -> dict[str, Any]:
        return service.doctor()

    @mcp.tool()
    def release_check(version: str = "1.0.0") -> dict[str, Any]:
        return service.release_check(version)

    @mcp.tool()
    def ci_check(
        base: str = "origin/main", head: str = "HEAD", pack_id: str | None = None
    ) -> dict[str, Any]:
        return service.ci_check(base, head, pack_id)

    @mcp.tool()
    def constitution_build() -> dict[str, Any]:
        return service.constitution_build()

    @mcp.tool()
    def constitution_show() -> dict[str, Any]:
        return service.constitution_show()

    @mcp.tool()
    def constitution_check(
        paths: list[str] | None = None,
        task_session_id: str | None = None,
        for_ci: bool = False,
    ) -> dict[str, Any]:
        return service.constitution_check(
            paths or [],
            task_session_id=task_session_id,
            for_ci=for_ci,
        )

    @mcp.tool()
    def task_start(task: str) -> dict[str, Any]:
        return service.task_start(task)

    @mcp.tool()
    def task_transition(
        task_session_id: str,
        state: str,
        actor: str = "mcp-agent",
        reason: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        return service.task_transition(
            task_session_id,
            state,
            actor=actor,
            reason=reason,
            pack_id=pack_id,
        )

    @mcp.tool()
    def task_show(task_session_id: str) -> dict[str, Any]:
        return service.task_show(task_session_id)

    @mcp.tool()
    def codex_preflight(
        task: str,
        paths: list[str] | None = None,
        mode: str = "write",
    ) -> dict[str, Any]:
        return service.codex_preflight(task, paths=paths, mode=mode)

    @mcp.tool()
    def codex_enforcement_status() -> dict[str, Any]:
        return service.codex_enforcement_status()

    @mcp.tool()
    def codex_parallel_plan(
        task_session_id: str,
        pack_id: str,
        paths: list[str] | None = None,
    ) -> dict[str, Any]:
        return service.codex_parallel_plan(task_session_id, pack_id, paths=paths)

    @mcp.tool()
    def codex_child_start(
        parent_task_session_id: str,
        role: str,
        objective: str,
        write_scope: list[str] | None = None,
    ) -> dict[str, Any]:
        return service.codex_child_start(
            parent_task_session_id,
            role,
            objective,
            write_scope=write_scope,
        )

    @mcp.tool()
    def codex_child_stop(
        child_agent_session_id: str,
        summary: str,
        changed_files: list[str] | None = None,
        tests_run: list[str] | None = None,
        blockers: list[str] | None = None,
    ) -> dict[str, Any]:
        return service.codex_child_stop(
            child_agent_session_id,
            summary,
            changed_files=changed_files,
            tests_run=tests_run,
            blockers=blockers,
        )

    @mcp.tool()
    def codex_child_pack(
        parent_pack_id: str, role: str, scope: list[str] | None = None
    ) -> dict[str, Any]:
        return service.codex_child_pack(parent_pack_id, role, scope=scope)

    @mcp.tool()
    def codex_merge_parallel_results(parallel_run_id: str) -> dict[str, Any]:
        return service.codex_merge_parallel_results(parallel_run_id)

    @mcp.tool()
    def plan_validate(
        plan: dict[str, Any],
        task_session_id: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        return service.plan_validate(
            plan, task_session_id=task_session_id, pack_id=pack_id
        )

    @mcp.tool()
    def plan_create(
        task_session_id: str,
        plan: dict[str, Any],
        pack_id: str | None = None,
        author: str = "mcp-agent",
    ) -> dict[str, Any]:
        return service.plan_create(
            task_session_id,
            plan,
            pack_id=pack_id,
            author=author,
        )

    @mcp.tool()
    def plan_amend(
        plan_id: str,
        plan: dict[str, Any],
        author: str = "mcp-agent",
        reason: str | None = None,
    ) -> dict[str, Any]:
        return service.plan_amend(plan_id, plan, author=author, reason=reason)

    @mcp.tool()
    def plan_show(plan_id: str) -> dict[str, Any]:
        return service.plan_show(plan_id)

    @mcp.tool()
    def plan_checkpoint(
        plan_id: str,
        step_id: str,
        paths: list[str] | None = None,
    ) -> dict[str, Any]:
        return service.plan_checkpoint(plan_id, step_id, paths=paths)

    @mcp.tool()
    def verify_run(
        commands: list[str],
        pack_id: str | None = None,
        retry_budget: int = 0,
        timeout: int = 120,
    ) -> dict[str, Any]:
        return service.verify_run(
            commands,
            pack_id=pack_id,
            retry_budget=retry_budget,
            timeout=timeout,
        )

    @mcp.tool()
    def workspace_index() -> dict[str, Any]:
        return service.workspace_index()

    @mcp.tool()
    def workspace_impact(repo_id: str) -> dict[str, Any]:
        return service.workspace_impact(repo_id)

    @mcp.tool()
    def workspace_status() -> dict[str, Any]:
        return service.workspace_status()

    @mcp.tool()
    def workspace_rule_promotions() -> dict[str, Any]:
        return service.workspace_rule_promotions()

    @mcp.tool()
    def security_scan() -> dict[str, Any]:
        return service.security_scan()

    @mcp.tool()
    def security_status() -> dict[str, Any]:
        return service.security_status()

    @mcp.tool()
    def security_ingest_redteam(
        fixtures: str | None = None,
        output: str | None = None,
        strict: bool = False,
    ) -> dict[str, Any]:
        return service.security_ingest_redteam(fixtures, output=output, strict=strict)

    @mcp.tool()
    def memory_candidates() -> dict[str, Any]:
        return service.memory_candidates()

    @mcp.tool()
    def memory_extraction_eval(
        fixtures: str | None = None, source_type: str | None = None
    ) -> dict[str, Any]:
        return service.memory_extraction_eval(
            fixtures=fixtures, source_type=source_type
        )

    @mcp.tool()
    def memory_trust_calibrate(apply: bool = False) -> dict[str, Any]:
        return service.memory_trust_calibrate(apply=apply)

    @mcp.tool()
    def memory_approve(rule_id: str, approved_by: str = "local-user") -> dict[str, Any]:
        return service.memory_approve(rule_id, approved_by)

    @mcp.tool()
    def memory_verify() -> dict[str, Any]:
        return service.memory_verify()

    @mcp.tool()
    def memory_stale() -> dict[str, Any]:
        return service.memory_stale()

    @mcp.tool()
    def memory_search(
        query: str, types: list[str] | None = None, status: str | None = None
    ) -> dict[str, Any]:
        return service.memory_search(query, types, status)

    @mcp.tool()
    def memory_show(record_id: str) -> dict[str, Any]:
        return service.memory_show(record_id)

    @mcp.tool()
    def memory_recall(
        query: str,
        paths: list[str] | None = None,
        types: list[str] | None = None,
        limit: int = 20,
        include_org: bool = False,
    ) -> dict[str, Any]:
        return service.memory_recall(
            query, paths, types, limit, include_org=include_org
        )

    @mcp.tool()
    def memory_consolidate(
        session_id: str | None = None, recent: int = 10
    ) -> dict[str, Any]:
        return service.memory_consolidate(session_id, recent)

    @mcp.tool()
    def memory_reflect(
        session_id: str | None = None, recent: int = 10
    ) -> dict[str, Any]:
        return service.memory_reflect(session_id, recent)

    @mcp.tool()
    def memory_maintain(
        session_id: str | None = None, recent: int = 10
    ) -> dict[str, Any]:
        return service.memory_maintain(session_id, recent)

    @mcp.tool()
    def memory_utilization(pack_id: str) -> dict[str, Any]:
        return service.memory_utilization(pack_id)

    @mcp.tool()
    def memory_propose(
        record_type: str,
        assertion: str,
        evidence_refs: list[dict[str, Any]] | None = None,
        source_kind: str = "manual",
        confidence: float = 1.0,
    ) -> dict[str, Any]:
        return service.memory_propose(
            record_type, assertion, evidence_refs, source_kind, confidence
        )

    @mcp.tool()
    def continuation_search(
        status: str | None = None, limit: int = 20
    ) -> dict[str, Any]:
        return service.continuation_list(status=status, limit=limit)

    @mcp.tool()
    def continuation_show(continuation_id: str) -> dict[str, Any]:
        return service.continuation_show(continuation_id)

    @mcp.tool()
    def continuation_resume(task: str, limit: int = 3) -> dict[str, Any]:
        return service.continuation_resume(task, limit=limit)

    @mcp.tool()
    def skill_search(
        query: str,
        limit: int = 5,
        include_untrusted: bool = False,
    ) -> dict[str, Any]:
        return service.skill_search(
            query, limit=limit, include_untrusted=include_untrusted
        )

    @mcp.tool()
    def skill_induce(session_id: str) -> dict[str, Any]:
        return service.skill_induce(session_id)

    @mcp.tool()
    def skill_show(skill_id: str) -> dict[str, Any]:
        return service.skill_show(skill_id)

    @mcp.tool()
    def skill_replay(skill_id: str, timeout: int = 120) -> dict[str, Any]:
        return service.skill_replay(skill_id, timeout=timeout)

    @mcp.tool()
    def learning_optimize(
        target: str = "pack_weights",
        iterations: int = 1,
        limit: int = 20,
        holdout_ratio: float = 0.3,
        adopt: bool = False,
    ) -> dict[str, Any]:
        return service.learning_optimize(
            target,
            iterations=iterations,
            limit=limit,
            holdout_ratio=holdout_ratio,
            adopt=adopt,
        )

    @mcp.tool()
    def learning_loop_verify(
        task: str | None = None,
        probe: str | None = None,
        require_closure: bool = False,
    ) -> dict[str, Any]:
        return service.learning_loop_verify(
            task,
            probe=probe,
            require_closure=require_closure,
        )

    @mcp.tool()
    def learning_archive(target: str | None = None, limit: int = 20) -> dict[str, Any]:
        return service.learning_archive(target=target, limit=limit)

    @mcp.tool()
    def learning_runs(target: str | None = None, limit: int = 20) -> dict[str, Any]:
        return service.learning_archive(target=target, limit=limit)

    @mcp.tool()
    def learning_benchmark_trends(limit: int = 20) -> dict[str, Any]:
        return service.learning_benchmark_trends(limit=limit)

    @mcp.tool()
    def learning_adopt(run_id: str) -> dict[str, Any]:
        return service.learning_adopt(run_id)

    @mcp.tool()
    def learning_revert(run_id: str) -> dict[str, Any]:
        return service.learning_revert(run_id)

    @mcp.tool()
    def learning_selfmod_propose(
        target: str,
        weakness: str = "",
        ancestor_run_id: str | None = None,
    ) -> dict[str, Any]:
        return service.learning_selfmod_propose(
            target,
            weakness=weakness,
            ancestor_run_id=ancestor_run_id,
        )

    @mcp.tool()
    def learning_selfmod_archive(
        target: str | None = None, limit: int = 20
    ) -> dict[str, Any]:
        return service.learning_selfmod_archive(target=target, limit=limit)

    @mcp.tool()
    def selfmod_show(target: str | None = None, limit: int = 20) -> dict[str, Any]:
        return service.learning_selfmod_archive(target=target, limit=limit)

    @mcp.tool()
    def learning_selfmod_adopt(
        run_id: str,
        approved_by: str = "local-user",
    ) -> dict[str, Any]:
        return service.learning_selfmod_adopt(run_id, approved_by=approved_by)

    @mcp.tool()
    def learning_selfmod_revert(run_id: str) -> dict[str, Any]:
        return service.learning_selfmod_revert(run_id)

    @mcp.tool()
    def session_start(task: str, agent_name: str = "codex") -> dict[str, Any]:
        return service.session_start(task, agent_name)

    @mcp.tool()
    def session_event(
        session_id: str, event_type: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return service.session_event(session_id, event_type, payload)

    @mcp.tool()
    def session_finish(session_id: str, result: str = "pass") -> dict[str, Any]:
        return service.session_finish(session_id, result)

    @mcp.tool()
    def session_explain(session_id: str) -> dict[str, Any]:
        return service.session_explain(session_id)

    @mcp.tool()
    def session_leases(status: str | None = "active") -> dict[str, Any]:
        return service.session_leases(status=status)

    @mcp.tool()
    def session_declare_impact(session_id: str, paths: list[str]) -> dict[str, Any]:
        return service.session_declare_impact(session_id, paths)

    @mcp.tool()
    def session_conflicts(status: str | None = "open") -> dict[str, Any]:
        return service.session_conflicts(status=status)

    @mcp.tool()
    def session_conflict_ack(conflict_id: str) -> dict[str, Any]:
        return service.session_conflict_update(conflict_id, "acknowledged")

    @mcp.tool()
    def session_conflict_resolve(conflict_id: str) -> dict[str, Any]:
        return service.session_conflict_update(conflict_id, "resolved")

    @mcp.tool()
    def runtime_candidates() -> dict[str, Any]:
        return service.runtime_candidates()

    @mcp.tool()
    def org_connector_add(
        kind: str,
        config: dict[str, Any] | None = None,
        display_name: str | None = None,
        access_scope: str = "restricted",
        remote_enabled: bool = False,
    ) -> dict[str, Any]:
        return service.org_connector_add(
            kind,
            config=config or {},
            display_name=display_name,
            access_scope=access_scope,
            remote_enabled=remote_enabled,
        )

    @mcp.tool()
    def org_ingest(
        connector: str,
        since: str | None = None,
        path: str | None = None,
        remote: bool = False,
        actor: str = "system",
    ) -> dict[str, Any]:
        return service.org_ingest(
            connector, since=since, path=path, remote=remote, actor=actor
        )

    @mcp.tool()
    def org_candidates(
        status: str | None = "quarantined",
        source: str | None = None,
        scope: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        return service.org_candidates(
            status=status, source=source, scope=scope, limit=limit
        )

    @mcp.tool()
    def org_approve(candidate_id: str, actor: str = "codeowner:mcp") -> dict[str, Any]:
        return service.org_approve(candidate_id, actor=actor)

    @mcp.tool()
    def org_reject(
        candidate_id: str, actor: str = "codeowner:mcp", reason: str = "rejected"
    ) -> dict[str, Any]:
        return service.org_reject(candidate_id, actor=actor, reason=reason)

    @mcp.tool()
    def decision_start(
        question: str,
        options: list[str] | None = None,
        seed_paths: list[str] | None = None,
    ) -> dict[str, Any]:
        return service.decision_start(
            question, options=options or [], seed_paths=seed_paths or []
        )

    @mcp.tool()
    def decision_analyze(decision_id: str) -> dict[str, Any]:
        return service.decision_analyze(decision_id)

    @mcp.tool()
    def decision_record(
        decision_id: str,
        chosen_option_id: str,
        rationale: str,
        actor: str | None = None,
    ) -> dict[str, Any]:
        if not chosen_option_id or not rationale:
            raise ValueError("decision_record requires chosen_option_id and rationale")
        return service.decision_record(
            decision_id,
            chosen_option_id=chosen_option_id,
            rationale=rationale,
            actor=actor or "local-user:mcp",
        )

    @mcp.tool()
    def dashboard_data() -> dict[str, Any]:
        return service.dashboard_data()

    @mcp.tool()
    def architecture_infer() -> dict[str, Any]:
        return service.architecture_infer()

    @mcp.tool()
    def architecture_explain(service_name: str) -> dict[str, Any]:
        return service.architecture_explain(service_name)

    @mcp.tool()
    def architecture_drift(strict: bool = False) -> dict[str, Any]:
        return service.architecture_drift(strict=strict)

    @mcp.tool()
    def semantic_accuracy_eval(fixtures: str | None = None) -> dict[str, Any]:
        return service.semantic_accuracy_eval(fixtures)

    @mcp.tool()
    def semantic_low_confidence(threshold: float = 0.5) -> dict[str, Any]:
        return service.semantic_low_confidence(threshold)

    @mcp.tool()
    def semantic_repair_list(status: str = "open", limit: int = 100) -> dict[str, Any]:
        return service.semantic_repair_list(status=status, limit=limit)

    @mcp.tool()
    def semantic_repair_confirm(
        finding_id: str,
        rationale: str = "",
        actor: str = "human:mcp",
    ) -> dict[str, Any]:
        return service.semantic_repair_confirm(
            finding_id, actor=actor, rationale=rationale
        )

    @mcp.tool()
    def semantic_repair_reject(
        finding_id: str,
        rationale: str = "",
        actor: str = "human:mcp",
    ) -> dict[str, Any]:
        return service.semantic_repair_reject(
            finding_id, actor=actor, rationale=rationale
        )

    @mcp.tool()
    def agent_route(
        task: str,
        risk_score: float = 0.0,
        capabilities: list[str] | None = None,
        remote_review_enabled: bool = False,
    ) -> dict[str, Any]:
        return service.agent_route(
            task,
            risk_score=risk_score,
            capabilities=capabilities,
            remote_review_enabled=remote_review_enabled,
        )

    mcp.run()
