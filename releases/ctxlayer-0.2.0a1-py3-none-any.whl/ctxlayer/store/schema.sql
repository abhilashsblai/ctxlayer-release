PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS schema_migrations (
  version    INTEGER PRIMARY KEY,
  name       TEXT NOT NULL,
  applied_at TEXT NOT NULL,
  checksum   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS repos (
  repo_id    TEXT PRIMARY KEY,
  root_path  TEXT NOT NULL,
  remote_url TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS snapshots (
  snapshot_id     TEXT PRIMARY KEY,
  repo_id         TEXT NOT NULL REFERENCES repos(repo_id),
  base_commit_sha TEXT NOT NULL,
  tree_digest     TEXT NOT NULL,
  dirty_digest    TEXT NOT NULL DEFAULT '',
  worktree_state  TEXT NOT NULL,
  branch_hint     TEXT,
  parent_snapshot TEXT,
  indexer_version TEXT NOT NULL,
  parser_bundle_version TEXT NOT NULL,
  chunker_version TEXT NOT NULL,
  embed_model     TEXT NOT NULL,
  created_at      TEXT NOT NULL,
  UNIQUE(repo_id, base_commit_sha, tree_digest, dirty_digest,
         indexer_version, parser_bundle_version, chunker_version, embed_model)
);

CREATE TABLE IF NOT EXISTS file_versions (
  file_version_id TEXT PRIMARY KEY,
  repo_id         TEXT NOT NULL,
  lang            TEXT,
  loc             INTEGER,
  skeleton        TEXT
);

CREATE TABLE IF NOT EXISTS snapshot_files (
  snapshot_id     TEXT NOT NULL REFERENCES snapshots(snapshot_id),
  path            TEXT NOT NULL,
  file_version_id TEXT NOT NULL REFERENCES file_versions(file_version_id),
  PRIMARY KEY (snapshot_id, path)
);

CREATE TABLE IF NOT EXISTS symbol_identities (
  symbol_identity_id TEXT PRIMARY KEY,
  repo_id   TEXT NOT NULL,
  path      TEXT NOT NULL,
  kind      TEXT NOT NULL,
  qualname  TEXT NOT NULL,
  is_test   INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS symbol_occurrences (
  symbol_occurrence_id TEXT PRIMARY KEY,
  symbol_identity_id   TEXT NOT NULL REFERENCES symbol_identities(symbol_identity_id),
  file_version_id      TEXT NOT NULL REFERENCES file_versions(file_version_id),
  start_line INTEGER,
  end_line   INTEGER,
  signature  TEXT,
  docstring  TEXT
);

CREATE TABLE IF NOT EXISTS edges (
  edge_id       TEXT PRIMARY KEY,
  scope_snapshot_id TEXT,
  src_repo_id   TEXT NOT NULL,
  src_node_type TEXT NOT NULL,
  src_node_id   TEXT NOT NULL,
  dst_repo_id   TEXT NOT NULL,
  dst_node_type TEXT NOT NULL,
  dst_node_id   TEXT NOT NULL,
  kind          TEXT NOT NULL,
  confidence    REAL NOT NULL DEFAULT 1.0,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_edges_src ON edges(src_repo_id, src_node_type, src_node_id, kind);
CREATE INDEX IF NOT EXISTS idx_edges_dst ON edges(dst_repo_id, dst_node_type, dst_node_id, kind);
CREATE INDEX IF NOT EXISTS idx_edges_scope ON edges(scope_snapshot_id);

CREATE TABLE IF NOT EXISTS chunks (
  chunk_id       TEXT PRIMARY KEY,
  snapshot_id    TEXT NOT NULL REFERENCES snapshots(snapshot_id),
  repo_id        TEXT NOT NULL,
  path           TEXT NOT NULL,
  symbol_identity_id TEXT,
  category       TEXT NOT NULL,
  start_line     INTEGER,
  end_line       INTEGER,
  text           TEXT NOT NULL,
  text_normalized TEXT NOT NULL,
  token_count    INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_chunks_snapshot_path ON chunks(snapshot_id, path);
CREATE INDEX IF NOT EXISTS idx_chunks_symbol ON chunks(symbol_identity_id);

CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
  chunk_id UNINDEXED,
  text_normalized
);

CREATE TABLE IF NOT EXISTS test_commands (
  command_id TEXT PRIMARY KEY,
  repo_id    TEXT NOT NULL,
  path_glob  TEXT NOT NULL,
  command    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS chunk_vectors (
  chunk_id TEXT PRIMARY KEY REFERENCES chunks(chunk_id) ON DELETE CASCADE,
  dims INTEGER NOT NULL,
  vector_json TEXT NOT NULL,
  model TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS chunk_vector_rows (
  vec_rowid INTEGER PRIMARY KEY AUTOINCREMENT,
  chunk_id TEXT NOT NULL UNIQUE REFERENCES chunks(chunk_id) ON DELETE CASCADE,
  dims INTEGER NOT NULL,
  model TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ownership (
  owner_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  path_glob TEXT NOT NULL,
  owner TEXT NOT NULL,
  source TEXT NOT NULL,
  confidence REAL NOT NULL DEFAULT 1.0
);

CREATE TABLE IF NOT EXISTS churn (
  churn_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  path TEXT NOT NULL,
  author TEXT,
  commits INTEGER NOT NULL,
  last_commit_sha TEXT,
  last_touched_at TEXT
);

CREATE TABLE IF NOT EXISTS cochange (
  cochange_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  path_a TEXT NOT NULL,
  path_b TEXT NOT NULL,
  commits_together INTEGER NOT NULL,
  commits_a INTEGER NOT NULL,
  commits_b INTEGER NOT NULL,
  jaccard REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_cochange_a ON cochange(repo_id, path_a, jaccard);
CREATE INDEX IF NOT EXISTS idx_cochange_b ON cochange(repo_id, path_b, jaccard);

CREATE TABLE IF NOT EXISTS eval_runs (
  eval_run_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  mode TEXT NOT NULL,
  train_count INTEGER NOT NULL,
  holdout_count INTEGER NOT NULL,
  metrics_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS efficacy_scorecards (
  scorecard_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  eval_run_id TEXT,
  schema_version TEXT NOT NULL,
  gate_status TEXT,
  report_json TEXT NOT NULL,
  audit_hash TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_efficacy_scorecards_repo_created
  ON efficacy_scorecards(repo_id, created_at);

CREATE TABLE IF NOT EXISTS release_reports (
  release_report_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  version TEXT NOT NULL,
  report_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ci_reports (
  ci_report_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  status TEXT NOT NULL,
  report_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS workspace_repos (
  workspace_repo_id TEXT PRIMARY KEY,
  workspace_root TEXT NOT NULL,
  repo_id TEXT NOT NULL,
  name TEXT NOT NULL,
  root_path TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS crossrepo_contracts (
  contract_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  path TEXT NOT NULL,
  kind TEXT NOT NULL,
  name TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS audit_anchors (
  anchor_id TEXT PRIMARY KEY,
  target TEXT NOT NULL,
  tip_hash TEXT NOT NULL,
  location TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS business_rules (
  rule_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  scope_glob TEXT,
  rule_text TEXT NOT NULL,
  source_type TEXT NOT NULL,
  source_ref TEXT NOT NULL,
  confidence REAL NOT NULL,
  status TEXT NOT NULL,
  approved_by TEXT,
  approved_at TEXT,
  supersedes_rule_id TEXT,
  updated_at TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS business_rule_evidence (
  rule_id TEXT NOT NULL REFERENCES business_rules(rule_id),
  repo_id TEXT,
  path TEXT,
  symbol_identity_id TEXT,
  quote_hash TEXT,
  evidence_type TEXT NOT NULL,
  evidence_kind TEXT,
  evidence_hash TEXT,
  line_start INTEGER,
  line_end INTEGER
);

CREATE TABLE IF NOT EXISTS business_rule_candidates (
  candidate_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  rule_text TEXT NOT NULL,
  source_type TEXT NOT NULL,
  confidence REAL NOT NULL,
  raw_score REAL,
  calibrated_confidence REAL,
  trust_tier TEXT,
  confidence_method TEXT,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS business_rule_candidate_evidence (
  candidate_id TEXT NOT NULL REFERENCES business_rule_candidates(candidate_id),
  repo_id TEXT,
  path TEXT,
  symbol_identity_id TEXT,
  evidence_kind TEXT NOT NULL,
  evidence_hash TEXT NOT NULL,
  line_start INTEGER,
  line_end INTEGER
);

CREATE TABLE IF NOT EXISTS business_rule_approvals (
  approval_id TEXT PRIMARY KEY,
  rule_id TEXT NOT NULL,
  approver TEXT NOT NULL,
  source TEXT NOT NULL,
  decision TEXT NOT NULL,
  notes TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS runtime_events (
  runtime_event_id TEXT PRIMARY KEY,
  source TEXT NOT NULL,
  repo_id TEXT,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  path TEXT,
  symbol_identity_id TEXT,
  severity TEXT NOT NULL,
  event_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS semantic_nodes (
  node_id TEXT PRIMARY KEY,
  repo_id TEXT,
  node_type TEXT NOT NULL,
  name TEXT NOT NULL,
  stable_key TEXT NOT NULL,
  confidence REAL NOT NULL,
  source TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  trust_tier TEXT,
  status TEXT,
  provenance_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_semantic_nodes_repo_type
  ON semantic_nodes(repo_id, node_type, name);

CREATE UNIQUE INDEX IF NOT EXISTS idx_semantic_nodes_stable_key
  ON semantic_nodes(stable_key);

CREATE TABLE IF NOT EXISTS semantic_edges (
  edge_id TEXT PRIMARY KEY,
  src_node_id TEXT NOT NULL REFERENCES semantic_nodes(node_id) ON DELETE CASCADE,
  dst_node_id TEXT NOT NULL REFERENCES semantic_nodes(node_id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  confidence REAL NOT NULL,
  evidence_json TEXT NOT NULL DEFAULT '[]',
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_semantic_edges_src
  ON semantic_edges(src_node_id, kind);

CREATE INDEX IF NOT EXISTS idx_semantic_edges_dst
  ON semantic_edges(dst_node_id, kind);

CREATE TABLE IF NOT EXISTS semantic_evidence (
  evidence_id TEXT PRIMARY KEY,
  node_id TEXT REFERENCES semantic_nodes(node_id) ON DELETE CASCADE,
  edge_id TEXT REFERENCES semantic_edges(edge_id) ON DELETE CASCADE,
  repo_id TEXT,
  path TEXT,
  symbol_identity_id TEXT,
  line_start INTEGER,
  line_end INTEGER,
  evidence_kind TEXT NOT NULL,
  evidence_hash TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_semantic_evidence_node
  ON semantic_evidence(node_id);

CREATE INDEX IF NOT EXISTS idx_semantic_evidence_edge
  ON semantic_evidence(edge_id);

CREATE TABLE IF NOT EXISTS business_node_approvals (
  approval_id TEXT PRIMARY KEY,
  node_id TEXT NOT NULL REFERENCES semantic_nodes(node_id) ON DELETE CASCADE,
  repo_id TEXT NOT NULL,
  decision TEXT NOT NULL,
  approver TEXT NOT NULL,
  notes TEXT,
  from_status TEXT,
  to_status TEXT NOT NULL,
  audit_row_hash TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_business_node_approvals_node
  ON business_node_approvals(node_id, created_at);

CREATE INDEX IF NOT EXISTS idx_business_node_approvals_repo_decision
  ON business_node_approvals(repo_id, decision, created_at);

CREATE TABLE IF NOT EXISTS org_knowledge_candidates (
  candidate_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  memory_record_id TEXT REFERENCES memory_records(record_id) ON DELETE SET NULL,
  source_connector TEXT NOT NULL,
  source_ref TEXT NOT NULL,
  content_extract TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  extracted_type TEXT NOT NULL,
  trust_tier TEXT NOT NULL DEFAULT 'low',
  confidence REAL NOT NULL DEFAULT 0.3,
  status TEXT NOT NULL DEFAULT 'quarantined',
  defense_result TEXT NOT NULL DEFAULT '{}',
  contradictions TEXT NOT NULL DEFAULT '[]',
  linked_entities TEXT NOT NULL DEFAULT '[]',
  captured_at TEXT,
  ingested_at TEXT NOT NULL,
  decay_at TEXT,
  provenance TEXT NOT NULL DEFAULT '{}',
  redaction_summary TEXT NOT NULL DEFAULT '{}',
  access_scope TEXT NOT NULL DEFAULT 'restricted',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_org_cand_status
  ON org_knowledge_candidates(workspace_id, repo_id, status);

CREATE INDEX IF NOT EXISTS idx_org_cand_source
  ON org_knowledge_candidates(source_connector, source_ref);

CREATE UNIQUE INDEX IF NOT EXISTS idx_org_cand_hash
  ON org_knowledge_candidates(workspace_id, content_hash);

CREATE TABLE IF NOT EXISTS org_connectors (
  connector_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  display_name TEXT NOT NULL,
  config_json TEXT NOT NULL DEFAULT '{}',
  secret_ref TEXT,
  access_scope TEXT NOT NULL DEFAULT 'restricted',
  remote_enabled INTEGER NOT NULL DEFAULT 0,
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_org_connectors_workspace_kind
  ON org_connectors(workspace_id, kind, enabled);

CREATE TABLE IF NOT EXISTS org_ingest_runs (
  run_id TEXT PRIMARY KEY,
  connector_id TEXT NOT NULL REFERENCES org_connectors(connector_id),
  workspace_id TEXT NOT NULL,
  since TEXT,
  items_seen INTEGER NOT NULL DEFAULT 0,
  items_quarantined INTEGER NOT NULL DEFAULT 0,
  items_rejected INTEGER NOT NULL DEFAULT 0,
  redactions INTEGER NOT NULL DEFAULT 0,
  remote_used INTEGER NOT NULL DEFAULT 0,
  audit_hash TEXT,
  started_at TEXT NOT NULL,
  finished_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_org_ingest_runs_connector_started
  ON org_ingest_runs(connector_id, started_at);

CREATE TABLE IF NOT EXISTS decisions (
  decision_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  question TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  snapshot_id TEXT,
  briefing_json TEXT NOT NULL DEFAULT '{}',
  human_decision_json TEXT,
  audit_hash TEXT,
  prev_audit_hash TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_decisions_repo
  ON decisions(repo_id, status);

CREATE INDEX IF NOT EXISTS idx_decisions_workspace_status
  ON decisions(workspace_id, status, updated_at);

CREATE TABLE IF NOT EXISTS semantic_file_index (
  repo_id TEXT NOT NULL,
  path TEXT NOT NULL,
  file_version_id TEXT NOT NULL,
  parser_backend TEXT NOT NULL,
  indexed_at TEXT NOT NULL,
  PRIMARY KEY (repo_id, path)
);

CREATE INDEX IF NOT EXISTS idx_semantic_file_index_repo
  ON semantic_file_index(repo_id, file_version_id);

CREATE TABLE IF NOT EXISTS semantic_drift_findings (
  finding_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  snapshot_id TEXT NOT NULL,
  finding_type TEXT NOT NULL,
  severity TEXT NOT NULL,
  node_id TEXT,
  edge_id TEXT,
  paths_json TEXT NOT NULL DEFAULT '[]',
  detail TEXT NOT NULL,
  confidence REAL,
  status TEXT NOT NULL DEFAULT 'open',
  detected_at TEXT NOT NULL,
  resolved_at TEXT,
  audit_hash TEXT,
  prev_audit_hash TEXT
);

CREATE INDEX IF NOT EXISTS idx_semantic_drift_repo_status
  ON semantic_drift_findings(repo_id, status, severity);

CREATE TABLE IF NOT EXISTS semantic_accuracy_runs (
  accuracy_run_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  fixture_set TEXT NOT NULL,
  metrics_json TEXT NOT NULL,
  passed INTEGER NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_semantic_accuracy_repo_created
  ON semantic_accuracy_runs(repo_id, created_at);

CREATE TABLE IF NOT EXISTS memory_eval_runs (
  memory_eval_run_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL,
  metrics_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS dirty_blobs (
  blob_id TEXT PRIMARY KEY,
  snapshot_id TEXT NOT NULL REFERENCES snapshots(snapshot_id),
  path TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  content BLOB NOT NULL
);

CREATE TABLE IF NOT EXISTS context_packs (
  pack_id TEXT PRIMARY KEY,
  snapshot_id TEXT NOT NULL REFERENCES snapshots(snapshot_id),
  repo_id TEXT NOT NULL,
  task_text_hash TEXT NOT NULL,
  manifest_json TEXT NOT NULL,
  reconstructible INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  bound_snapshot_id TEXT,
  binding_mode TEXT NOT NULL DEFAULT 'auto',
  bound_at TEXT,
  base_commit_sha TEXT,
  worktree_state TEXT,
  staleness_state TEXT NOT NULL DEFAULT 'fresh'
);

CREATE TABLE IF NOT EXISTS audit_log (
  audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
  pack_id TEXT NOT NULL,
  prev_hash TEXT NOT NULL,
  row_hash TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS session_leases (
  lease_id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  agent_name TEXT NOT NULL DEFAULT 'codex',
  bound_snapshot_id TEXT,
  impact_paths_json TEXT NOT NULL DEFAULT '[]',
  impact_hash TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active',
  acquired_at TEXT NOT NULL,
  renewed_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  released_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_session_leases_scope_status
  ON session_leases(workspace_id, repo_id, status, expires_at);

CREATE INDEX IF NOT EXISTS idx_session_leases_session_status
  ON session_leases(session_id, status, expires_at);

CREATE TABLE IF NOT EXISTS session_conflicts (
  conflict_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  left_session_id TEXT NOT NULL,
  right_session_id TEXT NOT NULL,
  conflict_type TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'warning',
  status TEXT NOT NULL DEFAULT 'open',
  paths_json TEXT NOT NULL DEFAULT '[]',
  detail_json TEXT NOT NULL DEFAULT '{}',
  detected_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  acknowledged_at TEXT,
  resolved_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_session_conflicts_scope_status
  ON session_conflicts(workspace_id, repo_id, status, detected_at);

CREATE TABLE IF NOT EXISTS audit_chain_state (
  chain_id TEXT PRIMARY KEY,
  tip_hash TEXT NOT NULL,
  height INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS outcomes (
  outcome_id TEXT PRIMARY KEY,
  pack_id TEXT NOT NULL,
  result TEXT NOT NULL,
  files_changed_json TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS memory_records (
  record_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  scope TEXT NOT NULL DEFAULT 'repo',
  type TEXT NOT NULL,
  subject_key TEXT NOT NULL,
  title TEXT,
  assertion TEXT NOT NULL,
  status TEXT NOT NULL,
  trust TEXT NOT NULL DEFAULT 'candidate',
  confidence REAL NOT NULL DEFAULT 1.0,
  importance REAL NOT NULL DEFAULT 0.5,
  source_kind TEXT NOT NULL,
  extraction_method TEXT NOT NULL,
  applies_when TEXT,
  avoid_when TEXT,
  owner TEXT,
  expires_at TEXT,
  invalidates_when TEXT,
  last_validated_at TEXT,
  superseded_by TEXT,
  provenance_json TEXT NOT NULL DEFAULT '{}',
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_memory_records_scope_type_status
  ON memory_records(workspace_id, repo_id, type, status);

CREATE INDEX IF NOT EXISTS idx_memory_records_subject
  ON memory_records(subject_key, type, status);

CREATE TABLE IF NOT EXISTS memory_evidence (
  evidence_id TEXT PRIMARY KEY,
  record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  repo_id TEXT,
  path TEXT,
  symbol_identity_id TEXT,
  line_start INTEGER,
  line_end INTEGER,
  evidence_kind TEXT NOT NULL,
  evidence_hash TEXT NOT NULL,
  source_ref TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_memory_evidence_record
  ON memory_evidence(record_id);

CREATE TABLE IF NOT EXISTS memory_transitions (
  transition_id TEXT PRIMARY KEY,
  record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  from_status TEXT,
  to_status TEXT NOT NULL,
  actor TEXT NOT NULL,
  reason TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_memory_transitions_record
  ON memory_transitions(record_id);

CREATE TABLE IF NOT EXISTS memory_review_queue (
  review_id TEXT PRIMARY KEY,
  record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  reason TEXT NOT NULL,
  severity TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL,
  resolved_at TEXT,
  resolution TEXT
);

CREATE INDEX IF NOT EXISTS idx_memory_review_queue_status
  ON memory_review_queue(status, severity, created_at);

CREATE TABLE IF NOT EXISTS memory_revision (
  revision_id TEXT PRIMARY KEY,
  record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  previous_hash TEXT,
  record_json TEXT NOT NULL,
  actor TEXT NOT NULL,
  reason TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_memory_revision_record
  ON memory_revision(record_id, created_at);

CREATE TABLE IF NOT EXISTS memory_conflicts (
  conflict_id TEXT PRIMARY KEY,
  left_record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  right_record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  conflict_type TEXT NOT NULL,
  summary TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL,
  resolved_at TEXT,
  resolution TEXT
);

CREATE INDEX IF NOT EXISTS idx_memory_conflicts_status
  ON memory_conflicts(status);

CREATE TABLE IF NOT EXISTS memory_decay_policies (
  type TEXT PRIMARY KEY,
  default_ttl_days INTEGER,
  stale_after_days INTEGER,
  requires_manual_expiry INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS agent_sessions (
  session_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  task_text_hash TEXT NOT NULL,
  agent_name TEXT,
  started_at TEXT NOT NULL,
  ended_at TEXT,
  status TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_agent_sessions_scope_status
  ON agent_sessions(workspace_id, repo_id, status);

CREATE TABLE IF NOT EXISTS agent_session_events (
  event_id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL REFERENCES agent_sessions(session_id) ON DELETE CASCADE,
  event_type TEXT NOT NULL,
  event_time TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  payload_hash TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_agent_session_events_session
  ON agent_session_events(session_id, event_time);

CREATE TABLE IF NOT EXISTS agent_session_artifacts (
  artifact_id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL REFERENCES agent_sessions(session_id) ON DELETE CASCADE,
  artifact_type TEXT NOT NULL,
  ref TEXT NOT NULL,
  content_hash TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_agent_session_artifacts_session
  ON agent_session_artifacts(session_id, artifact_type);

CREATE TABLE IF NOT EXISTS memory_associations (
  association_id TEXT PRIMARY KEY,
  record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  target_type TEXT NOT NULL,
  target_ref TEXT NOT NULL,
  kind TEXT NOT NULL,
  weight REAL NOT NULL DEFAULT 1.0,
  evidence_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_memory_associations_record
  ON memory_associations(record_id, kind);

CREATE INDEX IF NOT EXISTS idx_memory_associations_target
  ON memory_associations(target_type, target_ref, kind);

CREATE TABLE IF NOT EXISTS memory_vectors (
  record_id TEXT PRIMARY KEY REFERENCES memory_records(record_id) ON DELETE CASCADE,
  dims INTEGER NOT NULL,
  vector_json TEXT NOT NULL,
  model TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS memory_access_log (
  access_id TEXT PRIMARY KEY,
  pack_id TEXT NOT NULL,
  memory_record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  served_at TEXT NOT NULL,
  score REAL NOT NULL,
  signals_json TEXT NOT NULL DEFAULT '[]'
);

CREATE INDEX IF NOT EXISTS idx_memory_access_log_pack
  ON memory_access_log(pack_id);

CREATE TABLE IF NOT EXISTS memory_utilization (
  utilization_id TEXT PRIMARY KEY,
  pack_id TEXT NOT NULL,
  memory_record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
  utilization_kind TEXT NOT NULL,
  score REAL NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_memory_utilization_pack
  ON memory_utilization(pack_id);

CREATE TABLE IF NOT EXISTS learning_candidate (
  candidate_id TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  provenance_json TEXT NOT NULL DEFAULT '{}',
  confidence REAL NOT NULL DEFAULT 0.0,
  status TEXT NOT NULL DEFAULT 'candidate',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_learning_candidate_status
  ON learning_candidate(kind, status, created_at);

CREATE TABLE IF NOT EXISTS skill (
  skill_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  nl_description TEXT NOT NULL,
  trigger_signature TEXT NOT NULL,
  steps_json TEXT NOT NULL DEFAULT '[]',
  evidence_json TEXT NOT NULL DEFAULT '[]',
  embedding_ref TEXT,
  provenance_json TEXT NOT NULL DEFAULT '{}',
  success_count INTEGER NOT NULL DEFAULT 0,
  fail_count INTEGER NOT NULL DEFAULT 0,
  last_validated_at TEXT,
  status TEXT NOT NULL DEFAULT 'candidate',
  trust TEXT NOT NULL DEFAULT 'untrusted',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_skill_status_trust
  ON skill(status, trust, updated_at);

CREATE TABLE IF NOT EXISTS learning_run (
  run_id TEXT PRIMARY KEY,
  target TEXT NOT NULL,
  kind TEXT NOT NULL,
  before_json TEXT NOT NULL DEFAULT '{}',
  after_json TEXT NOT NULL DEFAULT '{}',
  train_metrics_json TEXT NOT NULL DEFAULT '{}',
  holdout_metrics_json TEXT NOT NULL DEFAULT '{}',
  gate_pass INTEGER NOT NULL DEFAULT 0,
  archived INTEGER NOT NULL DEFAULT 0,
  promoted INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_learning_run_kind_target
  ON learning_run(kind, target, created_at);

CREATE TABLE IF NOT EXISTS learning_event (
  event_id TEXT PRIMARY KEY,
  ts TEXT NOT NULL,
  phase TEXT NOT NULL,
  kind TEXT NOT NULL,
  ref TEXT,
  payload_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_learning_event_ts
  ON learning_event(ts, phase, kind);

CREATE TABLE IF NOT EXISTS constitutions (
  constitution_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT NOT NULL,
  constitution_hash TEXT NOT NULL,
  manifest_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_constitutions_repo_created
  ON constitutions(repo_id, created_at);

CREATE TABLE IF NOT EXISTS task_sessions (
  task_session_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  task_text_hash TEXT NOT NULL,
  current_state TEXT NOT NULL,
  pack_id TEXT,
  constitution_hash TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_task_sessions_scope_state
  ON task_sessions(workspace_id, repo_id, current_state);

CREATE TABLE IF NOT EXISTS task_session_transitions (
  transition_id TEXT PRIMARY KEY,
  task_session_id TEXT NOT NULL REFERENCES task_sessions(task_session_id) ON DELETE CASCADE,
  from_state TEXT,
  to_state TEXT NOT NULL,
  actor TEXT NOT NULL,
  reason TEXT,
  prev_hash TEXT NOT NULL,
  transition_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_task_session_transitions_session
  ON task_session_transitions(task_session_id, created_at);

CREATE TABLE IF NOT EXISTS task_plans (
  plan_id TEXT PRIMARY KEY,
  task_session_id TEXT REFERENCES task_sessions(task_session_id) ON DELETE SET NULL,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  plan_hash TEXT NOT NULL,
  status TEXT NOT NULL,
  current_revision_id TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_task_plans_session_status
  ON task_plans(task_session_id, status);

CREATE TABLE IF NOT EXISTS task_plan_revisions (
  revision_id TEXT PRIMARY KEY,
  plan_id TEXT NOT NULL REFERENCES task_plans(plan_id) ON DELETE CASCADE,
  revision_number INTEGER NOT NULL,
  plan_hash TEXT NOT NULL,
  previous_plan_hash TEXT,
  author TEXT NOT NULL,
  reason TEXT,
  plan_json TEXT NOT NULL,
  validation_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_task_plan_revisions_plan
  ON task_plan_revisions(plan_id, revision_number);

CREATE TABLE IF NOT EXISTS task_plan_checkpoints (
  checkpoint_id TEXT PRIMARY KEY,
  plan_id TEXT NOT NULL REFERENCES task_plans(plan_id) ON DELETE CASCADE,
  step_id TEXT NOT NULL,
  status TEXT NOT NULL,
  changed_paths_json TEXT NOT NULL DEFAULT '[]',
  violations_json TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_task_plan_checkpoints_plan
  ON task_plan_checkpoints(plan_id, created_at);

CREATE TABLE IF NOT EXISTS intents (
  intent_id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  snapshot_id TEXT NOT NULL REFERENCES snapshots(snapshot_id),
  problem_statement TEXT NOT NULL,
  problem_text_hash TEXT NOT NULL,
  skeleton_hash TEXT NOT NULL,
  status TEXT NOT NULL,
  selected_goal_id TEXT,
  audit_hash TEXT NOT NULL,
  prev_audit_hash TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  bound_snapshot_id TEXT,
  binding_mode TEXT NOT NULL DEFAULT 'auto',
  bound_at TEXT,
  base_commit_sha TEXT,
  worktree_state TEXT,
  staleness_state TEXT NOT NULL DEFAULT 'fresh'
);

CREATE INDEX IF NOT EXISTS idx_intents_scope
  ON intents(workspace_id, repo_id, status);

CREATE UNIQUE INDEX IF NOT EXISTS idx_intents_reproduce
  ON intents(problem_text_hash, snapshot_id);

CREATE TABLE IF NOT EXISTS intent_evidence (
  evidence_id TEXT PRIMARY KEY,
  intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
  ref TEXT NOT NULL,
  source_type TEXT NOT NULL,
  repo_id TEXT,
  path TEXT,
  symbol_identity_id TEXT,
  line_start INTEGER,
  line_end INTEGER,
  evidence_hash TEXT NOT NULL,
  confidence REAL NOT NULL DEFAULT 1.0,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_intent_evidence_intent
  ON intent_evidence(intent_id, source_type);

CREATE TABLE IF NOT EXISTS intent_decomposition_nodes (
  node_id TEXT PRIMARY KEY,
  intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
  parent_id TEXT,
  label TEXT NOT NULL,
  node_kind TEXT NOT NULL,
  origin TEXT NOT NULL,
  status TEXT NOT NULL,
  confidence REAL NOT NULL DEFAULT 1.0,
  evidence_refs_json TEXT NOT NULL DEFAULT '[]',
  ordinal INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS trust_calibration (
  calibration_id TEXT PRIMARY KEY,
  repo_id TEXT,
  source_type TEXT NOT NULL,
  default_tier TEXT NOT NULL,
  approvals INTEGER NOT NULL,
  rejections INTEGER NOT NULL,
  approval_rate REAL NOT NULL,
  sample_size INTEGER NOT NULL,
  confidence_floor REAL NOT NULL,
  method TEXT NOT NULL,
  computed_at TEXT NOT NULL,
  UNIQUE(repo_id, source_type)
);

CREATE TABLE IF NOT EXISTS extraction_eval_results (
  result_id TEXT PRIMARY KEY,
  memory_eval_run_id TEXT NOT NULL REFERENCES memory_eval_runs(memory_eval_run_id),
  repo_id TEXT,
  source_type TEXT NOT NULL,
  corpus_version TEXT NOT NULL,
  true_positive INTEGER NOT NULL,
  false_positive INTEGER NOT NULL,
  false_negative INTEGER NOT NULL,
  precision REAL NOT NULL,
  recall REAL NOT NULL,
  f1 REAL NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_extraction_eval_results_run
  ON extraction_eval_results(memory_eval_run_id, source_type);

CREATE INDEX IF NOT EXISTS idx_trust_calibration_scope
  ON trust_calibration(repo_id, source_type);

CREATE INDEX IF NOT EXISTS idx_intent_nodes_intent
  ON intent_decomposition_nodes(intent_id, parent_id, ordinal);

CREATE TABLE IF NOT EXISTS intent_hypotheses (
  hypothesis_id TEXT PRIMARY KEY,
  intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
  statement TEXT NOT NULL,
  origin TEXT NOT NULL,
  confidence REAL NOT NULL,
  rank INTEGER NOT NULL,
  verified INTEGER NOT NULL DEFAULT 0,
  evidence_refs_json TEXT NOT NULL DEFAULT '[]',
  signals_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_intent_hypotheses_intent
  ON intent_hypotheses(intent_id, rank);

CREATE TABLE IF NOT EXISTS intent_stakeholders (
  stakeholder_id TEXT PRIMARY KEY,
  intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
  owner TEXT NOT NULL,
  files_json TEXT NOT NULL DEFAULT '[]',
  reason TEXT NOT NULL,
  source TEXT NOT NULL,
  confidence REAL NOT NULL DEFAULT 1.0
);

CREATE TABLE IF NOT EXISTS intent_contradictions (
  contradiction_id TEXT PRIMARY KEY,
  intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
  a_ref TEXT NOT NULL,
  b_ref TEXT NOT NULL,
  description TEXT NOT NULL,
  detector TEXT NOT NULL,
  severity TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS intent_candidate_goals (
  goal_id TEXT PRIMARY KEY,
  intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
  statement TEXT NOT NULL,
  success_metric TEXT,
  metric_source TEXT NOT NULL,
  confidence REAL NOT NULL,
  origin TEXT NOT NULL,
  evidence_refs_json TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS intent_open_questions (
  question_id TEXT PRIMARY KEY,
  intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
  question TEXT NOT NULL,
  reason TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS goals (
  goal_id TEXT PRIMARY KEY,
  intent_id TEXT NOT NULL,
  workspace_id TEXT NOT NULL,
  repo_id TEXT,
  snapshot_id TEXT,
  statement TEXT NOT NULL,
  success_metric TEXT NOT NULL,
  metric_kind TEXT NOT NULL DEFAULT 'technical',
  metric_target TEXT,
  hypothesis TEXT,
  confidence REAL NOT NULL DEFAULT 0.0,
  status TEXT NOT NULL DEFAULT 'proposed',
  challenge_state TEXT NOT NULL DEFAULT 'none',
  permission_mode TEXT NOT NULL DEFAULT 'warn',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  bound_snapshot_id TEXT,
  binding_mode TEXT NOT NULL DEFAULT 'auto',
  bound_at TEXT,
  base_commit_sha TEXT,
  worktree_state TEXT,
  staleness_state TEXT NOT NULL DEFAULT 'fresh'
);

CREATE INDEX IF NOT EXISTS idx_goals_scope_status
  ON goals(workspace_id, repo_id, status);

CREATE INDEX IF NOT EXISTS idx_goals_intent
  ON goals(intent_id);

CREATE TABLE IF NOT EXISTS goal_evidence (
  evidence_id TEXT PRIMARY KEY,
  goal_id TEXT NOT NULL REFERENCES goals(goal_id) ON DELETE CASCADE,
  ref TEXT NOT NULL,
  source_type TEXT NOT NULL,
  weight REAL NOT NULL DEFAULT 1.0,
  detail_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_goal_evidence_goal
  ON goal_evidence(goal_id);

CREATE TABLE IF NOT EXISTS goal_alternatives (
  alt_id TEXT PRIMARY KEY,
  goal_id TEXT NOT NULL REFERENCES goals(goal_id) ON DELETE CASCADE,
  statement TEXT NOT NULL,
  projected_metric_delta TEXT NOT NULL,
  rationale TEXT NOT NULL,
  confidence REAL NOT NULL DEFAULT 0.0,
  evidence_refs_json TEXT NOT NULL DEFAULT '[]',
  rank INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'proposed',
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_goal_alternatives_goal
  ON goal_alternatives(goal_id, rank);

CREATE TABLE IF NOT EXISTS goal_decisions (
  decision_id TEXT PRIMARY KEY,
  goal_id TEXT NOT NULL REFERENCES goals(goal_id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  alt_id TEXT,
  actor TEXT NOT NULL,
  rationale TEXT,
  permission_mode TEXT NOT NULL,
  audit_row_hash TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_goal_decisions_goal
  ON goal_decisions(goal_id, created_at);
