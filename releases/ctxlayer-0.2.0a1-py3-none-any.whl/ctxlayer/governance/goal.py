from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Callable

from ctxlayer.audit import AuditLog
from ctxlayer.config import Settings
from ctxlayer.governance.policy import CapabilityPolicy
from ctxlayer.impact import ImpactEngine
from ctxlayer.memory.unified import UnifiedMemory
from ctxlayer.snapshot import SnapshotInfo
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import canonical_json, stable_id, utc_now

EventLogger = Callable[[str, str, str | None, dict[str, Any]], None]


class GoalGovernance:
    def __init__(
        self,
        repo_root: Path,
        store: SQLiteStore,
        settings: Settings,
        impact: ImpactEngine,
        audit: AuditLog,
        *,
        workspace_id: str,
        event_logger: EventLogger | None = None,
    ):
        self.repo_root = repo_root
        self.store = store
        self.settings = settings
        self.impact = impact
        self.audit = audit
        self.workspace_id = workspace_id
        self.event_logger = event_logger

    def evaluate(
        self,
        *,
        intent_id: str,
        snapshot: SnapshotInfo,
        candidate_goal_id: str | None = None,
        mode: str | None = None,
    ) -> dict[str, Any]:
        intent = self.store.intent(intent_id)
        if intent is None:
            raise KeyError(f"intent artifact not found: {intent_id}")
        if intent["snapshot_id"] != snapshot.snapshot_id:
            raise ValueError("intent snapshot differs from current snapshot; recreate the intent first")
        candidate = self._candidate_goal(intent_id, candidate_goal_id)
        goal_id = stable_id("goal", self.workspace_id, snapshot.repo_id, intent_id, candidate["goal_id"])
        existing = self.store.goal(goal_id)
        goal_surface = self._goal_surface(intent_id)
        impact_report = self.impact.report(snapshot=snapshot, paths=goal_surface) if goal_surface else {}
        goal_evidence = self._intent_goal_evidence(goal_id, intent_id)
        metric_surface, metric_evidence = self._metric_surface(
            goal_id=goal_id,
            repo_id=snapshot.repo_id,
            success_metric=str(candidate["success_metric"] or ""),
        )
        goal_evidence.extend(metric_evidence)
        analysis = self._analyze(
            success_metric=str(candidate["success_metric"] or ""),
            goal_surface=goal_surface,
            metric_surface=metric_surface,
            impact_report=impact_report,
            evidence=goal_evidence,
        )
        permission = self._resolve_permission_mode(mode, analysis["confidence"])
        metadata = {
            "candidate_goal_id": candidate["goal_id"],
            "goal_surface": goal_surface,
            "metric_surface": metric_surface,
            "impact": _impact_summary(impact_report),
            "projected_metric_delta": analysis["projected_metric_delta"],
            "mismatch": analysis["mismatch"],
            "evaluation_digest": analysis["evaluation_digest"],
            "permission_resolution": permission,
        }
        goal = {
            "goal_id": goal_id,
            "intent_id": intent_id,
            "workspace_id": self.workspace_id,
            "repo_id": snapshot.repo_id,
            "snapshot_id": snapshot.snapshot_id,
            "statement": candidate["statement"],
            "success_metric": candidate["success_metric"] or "unspecified success metric",
            "metric_kind": "runtime" if metric_surface else "technical",
            "metric_target": None,
            "hypothesis": f"Candidate goal from intent {intent_id} should move: {candidate['success_metric'] or 'unspecified metric'}",
            "confidence": analysis["confidence"],
            "status": existing["status"] if existing else "proposed",
            "challenge_state": existing["challenge_state"] if existing else "none",
            "permission_mode": permission["mode"],
            "created_at": existing["created_at"] if existing else utc_now(),
            "updated_at": utc_now(),
            "metadata": metadata,
        }
        audit = self.audit.record_goal(
            {
                "kind": "goal_created",
                "goal_id": goal_id,
                "intent_id": intent_id,
                "snapshot_id": snapshot.snapshot_id,
                "permission_mode": permission["mode"],
                "projected_metric_delta": analysis["projected_metric_delta"],
            }
        )
        self.store.upsert_goal(goal)
        self.store.replace_goal_evidence(goal_id, goal_evidence)
        self.store.replace_goal_alternatives(goal_id, analysis["alternatives"])
        self.store.record_goal_decision(
            goal_id=goal_id,
            kind="goal_created",
            actor="system",
            permission_mode=permission["mode"],
            audit_row_hash=audit["row_hash"],
            decision_id=stable_id("goal_decision", goal_id, "goal_created", analysis["evaluation_digest"]),
        )
        self._event("goal_evaluated", goal_id, {"intent_id": intent_id, "mismatch": analysis["mismatch"]})
        return self.show(goal_id)

    def show(self, goal_id: str) -> dict[str, Any]:
        row = self.store.goal(goal_id)
        if row is None:
            raise KeyError(f"goal not found: {goal_id}")
        return _goal_view(
            row,
            evidence=self.store.goal_evidence(goal_id),
            alternatives=self.store.goal_alternatives(goal_id),
            decisions=self.store.goal_decisions(goal_id),
        )

    def list(self, *, repo_id: str | None = None, status: str | None = None, limit: int = 50) -> dict[str, Any]:
        rows = [dict(row) for row in self.store.list_goals(repo_id=repo_id, status=status, limit=limit)]
        return {"ok": True, "count": len(rows), "goals": rows}

    def challenge(self, goal_id: str) -> dict[str, Any]:
        view = self.show(goal_id)
        alternatives = [alt for alt in view["alternatives"] if alt["status"] == "proposed"]
        if not alternatives:
            return {"ok": True, "goal_id": goal_id, "surfaced": False, "challenge": None}
        top = alternatives[0]
        evidence = [row for row in view["evidence"] if row["evidence_id"] in top["evidence_refs"]]
        if not evidence or not top.get("projected_metric_delta"):
            return {"ok": True, "goal_id": goal_id, "surfaced": False, "challenge": None}
        mode = view["permission_mode"]
        surfaced = mode != "silent"
        state = "challenged" if mode == "pause-and-challenge" else "warned" if mode == "warn" else "none"
        audit = self.audit.record_goal(
            {
                "kind": "goal_challenge",
                "goal_id": goal_id,
                "intent_id": view["intent_id"],
                "snapshot_id": view["snapshot_id"],
                "permission_mode": mode,
                "challenge_state": state,
                "alt_id": top["alt_id"],
                "projected_metric_delta": top["projected_metric_delta"],
            }
        )
        self.store.update_goal(goal_id, challenge_state=state)
        self.store.record_goal_decision(
            goal_id=goal_id,
            kind="challenge_emitted",
            actor="system",
            permission_mode=mode,
            alt_id=top["alt_id"],
            rationale=top["rationale"],
            audit_row_hash=audit["row_hash"],
        )
        self._event("goal_challenge", goal_id, {"alt_id": top["alt_id"], "surfaced": surfaced})
        return {
            "ok": True,
            "goal_id": goal_id,
            "surfaced": surfaced,
            "challenge": None
            if not surfaced
            else {
                "recommend": top["statement"],
                "instead_of": view["statement"],
                "projected_metric_delta": top["projected_metric_delta"],
                "evidence": evidence,
                "confidence": top["confidence"],
            },
            "alternative": top,
        }

    def accept_alternative(
        self,
        *,
        goal_id: str,
        alt_id: str,
        rationale: str,
        memory: UnifiedMemory | None = None,
        actor: str = "local-user",
    ) -> dict[str, Any]:
        return self._decide_alternative(
            goal_id=goal_id,
            alt_id=alt_id,
            rationale=rationale,
            actor=actor,
            accepted=True,
            memory=memory,
        )

    def reject_alternative(
        self,
        *,
        goal_id: str,
        alt_id: str,
        rationale: str,
        actor: str = "local-user",
    ) -> dict[str, Any]:
        return self._decide_alternative(
            goal_id=goal_id,
            alt_id=alt_id,
            rationale=rationale,
            actor=actor,
            accepted=False,
            memory=None,
        )

    def reevaluate(self, *, goal_id: str, snapshot: SnapshotInfo, trigger: str) -> dict[str, Any]:
        current = self.show(goal_id)
        updated = self.evaluate(
            intent_id=current["intent_id"],
            snapshot=snapshot,
            candidate_goal_id=current["metadata"].get("candidate_goal_id"),
            mode=current["permission_mode"],
        )
        digest = updated["metadata"].get("evaluation_digest") or ""
        audit = self.audit.record_goal(
            {
                "kind": "goal_decision",
                "goal_id": goal_id,
                "intent_id": updated["intent_id"],
                "snapshot_id": snapshot.snapshot_id,
                "permission_mode": updated["permission_mode"],
            }
        )
        self.store.record_goal_decision(
            goal_id=goal_id,
            kind="reevaluated",
            actor="continuation",
            permission_mode=updated["permission_mode"],
            rationale=trigger,
            audit_row_hash=audit["row_hash"],
            decision_id=stable_id("goal_decision", goal_id, "reevaluated", trigger, digest),
        )
        self._event("goal_reevaluated", goal_id, {"trigger": trigger})
        return self.show(goal_id)

    def _decide_alternative(
        self,
        *,
        goal_id: str,
        alt_id: str,
        rationale: str,
        actor: str,
        accepted: bool,
        memory: UnifiedMemory | None,
    ) -> dict[str, Any]:
        view = self.show(goal_id)
        alt = self.store.goal_alternative(alt_id)
        if alt is None or alt["goal_id"] != goal_id:
            raise ValueError(f"alternative does not belong to goal: {alt_id}")
        kind = "alternative_accepted" if accepted else "alternative_rejected"
        audit = self.audit.record_goal(
            {
                "kind": "goal_decision",
                "goal_id": goal_id,
                "intent_id": view["intent_id"],
                "snapshot_id": view["snapshot_id"],
                "permission_mode": view["permission_mode"],
                "alt_id": alt_id,
            }
        )
        self.store.set_goal_alternative_status(alt_id, "accepted" if accepted else "rejected")
        self.store.record_goal_decision(
            goal_id=goal_id,
            kind=kind,
            actor=actor,
            permission_mode=view["permission_mode"],
            alt_id=alt_id,
            rationale=rationale,
            audit_row_hash=audit["row_hash"],
        )
        if accepted:
            self.store.update_goal(goal_id, status="redirected", challenge_state="redirected")
            if memory is not None:
                memory.propose(
                    record_type="decision",
                    assertion=f"Accepted goal alternative for {goal_id}: {alt['statement']}",
                    source_kind="goal_governance",
                    confidence=1.0,
                    status="approved",
                    trust="approved",
                    provenance={
                        "generator": "human",
                        "validator": "human",
                        "input_source": "goal_governance",
                    },
                    metadata={
                        "rationale": rationale,
                        "alternatives": [view["statement"], alt["statement"]],
                        "goal_id": goal_id,
                        "alt_id": alt_id,
                    },
                    title="Goal alternative accepted",
                    importance=0.8,
                )
        self._event("goal_decision", goal_id, {"kind": kind, "alt_id": alt_id})
        return self.show(goal_id)

    def _candidate_goal(self, intent_id: str, candidate_goal_id: str | None) -> dict[str, Any]:
        candidates = [dict(row) for row in self.store.intent_candidate_goals(intent_id)]
        if not candidates:
            raise ValueError(f"intent has no candidate goals: {intent_id}")
        if candidate_goal_id:
            for candidate in candidates:
                if candidate["goal_id"] == candidate_goal_id:
                    return candidate
            raise ValueError(f"candidate goal does not belong to intent: {candidate_goal_id}")
        deterministic = [row for row in candidates if row.get("origin") == "deterministic"]
        return sorted(deterministic or candidates, key=lambda row: (-float(row["confidence"]), row["goal_id"]))[0]

    def _goal_surface(self, intent_id: str) -> list[str]:
        return sorted({row["path"] for row in self.store.intent_evidence(intent_id) if row["path"]})

    def _intent_goal_evidence(self, goal_id: str, intent_id: str) -> list[dict[str, Any]]:
        rows = []
        for row in self.store.intent_evidence(intent_id):
            ref = row["path"] or row["ref"]
            rows.append(
                {
                    "evidence_id": stable_id("goal_evidence", goal_id, "intent", row["evidence_id"]),
                    "goal_id": goal_id,
                    "ref": ref,
                    "source_type": "intent",
                    "weight": float(row["confidence"] or 1.0),
                    "detail": {
                        "intent_evidence_id": row["evidence_id"],
                        "path": row["path"],
                        "source_type": row["source_type"],
                    },
                    "created_at": utc_now(),
                }
            )
        return rows

    def _metric_surface(
        self, *, goal_id: str, repo_id: str, success_metric: str
    ) -> tuple[list[str], list[dict[str, Any]]]:
        tokens = _tokens(success_metric)
        rows = self.store.conn.execute(
            """
            SELECT * FROM runtime_events
            WHERE repo_id = ? AND path IS NOT NULL
            ORDER BY severity DESC, created_at DESC, runtime_event_id
            """,
            (repo_id,),
        ).fetchall()
        surfaces: list[str] = []
        evidence: list[dict[str, Any]] = []
        for row in rows:
            haystack = f"{row['title']} {row['message']} {row['path']}".casefold()
            if tokens and not any(token in haystack for token in tokens):
                continue
            path = str(row["path"])
            surfaces.append(path)
            evidence.append(
                {
                    "evidence_id": stable_id("goal_evidence", goal_id, "runtime", row["runtime_event_id"]),
                    "goal_id": goal_id,
                    "ref": row["runtime_event_id"],
                    "source_type": "runtime_event",
                    "weight": _severity_weight(row["severity"]),
                    "detail": {
                        "path": path,
                        "title": row["title"],
                        "severity": row["severity"],
                        "event_hash": row["event_hash"],
                    },
                    "created_at": utc_now(),
                }
            )
        return sorted(set(surfaces)), evidence

    def _analyze(
        self,
        *,
        success_metric: str,
        goal_surface: list[str],
        metric_surface: list[str],
        impact_report: dict[str, Any],
        evidence: list[dict[str, Any]],
    ) -> dict[str, Any]:
        impacted = set(impact_report.get("impacted_paths") or goal_surface)
        metric = set(metric_surface)
        intersection = sorted(impacted & metric)
        mismatch = bool(metric_surface) and not intersection
        evidence_refs = [row["evidence_id"] for row in evidence if row["source_type"] == "runtime_event"]
        if not evidence_refs:
            evidence_refs = [row["evidence_id"] for row in evidence[:1]]
        if mismatch:
            stated_delta = {
                "metric": success_metric or "unspecified success metric",
                "direction": "neutral",
                "magnitude": "near_zero",
                "reason": "goal surface does not intersect metric-attributed runtime surface",
            }
            alt_delta = {
                "metric": success_metric or "unspecified success metric",
                "direction": "improve",
                "magnitude": "material",
                "reason": "alternative targets metric-attributed runtime surface",
            }
            alternatives = [
                {
                    "alt_id": stable_id("goal_alt", evidence_refs, metric_surface, success_metric),
                    "statement": f"Target {', '.join(metric_surface[:3])} before changing {', '.join(goal_surface[:3])}",
                    "projected_metric_delta": alt_delta,
                    "rationale": "Runtime evidence attributes the metric to a different surface than the stated goal.",
                    "confidence": 0.85,
                    "evidence_refs": evidence_refs,
                    "rank": 1,
                    "status": "proposed",
                    "created_at": utc_now(),
                }
            ]
            confidence = 0.85
        else:
            stated_delta = {
                "metric": success_metric or "unspecified success metric",
                "direction": "unknown" if not metric_surface else "improve",
                "magnitude": "insufficient_evidence" if not metric_surface else "plausible",
                "reason": "no wrong-layer mismatch detected",
            }
            alternatives = []
            confidence = 0.45 if not metric_surface else 0.75
        digest = stable_id(
            "goal_evaluation",
            canonical_json(goal_surface),
            canonical_json(metric_surface),
            canonical_json(intersection),
            canonical_json(stated_delta),
        )
        return {
            "mismatch": mismatch,
            "confidence": confidence,
            "projected_metric_delta": stated_delta,
            "alternatives": alternatives,
            "evaluation_digest": digest,
        }

    def _resolve_permission_mode(self, override: str | None, confidence: float) -> dict[str, Any]:
        policy = CapabilityPolicy(self.repo_root, self.settings).manifest.get("goal_governance", {})
        requested = override or str(policy.get("mode") or "warn")
        if requested not in {"silent", "warn", "pause-and-challenge"}:
            requested = "warn"
        threshold = _float(policy.get("challenge_min_confidence"), 0.6)
        downgraded = requested == "pause-and-challenge" and confidence < threshold
        return {
            "requested": requested,
            "mode": "warn" if downgraded else requested,
            "challenge_min_confidence": threshold,
            "downgraded": downgraded,
        }

    def _event(self, kind: str, ref: str, payload: dict[str, Any]) -> None:
        if self.event_logger is not None:
            self.event_logger("A2", kind, ref, payload)


def _goal_view(
    row: Any, *, evidence: list[Any], alternatives: list[Any], decisions: list[Any]
) -> dict[str, Any]:
    item = dict(row)
    item["metadata"] = _json_obj(item.pop("metadata_json", "{}"))
    item["evidence"] = [_evidence_view(evidence_row) for evidence_row in evidence]
    item["alternatives"] = [_alternative_view(alt) for alt in alternatives]
    item["decisions"] = [dict(decision) for decision in decisions]
    return item


def _evidence_view(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["detail"] = _json_obj(item.pop("detail_json", "{}"))
    return item


def _alternative_view(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["projected_metric_delta"] = _json_obj(item["projected_metric_delta"])
    item["evidence_refs"] = _json_list(item.pop("evidence_refs_json", "[]"))
    return item


def _impact_summary(report: dict[str, Any]) -> dict[str, Any]:
    return {
        "impacted_paths": report.get("impacted_paths") or [],
        "risk": report.get("risk") or {},
        "tests": report.get("tests") or [],
    }


def _tokens(value: str) -> set[str]:
    return {part for part in re.split(r"[^a-z0-9]+", value.casefold()) if len(part) > 2}


def _severity_weight(value: str) -> float:
    token = str(value or "").casefold()
    return {"critical": 1.0, "high": 0.9, "medium": 0.7, "low": 0.5}.get(token, 0.6)


def _json_obj(value: str) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _json_list(value: str) -> list[Any]:
    try:
        parsed = json.loads(value or "[]")
    except json.JSONDecodeError:
        return []
    return parsed if isinstance(parsed, list) else []


def _float(value: Any, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default
