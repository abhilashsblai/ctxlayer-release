from __future__ import annotations

from pathlib import Path


def load(path: Path) -> list[dict[str, str]]:
    text = path.read_text(encoding="utf-8", errors="replace")
    return [{"title": "CI failure", "message": text[:1000], "path": None, "severity": "medium"}]
