from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ctxlayer.store import SQLiteStore
from ctxlayer.utils import canonical_json, stable_id, utc_now


class SemanticRepairQueue:
    def __init__(self, repo_root: Path, store: SQLiteStore):
        self.repo_root = repo_root
        self.store = store

    def list(
        self,
        *,
        repo_id: str,
        status: str | None = "open",
        limit: int = 100,
    ) -> dict[str, Any]:
        return {
            "ok": True,
            "schema_version": "ctxlayer.semantic_repair.v1",
            "repo_id": repo_id,
            "status": status,
            "findings": [
                _finding_dict(row)
                for row in self.store.semantic_drift_findings(
                    repo_id,
                    status=status,
                    limit=limit,
                )
            ],
        }

    def confirm(
        self,
        finding_id: str,
        *,
        actor: str = "human",
        rationale: str = "",
    ) -> dict[str, Any]:
        row = self.store.semantic_drift_finding(finding_id)
        if row is None:
            raise KeyError(f"semantic drift finding not found: {finding_id}")
        finding = _finding_dict(row)
        action = "confirmed"
        changed: dict[str, Any] = {}
        if finding["finding_type"] == "stale_node" and finding.get("node_id"):
            changed["deleted_node"] = self.store.delete_semantic_node(str(finding["node_id"]))
            action = "repaired"
        elif finding["finding_type"] == "low_confidence":
            if finding.get("node_id"):
                node = self.store.semantic_node(str(finding["node_id"]))
                if node:
                    metadata = json.loads(node["metadata_json"] or "{}")
                    provenance = metadata.get("provenance")
                    if not isinstance(provenance, dict):
                        provenance = {}
                    provenance["human_verified"] = True
                    provenance["verified_by"] = actor
                    provenance["verified_at"] = utc_now()
                    metadata["provenance"] = provenance
                    self.store.update_semantic_node_metadata(
                        str(finding["node_id"]),
                        metadata,
                        confidence=max(0.8, float(node["confidence"] or 0.0)),
                    )
                    changed["verified_node"] = finding["node_id"]
            if finding.get("edge_id"):
                edge = next(
                    (
                        item
                        for item in self.store.semantic_edges(finding["repo_id"])
                        if item["edge_id"] == finding["edge_id"]
                    ),
                    None,
                )
                if edge:
                    metadata = json.loads(edge["metadata_json"] or "{}")
                    provenance = metadata.get("provenance")
                    if not isinstance(provenance, dict):
                        provenance = {}
                    provenance["human_verified"] = True
                    provenance["verified_by"] = actor
                    provenance["verified_at"] = utc_now()
                    metadata["provenance"] = provenance
                    self.store.update_semantic_edge_metadata(
                        str(finding["edge_id"]),
                        metadata,
                        confidence=max(0.8, float(edge["confidence"] or 0.0)),
                    )
                    changed["verified_edge"] = finding["edge_id"]
        audit = _decision_audit(finding, action, actor=actor, rationale=rationale)
        self.store.update_semantic_drift_finding(
            finding_id,
            status=action,
            audit_hash=audit["audit_hash"],
            prev_audit_hash=audit["prev_audit_hash"],
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.semantic_repair_decision.v1",
            "finding_id": finding_id,
            "status": action,
            "changed": changed,
            "audit_hash": audit["audit_hash"],
            "prev_audit_hash": audit["prev_audit_hash"],
        }

    def reject(
        self,
        finding_id: str,
        *,
        actor: str = "human",
        rationale: str = "",
    ) -> dict[str, Any]:
        row = self.store.semantic_drift_finding(finding_id)
        if row is None:
            raise KeyError(f"semantic drift finding not found: {finding_id}")
        finding = _finding_dict(row)
        audit = _decision_audit(finding, "rejected", actor=actor, rationale=rationale)
        self.store.update_semantic_drift_finding(
            finding_id,
            status="rejected",
            audit_hash=audit["audit_hash"],
            prev_audit_hash=audit["prev_audit_hash"],
        )
        return {
            "ok": True,
            "schema_version": "ctxlayer.semantic_repair_decision.v1",
            "finding_id": finding_id,
            "status": "rejected",
            "audit_hash": audit["audit_hash"],
            "prev_audit_hash": audit["prev_audit_hash"],
        }


def _finding_dict(row: Any) -> dict[str, Any]:
    return {
        "finding_id": row["finding_id"],
        "repo_id": row["repo_id"],
        "snapshot_id": row["snapshot_id"],
        "finding_type": row["finding_type"],
        "type": row["finding_type"],
        "severity": row["severity"],
        "node_id": row["node_id"],
        "edge_id": row["edge_id"],
        "paths": json.loads(row["paths_json"] or "[]"),
        "detail": row["detail"],
        "confidence": row["confidence"],
        "status": row["status"],
        "detected_at": row["detected_at"],
        "resolved_at": row["resolved_at"],
        "audit_hash": row["audit_hash"],
        "prev_audit_hash": row["prev_audit_hash"],
    }


def _decision_audit(
    finding: dict[str, Any],
    decision: str,
    *,
    actor: str,
    rationale: str,
) -> dict[str, str]:
    prev_hash = str(finding.get("audit_hash") or "")
    payload = {
        "finding_id": finding["finding_id"],
        "decision": decision,
        "actor": actor,
        "rationale": rationale,
        "prev_audit_hash": prev_hash,
    }
    return {
        "prev_audit_hash": prev_hash,
        "audit_hash": stable_id(prev_hash, canonical_json(payload)),
    }
