from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


def extract(repo_root: Path) -> list[dict[str, Any]]:
    contracts: list[dict[str, Any]] = []
    for path in [*repo_root.rglob("*openapi*.json"), *repo_root.rglob("*swagger*.json")]:
        rel = path.relative_to(repo_root).as_posix()
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        for route in sorted((data.get("paths") or {}).keys()):
            contracts.append(
                {"path": rel, "kind": "provides_api", "name": route, "metadata": {"format": "openapi"}}
            )
    for path in [*repo_root.rglob("*openapi*.yaml"), *repo_root.rglob("*swagger*.yml")]:
        text = path.read_text(encoding="utf-8", errors="replace")
        rel = path.relative_to(repo_root).as_posix()
        for route in sorted(set(re.findall(r"^\s{0,4}(/[^:\s]+):", text, flags=re.MULTILINE))):
            contracts.append(
                {"path": rel, "kind": "provides_api", "name": route, "metadata": {"format": "openapi"}}
            )
    for path in repo_root.rglob("*client*.*"):
        if path.suffix.lower() not in {".ts", ".tsx", ".js", ".py"}:
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        for route in sorted(set(re.findall(r"['\"](/api/[^'\"]+)['\"]", text))):
            contracts.append(
                {
                    "path": path.relative_to(repo_root).as_posix(),
                    "kind": "consumes_api",
                    "name": route,
                    "metadata": {"signal": "generated_client"},
                }
            )
    return contracts
