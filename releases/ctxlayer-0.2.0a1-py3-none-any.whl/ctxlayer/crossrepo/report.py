from __future__ import annotations

from typing import Any


def impact_report(changed_repo: str, impacts: list[dict[str, Any]]) -> dict[str, Any]:
    direct = [
        {
            "repo": item["dst_repo_id"],
            "path": item["dst_path"],
            "kind": item["kind"],
            "confidence": item["confidence"],
        }
        for item in impacts
        if item["src_repo_id"] == changed_repo
    ]
    return {
        "scope": "workspace",
        "changed_repo": changed_repo,
        "direct_impacts": direct,
        "suggested_checks": [
            {"repo": item["repo"], "command": f"run tests covering {item['path']}"} for item in direct
        ],
    }
