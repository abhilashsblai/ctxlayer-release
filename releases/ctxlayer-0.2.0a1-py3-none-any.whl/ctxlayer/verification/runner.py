from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any

from ctxlayer.compiler import ContextCompiler
from ctxlayer.snapshot import SnapshotInfo
from ctxlayer.utils import sha256_text, stable_id


class VerificationRunner:
    def __init__(self, repo_root: Path, compiler: ContextCompiler):
        self.repo_root = repo_root
        self.compiler = compiler

    def run(
        self,
        *,
        snapshot: SnapshotInfo,
        commands: list[str],
        pack_id: str | None = None,
        retry_budget: int = 0,
        timeout: int = 120,
        reproduction_command: str | None = None,
        context_decision: str | None = None,
    ) -> dict[str, Any]:
        # Ask-or-assume: if the pre-edit context-sufficiency gate decided to abstain, do not
        # spend retry budget guessing — surface an escalation instead of a repair loop.
        if context_decision == "abstain":
            return {
                "ok": False,
                "schema_version": "ctxlayer.verification_report.v1",
                "verification_id": stable_id(snapshot.snapshot_id, pack_id or "", commands),
                "pack_id": pack_id,
                "retry_budget": retry_budget,
                "attempts": [],
                "failures": [],
                "repair_pack": None,
                "status": "abstain_escalate",
            }
        # Reproduction-test-first: the reproduction_command slot is the PRE-repair baseline and
        # must be RED. A red reproduction is a genuine failure that drives repair (and seeds the
        # repair pack). A green reproduction does not actually reproduce the bug, so the run
        # cannot be trusted as a pass — it is reported as an invalid reproduction. Either way a
        # supplied reproduction_command never yields status=pass; post-repair confirmation runs
        # the (now-green) test via `commands` instead (stronger, less-gameable oracle —
        # arXiv:2601.19066).
        reproduction = None
        if reproduction_command:
            repro_result = self._run_command(reproduction_command, timeout)
            reproduction = {
                **repro_result,
                "is_red": not repro_result["ok"],
                "valid_reproduction": not repro_result["ok"],
            }

        attempts = []
        for command in commands:
            attempts.append(self._run_command(command, timeout))
        failures = [item for item in attempts if not item["ok"]]

        repro_red = bool(reproduction and reproduction["is_red"])
        repro_invalid = bool(reproduction and not reproduction["is_red"])
        needs_repair = bool(failures) or repro_red

        repair_pack = None
        if needs_repair:
            failure_lines = [
                f"- {item['command']}: {item['failure_hash']}" for item in failures
            ]
            seed_commands = list(failures)
            if repro_red:
                failure_lines.append(
                    f"- reproduction (must turn green): {reproduction['command']}"
                )
                seed_commands = [*failures, reproduction]
            task = "Repair verification failures:\n" + "\n".join(failure_lines)
            repair_pack = self.compiler.compile(
                snapshot=snapshot,
                task=task,
                seed_paths=_seed_paths_from_failures(seed_commands),
                write=False,
            )

        if repro_invalid:
            ok, status = False, "invalid_reproduction"
        elif needs_repair:
            ok, status = False, "repair_required"
        else:
            ok, status = True, "pass"

        return {
            "ok": ok,
            "schema_version": "ctxlayer.verification_report.v1",
            "verification_id": stable_id(snapshot.snapshot_id, pack_id or "", commands, attempts),
            "pack_id": pack_id,
            "retry_budget": retry_budget,
            "reproduction": reproduction,
            "attempts": attempts,
            "failures": failures,
            "repair_pack": repair_pack,
            "status": status,
        }

    def _run_command(self, command: str, timeout: int) -> dict[str, Any]:
        result = subprocess.run(
            command,
            cwd=self.repo_root,
            shell=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
        )
        return {
            "command": command,
            "returncode": result.returncode,
            "ok": result.returncode == 0,
            "stdout_tail": result.stdout[-4000:],
            "stderr_tail": result.stderr[-4000:],
            "failure_hash": sha256_text(result.stdout + result.stderr)
            if result.returncode != 0
            else None,
        }


def _seed_paths_from_failures(failures: list[dict[str, Any]]) -> list[str]:
    seeds = []
    for failure in failures:
        for token in str(failure["command"]).split():
            normalized = token.strip("'\"").replace("\\", "/")
            if "/" in normalized and "." in normalized:
                seeds.append(normalized)
    return sorted(set(seeds))
