from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from ctxlayer.snapshot import SnapshotInfo
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import sha256_text, stable_id

IGNORE_PREFIXES = (".git/", ".ctxlayer/", "__pycache__/")


def collect_evidence(
    *,
    repo_root: Path,
    store: SQLiteStore,
    snapshot: SnapshotInfo,
    intent_id: str,
    problem: str,
    limit: int = 8,
) -> list[dict[str, Any]]:
    tokens = _tokens(problem)
    scored: dict[str, dict[str, Any]] = {}
    for idx, row in enumerate(store.search_chunks(snapshot.snapshot_id, problem, limit=limit * 4)):
        item = _from_chunk(intent_id, snapshot.repo_id, row, 1.0 / (idx + 1), "index")
        scored[item["ref"]] = _merge(scored.get(item["ref"]), item)
    for row in store.snapshot_files(snapshot.snapshot_id):
        path = str(row["path"])
        if path.startswith(IGNORE_PREFIXES):
            continue
        score = _path_score(path, tokens)
        if score <= 0:
            continue
        item = _from_file(repo_root, intent_id, snapshot.repo_id, row, score)
        scored[item["ref"]] = _merge(scored.get(item["ref"]), item)
    if not scored:
        for row in store.snapshot_files(snapshot.snapshot_id)[:limit]:
            item = _from_file(repo_root, intent_id, snapshot.repo_id, row, 0.2)
            scored[item["ref"]] = _merge(scored.get(item["ref"]), item)
    return sorted(scored.values(), key=lambda item: (-float(item["confidence"]), item["ref"]))[:limit]


def _from_chunk(
    intent_id: str, repo_id: str, row: Any, confidence: float, source_type: str
) -> dict[str, Any]:
    path = str(row["path"])
    ref = path
    text = str(row.get("text") if isinstance(row, dict) else row["text"])
    evidence_hash = sha256_text(f"{path}\n{text}")
    return {
        "evidence_id": stable_id("intent_evidence", intent_id, ref, evidence_hash),
        "intent_id": intent_id,
        "ref": ref,
        "source_type": source_type,
        "repo_id": repo_id,
        "path": path,
        "symbol_identity_id": row["symbol_identity_id"],
        "line_start": row["start_line"],
        "line_end": row["end_line"],
        "evidence_hash": evidence_hash,
        "confidence": round(min(1.0, max(0.1, confidence)), 4),
        "metadata": {"chunk_id": row["chunk_id"], "token_count": row["token_count"]},
    }


def _from_file(repo_root: Path, intent_id: str, repo_id: str, row: Any, confidence: float) -> dict[str, Any]:
    path = str(row["path"])
    full_path = repo_root / path
    if full_path.is_file():
        content = full_path.read_text(encoding="utf-8", errors="replace")[:4000]
    else:
        content = str(row["skeleton"] or "")
    evidence_hash = sha256_text(f"{path}\n{content}")
    return {
        "evidence_id": stable_id("intent_evidence", intent_id, path, evidence_hash),
        "intent_id": intent_id,
        "ref": path,
        "source_type": "index",
        "repo_id": repo_id,
        "path": path,
        "symbol_identity_id": None,
        "line_start": None,
        "line_end": None,
        "evidence_hash": evidence_hash,
        "confidence": round(min(1.0, max(0.1, confidence)), 4),
        "metadata": {"lang": row["lang"], "loc": row["loc"]},
    }


def _merge(left: dict[str, Any] | None, right: dict[str, Any]) -> dict[str, Any]:
    if left is None:
        return right
    if float(right["confidence"]) > float(left["confidence"]):
        left.update(right)
    return left


def _tokens(problem: str) -> set[str]:
    return {part for part in re.split(r"[^a-z0-9]+", problem.casefold()) if len(part) > 2}


def _path_score(path: str, tokens: set[str]) -> float:
    lowered = path.casefold()
    score = 0.0
    for token in tokens:
        if token in lowered:
            score += 0.25
    if any(part in lowered for part in ("service", "route", "controller", "handler", "model")):
        score += 0.35
    if any(part in lowered for part in ("test", "spec")):
        score += 0.2
    return round(score, 4)
