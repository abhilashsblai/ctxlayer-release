from __future__ import annotations

from typing import Any

from ctxlayer.utils import stable_id, utc_now


def build_skeleton(*, intent_id: str, problem: str, evidence: list[dict[str, Any]]) -> list[dict[str, Any]]:
    problem_class = classify_problem(problem)
    refs = [row["evidence_id"] for row in evidence]
    root_id = stable_id("intent_node", intent_id, "root", problem_class)
    nodes = [
        _node(
            intent_id=intent_id,
            node_id=root_id,
            parent_id=None,
            label=f"{problem_class.title()} framing for: {problem}",
            node_kind="root",
            evidence_refs=refs,
            ordinal=0,
        )
    ]
    for ordinal, row in enumerate(evidence[:5], start=1):
        path = row.get("path") or row["ref"]
        nodes.append(
            _node(
                intent_id=intent_id,
                node_id=stable_id("intent_node", intent_id, "evidence", path),
                parent_id=root_id,
                label=f"Inspect {path} for contribution to {problem_class}",
                node_kind="subsystem",
                evidence_refs=[row["evidence_id"]],
                ordinal=ordinal,
            )
        )
    if not evidence:
        nodes.append(
            _node(
                intent_id=intent_id,
                node_id=stable_id("intent_node", intent_id, "question", "no_evidence"),
                parent_id=root_id,
                label="Locate code or runtime evidence before choosing implementation scope",
                node_kind="question",
                evidence_refs=[],
                ordinal=1,
            )
        )
    return nodes


def classify_problem(problem: str) -> str:
    lowered = problem.casefold()
    if any(word in lowered for word in ("slow", "latency", "performance", "timeout", "speed")):
        return "performance"
    if any(word in lowered for word in ("bug", "error", "fail", "broken", "regression", "reliability")):
        return "correctness"
    if any(word in lowered for word in ("reduce", "scope", "cleanup", "simplify")):
        return "scope-reduction"
    return "feature"


def _node(
    *,
    intent_id: str,
    node_id: str,
    parent_id: str | None,
    label: str,
    node_kind: str,
    evidence_refs: list[str],
    ordinal: int,
) -> dict[str, Any]:
    return {
        "node_id": node_id,
        "intent_id": intent_id,
        "parent_id": parent_id,
        "label": label,
        "node_kind": node_kind,
        "origin": "deterministic",
        "status": "evidence_linked" if evidence_refs else "unverified",
        "confidence": 1.0,
        "evidence_refs": sorted(evidence_refs),
        "ordinal": ordinal,
        "created_at": utc_now(),
    }
