from __future__ import annotations

from typing import Any

from ctxlayer.utils import stable_id, utc_now


def propose(*, intent_id: str, problem: str) -> dict[str, list[dict[str, Any]]]:
    node_id = stable_id("intent_llm_node", intent_id, problem)
    hypothesis_id = stable_id("intent_llm_hypothesis", intent_id, problem)
    goal_statement = f"Validate an alternative framing for '{problem}' before implementation"
    return {
        "nodes": [
            {
                "node_id": node_id,
                "intent_id": intent_id,
                "parent_id": None,
                "label": goal_statement,
                "node_kind": "question",
                "origin": "llm_proposed",
                "status": "unverified",
                "confidence": 0.35,
                "evidence_refs": [],
                "ordinal": 900,
                "created_at": utc_now(),
            }
        ],
        "hypotheses": [
            {
                "hypothesis_id": hypothesis_id,
                "intent_id": intent_id,
                "statement": goal_statement,
                "origin": "llm_proposed",
                "confidence": 0.35,
                "rank": 900,
                "verified": False,
                "evidence_refs": [],
                "signals": {"proposal": "opt_in_unverified"},
                "created_at": utc_now(),
            }
        ],
        "goals": [
            {
                "goal_id": stable_id("intent_llm_goal", intent_id, goal_statement),
                "intent_id": intent_id,
                "statement": goal_statement,
                "success_metric": None,
                "metric_source": "none",
                "confidence": 0.35,
                "origin": "llm_proposed",
                "evidence_refs": [],
                "created_at": utc_now(),
            }
        ],
    }
