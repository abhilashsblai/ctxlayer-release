from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from ctxlayer.utils import canonical_json, stable_id


@dataclass(frozen=True)
class IntentArtifact:
    intent_id: str
    problem_statement: str
    snapshot_id: str
    skeleton_hash: str
    status: str
    selected_goal_id: str | None


def normalize_problem(problem: str) -> str:
    normalized = " ".join(str(problem or "").strip().split())
    if not normalized:
        raise ValueError("intent problem statement is required")
    return normalized


def problem_text_hash(problem: str) -> str:
    return stable_id("intent_problem", normalize_problem(problem).casefold())


def skeleton_hash(nodes: list[dict[str, Any]]) -> str:
    deterministic = [
        {
            "node_id": node["node_id"],
            "parent_id": node.get("parent_id"),
            "label": node["label"],
            "node_kind": node["node_kind"],
            "status": node["status"],
            "evidence_refs": sorted(node.get("evidence_refs") or []),
            "ordinal": int(node.get("ordinal", 0)),
        }
        for node in sorted(
            (node for node in nodes if node.get("origin") == "deterministic"),
            key=lambda item: (str(item.get("parent_id") or ""), int(item.get("ordinal", 0)), item["label"]),
        )
    ]
    return stable_id("intent_skeleton", canonical_json(deterministic))


def to_view(
    header: Any,
    *,
    evidence: list[Any],
    nodes: list[Any],
    hypotheses: list[Any],
    stakeholders: list[Any],
    contradictions: list[Any],
    candidate_goals: list[Any],
    open_questions: list[Any],
) -> dict[str, Any]:
    if header is None:
        raise KeyError("intent not found")
    return {
        "intent_id": header["intent_id"],
        "problem_statement": header["problem_statement"],
        "problem_text_hash": header["problem_text_hash"],
        "created_at": header["created_at"],
        "updated_at": header["updated_at"],
        "snapshot_id": header["snapshot_id"],
        "repo_id": header["repo_id"],
        "status": header["status"],
        "selected_goal_id": header["selected_goal_id"],
        "skeleton_hash": header["skeleton_hash"],
        "evidence": [_row_evidence(row) for row in evidence],
        "decomposition": [_row_node(row) for row in nodes],
        "hypotheses": [_row_hypothesis(row) for row in hypotheses],
        "stakeholders": [_row_stakeholder(row) for row in stakeholders],
        "contradictions": [dict(row) for row in contradictions],
        "candidate_goals": [_row_goal(row) for row in candidate_goals],
        "open_questions": [dict(row) for row in open_questions],
        "audit_hash": header["audit_hash"],
        "prev_audit_hash": header["prev_audit_hash"],
        "metadata": _json_obj(header["metadata_json"]),
    }


def _row_evidence(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["metadata"] = _json_obj(item.pop("metadata_json", "{}"))
    return item


def _row_node(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["evidence_refs"] = _json_list(item.pop("evidence_refs_json", "[]"))
    return item


def _row_hypothesis(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["verified"] = bool(item.get("verified"))
    item["evidence_refs"] = _json_list(item.pop("evidence_refs_json", "[]"))
    item["signals"] = _json_obj(item.pop("signals_json", "{}"))
    return item


def _row_stakeholder(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["files"] = _json_list(item.pop("files_json", "[]"))
    return item


def _row_goal(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["evidence_refs"] = _json_list(item.pop("evidence_refs_json", "[]"))
    return item


def _json_obj(value: str) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _json_list(value: str) -> list[Any]:
    try:
        parsed = json.loads(value or "[]")
    except json.JSONDecodeError:
        return []
    return parsed if isinstance(parsed, list) else []
