from __future__ import annotations

from ctxlayer.org.connectors.crm import CrmExportConnector
from ctxlayer.org.connectors.email import EmailExportConnector
from ctxlayer.org.connectors.slack import SlackExportConnector
from ctxlayer.org.connectors.transcript import TranscriptConnector

CONNECTORS = {
    "transcript": TranscriptConnector,
    "slack": SlackExportConnector,
    "email": EmailExportConnector,
    "crm": CrmExportConnector,
}

__all__ = ["CONNECTORS", "CrmExportConnector", "EmailExportConnector", "SlackExportConnector", "TranscriptConnector"]
