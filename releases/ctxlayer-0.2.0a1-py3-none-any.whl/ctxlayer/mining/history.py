from __future__ import annotations

import itertools
import subprocess
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class HistorySignals:
    churn_rows: list[dict[str, object]]
    cochange_rows: list[dict[str, object]]


class HistoryMiner:
    def __init__(self, repo_root: Path, max_files_per_commit: int = 30):
        self.repo_root = repo_root
        self.max_files_per_commit = max_files_per_commit

    def mine(self, reachable_ref: str = "HEAD", limit: int = 500) -> HistorySignals:
        commits = self._commits(reachable_ref, limit)
        churn: dict[tuple[str, str | None], dict[str, object]] = {}
        path_commits: dict[str, set[str]] = defaultdict(set)
        pair_counts: Counter[tuple[str, str]] = Counter()
        for commit in commits:
            files = commit["files"]
            if not files or len(files) > self.max_files_per_commit:
                continue
            sha = str(commit["sha"])
            author = commit.get("author")
            date = commit.get("date")
            for path in files:
                key = (path, str(author) if author else None)
                row = churn.setdefault(
                    key,
                    {
                        "path": path,
                        "author": author,
                        "commits": 0,
                        "last_commit_sha": sha,
                        "last_touched_at": date,
                    },
                )
                row["commits"] = int(row["commits"]) + 1
                if not row.get("last_touched_at") or str(date) > str(row["last_touched_at"]):
                    row["last_commit_sha"] = sha
                    row["last_touched_at"] = date
                path_commits[path].add(sha)
            for left, right in itertools.combinations(sorted(set(files)), 2):
                pair_counts[(left, right)] += 1
        cochange_rows: list[dict[str, object]] = []
        for (left, right), together in pair_counts.items():
            left_count = len(path_commits[left])
            right_count = len(path_commits[right])
            union = left_count + right_count - together
            if union <= 0:
                continue
            jaccard = together / union
            if jaccard > 0:
                cochange_rows.append(
                    {
                        "path_a": left,
                        "path_b": right,
                        "commits_together": together,
                        "commits_a": left_count,
                        "commits_b": right_count,
                        "jaccard": round(jaccard, 6),
                    }
                )
        return HistorySignals(list(churn.values()), cochange_rows)

    def commits_as_of(self, parent_sha: str, limit: int = 500) -> list[dict[str, object]]:
        return self._commits(parent_sha, limit)

    def _commits(self, ref: str, limit: int) -> list[dict[str, object]]:
        try:
            result = subprocess.run(
                [
                    "git",
                    "log",
                    f"--max-count={limit}",
                    "--date=iso-strict",
                    "--pretty=format:__CTX__%H%x1f%an%x1f%ad",
                    "--name-only",
                    ref,
                ],
                cwd=self.repo_root,
                check=True,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                timeout=30,
            )
        except (subprocess.SubprocessError, FileNotFoundError):
            return []
        commits: list[dict[str, object]] = []
        current: dict[str, object] | None = None
        files: list[str] = []
        for raw in result.stdout.splitlines():
            line = raw.strip()
            if not line:
                continue
            if line.startswith("__CTX__"):
                if current is not None:
                    current["files"] = files
                    commits.append(current)
                sha, author, date = line.removeprefix("__CTX__").split("\x1f", 2)
                current = {"sha": sha, "author": author, "date": date}
                files = []
            elif current is not None:
                files.append(line.replace("\\", "/"))
        if current is not None:
            current["files"] = files
            commits.append(current)
        return commits
