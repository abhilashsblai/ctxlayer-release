from __future__ import annotations

from pathlib import Path

from ctxlayer.memory.evidence import RuleCandidate
from ctxlayer.memory.source_scanners.common import scan_rule_text


def scan(root: Path) -> list[RuleCandidate]:
    candidates: list[RuleCandidate] = []
    for folder in [root / "incidents", root / "runtime", root / ".ctxlayer" / "incidents"]:
        if not folder.exists():
            continue
        for path in [*folder.rglob("*.md"), *folder.rglob("*.txt"), *folder.rglob("*.json")]:
            if ".git" in path.parts:
                continue
            candidates.extend(scan_rule_text(path, root, "incidents", 0.57))
    return candidates
