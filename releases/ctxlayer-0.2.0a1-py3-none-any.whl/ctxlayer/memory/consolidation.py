from __future__ import annotations

import json
from collections import Counter
from typing import Any

from ctxlayer.memory.session import AgentSessionMemory
from ctxlayer.memory.unified import UnifiedMemory
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import sha256_text


class MemoryConsolidator:
    def __init__(
        self,
        store: SQLiteStore,
        workspace_id: str,
        repo_id: str | None,
        *,
        min_session_evidence: int = 2,
    ):
        self.store = store
        self.workspace_id = workspace_id
        self.repo_id = repo_id
        self.min_session_evidence = max(1, int(min_session_evidence))
        self.unified = UnifiedMemory(store, workspace_id, repo_id)
        self.sessions = AgentSessionMemory(store, workspace_id, repo_id)

    def consolidate(
        self, *, session_id: str | None = None, recent: int = 10
    ) -> dict[str, Any]:
        session_ids = [session_id] if session_id else [row["session_id"] for row in self.sessions.recent(recent)]
        proposed = []
        for sid in session_ids:
            if not sid:
                continue
            explanation = self.sessions.explain(sid)
            if not explanation.get("ok"):
                continue
            proposed.extend(self._from_session(explanation))
        return {"ok": True, "proposed": proposed}

    def _from_session(self, explanation: dict[str, Any]) -> list[dict[str, Any]]:
        session = explanation["session"]
        events = explanation["events"]
        artifacts = explanation["artifacts"]
        proposed = []
        edited_counts = Counter(
            artifact["ref"]
            for artifact in artifacts
            if artifact["artifact_type"] == "file_edited" and artifact["ref"]
        )
        read_counts = Counter(
            artifact["ref"]
            for artifact in artifacts
            if artifact["artifact_type"] == "file_read" and artifact["ref"]
        )
        failed_tests = [
            event["payload"]
            for event in events
            if event["event_type"] == "test_run"
            and str(event["payload"].get("result", "")).lower() in {"fail", "failed", "error"}
        ]
        successful_tests = [
            event["payload"]
            for event in events
            if event["event_type"] == "test_run"
            and str(event["payload"].get("result", "")).lower() in {"pass", "passed", "ok"}
        ]
        for path, count in edited_counts.items():
            if count < self.min_session_evidence:
                continue
            proposed.append(
                self._propose(
                    record_type="gotcha",
                    assertion=(
                        f"{path} was edited during an agent session and should be checked when related tasks change."
                    ),
                    session_id=session["session_id"],
                    evidence_ref=path,
                    confidence=0.55,
                )
            )
        read_only_floor = max(2, self.min_session_evidence)
        for path, count in read_counts.items():
            if path in edited_counts:
                # Already represented by the edited pass above; do not duplicate.
                continue
            if count < read_only_floor:
                continue
            proposed.append(
                self._propose(
                    record_type="gotcha",
                    assertion=(
                        f"{path} repeatedly appears in agent sessions and should be checked when related tasks change."
                    ),
                    session_id=session["session_id"],
                    evidence_ref=path,
                    confidence=0.55,
                )
            )
        for test in failed_tests:
            command = test.get("command") or "unknown test command"
            proposed.append(
                self._propose(
                    record_type="gotcha",
                    assertion=f"Test command `{command}` failed in a prior session and may indicate a fragile workflow.",
                    session_id=session["session_id"],
                    evidence_ref=command,
                    confidence=0.6,
                )
            )
        for test in successful_tests:
            command = test.get("command") or "unknown test command"
            proposed.append(
                self._propose(
                    record_type="pattern",
                    assertion=f"Test command `{command}` has been used successfully for related changes.",
                    session_id=session["session_id"],
                    evidence_ref=command,
                    confidence=0.55,
                )
            )
        return proposed

    def _propose(
        self,
        *,
        record_type: str,
        assertion: str,
        session_id: str,
        evidence_ref: str,
        confidence: float,
    ) -> dict[str, Any]:
        evidence = {
            "repo_id": self.repo_id,
            "path": evidence_ref if "/" in evidence_ref or "\\" in evidence_ref else None,
            "symbol_identity_id": None,
            "evidence_kind": "agent_session",
            "evidence_hash": sha256_text(json.dumps({"session_id": session_id, "ref": evidence_ref}, sort_keys=True)),
            "source_ref": session_id,
            "metadata": {"session_id": session_id, "ref": evidence_ref},
        }
        record_id = self.unified.propose(
            record_type=record_type,
            assertion=assertion,
            source_kind="consolidation:deterministic",
            confidence=confidence,
            evidence=[evidence],
            status="candidate",
            metadata={"session_id": session_id},
        )
        maintenance = self.unified.maintain_candidate(record_id)
        self.store.upsert_memory_association(
            record_id=record_id,
            target_type="session",
            target_ref=session_id,
            kind="observed_in_session",
            weight=1.0,
        )
        if evidence["path"]:
            self.store.upsert_memory_association(
                record_id=record_id,
                target_type="file",
                target_ref=evidence["path"],
                kind="evidenced_by_file",
                weight=0.8,
            )
        row = self.store.memory_record(record_id)
        return {
            "record_id": record_id,
            "type": record_type,
            "assertion": assertion,
            "status": row["status"] if row else "candidate",
            "maintenance": maintenance,
        }
