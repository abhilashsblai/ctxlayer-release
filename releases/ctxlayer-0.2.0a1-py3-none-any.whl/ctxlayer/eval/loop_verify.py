from __future__ import annotations

from pathlib import Path
from typing import Any

from ctxlayer.utils import canonical_json, stable_id, utc_now

DEFAULT_PROBE_TASK = "change greeting service"
DEFAULT_PROBE_PATHS = ["app/service.py"]


def verify_loop(
    repo_root: Path,
    *,
    task: str = DEFAULT_PROBE_TASK,
    paths: list[str] | None = None,
    result: str = "pass",
) -> dict[str, Any]:
    """Verify that an outcome changes the next context pack's learning signals."""

    probe_paths = _normalize_paths(paths or DEFAULT_PROBE_PATHS)
    from ctxlayer.service import CtxLayerService

    with CtxLayerService(repo_root) as service:
        pre_pack = service.get_context_pack(task, seed_paths=probe_paths)
        pre_signal = _signal_summary(pre_pack, probe_paths)
        outcome = service.record_outcome(
            pre_pack["pack_id"],
            result,
            files_changed=probe_paths,
            summary="Phase 0 loop verification probe outcome.",
        )
        post_pack = service.get_context_pack(task, seed_paths=probe_paths)
        post_signal = _signal_summary(post_pack, probe_paths)

    ranking_changed = pre_signal["signal_hash"] != post_signal["signal_hash"]
    outcome_paths = [
        item["path"]
        for item in post_signal["items"]
        if "rerank:outcome" in item["provenance"]
        and "rerank:outcome" not in pre_signal["provenance_by_path"].get(item["path"], [])
    ]
    score_deltas = _score_deltas(pre_signal, post_signal)
    evidence = _evidence(outcome_paths, score_deltas)
    verified = ranking_changed or bool(outcome_paths)
    return {
        "ok": verified and bool(outcome.get("ok")),
        "schema_version": "ctxlayer.loop_closure.v1",
        "created_at": utc_now(),
        "task": task,
        "paths": probe_paths,
        "result": result,
        "pre_pack_id": pre_pack["pack_id"],
        "post_pack_id": post_pack["pack_id"],
        "outcome": {
            "ok": bool(outcome.get("ok")),
            "outcome_id": outcome.get("outcome_id"),
            "agent_session_id": outcome.get("agent_session_id"),
        },
        "loop_closure": {
            "verified": verified,
            "reason": "verified" if verified else "no_signal_change",
            "ranking_changed": ranking_changed,
            "rule_status_changed": bool(outcome_paths),
            "pre_signal_hash": pre_signal["signal_hash"],
            "post_signal_hash": post_signal["signal_hash"],
            "evidence": evidence,
        },
        "pre": pre_signal,
        "post": post_signal,
    }


def _signal_summary(pack: dict[str, Any], probe_paths: list[str]) -> dict[str, Any]:
    items = [_item_signal(item) for item in pack.get("items", []) if isinstance(item, dict)]
    by_path = {item["path"]: item for item in items}
    selected = [by_path[path] for path in probe_paths if path in by_path]
    signal_payload = {
        "selected": selected,
        "items": items,
    }
    return {
        "pack_id": pack.get("pack_id"),
        "signal_hash": stable_id("loop_signal", canonical_json(signal_payload)),
        "items": items,
        "selected": selected,
        "provenance_by_path": {item["path"]: item["provenance"] for item in items},
    }


def _item_signal(item: dict[str, Any]) -> dict[str, Any]:
    return {
        "path": str(item.get("path") or "").replace("\\", "/"),
        "start_line": item.get("start_line"),
        "end_line": item.get("end_line"),
        "score": float(item.get("score") or 0.0),
        "provenance": sorted(str(value) for value in item.get("provenance", []) or []),
    }


def _score_deltas(pre: dict[str, Any], post: dict[str, Any]) -> list[dict[str, Any]]:
    pre_by_path = {item["path"]: item for item in pre["items"]}
    deltas = []
    for item in post["items"]:
        previous = pre_by_path.get(item["path"])
        if previous is None:
            continue
        delta = round(float(item["score"]) - float(previous["score"]), 6)
        if delta:
            deltas.append(
                {
                    "path": item["path"],
                    "pre_score": previous["score"],
                    "post_score": item["score"],
                    "delta": delta,
                }
            )
    return deltas


def _evidence(outcome_paths: list[str], score_deltas: list[dict[str, Any]]) -> list[dict[str, Any]]:
    evidence = [
        {"kind": "rerank_outcome_provenance", "path": path}
        for path in sorted(set(outcome_paths))
    ]
    evidence.extend({"kind": "score_delta", **delta} for delta in score_deltas)
    return evidence


def _normalize_paths(paths: list[str]) -> list[str]:
    return sorted({path.replace("\\", "/") for path in paths if path})
