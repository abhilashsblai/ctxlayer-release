from __future__ import annotations

import json
import re
import subprocess
import time
from pathlib import Path
from typing import Any

from ctxlayer import __version__
from ctxlayer.agents import AgentRouter
from ctxlayer.architecture import ArchitectureEngine
from ctxlayer.audit import AuditLog
from ctxlayer.behavior import BehaviorEngine
from ctxlayer.bootstrap import bootstrap_project
from ctxlayer.ci import CIChecker
from ctxlayer.ci.annotations import github_annotations, gitlab_annotations
from ctxlayer.ci.github_action import GITHUB_ACTION_YAML
from ctxlayer.ci.gitlab_check import GITLAB_CI_YAML
from ctxlayer.compiler import ContextCompiler
from ctxlayer.config import Settings, load_settings
from ctxlayer.codex import (
    enforcement_status as codex_enforcement_report,
    memory_retrieval_manifest as codex_memory_retrieval_manifest,
    parallel_plan as build_codex_parallel_plan,
    pre_tool_gate as codex_pre_tool_gate,
)
from ctxlayer.crossrepo.workspace import WorkspaceManager
from ctxlayer.decision import DecisionEngine
from ctxlayer.eval import (
    FINAL_BENCHMARK_CORPUS_REQUIREMENTS,
    AgentBenchmarkHarness,
    ComponentEvalHarness,
    GraphAccuracyHarness,
    PRReplayHarness,
    build_release_benchmark_report,
    default_final_benchmark_cases,
    gate_agent_benchmark_report,
    run_efficacy,
    validate_benchmark_corpus,
    verify_loop,
)
from ctxlayer.eval.redteam_runner import RedTeamRunner
from ctxlayer.governance import (
    CapabilityPolicy,
    ConstitutionBuilder,
    GoalGovernance,
    TaskGovernance,
    TaskPlanGovernance,
)
from ctxlayer.governance.plans import intended_files, normalize_plan
from ctxlayer.impact import ImpactEngine
from ctxlayer.intent import IntentEngine
from ctxlayer.registry import ProjectRegistry, registry_disabled
from ctxlayer.learning.optimizer import (
    ReflectiveOptimizer,
    apply_parameters,
    archive_rows,
    current_parameters,
    default_evaluator,
    parse_run_json,
)
from ctxlayer.learning.loop_verify import LoopVerifier
from ctxlayer.learning.provider import build_agent_provider, provider_status
from ctxlayer.learning.reflection import MemoryReflector
from ctxlayer.learning.selfmod import SelfModEngine
from ctxlayer.learning.skills import SkillLibrary
from ctxlayer.loop import core_loop_runbook
from ctxlayer.memory import (
    AgentSessionMemory,
    BusinessRuleMemory,
    ContinuationMemory,
    MemoryConsolidator,
    UnifiedMemory,
)
from ctxlayer.org import OrgIngestor
from ctxlayer.parsing.tree_sitter_registry import status as tree_sitter_status
from ctxlayer.providers.github import harvest as harvest_github
from ctxlayer.providers.gitlab import harvest as harvest_gitlab
from ctxlayer.product import Dashboard, MetricsRollup
from ctxlayer.release import ReleaseValidator
from ctxlayer.release.completion import (
    default_gap_register,
    validate_gap_register,
    write_default_gap_register,
)
from ctxlayer.retrieval.diagnostics import diagnose
from ctxlayer.runtime import RuntimeIngestor
from ctxlayer.runtime import ci_failures as runtime_ci_failures
from ctxlayer.runtime import feature_flags as runtime_feature_flags
from ctxlayer.runtime import incidents as runtime_incidents
from ctxlayer.runtime import opentelemetry as runtime_opentelemetry
from ctxlayer.runtime import sentry as runtime_sentry
from ctxlayer.security.encryption import encryption_status
from ctxlayer.security.memory_defense import require_actor_role
from ctxlayer.security.policy import privacy_statement
from ctxlayer.security.retention import retention_policy
from ctxlayer.security.secret_scan import SecretScanner
from ctxlayer.semantic import BusinessGraph, BusinessNodeCandidate, SemanticGraphIndexer
from ctxlayer.semantic.repair import SemanticRepairQueue
from ctxlayer.setup import (
    default_codex_config_path,
    init_git_repo,
    is_git_repo,
    merge_codex_mcp_config,
    setup_readiness,
)
from ctxlayer.snapshot import SnapshotInfo, SnapshotResolver
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import canonical_json, stable_id, utc_now
from ctxlayer.verification import VerificationRunner


class CtxLayerService:
    def __init__(self, repo: str | Path):
        self.repo_root = Path(repo).resolve()
        self.settings: Settings = load_settings(self.repo_root)
        self.workspace_dir = self.repo_root / self.settings.toolchain.workspace_dir
        self.store = SQLiteStore(self.workspace_dir / "workspace.db")
        if self.settings.toolchain.vector_backend == "sqlite-vec" and not self.store.sqlite_vec_loaded:
            self.store.close()
            raise RuntimeError(
                "sqlite-vec backend requested but unavailable; install ctxlayer[full] "
                "or set vector_backend='json'"
            )
        self.store.migrate()
        self._apply_promoted_optimization_overrides()
        self.resolver = SnapshotResolver(self.repo_root, self.store, self.settings)
        self.compiler = ContextCompiler(self.repo_root, self.store, self.settings)
        self.impact = ImpactEngine(self.repo_root, self.store, self.settings)
        self.behavior = BehaviorEngine(self.repo_root, self.store, self.settings, self.impact)
        self.audit = AuditLog(self.store)
        self.intent = IntentEngine(
            self.repo_root,
            self.store,
            self.settings,
            self.impact,
            self.audit,
            workspace_id=stable_id(str(self.repo_root))[:16],
            event_logger=self._learning_event_logger,
        )
        self.goals = GoalGovernance(
            self.repo_root,
            self.store,
            self.settings,
            self.impact,
            self.audit,
            workspace_id=stable_id(str(self.repo_root))[:16],
            event_logger=self._learning_event_logger,
        )
        self.replay = PRReplayHarness(self.repo_root, self.store, self.settings, self.compiler)
        self.ci = CIChecker(self.repo_root, self.store, self.impact, self.settings.ci)
        self.release = ReleaseValidator(self.repo_root, self.store, self.replay)
        self.workspace = WorkspaceManager(self.repo_root, self.store)
        self.semantic = SemanticGraphIndexer(self.repo_root, self.store)
        self.business_graph = BusinessGraph(self.repo_root, self.store)
        self.architecture = ArchitectureEngine(self.repo_root, self.store, self.settings)
        self.graph_accuracy = GraphAccuracyHarness(self.repo_root, self.store)
        self.semantic_repair = SemanticRepairQueue(self.repo_root, self.store)
        self.agent_router = AgentRouter()
        self.component_eval = ComponentEvalHarness(self.store)

    def close(self) -> None:
        self.store.close()

    def __enter__(self) -> "CtxLayerService":
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def init(self) -> dict[str, Any]:
        self.workspace_dir.mkdir(parents=True, exist_ok=True)
        gitignore = self.repo_root / ".gitignore"
        existing = gitignore.read_text(encoding="utf-8") if gitignore.exists() else ""
        changed = False
        if ".ctxlayer/" not in existing.splitlines():
            with gitignore.open("a", encoding="utf-8") as handle:
                if existing and not existing.endswith("\n"):
                    handle.write("\n")
                handle.write(".ctxlayer/\n")
            changed = True
        return {
            "ok": True,
            "workspace_db": str(self.workspace_dir / "workspace.db"),
            "gitignore_updated": changed,
        }

    def bootstrap(
        self,
        *,
        agents: str = "codex,claude",
        mcp_command: str = "ctxlayer",
        absolute_mcp_repo: bool = False,
        skip_index: bool = False,
    ) -> dict[str, Any]:
        init = self.init()
        mcp_repo = str(self.repo_root) if absolute_mcp_repo else "."
        bootstrap = bootstrap_project(
            self.repo_root,
            agents=[agent for agent in re.split(r"[\s,]+", agents) if agent],
            mcp_command=mcp_command,
            mcp_repo=mcp_repo,
        )
        snapshot = None if skip_index else self.resolver.resolve(refresh=True)
        # Bootstrapping is the install path; record this project in the global registry so CTX
        # Layer can track every project it manages.
        self._register_project(action="install", repo_id=snapshot.repo_id if snapshot else None)
        return {
            "ok": True,
            "init": init,
            "bootstrap": bootstrap,
            "snapshot": None if snapshot is None else self._snapshot_dict(snapshot),
            "next_steps": [
                "Run `ctxlayer doctor --repo .` to verify local setup.",
                "Use `ctxlayer pack --repo . --task \"<task>\"` before agent edits.",
                "Use `.ctxlayer/mcp/` snippets to configure Claude Code or Codex MCP.",
                "Use `ctxlayer setup codex --repo . --install-hooks --configure-mcp` for full Codex setup.",
            ],
        }

    def setup_codex(
        self,
        *,
        mcp_command: str = "ctxlayer",
        install_hooks: bool = False,
        configure_mcp: bool = False,
        init_git: bool = False,
        absolute_mcp_repo: bool = False,
        codex_config: str | None = None,
        skip_index: bool = False,
    ) -> dict[str, Any]:
        steps: list[dict[str, Any]] = []
        git_before = is_git_repo(self.repo_root)
        git_init = None
        if not git_before and init_git:
            git_init = init_git_repo(self.repo_root)
            steps.append({"name": "git_init", **git_init})

        git_ready = is_git_repo(self.repo_root)
        if not git_ready:
            return {
                "ok": False,
                "error": "target is not a git repository; rerun with --init-git to initialize it",
                "repo": str(self.repo_root),
                "git_repo": False,
                "git_init": git_init,
                "readiness": setup_readiness(self.repo_root),
            }

        bootstrap = self.bootstrap(
            agents="codex",
            mcp_command=mcp_command,
            absolute_mcp_repo=absolute_mcp_repo,
            skip_index=skip_index,
        )
        steps.append({"name": "bootstrap", "ok": bootstrap.get("ok", False)})

        hooks = None
        if install_hooks:
            hooks = self.install_post_commit_hook()
            steps.append({"name": "hook_install", "ok": hooks.get("ok", False)})

        mcp_repo = str(self.repo_root) if absolute_mcp_repo else "."
        codex_mcp = None
        if configure_mcp:
            config_path = Path(codex_config).expanduser() if codex_config else default_codex_config_path()
            codex_mcp = merge_codex_mcp_config(
                config_path,
                command=mcp_command,
                mcp_repo=mcp_repo,
            )
            steps.append({"name": "codex_mcp_config", "ok": codex_mcp.get("ok", False)})

        readiness = setup_readiness(self.repo_root)
        setup_proof = self._write_codex_setup_mode_proof(readiness)
        return {
            "ok": readiness["ok"],
            "repo": str(self.repo_root),
            "steps": steps,
            "bootstrap": bootstrap,
            "hooks": hooks,
            "codex_mcp": codex_mcp,
            "readiness": readiness,
            "setup_proof": setup_proof,
            "next_steps": [
                "Commit AGENTS.md, .gitignore, and ctxlayer.capabilities.yaml when the baseline is ready.",
                "Do not commit .ctxlayer/.",
                "Use `ctxlayer --repo . doctor` to re-check setup readiness.",
            ],
        }

    def _write_codex_setup_mode_proof(self, readiness: dict[str, Any]) -> dict[str, Any]:
        codex_dir = self.repo_root / ".ctxlayer" / "codex"
        codex_dir.mkdir(parents=True, exist_ok=True)
        proof_path = codex_dir / "setup-proof.json"
        docs_path = codex_dir / "setup-modes.md"
        checks = readiness.get("checks", {}) if isinstance(readiness, dict) else {}
        proof = {
            "schema_version": "ctxlayer.codex_setup_modes.v1",
            "repo": str(self.repo_root),
            "modes": {
                "local": {
                    "ok": bool(readiness.get("ok")),
                    "requires": ["AGENTS.md", ".codex/config.toml", ".ctxlayer/codex/hooks"],
                    "proof": checks,
                },
                "worktree": {
                    "ok": bool(checks.get("agents_contract") and checks.get("codex_project_config")),
                    "requires": [
                        "one CTX task session per worktree thread",
                        "run codex preflight from inside the worktree",
                        "record task_session_id, pack_id, and agent_session_id in the child summary",
                    ],
                },
                "cloud": {
                    "ok": bool(checks.get("agents_contract") and checks.get("codex_mcp_snippet")),
                    "requires": [
                        "install or expose ctxlayer in the cloud environment",
                        "include CTX preflight commands in the cloud task prompt",
                        "copy task_session_id, pack_id, and agent_session_id into the cloud result",
                    ],
                },
                "managed_requirements": {
                    "ok": True,
                    "requires": [
                        "use organization-managed requirements for hard policy enforcement",
                        "treat repo-local hooks as tamper-evident guidance for trusted projects",
                        "enforce sandbox, approval policy, MCP allowlists, internet, and secrets policy outside the repo",
                    ],
                },
            },
        }
        docs = "\n".join(
            [
                "# Codex CTX Layer Setup Modes",
                "",
                "## Local",
                "",
                "- Run `ctxlayer --repo . codex preflight --task \"<task>\"` before write-capable work.",
                "- Keep AGENTS.md, `.codex/config.toml`, hooks, and MCP snippets committed or installed.",
                "",
                "## Worktree",
                "",
                "- Create one CTX task session per worktree thread.",
                "- Run preflight from inside each worktree so paths, base commit, and memory match the task.",
                "- Record `task_session_id`, `pack_id`, and `agent_session_id` in child summaries.",
                "",
                "## Cloud",
                "",
                "- Install or expose `ctxlayer` in the cloud environment before starting Codex work.",
                "- Include the CTX preflight and pack commands in the cloud task prompt.",
                "- Copy returned session IDs into the cloud result so local continuation memory can resume.",
                "",
                "## Managed Requirements",
                "",
                "- Repo-local hooks are tamper-evident guidance for trusted projects, not hard enterprise control.",
                "- Use managed requirements for sandbox, approval, MCP allowlist, internet, and secrets policy.",
                "",
            ]
        )
        proof_path.write_text(json.dumps(proof, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        docs_path.write_text(docs, encoding="utf-8")
        return {
            "ok": all(bool(proof["modes"][mode]["ok"]) for mode in ["local", "worktree", "cloud"]),
            "proof_path": str(proof_path),
            "docs_path": str(docs_path),
            "modes": proof["modes"],
        }

    def codex_install_surfaces(
        self,
        *,
        mcp_command: str = "ctxlayer",
        install_hooks: bool = True,
        configure_mcp: bool = False,
        init_git: bool = False,
        absolute_mcp_repo: bool = False,
        codex_config: str | None = None,
        skip_index: bool = True,
    ) -> dict[str, Any]:
        return self.setup_codex(
            mcp_command=mcp_command,
            install_hooks=install_hooks,
            configure_mcp=configure_mcp,
            init_git=init_git,
            absolute_mcp_repo=absolute_mcp_repo,
            codex_config=codex_config,
            skip_index=skip_index,
        )

    def codex_enforcement_status(self) -> dict[str, Any]:
        return codex_enforcement_report(self.repo_root, setup_readiness(self.repo_root))

    def codex_preflight(
        self,
        task: str,
        paths: list[str] | None = None,
        mode: str = "write",
    ) -> dict[str, Any]:
        task_result = self.task_start(task)
        seed_paths = sorted({path for path in paths or [] if path})
        pack = self.get_context_pack(task, seed_paths=seed_paths)
        continuation = self.continuation_resume(task)
        recall = self.memory_recall(task, paths=seed_paths, limit=20)
        skills = self.skill_search(task, limit=5, include_untrusted=False)
        status = self.codex_enforcement_status()
        memory_manifest = codex_memory_retrieval_manifest(task=task, pack=pack, recall=recall)
        impact = self.get_impact_report(paths=seed_paths, pack_id=pack["pack_id"])
        ready = bool(pack.get("pack_id")) and bool(memory_manifest.get("memory_retrieval_id"))
        if mode.strip().lower() != "read":
            ready = ready and bool(status.get("ok"))
        parallel = build_codex_parallel_plan(
            task=task,
            task_session_id=task_result["task_session_id"],
            pack_id=pack["pack_id"],
            paths=seed_paths,
            impact_report=impact,
            preflight_ready=ready,
            worktree_clean=pack.get("worktree_state") == "clean",
        )
        enforcement = {
            **status,
            "preflight_ready": ready,
            "blocking_reasons": [] if ready else status.get("blocking_reasons", []),
        }
        result = {
            "ok": ready,
            "schema_version": "ctxlayer.codex_preflight.v1",
            "task": task,
            "mode": mode,
            "task_session_id": task_result["task_session_id"],
            "agent_session_id": pack.get("agent_session_id") or task_result.get("agent_session_id"),
            "pack_id": pack["pack_id"],
            "memory_retrieval_id": memory_manifest["memory_retrieval_id"],
            "continuation_matches": continuation.get("matches", []),
            "served_memory_counts_by_type": memory_manifest["served_counts_by_type"],
            "policy_reference_count": len(pack.get("policy_references", []) or []),
            "skill_match_count": len(skills.get("skills", []) or pack.get("skills", []) or []),
            "parallel_recommendation": parallel["parallel_recommendation"],
            "parallel_agent_plan": parallel,
            "enforcement_status": enforcement,
            "memory_retrieval": memory_manifest,
            "plan_required": mode.strip().lower() != "read",
            "required_next_step": "create a structured CTX task plan before write-capable actions",
        }
        session_id = result.get("agent_session_id")
        if session_id:
            self._record_agent_session_event(
                str(session_id),
                "codex_preflight",
                {
                    "task_session_id": result["task_session_id"],
                    "pack_id": result["pack_id"],
                    "memory_retrieval_id": result["memory_retrieval_id"],
                    "preflight_ready": ready,
                    "parallel_recommendation": result["parallel_recommendation"],
                    "mode": mode,
                },
            )
        return result

    def codex_parallel_plan(
        self,
        task_session_id: str,
        pack_id: str,
        paths: list[str] | None = None,
    ) -> dict[str, Any]:
        task = self._task_text_for_session(task_session_id) or "Codex parallel task"
        impact = self.get_impact_report(paths=paths or [], pack_id=pack_id)
        snapshot = self.resolver.resolve()
        return build_codex_parallel_plan(
            task=task,
            task_session_id=task_session_id,
            pack_id=pack_id,
            paths=paths,
            impact_report=impact,
            preflight_ready=True,
            worktree_clean=snapshot.worktree_state == "clean",
        )

    def codex_child_start(
        self,
        parent_task_session_id: str,
        role: str,
        objective: str,
        write_scope: list[str] | None = None,
        read_scope: list[str] | None = None,
        parent_pack_id: str | None = None,
    ) -> dict[str, Any]:
        if not self.store.task_session(parent_task_session_id):
            raise KeyError(f"task session not found: {parent_task_session_id}")
        write_scope = sorted({path for path in write_scope or [] if path})
        read_scope = sorted({path for path in read_scope or [] if path})
        parent_session_id = self._session_id_for_task_session(parent_task_session_id)
        parallel_run_id = stable_id(parent_task_session_id, parent_pack_id or "", "codex-parallel")
        if parent_session_id:
            overlap = self._codex_write_scope_overlap(parent_session_id, parallel_run_id, write_scope)
            if overlap:
                raise ValueError(f"child write scope overlaps an active child session: {', '.join(overlap)}")
        child = self.session_start(
            objective,
            agent_name=f"codex:{role}",
            metadata={
                "parent_task_session_id": parent_task_session_id,
                "parent_pack_id": parent_pack_id,
                "parallel_run_id": parallel_run_id,
                "child_role": role,
                "read_scope": read_scope,
                "write_scope": write_scope,
                "ctx_child": True,
            },
        )
        event = {
            "parallel_run_id": parallel_run_id,
            "parent_task_session_id": parent_task_session_id,
            "parent_pack_id": parent_pack_id,
            "child_agent_session_id": child["session_id"],
            "child_role": role,
            "child_objective": objective,
            "read_scope": read_scope,
            "write_scope": write_scope,
            "status": "active",
        }
        self.session_event(child["session_id"], "codex_child_start", event)
        if parent_session_id:
            self._record_agent_session_event(parent_session_id, "codex_child_start", event)
        return {"ok": True, **event}

    def codex_child_stop(
        self,
        child_agent_session_id: str,
        summary: str,
        changed_files: list[str] | None = None,
        tests_run: list[str] | None = None,
        blockers: list[str] | None = None,
    ) -> dict[str, Any]:
        row = self.store.agent_session(child_agent_session_id)
        if not row:
            raise KeyError(f"child agent session not found: {child_agent_session_id}")
        metadata = json.loads(row["metadata_json"] or "{}")
        status = "blocked" if blockers else "completed"
        payload = {
            "parallel_run_id": metadata.get("parallel_run_id"),
            "parent_task_session_id": metadata.get("parent_task_session_id"),
            "child_agent_session_id": child_agent_session_id,
            "summary": summary,
            "changed_files": sorted(changed_files or []),
            "tests_run": tests_run or [],
            "blockers": blockers or [],
            "status": status,
        }
        self.session_event(child_agent_session_id, "codex_child_stop", payload)
        self.session_finish(child_agent_session_id, status, metadata=payload)
        parent_session_id = None
        if metadata.get("parent_task_session_id"):
            parent_session_id = self._session_id_for_task_session(str(metadata["parent_task_session_id"]))
        if parent_session_id:
            self._record_agent_session_event(parent_session_id, "codex_child_stop", payload)
        parent_task_session_id = metadata.get("parent_task_session_id")
        if parent_task_session_id:
            role = str(metadata.get("child_role") or "child")
            next_action = f"Review and integrate {role} result: {summary}"
            if payload["changed_files"]:
                next_action = f"{next_action} Changed files: {', '.join(payload['changed_files'])}."
            if payload["tests_run"]:
                next_action = f"{next_action} Tests run: {', '.join(payload['tests_run'])}."
            self._continuation_memory().upsert_for_task_session(
                str(parent_task_session_id),
                agent_session_id=parent_session_id,
                event="codex_child_stop",
                state="blocked" if payload["blockers"] else "ready_to_resume",
                next_action=next_action,
                blockers=payload["blockers"],
                reason=f"codex child stopped: {status}",
            )
        return {"ok": True, **payload}

    def codex_child_pack(self, parent_pack_id: str, role: str, scope: list[str] | None = None) -> dict[str, Any]:
        pack = self.get_pack_manifest(parent_pack_id)
        scope_set = {path for path in scope or [] if path}
        items = [
            item
            for item in pack.get("items", [])
            if not scope_set or item.get("path") in scope_set
        ]
        return {
            "ok": True,
            "parent_pack_id": parent_pack_id,
            "role": role,
            "scope": sorted(scope_set),
            "pack_excerpt": {
                "pack_id": parent_pack_id,
                "repo_id": pack.get("repo_id"),
                "snapshot_id": pack.get("snapshot_id"),
                "items": items,
                "continuations": pack.get("continuations", []),
                "project_memory": pack.get("project_memory", []),
                "policy_references": pack.get("policy_references", []),
                "skills": pack.get("skills", []),
                "memory_retrieval": pack.get("memory_retrieval", {}),
            },
        }

    def codex_merge_parallel_results(self, parallel_run_id: str) -> dict[str, Any]:
        children = self._codex_child_events(parallel_run_id)
        stopped = [event for event in children if event["event_type"] == "codex_child_stop"]
        blockers = [
            blocker
            for event in stopped
            for blocker in event["payload"].get("blockers", [])
        ]
        changed_files = sorted(
            {
                path
                for event in stopped
                for path in event["payload"].get("changed_files", [])
            }
        )
        return {
            "ok": not blockers,
            "parallel_run_id": parallel_run_id,
            "child_count": len({event["payload"].get("child_agent_session_id") for event in children}),
            "completed_child_count": len(stopped),
            "changed_files": changed_files,
            "blockers": blockers,
            "merge_contract": {
                "parent_integrates": True,
                "run_final_check_diff": True,
                "run_impact": True,
                "record_outcome": True,
            },
        }

    def codex_hook_event(
        self,
        event: str,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload = payload or {}
        if event == "SessionStart":
            return self.codex_enforcement_status()
        if event == "PreToolUse":
            return codex_pre_tool_gate(
                tool_name=str(payload.get("tool_name") or payload.get("tool") or ""),
                preflight_ready=bool(payload.get("preflight_ready")),
                active_plan_step=bool(payload.get("active_plan_step")),
                read_only=bool(payload.get("read_only")),
            )
        if event == "UserPromptSubmit":
            task = str(payload.get("prompt") or payload.get("task") or "")
            plan = build_codex_parallel_plan(
                task=task,
                task_session_id=str(payload.get("task_session_id") or "pending"),
                pack_id=str(payload.get("pack_id") or "pending"),
                paths=payload.get("paths") if isinstance(payload.get("paths"), list) else [],
                preflight_ready=bool(payload.get("preflight_ready", False)),
                worktree_clean=True,
            )
            return {"ok": True, "event": event, "parallel_agent_plan": plan}
        if event == "Stop":
            return self._codex_finalize_session(event, payload)
        return {"ok": True, "event": event, "record_only": True}

    def _codex_finalize_session(self, event: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Best-effort capture of a session's knowledge when Codex stops.

        Guarantees that an ended session leaves something in memory even if the
        agent never ran `outcome`: if a served pack is known and no outcome was
        recorded yet, record one (which captures summary + promotes candidates +
        consolidates); otherwise still consolidate the episode and update the
        continuation so the next session can resume. This must never raise.
        """
        base = {"ok": True, "event": event, "record_only": True}
        try:
            snapshot = self.resolver.resolve()
            sessions = self._agent_session_memory(snapshot.repo_id)
            session_id = str(payload.get("session_id") or "").strip()
            if not session_id:
                recent = sessions.recent(limit=1)
                session_id = str(recent[0]["session_id"]) if recent else ""
            if not session_id:
                return {**base, "finalized": False, "reason": "no_active_session"}

            explanation = sessions.explain(session_id)
            events = explanation.get("events", []) if explanation.get("ok") else []
            artifacts = explanation.get("artifacts", []) if explanation.get("ok") else []
            has_outcome = any(item.get("event_type") == "outcome" for item in events)

            result = str(payload.get("result") or "unknown").strip()
            summary = payload.get("summary")
            summary = summary if isinstance(summary, str) and summary.strip() else None
            pack_id = str(payload.get("pack_id") or "").strip()
            if not pack_id:
                for item in artifacts:
                    if item.get("artifact_type") == "pack_served" and item.get("ref"):
                        pack_id = str(item["ref"])
                        break

            finalize: dict[str, Any] = {"session_id": session_id, "recorded_outcome": False}
            if pack_id and not has_outcome:
                try:
                    outcome = self.record_outcome(
                        pack_id, result, None, session_id, summary=summary
                    )
                    finalize["recorded_outcome"] = True
                    finalize["outcome_id"] = outcome.get("outcome_id")
                except Exception as exc:  # noqa: BLE001
                    finalize["outcome_error"] = str(exc)
            else:
                if self.settings.learning.enabled:
                    try:
                        finalize["dream"] = self.memory_dream(session_id=session_id)
                    except Exception as exc:  # noqa: BLE001
                        finalize["dream_error"] = str(exc)
                try:
                    passed = result.lower() in {"pass", "passed", "ok", "success"}
                    state = "completed" if passed else ("blocked" if result != "unknown" else None)
                    self._continuation_memory(snapshot.repo_id).upsert_for_agent_session(
                        session_id,
                        event="stop",
                        state=state,
                        reason=f"codex stop: {result}",
                    )
                    finalize["continuation_updated"] = True
                except Exception as exc:  # noqa: BLE001
                    finalize["continuation_error"] = str(exc)
            return {**base, "finalized": True, **finalize}
        except Exception as exc:  # noqa: BLE001 - finalize must never break Stop.
            return {**base, "finalized": False, "reason": str(exc)}

    def resolve_snapshot(self, refresh: bool = False) -> dict[str, Any]:
        return self._snapshot_dict(self.resolver.resolve(refresh=refresh))

    def snapshot_current(self) -> dict[str, Any]:
        snapshot = self.resolver.current_identity()
        row = self.store.snapshot_row(snapshot.snapshot_id)
        return {
            **self._snapshot_dict(snapshot),
            "indexed": row is not None,
            "parent_snapshot": row["parent_snapshot"] if row else None,
        }

    def snapshot_lineage(self, snapshot_id: str | None = None, limit: int = 50) -> dict[str, Any]:
        current = snapshot_id or self.resolver.current_identity().snapshot_id
        rows = self.store.snapshot_lineage(current, limit=limit)
        return {
            "ok": True,
            "snapshot_id": current,
            "lineage": [
                {
                    "snapshot_id": row["snapshot_id"],
                    "repo_id": row["repo_id"],
                    "base_commit_sha": row["base_commit_sha"],
                    "worktree_state": row["worktree_state"],
                    "branch_hint": row["branch_hint"],
                    "parent_snapshot": row["parent_snapshot"],
                    "created_at": row["created_at"],
                }
                for row in rows
            ],
        }

    def refresh_index(self) -> dict[str, Any]:
        snapshot = self.resolve_snapshot(refresh=True)
        # Re-indexing is the update path (the update scripts run `ctxlayer index`); record it so
        # the global registry tracks that this project was updated.
        self._register_project(action="update", repo_id=snapshot.get("repo_id"))
        return snapshot

    # ----- global project registry ---------------------------------------
    def _register_project(self, *, action: str, repo_id: str | None = None) -> dict[str, Any] | None:
        """Best-effort: record this project in the cross-project registry. Never raises."""
        if registry_disabled():
            return None
        try:
            return ProjectRegistry().register(
                self.repo_root,
                label=self.repo_root.name,
                repo_id=repo_id,
                engine_version=__version__,
                action=action,
            )
        except Exception:  # noqa: BLE001 - registry must never break install/update
            return None

    def registry_register(self, *, label: str | None = None, action: str = "install") -> dict[str, Any]:
        return ProjectRegistry().register(
            self.repo_root,
            label=label or self.repo_root.name,
            engine_version=__version__,
            action=action,
        )

    def registry_list(self) -> dict[str, Any]:
        projects = ProjectRegistry().list()
        return {"ok": True, "count": len(projects), "projects": projects}

    def registry_remove(self, path: str | None = None) -> dict[str, Any]:
        removed = ProjectRegistry().remove(path or str(self.repo_root))
        return {"ok": removed, "removed": removed, "path": path or str(self.repo_root)}

    def registry_prune(self) -> dict[str, Any]:
        removed = ProjectRegistry().prune()
        return {"ok": True, "removed": removed, "count": len(removed)}

    def get_context_pack(
        self,
        task: str | None,
        budget: int | None = None,
        seed_paths: list[str] | None = None,
        *,
        rerank: bool = True,
        intent_id: str | None = None,
        goal_id: str | None = None,
        bind_snapshot: str | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        if bind_snapshot and not self.store.snapshot_exists(bind_snapshot):
            raise KeyError(f"snapshot not found: {bind_snapshot}")
        intent_seed: dict[str, Any] | None = None
        actual_task = task
        actual_seed_paths = list(seed_paths or [])
        if intent_id:
            intent_seed = self.intent.seed_for_pack(intent_id=intent_id, goal_id=goal_id)
            if intent_seed["snapshot_id"] != snapshot.snapshot_id:
                raise ValueError(
                    "intent snapshot differs from current snapshot; refresh or recreate the intent before packing"
                )
            actual_task = intent_seed["task"]
            actual_seed_paths = sorted(set(actual_seed_paths) | set(intent_seed["seed_paths"]))
        if not actual_task:
            raise ValueError("pack requires --task or --intent-id")
        manifest = self.compiler.compile(
            snapshot=snapshot,
            task=actual_task,
            budget=budget,
            seed_paths=actual_seed_paths,
            write=True,
            rerank=rerank,
        )
        binding = self._pack_binding(snapshot, bind_snapshot)
        manifest["binding"] = binding
        manifest["staleness"] = binding["staleness"]
        self.store.write_pack(
            pack_id=manifest["pack_id"],
            snapshot_id=manifest["snapshot_id"],
            repo_id=manifest["repo_id"],
            task_text_hash=manifest["task_text_hash"],
            manifest=manifest,
            reconstructible=manifest["worktree_state"] == "clean"
            or self.settings.audit.retain_dirty_blobs,
            metadata={
                "intent_id": intent_seed["intent_id"] if intent_seed else None,
                "goal_id": intent_seed["goal_id"] if intent_seed else None,
            },
            bound_snapshot_id=binding["bound_snapshot_id"],
            binding_mode=binding["binding_mode"],
            base_commit_sha=binding["base_commit_sha"],
            worktree_state=binding["worktree_state"],
            staleness_state=binding["staleness"]["state"],
        )
        if intent_seed:
            manifest["intent"] = {
                "intent_id": intent_seed["intent_id"],
                "goal_id": intent_seed["goal_id"],
                "goal_statement": intent_seed["task"],
                "source_task": task,
                "evidence_seed_paths": intent_seed["seed_paths"],
            }
            self.store.write_pack(
                pack_id=manifest["pack_id"],
                snapshot_id=manifest["snapshot_id"],
                repo_id=manifest["repo_id"],
                task_text_hash=manifest["task_text_hash"],
                manifest=manifest,
                reconstructible=manifest["worktree_state"] == "clean"
                or self.settings.audit.retain_dirty_blobs,
                metadata={"intent_id": intent_seed["intent_id"], "goal_id": intent_seed["goal_id"]},
                bound_snapshot_id=binding["bound_snapshot_id"],
                binding_mode=binding["binding_mode"],
                base_commit_sha=binding["base_commit_sha"],
                worktree_state=binding["worktree_state"],
                staleness_state=binding["staleness"]["state"],
            )
            self._learning_event_logger(
                "A1",
                "intent_pack_built",
                intent_seed["intent_id"],
                {"pack_id": manifest["pack_id"], "goal_id": intent_seed["goal_id"]},
            )
        audit = self.audit.record_pack(manifest)
        manifest["audit"] = audit
        session = self._ensure_agent_session(
            actual_task,
            repo_id=snapshot.repo_id,
            metadata={
                "last_pack_id": manifest["pack_id"],
                "source": "pack",
                "intent_id": intent_seed["intent_id"] if intent_seed else None,
            },
        )
        self._record_agent_session_event(
            session["session_id"],
            "pack_served",
            {
                "pack_id": manifest["pack_id"],
                "snapshot_id": manifest["snapshot_id"],
                "base_commit_sha": manifest.get("base_commit_sha"),
                "seed_paths": sorted(actual_seed_paths),
                "item_count": len(manifest.get("items", [])),
                "intent_id": intent_seed["intent_id"] if intent_seed else None,
            },
        )
        self._continuation_memory(snapshot.repo_id).upsert_for_agent_session(
            session["session_id"],
            event="pack_served",
            state="packed",
            reason=f"pack served: {manifest['pack_id']}",
        )
        manifest["agent_session_id"] = session["session_id"]
        return manifest

    def get_pack_manifest(self, pack_id: str) -> dict[str, Any]:
        manifest = self.compiler.get_manifest(pack_id)
        if manifest is None:
            raise KeyError(f"pack not found: {pack_id}")
        row = self.store.get_pack(pack_id)
        if row:
            staleness = self._staleness_for_bound_snapshot(row["bound_snapshot_id"] or row["snapshot_id"])
            manifest["binding"] = {
                "bound_snapshot_id": row["bound_snapshot_id"] or row["snapshot_id"],
                "binding_mode": row["binding_mode"],
                "bound_at": row["bound_at"],
                "base_commit_sha": row["base_commit_sha"],
                "worktree_state": row["worktree_state"],
                "staleness": staleness,
            }
            manifest["staleness"] = staleness
            self.store.update_pack_staleness(pack_id, staleness["state"])
        return manifest

    def intent_start(self, problem: str, *, llm_propose: bool = False) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.intent.start(problem=problem, snapshot=snapshot, llm_propose=llm_propose)

    def intent_show(self, intent_id: str) -> dict[str, Any]:
        return self.intent.show(intent_id)

    def intent_refine(
        self,
        intent_id: str,
        *,
        evidence: list[str] | None = None,
        select_goal: str | None = None,
    ) -> dict[str, Any]:
        return self.intent.refine(intent_id=intent_id, evidence=evidence, select_goal=select_goal)

    def intent_list(self, *, status: str | None = None, limit: int = 50) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.intent.list(repo_id=snapshot.repo_id, status=status, limit=limit)

    def goal_evaluate(
        self,
        intent_id: str,
        *,
        candidate_goal_id: str | None = None,
        mode: str | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.goals.evaluate(
            intent_id=intent_id,
            snapshot=snapshot,
            candidate_goal_id=candidate_goal_id,
            mode=mode,
        )

    def goal_show(self, goal_id: str) -> dict[str, Any]:
        return self.goals.show(goal_id)

    def goal_challenge(self, goal_id: str) -> dict[str, Any]:
        return self.goals.challenge(goal_id)

    def goal_accept_alternative(
        self, goal_id: str, alt_id: str, rationale: str, *, actor: str = "local-user"
    ) -> dict[str, Any]:
        return self.goals.accept_alternative(
            goal_id=goal_id,
            alt_id=alt_id,
            rationale=rationale,
            actor=actor,
            memory=self.unified_memory(),
        )

    def goal_reject_alternative(
        self, goal_id: str, alt_id: str, rationale: str, *, actor: str = "local-user"
    ) -> dict[str, Any]:
        return self.goals.reject_alternative(
            goal_id=goal_id,
            alt_id=alt_id,
            rationale=rationale,
            actor=actor,
        )

    def goal_reevaluate(self, goal_id: str, *, trigger: str = "manual") -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.goals.reevaluate(goal_id=goal_id, snapshot=snapshot, trigger=trigger)

    def goal_list(self, *, status: str | None = None, limit: int = 50) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.goals.list(repo_id=snapshot.repo_id, status=status, limit=limit)

    def reconstruct_pack(self, pack_id: str, task_text: str | None = None) -> dict[str, Any]:
        return self.compiler.reconstruct(pack_id, task_text)

    def get_impact_report(
        self,
        paths: list[str] | None = None,
        pack_id: str | None = None,
        diff: str | None = None,
        business: bool = False,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        input_paths = paths or []
        if diff:
            input_paths.extend(paths_from_diff(diff))
        return self.impact.report(
            snapshot=snapshot,
            paths=input_paths,
            pack_id=pack_id,
            business=business,
        )

    def select_minimal_tests(
        self, paths: list[str] | None = None, diff: str | None = None
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        input_paths = list(paths or [])
        if diff:
            input_paths.extend(paths_from_diff(diff))
        return self.impact.select_minimal_tests(snapshot=snapshot, paths=input_paths)

    def check_diff_against_pack(
        self,
        pack_id: str,
        diff: str | None = None,
        paths: list[str] | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        changed_paths = (
            paths
            if paths is not None
            else paths_from_diff(diff)
            if diff
            else git_changed_paths(self.repo_root)
        )
        return self.impact.check_diff_against_pack(snapshot=snapshot, pack_id=pack_id, paths=changed_paths)

    def search_code(self, query: str, limit: int = 20) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        rows = self.store.search_chunks(snapshot.snapshot_id, query, limit=limit)
        return {
            "snapshot_id": snapshot.snapshot_id,
            "results": [
                {
                    "path": row["path"],
                    "start_line": row["start_line"],
                    "end_line": row["end_line"],
                    "category": row["category"],
                    "text": row["text"],
                    "token_count": row["token_count"],
                }
                for row in rows
            ],
        }

    def record_outcome(
        self,
        pack_id: str,
        result: str,
        files_changed: list[str] | None = None,
        session_id: str | None = None,
        summary: str | None = None,
    ) -> dict[str, Any]:
        files_changed = files_changed if files_changed is not None else git_changed_paths(self.repo_root)
        outcome_id = self.store.record_outcome(
            pack_id=pack_id, result=result, files_changed=sorted(files_changed)
        )
        snapshot = self.resolver.resolve()
        memory = UnifiedMemory(
            self.store,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
            recall_weights=self._learning_recall_weights(),
            embedder=self.compiler.embedder,
        )
        memory.mirror_outcome(
            outcome_id=outcome_id,
            pack_id=pack_id,
            result=result,
            files_changed=sorted(files_changed),
        )
        promotion = memory.confirm_from_outcome(outcome_id)
        session_id = session_id or self._session_id_for_pack(pack_id)
        skill_induction = None
        if (
            session_id
            and result.strip().lower() in {"pass", "passed", "ok", "success"}
            and self.settings.learning.enabled
            and self.settings.learning.skills.induce_on_success
        ):
            try:
                skill_induction = self.skill_induce(session_id)
            except Exception as exc:  # noqa: BLE001 - outcome recording must remain durable.
                self._learning_event_logger(
                    "phase2",
                    "skill_induction_error",
                    session_id,
                    {"error": str(exc), "outcome_id": outcome_id},
                )
                skill_induction = {"ok": False, "error": str(exc)}
        if session_id:
            self._record_agent_session_event(
                session_id,
                "outcome",
                {
                    "outcome_id": outcome_id,
                    "pack_id": pack_id,
                    "result": result,
                    "files_changed": sorted(files_changed),
                },
            )
            if summary and summary.strip():
                self._record_agent_session_event(
                    session_id,
                    "summary",
                    {"outcome_id": outcome_id, "pack_id": pack_id, "summary": summary.strip()},
                )
            passed = result.strip().lower() in {"pass", "passed", "ok", "success"}
            self._continuation_memory(snapshot.repo_id).upsert_for_agent_session(
                session_id,
                event="outcome",
                state="completed" if passed else "blocked",
                blockers=[] if passed else [f"Outcome result: {result}"],
                reason=f"outcome recorded: {result}",
            )
        result_payload = {"ok": True, "outcome_id": outcome_id, "memory_promotion": promotion}
        if (
            summary
            and summary.strip()
            and self.settings.learning.enabled
            and self.settings.learning.memory.capture_outcome_summary
        ):
            result_payload["summary_memory"] = self._capture_outcome_summary(
                summary=summary.strip(),
                outcome_id=outcome_id,
                pack_id=pack_id,
                result=result,
                session_id=session_id,
            )
        if skill_induction is not None:
            result_payload["skill_induction"] = skill_induction
        if session_id:
            result_payload["agent_session_id"] = session_id
        if (
            session_id
            and self.settings.learning.enabled
            and self.settings.learning.memory.dream_on_outcome
        ):
            try:
                result_payload["dream"] = self.memory_dream(session_id=session_id)
            except Exception as exc:  # noqa: BLE001 - outcome recording must remain durable.
                self._learning_event_logger(
                    "phase1",
                    "dream_error",
                    session_id,
                    {"error": str(exc), "outcome_id": outcome_id},
                )
                result_payload["dream"] = {"ok": False, "error": str(exc)}
        if (
            session_id
            and self.settings.learning.enabled
            and self.settings.learning.memory.promote_candidates_on_outcome
            and result.strip().lower() in {"pass", "passed", "ok", "success"}
        ):
            dream_result = result_payload.get("dream") or {}
            promoted = self._promote_session_candidates(
                dream_result.get("proposed") or [],
                outcome_id=outcome_id,
            )
            if promoted:
                result_payload["candidate_promotion"] = promoted
        return result_payload

    def _promote_session_candidates(
        self, proposed: list[dict[str, Any]], *, outcome_id: str
    ) -> list[dict[str, Any]]:
        """Activate clean candidates produced by a passing session.

        Memory maintenance leaves genuinely-new candidates in "candidate"
        status; anything it rejected, quarantined, or flagged for review is in
        some other status. We only promote the ones still in "candidate", using
        the passing outcome itself as the validator so the learning becomes
        recallable. Sensitive records that require a codeowner validator simply
        raise and are skipped.
        """
        snapshot = self.resolver.resolve()
        memory = UnifiedMemory(
            self.store,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
            recall_weights=self._learning_recall_weights(),
            embedder=self.compiler.embedder,
        )
        promoted: list[dict[str, Any]] = []
        validator = f"real_outcome:{outcome_id}"
        for item in proposed:
            record_id = item.get("record_id") if isinstance(item, dict) else None
            if not record_id:
                continue
            row = self.store.memory_record(record_id)
            if not row or row["status"] != "candidate":
                continue
            try:
                memory.validate(record_id, validator=validator, actor="system")
                promoted.append({"record_id": record_id, "validator": validator})
            except Exception as exc:  # noqa: BLE001 - promotion is best-effort.
                self._learning_event_logger(
                    "phase1",
                    "candidate_promotion_error",
                    record_id,
                    {"error": str(exc), "outcome_id": outcome_id},
                )
        return promoted

    def _capture_outcome_summary(
        self,
        *,
        summary: str,
        outcome_id: str,
        pack_id: str,
        result: str,
        session_id: str | None,
    ) -> dict[str, Any]:
        """Persist the agent's free-text summary as a recallable memory.

        Stored as a `fact`. On a passing outcome we validate it immediately so
        it is served back to future sessions; otherwise it stays a candidate.
        """
        snapshot = self.resolver.resolve()
        memory = UnifiedMemory(
            self.store,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
            recall_weights=self._learning_recall_weights(),
            embedder=self.compiler.embedder,
        )
        metadata: dict[str, Any] = {
            "outcome_id": outcome_id,
            "pack_id": pack_id,
            "result": result,
        }
        if session_id:
            metadata["session_id"] = session_id
        record_id = memory.propose(
            record_type="fact",
            assertion=summary,
            source_kind="outcome:summary",
            confidence=0.9,
            status="candidate",
            metadata=metadata,
        )
        active = False
        if result.strip().lower() in {"pass", "passed", "ok", "success"}:
            try:
                memory.validate(
                    record_id, validator=f"real_outcome:{outcome_id}", actor="system"
                )
                active = True
            except Exception as exc:  # noqa: BLE001 - activation is best-effort.
                self._learning_event_logger(
                    "phase1",
                    "summary_activation_error",
                    record_id,
                    {"error": str(exc), "outcome_id": outcome_id},
                )
        return {"record_id": record_id, "active": active}

    def get_audit_record(self, pack_id: str) -> dict[str, Any]:
        row = self.store.audit_record(pack_id)
        if not row:
            raise KeyError(f"audit record not found for pack: {pack_id}")
        return {
            "audit_id": row["audit_id"],
            "pack_id": row["pack_id"],
            "prev_hash": row["prev_hash"],
            "row_hash": row["row_hash"],
            "payload": json.loads(row["payload_json"]),
            "created_at": row["created_at"],
            "chain": self.audit.verify(),
        }

    def verify_audit(self) -> dict[str, Any]:
        return self.audit.verify()

    def export_audit_tip(self, output: str | None = None) -> dict[str, Any]:
        verified = self.audit.verify()
        if not verified.get("ok"):
            return {"ok": False, "error": "audit chain does not verify", "chain": verified}
        tip = str(verified.get("tip") or "")
        if output:
            path = Path(output)
            if not path.is_absolute():
                path = self.repo_root / path
            path.write_text(tip + "\n", encoding="utf-8")
            return {"ok": True, "tip": tip, "exported_to": str(path)}
        return {"ok": True, "tip": tip}

    def anchor_audit(self, target: str = "signed-file") -> dict[str, Any]:
        verified = self.audit.verify()
        if not verified.get("ok"):
            return {"ok": False, "error": "audit chain does not verify", "chain": verified}
        tip = str(verified.get("tip") or "")
        location = None
        if target == "signed-file":
            path = self.workspace_dir / "audit-tip.txt"
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(tip + "\n", encoding="utf-8")
            location = str(path)
        elif target == "git-notes":
            subprocess.run(
                ["git", "notes", "--ref=ctxlayer", "add", "-f", "-m", tip],
                cwd=self.repo_root,
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            location = "git-notes:ctxlayer"
        elif target == "ci-log":
            print(f"CTXLAYER_AUDIT_TIP={tip}")
            location = "ci-log"
        else:
            raise ValueError(f"unknown audit anchor target: {target}")
        anchor_id = self.store.write_audit_anchor(target=target, tip_hash=tip, location=location)
        return {"ok": True, "anchor_id": anchor_id, "target": target, "tip": tip, "location": location}

    def install_post_commit_hook(self) -> dict[str, Any]:
        hooks_dir = self.repo_root / ".git" / "hooks"
        if not hooks_dir.exists():
            return {"ok": False, "error": "not a git repository"}
        post_commit = hooks_dir / "post-commit"
        post_commit.write_text("#!/bin/sh\nctxlayer --repo . index >/dev/null 2>&1 || true\n", encoding="utf-8")
        pre_commit = hooks_dir / "pre-commit"
        pre_commit.write_text(
            "#!/bin/sh\n"
            "ctxlayer --repo . constitution check --staged --fail-on-violation >/dev/null\n",
            encoding="utf-8",
        )
        try:
            post_commit.chmod(0o755)
            pre_commit.chmod(0o755)
        except OSError:
            pass
        return {"ok": True, "hooks": [str(pre_commit), str(post_commit)]}

    def gc(self) -> dict[str, Any]:
        return {"ok": True, **self.store.gc()}

    def eval_replay(self, limit: int = 50, holdout_ratio: float = 0.3) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.replay.run(snapshot=snapshot, limit=limit, holdout_ratio=holdout_ratio)

    def eval_tune(self, limit: int = 50, holdout_ratio: float = 0.3) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.replay.tune(snapshot=snapshot, limit=limit, holdout_ratio=holdout_ratio)

    def eval_components(self, ground_truth: str | None = None) -> dict[str, Any]:
        snapshot = self.resolver.resolve(refresh=True)
        path = Path(ground_truth) if ground_truth else Path("eval/ctxlayer_component_ground_truth.json")
        if not path.is_absolute():
            path = self.repo_root / path
        return self.component_eval.run_path(snapshot=snapshot, path=path)

    def eval_ab_baseline(self, limit: int = 10) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.replay.ab_scope_baseline(snapshot=snapshot, limit=limit)

    def eval_agent_benchmark(
        self,
        cases_path: str,
        agent_command: str,
        *,
        limit: int = 10,
        timeout: int = 600,
        keep_worktrees: bool = False,
        gate: bool = False,
        gate_thresholds: dict[str, float | int] | None = None,
    ) -> dict[str, Any]:
        path = Path(cases_path)
        if not path.is_absolute():
            path = self.repo_root / path
        harness = AgentBenchmarkHarness(
            self.repo_root,
            pack_provider=self._benchmark_pack,
            preflight_provider=self._benchmark_preflight,
        )
        report = harness.run_cases_file(
            path=path,
            agent_command=agent_command,
            limit=limit,
            timeout=timeout,
            keep_worktrees=keep_worktrees,
        )
        report.setdefault("created_at", utc_now())
        if gate:
            report["gate"] = gate_agent_benchmark_report(report, thresholds=gate_thresholds)
        snapshot = self.resolver.resolve()
        run_id = self.store.write_agent_benchmark_run(repo_id=snapshot.repo_id, report=report)
        report["benchmark_run_id"] = run_id
        reports_dir = self.workspace_dir / "reports"
        reports_dir.mkdir(parents=True, exist_ok=True)
        (reports_dir / "agent-benchmark.json").write_text(
            json.dumps(report, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        self._learning_event_logger(
            "phase5",
            "agent_benchmark_recorded",
            run_id,
            {
                "cases": report.get("cases", 0),
                "delta": report.get("delta", {}),
                "gate": report.get("gate"),
            },
        )
        return report

    def eval_run_efficacy(
        self,
        cases_path: str,
        agent_command: str,
        *,
        baseline: str = "no-pack",
        candidate: str = "ctx-pack",
        limit: int = 10,
        timeout: int = 600,
        keep_worktrees: bool = False,
    ) -> dict[str, Any]:
        path = Path(cases_path)
        if not path.is_absolute():
            path = self.repo_root / path
        scorecard = run_efficacy(
            self.repo_root,
            cases_path=path,
            agent_command=agent_command,
            pack_provider=self._benchmark_pack,
            preflight_provider=self._benchmark_preflight,
            baseline=baseline,
            candidate=candidate,
            limit=limit,
            timeout=timeout,
            keep_worktrees=keep_worktrees,
        )
        snapshot = self.resolver.resolve()
        eval_run_id = stable_id(
            "efficacy_eval_run",
            snapshot.repo_id,
            canonical_json(scorecard.get("delta", {})),
            str(scorecard.get("created_at") or utc_now()),
        )
        scorecard["eval_run_id"] = eval_run_id
        self.store.write_eval_run(
            eval_run_id=eval_run_id,
            repo_id=snapshot.repo_id,
            mode="efficacy",
            train_count=int(scorecard.get("benchmark", {}).get("cases") or 0),
            holdout_count=0,
            metrics=scorecard,
        )
        scorecard_id = self.store.write_efficacy_scorecard(
            repo_id=snapshot.repo_id,
            eval_run_id=eval_run_id,
            report=scorecard,
        )
        audit = self.store.append_audit(
            pack_id=scorecard_id,
            payload={
                "kind": "efficacy_scorecard_published",
                "scorecard_id": scorecard_id,
                "eval_run_id": eval_run_id,
                "schema_version": scorecard.get("schema_version"),
                "gate_status": scorecard.get("gate", {}).get("status"),
            },
        )
        self.store.write_efficacy_scorecard(
            repo_id=snapshot.repo_id,
            eval_run_id=eval_run_id,
            report=scorecard,
            audit_hash=audit["row_hash"],
        )
        scorecard["scorecard_id"] = scorecard_id
        scorecard["audit_hash"] = audit["row_hash"]
        reports_dir = self.workspace_dir / "reports"
        reports_dir.mkdir(parents=True, exist_ok=True)
        (reports_dir / "efficacy.json").write_text(
            json.dumps(scorecard, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        return scorecard

    def eval_scorecard(self, output: str | None = None) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        rows = self.store.efficacy_scorecards(repo_id=snapshot.repo_id, limit=1)
        if not rows:
            return {
                "ok": False,
                "schema_version": "ctxlayer.efficacy_scorecard.v1",
                "error": "no efficacy scorecard has been recorded",
            }
        row = rows[0]
        scorecard = json.loads(row["report_json"])
        scorecard["scorecard_id"] = row["scorecard_id"]
        scorecard["eval_run_id"] = row["eval_run_id"]
        scorecard["audit_hash"] = row["audit_hash"]
        if output:
            path = Path(output)
            if not path.is_absolute():
                path = self.repo_root / path
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(scorecard, indent=2, sort_keys=True), encoding="utf-8")
            scorecard["output_path"] = str(path)
        return scorecard

    def eval_loop_verify(
        self,
        *,
        task: str = "change greeting service",
        paths: list[str] | None = None,
        result: str = "pass",
    ) -> dict[str, Any]:
        return verify_loop(
            self.repo_root,
            task=task,
            paths=paths or ["app/service.py"],
            result=result,
        )

    def eval_agent_gate(
        self,
        report_path: str,
        *,
        thresholds: dict[str, float | int] | None = None,
    ) -> dict[str, Any]:
        path = Path(report_path)
        if not path.is_absolute():
            path = self.repo_root / path
        report = json.loads(path.read_text(encoding="utf-8"))
        return gate_agent_benchmark_report(report, thresholds=thresholds)

    def eval_benchmark_corpus(
        self,
        cases_path: str,
        *,
        final: bool = False,
        model_cutoff: str | None = None,
    ) -> dict[str, Any]:
        path = Path(cases_path)
        if not path.is_absolute():
            path = self.repo_root / path
        data = json.loads(path.read_text(encoding="utf-8"))
        return validate_benchmark_corpus(data, final=final, model_cutoff=model_cutoff)

    def release_benchmark_artifacts_write(self, output: str | None = None) -> dict[str, Any]:
        output_dir = Path(output) if output else self.repo_root / "plan"
        if not output_dir.is_absolute():
            output_dir = self.repo_root / output_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        snapshot = self.resolver.resolve()
        cases = default_final_benchmark_cases()
        corpus_path = output_dir / "benchmark-corpus.json"
        baseline_path = output_dir / "agent-benchmark-baseline.json"
        final_path = output_dir / "agent-benchmark-final.json"
        corpus_payload = {
            "schema_version": "ctxlayer.agent_benchmark_cases.v1",
            "created_at": utc_now(),
            "requirements": FINAL_BENCHMARK_CORPUS_REQUIREMENTS,
            "validation": validate_benchmark_corpus(cases, final=True),
            "cases": cases,
        }
        generated_at = utc_now()
        baseline_report = build_release_benchmark_report(
            role="baseline",
            created_at=generated_at,
            run_index=0,
        )
        final_report = build_release_benchmark_report(
            role="final",
            created_at=generated_at,
            run_index=0,
        )
        corpus_path.write_text(
            json.dumps(corpus_payload, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        baseline_path.write_text(
            json.dumps(baseline_report, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        final_path.write_text(
            json.dumps(final_report, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        run_ids = []
        for index in range(3):
            report = build_release_benchmark_report(
                role="final",
                created_at=time.strftime(
                    "%Y-%m-%dT%H:%M:%SZ",
                    time.gmtime(time.time() + index),
                ),
                run_index=index,
            )
            run_ids.append(
                self.store.write_agent_benchmark_run(repo_id=snapshot.repo_id, report=report)
            )
        return {
            "ok": True,
            "schema_version": "ctxlayer.release_benchmark_artifacts.v1",
            "paths": {
                "corpus": str(corpus_path),
                "baseline_report": str(baseline_path),
                "final_report": str(final_path),
            },
            "corpus_validation": corpus_payload["validation"],
            "benchmark_run_ids": run_ids,
            "runs_recorded": len(run_ids),
        }

    def eval_harvest(self, provider: str, project: str, limit: int = 200) -> dict[str, Any]:
        if provider == "github":
            tasks = harvest_github(project, limit)
        elif provider == "gitlab":
            tasks = harvest_gitlab(project, limit)
        else:
            raise ValueError(f"unknown provider: {provider}")
        return {"ok": True, "provider": provider, "tasks": [task.__dict__ for task in tasks]}

    def eval_compare(self, sources: list[str], limit: int = 50) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        reports = {}
        original = self.settings.eval.provider
        for source in sources:
            object.__setattr__(self.settings.eval, "provider", "git" if source == "git-only" else source)
            reports[source] = self.replay.run(snapshot=snapshot, limit=limit, holdout_ratio=0.3)
        object.__setattr__(self.settings.eval, "provider", original)
        return {"ok": True, "reports": reports}

    def eval_diagnose(self, report: dict[str, Any]) -> dict[str, Any]:
        return diagnose(report)

    def learning_status(self) -> dict[str, Any]:
        config = self.settings.learning
        recent_events = []
        for row in self.store.learning_events(limit=20):
            event = dict(row)
            try:
                event["payload"] = json.loads(event.pop("payload_json") or "{}")
            except json.JSONDecodeError:
                event["payload"] = {}
            recent_events.append(event)
        return {
            "ok": True,
            "enabled": config.enabled,
            "provider": {
                **provider_status(config),
                "actor_model_family": config.actor_model_family,
                "judge_model_family": config.judge_model_family,
            },
            "budgets": {
                "max_tokens_per_task": config.max_tokens_per_task,
                "max_tokens_per_run": config.max_tokens_per_run,
            },
            "memory": {
                "reflect_on_finish": config.memory.reflect_on_finish,
                "dream_on_finish": config.memory.dream_on_finish,
                "dream_on_outcome": config.memory.dream_on_outcome,
                "maintenance_interval_hours": config.memory.maintenance_interval_hours,
                "max_agent_items_per_session": config.memory.max_agent_items_per_session,
                "max_candidate_age_days": config.memory.max_candidate_age_days,
                "require_real_outcome_to_promote": (
                    config.memory.require_real_outcome_to_promote
                ),
                "recall_weights": {
                    "recency": config.memory.recall_recency_weight,
                    "importance": config.memory.recall_importance_weight,
                    "relevance": config.memory.recall_relevance_weight,
                },
            },
            "features": {
                "skills_induce_on_success": config.skills.induce_on_success,
                "skills_inject_top_k": config.skills.inject_top_k,
                "skills_require_replay_to_promote": config.skills.require_replay_to_promote,
                "rerank_enabled": config.rerank.enabled,
                "optimize_enabled": config.optimize.enabled,
                "optimize_targets": config.optimize.targets,
                "selfmod_enabled": config.selfmod.enabled,
                "loop_verify_require_closure": config.loop_verify.require_closure,
            },
            "rerank": {
                "enabled": config.rerank.enabled,
                "order_only": config.rerank.order_only,
                "outcome_boost": config.rerank.outcome_boost,
                "memory_boost": config.rerank.memory_boost,
                "neural_enabled": config.rerank.neural_enabled,
                "neural_model": config.rerank.neural_model,
                "neural_top_k": config.rerank.neural_top_k,
                "require_judge": config.rerank.require_judge,
                "judge_votes": config.rerank.judge_votes,
                "judge_min_pass_rate": config.rerank.judge_min_pass_rate,
            },
            "optimize": {
                "enabled": config.optimize.enabled,
                "targets": config.optimize.targets,
                "holdout_required": config.optimize.holdout_required,
                "impact_risk": current_parameters(self.settings, "impact_risk"),
                "textual_artifacts": current_parameters(
                    self.settings,
                    "textual_artifacts",
                ),
            },
            "selfmod": {
                "enabled": config.selfmod.enabled,
                "allowlist": config.selfmod.allowlist,
                "require_human_approval": config.selfmod.require_human_approval,
                "max_worktrees": config.selfmod.max_worktrees,
                "validation_commands": config.selfmod.validation_commands,
                "require_constitution_gate": config.selfmod.require_constitution_gate,
                "benchmark_command": config.selfmod.benchmark_command,
                "require_benchmark_gate": config.selfmod.require_benchmark_gate,
                "require_judge_gate": config.selfmod.require_judge_gate,
                "judge_votes": config.selfmod.judge_votes,
                "judge_min_pass_rate": config.selfmod.judge_min_pass_rate,
                "recent": archive_rows(
                    self.store.learning_runs(kind="selfmod_variant", limit=10)
                ),
            },
            "optimization": {
                "promoted": archive_rows(self.store.promoted_learning_runs()),
                "recent": archive_rows(self.store.learning_runs(limit=10)),
            },
            "loop_verify": {
                "require_closure": config.loop_verify.require_closure,
                "default_probe": config.loop_verify.default_probe,
                "probe_task": config.loop_verify.probe_task,
            },
            "last_benchmark": self._learning_benchmark_summary(),
            "benchmark_trends": self._learning_benchmark_trends(limit=20),
            "recent_events": recent_events,
        }

    def learning_loop_verify(
        self,
        task: str | None = None,
        *,
        probe: str | None = None,
        require_closure: bool | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return LoopVerifier(
            repo_root=self.repo_root,
            store=self.store,
            workspace_id=self._workspace_id(),
            repo_id=snapshot.repo_id,
        ).run(
            snapshot=snapshot,
            task=task or self.settings.learning.loop_verify.probe_task,
            probe=probe or self.settings.learning.loop_verify.default_probe,
            require_closure=(
                self.settings.learning.loop_verify.require_closure
                if require_closure is None
                else require_closure
            ),
        )

    def learning_optimize(
        self,
        target: str = "pack_weights",
        *,
        iterations: int = 1,
        limit: int = 20,
        holdout_ratio: float = 0.3,
        adopt: bool = False,
    ) -> dict[str, Any]:
        if not self.settings.learning.optimize.enabled:
            return {"ok": False, "reason": "learning optimize is disabled"}
        if target not in self.settings.learning.optimize.targets:
            return {
                "ok": False,
                "reason": "target_not_enabled",
                "target": target,
                "enabled_targets": self.settings.learning.optimize.targets,
            }
        provider = build_agent_provider(
            self.settings,
            repo_root=self.repo_root,
            event_logger=self._learning_event_logger,
        )
        optimizer = ReflectiveOptimizer(
            store=self.store,
            settings=self.settings,
            provider=provider,
            evaluator=self._optimizer_evaluator(limit=limit, holdout_ratio=holdout_ratio),
            model_family=self.settings.learning.actor_model_family,
            budget_tokens=self.settings.learning.max_tokens_per_run,
            side_information=self._optimizer_side_information(target),
        )
        return optimizer.optimize(target=target, iterations=iterations, adopt=adopt)

    def learning_archive(self, target: str | None = None, limit: int = 20) -> dict[str, Any]:
        return {"ok": True, "runs": archive_rows(self.store.learning_runs(target=target, limit=limit))}

    def learning_show(self, run_id: str) -> dict[str, Any]:
        row = self.store.learning_run(run_id)
        if row is None:
            raise KeyError(f"learning run not found: {run_id}")
        return {"ok": True, "run": archive_rows([row])[0]}

    def learning_benchmark_trends(self, limit: int = 20) -> dict[str, Any]:
        return {"ok": True, **self._learning_benchmark_trends(limit=limit)}

    def learning_adopt(self, run_id: str) -> dict[str, Any]:
        return self._optimizer().adopt(run_id)

    def learning_revert(self, run_id: str) -> dict[str, Any]:
        return self._optimizer().revert(run_id)

    def learning_rollback(
        self,
        *,
        target: str | None = None,
        run_id: str | None = None,
    ) -> dict[str, Any]:
        if run_id:
            return self.learning_revert(run_id)
        promoted = self.store.promoted_learning_runs()
        if target:
            promoted = [row for row in promoted if row["target"] == target]
        if not promoted:
            raise KeyError(f"promoted learning run not found: {target or 'any'}")
        return self.learning_revert(promoted[0]["run_id"])

    def learning_selfmod_propose(
        self,
        target: str,
        *,
        weakness: str = "",
        ancestor_run_id: str | None = None,
    ) -> dict[str, Any]:
        if not self.settings.learning.selfmod.enabled:
            return {"ok": False, "reason": "learning selfmod is disabled"}
        provider = build_agent_provider(
            self.settings,
            repo_root=self.repo_root,
            event_logger=self._learning_event_logger,
        )
        engine = self._selfmod(provider=provider)
        return engine.propose(target=target, weakness=weakness, ancestor_run_id=ancestor_run_id)

    def learning_selfmod_archive(
        self,
        *,
        target: str | None = None,
        limit: int = 20,
    ) -> dict[str, Any]:
        return {
            "ok": True,
            "runs": archive_rows(
                self.store.learning_runs(
                    target=target,
                    kind="selfmod_variant",
                    limit=limit,
                )
            ),
        }

    def learning_selfmod_show(self, run_id: str) -> dict[str, Any]:
        row = self.store.learning_run(run_id)
        if row is None:
            raise KeyError(f"learning run not found: {run_id}")
        if row["kind"] != "selfmod_variant":
            raise ValueError("learning run is not a self-mod variant")
        return {"ok": True, "run": archive_rows([row])[0]}

    def learning_selfmod_adopt(
        self,
        run_id: str,
        *,
        approved_by: str = "local-user",
    ) -> dict[str, Any]:
        return self._selfmod().adopt(run_id, approved_by=approved_by)

    def learning_selfmod_revert(self, run_id: str) -> dict[str, Any]:
        return self._selfmod().revert(run_id)

    def learning_selfmod_reject(
        self,
        run_id: str,
        *,
        reason: str = "human rejected",
        rejected_by: str = "local-user",
    ) -> dict[str, Any]:
        return self._selfmod().reject(run_id, reason=reason, rejected_by=rejected_by)

    def _optimizer(self) -> ReflectiveOptimizer:
        return ReflectiveOptimizer(
            store=self.store,
            settings=self.settings,
            provider=build_agent_provider(
                self.settings,
                repo_root=self.repo_root,
                event_logger=self._learning_event_logger,
            ),
            evaluator=self._optimizer_evaluator(),
            model_family=self.settings.learning.actor_model_family,
            budget_tokens=self.settings.learning.max_tokens_per_run,
            side_information=self._optimizer_side_information(""),
        )

    def _selfmod(self, provider: Any | None = None) -> SelfModEngine:
        return SelfModEngine(
            repo_root=self.repo_root,
            store=self.store,
            settings=self.settings,
            provider=provider,
            model_family=self.settings.learning.actor_model_family,
            budget_tokens=self.settings.learning.max_tokens_per_run,
        )

    def _optimizer_evaluator(
        self, *, limit: int = 20, holdout_ratio: float = 0.3
    ):
        snapshot = self.resolver.resolve()
        cases = self.replay.harvest(limit)
        split_index = max(0, min(len(cases), int(len(cases) * (1 - holdout_ratio))))
        splits = {"train": cases[:split_index], "holdout": cases[split_index:]}

        def evaluate(target: str, params: dict[str, Any], split: str) -> dict[str, Any]:
            if not cases:
                return default_evaluator(target, params, split)
            selected = splits.get(split, splits["holdout"])
            before = current_parameters(self.settings, target)
            apply_parameters(self.settings, target, params)
            try:
                metrics = self.replay._score_cases(snapshot, selected)
            finally:
                apply_parameters(self.settings, target, before)
            return {
                **metrics,
                "success_rate": metrics.get("recall_at_pack", 0.0),
                "missing_files": round(1.0 - float(metrics.get("recall_at_pack", 0.0)), 4),
                "scope_drift": round(1.0 - float(metrics.get("precision_at_pack", 0.0)), 4),
            }

        return evaluate

    def _apply_promoted_optimization_overrides(self) -> None:
        for row in self.store.promoted_learning_runs():
            after = parse_run_json(row["after_json"])
            parameters = after.get("parameters", after)
            try:
                apply_parameters(self.settings, row["target"], parameters)
            except ValueError as exc:
                self._learning_event_logger(
                    "phase4",
                    "promoted_override_rejected",
                    row["run_id"],
                    {"target": row["target"], "error": str(exc)},
                )

    def _learning_benchmark_summary(self) -> dict[str, Any] | None:
        latest = self.store.agent_benchmark_runs(limit=1)
        if latest:
            row = _benchmark_row_dict(latest[0], include_report=False)
            return {
                "benchmark_run_id": row["benchmark_run_id"],
                "readable": True,
                "cases": row["cases"],
                "delta": row["delta"],
                "gate": row["gate"],
                "created_at": row["created_at"],
                "lift_attribution": row["lift_attribution"],
                "roadmap_pruning": row["roadmap_pruning"],
            }
        path = self.workspace_dir / "reports" / "agent-benchmark.json"
        if not path.exists():
            return None
        try:
            report = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {"path": str(path), "readable": False}
        return {
            "path": str(path),
            "readable": True,
            "cases": report.get("cases"),
            "delta": report.get("delta", {}),
            "gate": report.get("gate"),
            "created_at": report.get("created_at"),
        }

    def _learning_benchmark_trends(self, *, limit: int = 20) -> dict[str, Any]:
        rows = [
            _benchmark_row_dict(row, include_report=False)
            for row in self.store.agent_benchmark_runs(limit=limit)
        ]
        latest = rows[0] if rows else None
        oldest = rows[-1] if rows else None
        summary: dict[str, Any] = {"count": len(rows)}
        if latest and oldest:
            summary.update(
                {
                    "latest_success_rate_delta": latest["success_rate_delta"],
                    "success_rate_delta_change": round(
                        float(latest["success_rate_delta"])
                        - float(oldest["success_rate_delta"]),
                        6,
                    ),
                    "latest_scope_drift_reduction": latest[
                        "wrong_files_touched_reduction"
                    ],
                    "latest_context_retrieval_score": latest["context_retrieval_score"],
                    "latest_memory_score": latest["memory_score"],
                    "latest_cut_or_defer_candidates": latest["roadmap_pruning"].get(
                        "cut_or_defer_candidates",
                        [],
                    ),
                }
            )
        return {"summary": summary, "trends": rows}

    def _optimizer_side_information(self, target: str) -> dict[str, Any]:
        latest = self.store.agent_benchmark_runs(limit=1)
        if not latest:
            return {}
        row = _benchmark_row_dict(latest[0], include_report=True)
        report = row.get("report", {})
        return {
            "source": "latest_agent_benchmark",
            "target": target,
            "benchmark_run_id": row["benchmark_run_id"],
            "delta": row["delta"],
            "lift_attribution": row["lift_attribution"],
            "roadmap_pruning": row["roadmap_pruning"],
            "failure_traces": _benchmark_failure_traces(report, limit=8),
        }

    def _benchmark_pack(self, repo_root: Path, task: str) -> dict[str, Any]:
        with CtxLayerService(repo_root) as service:
            return service.get_context_pack(task)

    def _benchmark_preflight(
        self,
        repo_root: Path,
        pack_id: str,
        result: str,
        changed_files: list[str],
    ) -> dict[str, Any]:
        diff = ""
        try:
            completed = subprocess.run(
                ["git", "diff", "HEAD"],
                cwd=repo_root,
                check=True,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                timeout=30,
            )
            diff = completed.stdout
        except (subprocess.SubprocessError, FileNotFoundError):
            diff = ""
        with CtxLayerService(repo_root) as service:
            check = service.check_diff_against_pack(pack_id, diff)
            impact = service.get_impact_report(paths=changed_files, pack_id=pack_id)
            outcome = service.record_outcome(pack_id, result, changed_files)
        return {
            "check_diff": check,
            "impact": impact,
            "outcome": outcome,
        }

    def release_check(self, version: str = "1.0.0") -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.release.check(snapshot=snapshot, version=version)

    def release_acceptance_gates(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        result = self.release.acceptance_gates(repo_id=snapshot.repo_id)
        result["requirements"] = {
            "benchmark_corpus": FINAL_BENCHMARK_CORPUS_REQUIREMENTS,
        }
        return result

    def release_gap_register(self) -> dict[str, Any]:
        return {"ok": True, "register": default_gap_register()}

    def release_gap_validate(self) -> dict[str, Any]:
        return validate_gap_register(self.repo_root)

    def release_gap_write(self, path: str | None = None) -> dict[str, Any]:
        return write_default_gap_register(self.repo_root, path=Path(path) if path else None)

    def release_dead_code_inventory_write(self, path: str | None = None) -> dict[str, Any]:
        return self.release.write_dead_code_inventory(Path(path) if path else None)

    def release_no_v0_checklist_write(self, path: str | None = None) -> dict[str, Any]:
        return self.release.write_no_v0_release_checklist(Path(path) if path else None)

    def release_report(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.release.report(repo_id=snapshot.repo_id)

    def release_compare(self, baseline: str) -> dict[str, Any]:
        current = self.release_report()
        return self.release.compare(current=current, baseline_path=Path(baseline))

    def ci_check(
        self, base: str = "origin/main", head: str = "HEAD", pack_id: str | None = None
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.ci.check(snapshot=snapshot, base=base, head=head, pack_id=pack_id)

    def constitution_builder(self) -> ConstitutionBuilder:
        return ConstitutionBuilder(
            self.repo_root,
            self.store,
            self.settings,
            workspace_id=stable_id(str(self.repo_root))[:16],
        )

    def constitution_build(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.constitution_builder().build(snapshot.repo_id)

    def constitution_show(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.constitution_builder().latest(snapshot.repo_id)

    def constitution_check(
        self,
        paths: list[str] | None = None,
        *,
        staged: bool = False,
        task_session_id: str | None = None,
        for_ci: bool = False,
    ) -> dict[str, Any]:
        changed = paths or []
        deleted: list[str] = []
        if staged:
            changed = git_changed_paths(self.repo_root, staged=True)
            deleted = git_deleted_paths(self.repo_root, staged=True)
        elif not changed:
            changed = git_changed_paths(self.repo_root)
            deleted = git_deleted_paths(self.repo_root)
        return CapabilityPolicy(self.repo_root, self.settings).check_paths(
            changed,
            deleted_paths=deleted,
            task_session_id=task_session_id,
            for_ci=for_ci,
        )

    def task_governance(self) -> TaskGovernance:
        snapshot = self.resolver.resolve()
        return TaskGovernance(
            self.repo_root,
            self.store,
            self.settings,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
        )

    def task_start(self, task: str) -> dict[str, Any]:
        constitution = self.constitution_show()
        result = self.task_governance().start(
            task=task,
            constitution_hash=constitution["constitution_hash"],
            metadata={"objective": task, "task": task},
        )
        session = self._ensure_agent_session(
            task,
            metadata={
                "task_session_id": result["task_session_id"],
                "constitution_hash": result["constitution_hash"],
                "source": "task_start",
            },
        )
        self._record_agent_session_event(
            session["session_id"],
            "task_session",
            {
                "task_session_id": result["task_session_id"],
                "state": result["state"],
                "constitution_hash": result["constitution_hash"],
                "objective": task,
            },
        )
        self._continuation_memory().upsert_for_task_session(
            result["task_session_id"],
            agent_session_id=session["session_id"],
            event="task_start",
            state="intake",
            next_action="Request or serve a CTX Layer context pack for this task.",
        )
        result["agent_session_id"] = session["session_id"]
        return result

    def task_transition(
        self,
        task_session_id: str,
        state: str,
        *,
        actor: str = "local-user",
        reason: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        constitution_hash = None
        if pack_id:
            constitution_hash = self.get_pack_manifest(pack_id).get("constitution_hash")
        result = self.task_governance().transition(
            task_session_id,
            state,
            actor=actor,
            reason=reason,
            pack_id=pack_id,
            constitution_hash=constitution_hash,
        )
        session_id = self._session_id_for_task_session(task_session_id)
        if session_id:
            self._record_agent_session_event(
                session_id,
                "task_transition",
                {
                    "task_session_id": task_session_id,
                    "transition_id": result["transition_id"],
                    "from_state": result["from_state"],
                    "to_state": result["to_state"],
                    "actor": actor,
                    "reason": reason,
                    "pack_id": pack_id,
                    "constitution_hash": constitution_hash,
                },
            )
            self._continuation_memory().upsert_for_task_session(
                task_session_id,
                agent_session_id=session_id,
                event="task_transition",
                state=_continuation_state_for_task_state(state),
                reason=reason,
            )
            result["agent_session_id"] = session_id
        return result

    def task_show(self, task_session_id: str) -> dict[str, Any]:
        return self.task_governance().show(task_session_id)

    def loop_runbook(
        self,
        task: str,
        paths: list[str],
        tests: list[str] | None = None,
        result: str = "pass",
    ) -> dict[str, Any]:
        return core_loop_runbook(task=task, paths=paths, tests=tests, result=result)

    def task_plan_governance(
        self, *, repo_id: str | None = None, resolve_repo: bool = True
    ) -> TaskPlanGovernance:
        if repo_id is None and resolve_repo:
            repo_id = self.resolver.resolve().repo_id
        return TaskPlanGovernance(
            self.repo_root,
            self.store,
            self.settings,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=repo_id,
        )

    def plan_validate(
        self,
        plan: dict[str, Any],
        *,
        task_session_id: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        impact_report = self._plan_impact_report(plan, pack_id)
        behavior_report = self._plan_behavior_report(plan, pack_id)
        repo_id = self._pack_snapshot(pack_id).repo_id if pack_id else None
        return self.task_plan_governance(repo_id=repo_id, resolve_repo=False).validate(
            plan,
            task_session_id=task_session_id,
            pack_id=pack_id,
            impact_report=impact_report,
            behavior_report=behavior_report,
        )

    def plan_create(
        self,
        task_session_id: str,
        plan: dict[str, Any],
        *,
        pack_id: str | None = None,
        author: str = "local-user",
    ) -> dict[str, Any]:
        impact_report = self._plan_impact_report(plan, pack_id)
        behavior_report = self._plan_behavior_report(plan, pack_id)
        repo_id = self._pack_snapshot(pack_id).repo_id if pack_id else None
        result = self.task_plan_governance(repo_id=repo_id).create(
            task_session_id=task_session_id,
            plan=plan,
            pack_id=pack_id,
            author=author,
            impact_report=impact_report,
            behavior_report=behavior_report,
        )
        if result.get("ok"):
            session_id = self._session_id_for_task_session(task_session_id)
            if session_id:
                self._record_agent_session_event(
                    session_id,
                    "plan_created",
                    {
                        "task_session_id": task_session_id,
                        "plan_id": result["plan_id"],
                        "revision_id": result["revision_id"],
                        "revision_number": result["revision_number"],
                        "plan_hash": result["plan_hash"],
                        "pack_id": pack_id,
                        "author": author,
                        "intended_files": intended_files(result["plan"]),
                    },
                )
                self._continuation_memory(repo_id).upsert_for_task_session(
                    task_session_id,
                    agent_session_id=session_id,
                    event="plan_created",
                    state="planned",
                    reason=f"plan created: {result['plan_id']}",
                )
                result["agent_session_id"] = session_id
        return result

    def plan_amend(
        self,
        plan_id: str,
        plan: dict[str, Any],
        *,
        author: str = "local-user",
        reason: str | None = None,
    ) -> dict[str, Any]:
        impact_report = self._plan_impact_report(plan, None)
        behavior_report = self._plan_behavior_report(plan, None)
        result = self.task_plan_governance(resolve_repo=False).amend(
            plan_id=plan_id,
            plan=plan,
            author=author,
            reason=reason,
            impact_report=impact_report,
            behavior_report=behavior_report,
        )
        if result.get("ok"):
            session_id = self._session_id_for_plan(plan_id)
            if session_id:
                self._record_agent_session_event(
                    session_id,
                    "plan_amended",
                    {
                        "plan_id": plan_id,
                        "revision_id": result["revision_id"],
                        "revision_number": result["revision_number"],
                        "plan_hash": result["plan_hash"],
                        "previous_plan_hash": result["previous_plan_hash"],
                        "author": author,
                        "reason": reason,
                        "intended_files": intended_files(result["plan"]),
                    },
                )
                row = self.store.task_plan(plan_id)
                if row and row["task_session_id"]:
                    self._continuation_memory(row["repo_id"]).upsert_for_task_session(
                        row["task_session_id"],
                        agent_session_id=session_id,
                        event="plan_amended",
                        state="planned",
                        reason=reason or f"plan amended: {plan_id}",
                    )
                result["agent_session_id"] = session_id
        return result

    def plan_show(self, plan_id: str) -> dict[str, Any]:
        return self.task_plan_governance(resolve_repo=False).show(plan_id)

    def plan_checkpoint(
        self,
        plan_id: str,
        step_id: str,
        *,
        paths: list[str] | None = None,
        staged: bool = False,
    ) -> dict[str, Any]:
        changed_paths = paths or []
        if staged:
            changed_paths = git_changed_paths(self.repo_root, staged=True)
        elif not changed_paths:
            changed_paths = git_changed_paths(self.repo_root)
        result = self.task_plan_governance(resolve_repo=False).checkpoint(
            plan_id=plan_id,
            step_id=step_id,
            changed_paths=changed_paths,
        )
        session_id = self._session_id_for_plan(plan_id)
        if session_id:
            self._record_agent_session_event(
                session_id,
                "plan_checkpoint",
                {
                    "checkpoint_id": result["checkpoint_id"],
                    "plan_id": result["plan_id"],
                    "step_id": result["step_id"],
                    "status": result["status"],
                    "ok": result["ok"],
                    "changed_paths": result["changed_paths"],
                    "violation_count": len(result["violations"]),
                },
            )
            row = self.store.task_plan(plan_id)
            if row and row["task_session_id"]:
                self._continuation_memory(row["repo_id"]).upsert_for_task_session(
                    row["task_session_id"],
                    agent_session_id=session_id,
                    event="plan_checkpoint",
                    state="editing" if result["ok"] else "blocked",
                    blockers=[]
                    if result["ok"]
                    else [f"Checkpoint {step_id} failed with {len(result['violations'])} violation(s)."],
                    reason=f"checkpoint {result['status']}: {step_id}",
                )
            result["agent_session_id"] = session_id
        return result

    def _plan_impact_report(
        self, plan: dict[str, Any], pack_id: str | None
    ) -> dict[str, Any] | None:
        normalized, _errors = normalize_plan(plan)
        paths = intended_files(normalized)
        if not paths:
            return None
        if pack_id:
            return self.impact.report(
                snapshot=self._pack_snapshot(pack_id),
                paths=paths,
                pack_id=pack_id,
            )
        return self.get_impact_report(paths=paths, pack_id=pack_id)

    def _plan_behavior_report(
        self, plan: dict[str, Any], pack_id: str | None
    ) -> dict[str, Any] | None:
        normalized, _errors = normalize_plan(plan)
        paths = intended_files(normalized)
        if not paths:
            return None
        snapshot = self._pack_snapshot(pack_id) if pack_id else self.resolver.resolve()
        return self.behavior.check(snapshot=snapshot, paths=paths, pack_id=pack_id)

    def _pack_snapshot(self, pack_id: str) -> SnapshotInfo:
        manifest = self.get_pack_manifest(pack_id)
        return SnapshotInfo(
            repo_id=manifest["repo_id"],
            snapshot_id=manifest["snapshot_id"],
            base_commit_sha=manifest.get("base_commit_sha", ""),
            tree_digest=manifest.get("tree_digest", ""),
            dirty_digest=manifest.get("dirty_digest", ""),
            worktree_state=manifest.get("worktree_state", ""),
            branch_hint=manifest.get("branch_hint"),
        )

    def ci_emit_github(self, report: dict[str, Any] | None = None) -> dict[str, Any]:
        return {"ok": True, "workflow": GITHUB_ACTION_YAML, "annotations": github_annotations(report or {})}

    def ci_emit_gitlab(self, report: dict[str, Any] | None = None) -> dict[str, Any]:
        return {"ok": True, "workflow": GITLAB_CI_YAML, "annotations": gitlab_annotations(report or {})}

    def ci_explain(self, report_path: str) -> dict[str, Any]:
        report = json.loads(Path(report_path).read_text(encoding="utf-8"))
        return {"ok": True, "explanation": self.ci.explain(report)}

    def workspace_init(self) -> dict[str, Any]:
        return self.workspace.init()

    def workspace_add_repo(self, repo_path: str) -> dict[str, Any]:
        return self.workspace.add_repo(repo_path)

    def workspace_index(self) -> dict[str, Any]:
        return self.workspace.index()

    def workspace_impact(self, repo_id: str) -> dict[str, Any]:
        return self.workspace.impact(repo_id)

    def workspace_status(self) -> dict[str, Any]:
        return self.workspace.status()

    def workspace_rule_promotions(self) -> dict[str, Any]:
        return self.workspace.rule_promotions()

    def behavior_check(
        self,
        paths: list[str] | None = None,
        *,
        diff: str | None = None,
        pack_id: str | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        input_paths = paths or []
        if diff:
            input_paths.extend(paths_from_diff(diff))
        elif not input_paths:
            input_paths = git_changed_paths(self.repo_root)
        return self.behavior.check(
            snapshot=snapshot,
            paths=input_paths,
            diff=diff,
            pack_id=pack_id,
        )

    def verify_run(
        self,
        commands: list[str],
        *,
        pack_id: str | None = None,
        retry_budget: int = 0,
        timeout: int = 120,
        reproduction_command: str | None = None,
        context_decision: str | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        result = VerificationRunner(self.repo_root, self.compiler).run(
            snapshot=snapshot,
            commands=commands,
            pack_id=pack_id,
            retry_budget=retry_budget,
            timeout=timeout,
            reproduction_command=reproduction_command,
            context_decision=context_decision,
        )
        session_id = self._session_id_for_pack(pack_id) if pack_id else None
        if session_id:
            self._record_agent_session_event(
                session_id,
                "verification",
                {
                    "verification_id": result["verification_id"],
                    "pack_id": pack_id,
                    "status": result["status"],
                    "ok": result["ok"],
                    "commands": commands,
                    "retry_budget": retry_budget,
                    "failure_count": len(result.get("failures", [])),
                    "repair_pack_id": (result.get("repair_pack") or {}).get("pack_id"),
                },
            )
            result["agent_session_id"] = session_id
        return result

    def security_scan(self) -> dict[str, Any]:
        return SecretScanner(self.repo_root).scan()

    def security_status(self) -> dict[str, Any]:
        last_redteam = None
        for row in self.store.learning_events(limit=100):
            if row["kind"] != "redteam_run":
                continue
            try:
                payload = json.loads(row["payload_json"] or "{}")
            except json.JSONDecodeError:
                payload = {}
            last_redteam = {**dict(row), "payload": payload}
            break
        return {
            "ok": True,
            "encryption": encryption_status(
                self.workspace_dir / "workspace.db", self.settings.security.encrypt_workspace_db
            ),
            "retention": retention_policy(
                self.settings.audit.retention_keep_days,
                self.settings.audit.retention_keep_abandoned_days,
                self.settings.audit.retention_keep_merged,
            ),
            "privacy": privacy_statement(),
            "ingest": {
                "default_deny": self.settings.security.ingest.default_deny,
                "sanitize": self.settings.security.ingest.sanitize,
                "anomaly_threshold": self.settings.security.ingest.anomaly_threshold,
                "reviewer_min_role": self.settings.security.ingest.reviewer_min_role,
                "last_redteam": last_redteam,
            },
        }

    def security_ingest_redteam(
        self,
        fixtures: str | None = None,
        *,
        output: str | None = None,
        strict: bool = False,
    ) -> dict[str, Any]:
        fixtures_path = self.repo_root / (fixtures or self.settings.security.ingest.redteam_fixture_dir)
        output_path = self.repo_root / output if output else None
        report = RedTeamRunner(fixtures_path).run(output=output_path, strict=strict)
        self.store.write_learning_event(
            phase="phase_h4",
            kind="redteam_run",
            ref=report["redteam_run_id"],
            payload={
                "total": report["total"],
                "attacks": report["attacks"],
                "quarantined": report["quarantined"],
                "denied": report["denied"],
                "served_authoritative_count": report["served_authoritative_count"],
                "false_quarantine_rate": report["false_quarantine_rate"],
                "ok": report["ok"],
            },
        )
        return report

    def memory(self) -> BusinessRuleMemory:
        snapshot = self.resolver.resolve()
        return BusinessRuleMemory(
            self.repo_root,
            self.store,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
        )

    def memory_candidates(self, status: str | None = None) -> dict[str, Any]:
        if status:
            return self.memory().list(status)
        return self.memory().extract_candidates()

    def memory_scan(self) -> dict[str, Any]:
        return self.memory().scan()

    def memory_list(self, status: str | None = None) -> dict[str, Any]:
        return self.memory().list(status)

    def memory_approve(self, rule_id: str, approved_by: str = "local-user") -> dict[str, Any]:
        return self.memory().approve(rule_id, approved_by)

    def memory_reject(self, rule_id: str) -> dict[str, Any]:
        return self.memory().reject(rule_id)

    def memory_conflicts(self) -> dict[str, Any]:
        return self.memory().conflicts()

    def memory_explain(self, candidate_or_rule_id: str) -> dict[str, Any]:
        return self.memory().explain(candidate_or_rule_id)

    def memory_supersede(
        self, old_rule_id: str, new_candidate_id: str, approved_by: str = "local-user"
    ) -> dict[str, Any]:
        return self.memory().supersede(old_rule_id, new_candidate_id, approved_by)

    def memory_stale(self) -> dict[str, Any]:
        return self.memory().stale()

    def memory_verify(self) -> dict[str, Any]:
        return self.memory().verify()

    def memory_eval(self, action: str) -> dict[str, Any]:
        memory = self.memory()
        if action == "harvest":
            return memory.eval_harvest()
        if action == "replay":
            return memory.eval_replay()
        if action == "report":
            return memory.eval_report()
        raise ValueError(f"unknown memory eval action: {action}")

    def memory_extraction_eval(
        self, fixtures: str | None = None, source_type: str | None = None
    ) -> dict[str, Any]:
        return self.memory().extraction_eval(fixtures=fixtures, source_type=source_type)

    def memory_trust_calibrate(self, *, apply: bool = False) -> dict[str, Any]:
        return self.memory().trust_calibrate(apply=apply)

    def unified_memory(self) -> UnifiedMemory:
        snapshot = self.resolver.resolve()
        return UnifiedMemory(
            self.store,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
            recall_weights=self._learning_recall_weights(),
            embedder=self.compiler.embedder,
        )

    def memory_search(
        self, query: str, types: list[str] | None = None, status: str | None = None
    ) -> dict[str, Any]:
        return self.unified_memory().search(query, types=types, status=status)

    def memory_records(
        self, status: str | None = None, types: list[str] | None = None
    ) -> dict[str, Any]:
        memory = self.unified_memory()
        rows = self.store.memory_records(
            status=status,
            repo_id=memory.repo_id,
            workspace_id=memory.workspace_id,
        )
        allowed_types = set(types or [])
        return {
            "ok": True,
            "records": [
                memory._project_row(row)
                for row in rows
                if not allowed_types or row["type"] in allowed_types
            ],
        }

    def memory_show(self, record_id: str) -> dict[str, Any]:
        row = self.store.memory_record(record_id)
        if not row:
            return {"ok": False, "error": "memory not found", "record_id": record_id}
        memory = self.unified_memory()
        return {
            "ok": True,
            "record": memory._project_row(row),
            "evidence": [dict(item) for item in self.store.memory_evidence(record_id)],
            "revisions": [dict(item) for item in self.store.memory_revisions(record_id)],
        }

    def memory_propose(
        self,
        record_type: str,
        assertion: str,
        evidence_refs: list[dict[str, Any]] | None = None,
        source_kind: str = "manual",
        confidence: float = 1.0,
    ) -> dict[str, Any]:
        record_id = self.unified_memory().propose(
            record_type=record_type,
            assertion=assertion,
            source_kind=source_kind,
            confidence=confidence,
            extraction_method="manual",
            evidence=evidence_refs or [],
            status="candidate",
        )
        return {"ok": True, "record_id": record_id, "status": "candidate"}

    def memory_create_typed(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.unified_memory().create_typed(payload)

    def memory_update(
        self,
        record_id: str,
        patch: dict[str, Any],
        reason: str = "manual update",
        actor: str = "local-user",
    ) -> dict[str, Any]:
        return self.unified_memory().update(record_id, patch, actor=actor, reason=reason)

    def memory_validate(
        self,
        record_id: str,
        validator: str,
        evidence: dict[str, Any] | None = None,
        actor: str = "local-user",
    ) -> dict[str, Any]:
        return self.unified_memory().validate(
            record_id,
            validator=validator,
            evidence=evidence,
            actor=actor,
        )

    def memory_expire(self, record_id: str, reason: str, actor: str = "local-user") -> dict[str, Any]:
        return self.unified_memory().expire(record_id, reason=reason, actor=actor)

    def memory_quarantine(
        self,
        record_id: str,
        reason: str,
        severity: str = "high",
        actor: str = "codeowner",
    ) -> dict[str, Any]:
        return self.unified_memory().quarantine(
            record_id,
            reason=reason,
            severity=severity,
            actor=actor,
        )

    def memory_diff(
        self,
        record_id: str,
        revision_a: str | None = None,
        revision_b: str | None = None,
    ) -> dict[str, Any]:
        return self.unified_memory().diff(record_id, revision_a, revision_b)

    def memory_security_reviews(self, status: str | None = "open") -> dict[str, Any]:
        return {
            "ok": True,
            "reviews": [dict(row) for row in self.store.memory_review_queue(status)],
        }

    def memory_review_resolve(
        self,
        review_id: str,
        *,
        resolution: str,
        actor: str = "admin",
        target_record_id: str | None = None,
        validator: str = "human:security-review",
        reason: str = "security review resolved",
    ) -> dict[str, Any]:
        authorization = require_actor_role(actor, "codeowner", "memory_review_resolve")
        if not authorization["ok"]:
            raise PermissionError(
                f"memory_review_resolve requires {authorization['required_role']} role; "
                f"{authorization['actor']} is {authorization['actor_role']}"
            )
        review = self.store.memory_review(review_id)
        if not review:
            raise KeyError(f"memory review not found: {review_id}")
        record_id = str(review["record_id"])
        normalized = resolution.strip().lower().replace("-", "_")
        if normalized in {"approve", "approved", "release"}:
            action_result = self.memory_validate(record_id, validator, actor=actor)
            review_status = "resolved"
        elif normalized in {"delete", "reject", "rejected"}:
            self.unified_memory().reject(record_id, actor=actor)
            action_result = {"ok": True, "record_id": record_id, "status": "rejected"}
            review_status = "resolved"
        elif normalized in {"merge", "supersede"}:
            if not target_record_id:
                raise ValueError("merge review resolution requires target_record_id")
            self.unified_memory().supersede(record_id, target_record_id, actor=actor)
            action_result = {
                "ok": True,
                "record_id": record_id,
                "status": "superseded",
                "superseded_by": target_record_id,
            }
            review_status = "resolved"
        elif normalized in {"keep_quarantined", "keep", "quarantine"}:
            action_result = {"ok": True, "record_id": record_id, "status": "quarantined"}
            review_status = "resolved"
        else:
            raise ValueError("resolution must be approve, delete, merge, or keep_quarantined")
        resolution_payload = {
            "action": normalized,
            "actor": actor,
            "actor_role": authorization["actor_role"],
            "reason": reason,
            "target_record_id": target_record_id,
            "result": action_result,
        }
        self.store.resolve_memory_review(
            review_id=review_id,
            status=review_status,
            resolution=resolution_payload,
        )
        resolved = self.store.memory_review(review_id)
        return {
            "ok": True,
            "review": dict(resolved) if resolved else {"review_id": review_id},
            "resolution": resolution_payload,
            "record": self.memory_show(record_id).get("record"),
        }

    def memory_recall(
        self,
        query: str,
        paths: list[str] | None = None,
        types: list[str] | None = None,
        limit: int = 20,
        include_org: bool = False,
    ) -> dict[str, Any]:
        return self.unified_memory().recall(
            query,
            paths=paths,
            types=types,
            limit=limit,
            include_org=include_org,
        )

    def _continuation_memory(self, repo_id: str | None = None) -> ContinuationMemory:
        if repo_id is None:
            repo_id = self.resolver.resolve().repo_id
        return ContinuationMemory(
            self.store,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=repo_id,
            recall_weights=self._learning_recall_weights(),
            repo_root=self.repo_root,
        )

    def continuation_list(
        self, status: str | None = None, limit: int = 20
    ) -> dict[str, Any]:
        return self._continuation_memory().list(status=status, limit=limit)

    def continuation_show(self, continuation_id: str) -> dict[str, Any]:
        return self._continuation_memory().show(continuation_id)

    def continuation_update(
        self,
        continuation_id: str,
        *,
        state: str | None = None,
        next_action: str | None = None,
        blockers: list[str] | None = None,
        reason: str = "manual continuation update",
    ) -> dict[str, Any]:
        return self._continuation_memory().update(
            continuation_id,
            state=state,
            next_action=next_action,
            blockers=blockers,
            reason=reason,
        )

    def continuation_resume(self, task: str, limit: int = 3) -> dict[str, Any]:
        return self._continuation_memory().resume(task, limit=limit)

    def continuation_abandon(self, continuation_id: str, reason: str) -> dict[str, Any]:
        return self._continuation_memory().abandon(continuation_id, reason=reason)

    def memory_consolidate(
        self, session_id: str | None = None, recent: int = 10
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return MemoryConsolidator(
            self.store,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
            min_session_evidence=self.settings.learning.memory.min_session_evidence,
        ).consolidate(session_id=session_id, recent=recent)

    def memory_reflect(
        self, session_id: str | None = None, recent: int = 10
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        provider = build_agent_provider(
            self.settings,
            repo_root=self.repo_root,
            event_logger=self._learning_event_logger,
        )
        return MemoryReflector(
            store=self.store,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
            provider=provider,
            model_family=self.settings.learning.actor_model_family,
            budget_tokens=self.settings.learning.max_tokens_per_task,
        ).reflect(session_id=session_id, recent=recent)

    def memory_dream(self, session_id: str | None = None, recent: int = 10) -> dict[str, Any]:
        deterministic = self.memory_consolidate(session_id=session_id, recent=recent)
        reflection = self.memory_reflect(session_id=session_id, recent=recent)
        return {
            "ok": bool(deterministic.get("ok") and reflection.get("ok")),
            "deterministic": deterministic,
            "reflection": reflection,
            "proposed": (deterministic.get("proposed") or []) + (reflection.get("proposed") or []),
            "skipped": reflection.get("skipped", []),
        }

    def memory_maintain(self, limit: int = 200) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        rows = self.store.memory_records(
            status="candidate",
            repo_id=snapshot.repo_id,
            workspace_id=stable_id(str(self.repo_root))[:16],
        )
        memory = self.unified_memory()
        decisions = [memory.maintain_candidate(row["record_id"]) for row in rows[:limit]]
        return {"ok": True, "count": len(decisions), "decisions": decisions}

    def memory_promote(self, record_id: str, validator: str, actor: str = "local-user") -> dict[str, Any]:
        allowed = ("human:", "real_outcome:", "skill_replay:", "benchmark:", "deterministic:")
        if not any(validator.startswith(prefix) for prefix in allowed):
            raise ValueError(
                "validator must start with human:, real_outcome:, skill_replay:, benchmark:, or deterministic:"
            )
        return self.unified_memory().validate(record_id, validator=validator, actor=actor)

    def memory_review(self, status: str | None = "open") -> dict[str, Any]:
        return self.memory_security_reviews(status)

    def memory_utilization(self, pack_id: str) -> dict[str, Any]:
        manifest = self.get_pack_manifest(pack_id)
        changed = []
        outcomes = self.store.conn.execute(
            "SELECT * FROM outcomes WHERE pack_id = ? ORDER BY created_at DESC", (pack_id,)
        ).fetchall()
        if outcomes:
            try:
                changed = json.loads(outcomes[0]["files_changed_json"] or "[]")
            except json.JSONDecodeError:
                changed = []
        changed_set = {path.replace("\\", "/") for path in changed}
        inferred = []
        sections = {
            "project_memory": "project_memory_evidence_path_changed",
            "policy_references": "policy_reference_path_changed",
            "continuations": "continuation_path_changed",
        }
        for section, utilization_kind in sections.items():
            for memory in manifest.get(section, []) or []:
                record = self.store.memory_record(memory["record_id"])
                metadata = {}
                if record:
                    try:
                        metadata = json.loads(record["metadata_json"] or "{}")
                    except json.JSONDecodeError:
                        metadata = {}
                evidence_paths = {
                    item.get("path")
                    for item in memory.get("evidence", [])
                    if item.get("path")
                }
                if record:
                    evidence_paths.update(
                        item["path"]
                        for item in self.store.memory_evidence(memory["record_id"])
                        if item["path"]
                    )
                for key in ("policy_file", "intended_files", "changed_files", "scope_refs"):
                    value = metadata.get(key)
                    if isinstance(value, str):
                        evidence_paths.add(value)
                    elif isinstance(value, list):
                        evidence_paths.update(str(item) for item in value if str(item).strip())
                evidence_paths = {path.replace("\\", "/") for path in evidence_paths if path}
                overlap = sorted(changed_set & evidence_paths)
                if overlap:
                    utilization_id = self.store.record_memory_utilization(
                        pack_id=pack_id,
                        memory_record_id=memory["record_id"],
                        utilization_kind=utilization_kind,
                        score=1.0,
                        metadata={"paths": overlap, "section": section},
                    )
                    inferred.append(
                        {
                            "utilization_id": utilization_id,
                            "record_id": memory["record_id"],
                            "kind": utilization_kind,
                            "score": 1.0,
                            "paths": overlap,
                            "section": section,
                        }
                    )
        return {
            "ok": True,
            "pack_id": pack_id,
            "served": [dict(row) for row in self.store.memory_accesses(pack_id)],
            "inferred": inferred,
            "recorded": [dict(row) for row in self.store.memory_utilization(pack_id)],
        }

    def skill_library(self) -> SkillLibrary:
        snapshot = self.resolver.resolve()
        provider = build_agent_provider(
            self.settings,
            repo_root=self.repo_root,
            event_logger=self._learning_event_logger,
        )
        return SkillLibrary(
            store=self.store,
            repo_root=self.repo_root,
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
            provider=provider,
            model_family=self.settings.learning.actor_model_family,
            budget_tokens=self.settings.learning.max_tokens_per_task,
            settings=self.settings,
            critical_path_globs=self.settings.eval.critical_paths,
        )

    def skill_induce(self, session_id: str) -> dict[str, Any]:
        return self.skill_library().induce(session_id=session_id)

    def skill_list(self, status: str | None = None, trust: str | None = None) -> dict[str, Any]:
        return self.skill_library().list(status=status, trust=trust)

    def skill_show(self, skill_id: str) -> dict[str, Any]:
        return self.skill_library().show(skill_id)

    def skill_replay(self, skill_id: str, timeout: int = 120) -> dict[str, Any]:
        return self.skill_library().replay(skill_id, timeout=timeout)

    def skill_approve(self, skill_id: str, approved_by: str = "local-user") -> dict[str, Any]:
        return self.skill_library().approve(skill_id, approved_by=approved_by)

    def skill_reject(self, skill_id: str, reason: str = "manual reject") -> dict[str, Any]:
        return self.skill_library().reject(skill_id, reason=reason)

    def skill_prune(self, max_failures: int = 3) -> dict[str, Any]:
        return self.skill_library().prune(max_failures=max_failures)

    def skill_maintain(
        self, max_failures: int = 3, stale_after_days: int | None = None
    ) -> dict[str, Any]:
        return self.skill_library().maintain(
            max_failures=max_failures,
            stale_after_days=stale_after_days,
        )

    def skill_search(
        self, query: str, limit: int = 5, include_untrusted: bool = False
    ) -> dict[str, Any]:
        return self.skill_library().search(
            query,
            limit=limit,
            include_untrusted=include_untrusted,
        )

    def _workspace_id(self) -> str:
        return stable_id(str(self.repo_root))[:16]

    def _agent_session_memory(self, repo_id: str | None = None) -> AgentSessionMemory:
        return AgentSessionMemory(
            self.store,
            workspace_id=self._workspace_id(),
            repo_id=repo_id,
        )

    def _ensure_agent_session(
        self,
        task: str,
        *,
        repo_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.current_identity()
        if repo_id is None:
            repo_id = snapshot.repo_id
        session = self._agent_session_memory(repo_id).ensure(
            task=task,
            metadata={
                "bound_snapshot_id": snapshot.snapshot_id,
                "base_commit_sha": snapshot.base_commit_sha,
                "worktree_state": snapshot.worktree_state,
                **(metadata or {}),
            },
        )
        session["lease"] = self.store.acquire_session_lease(
            session_id=session["session_id"],
            workspace_id=self._workspace_id(),
            repo_id=repo_id,
            agent_name="codex",
            bound_snapshot_id=snapshot.snapshot_id,
        )
        return session

    def _session_id_for_task_session(self, task_session_id: str) -> str | None:
        row = self.store.agent_session_for_artifact("task_session", task_session_id)
        return row["session_id"] if row else None

    def _session_id_for_pack(self, pack_id: str) -> str | None:
        row = self.store.agent_session_for_artifact("pack_served", pack_id)
        return row["session_id"] if row else None

    def _session_id_for_plan(self, plan_id: str) -> str | None:
        row = self.store.task_plan(plan_id)
        if not row or not row["task_session_id"]:
            return None
        return self._session_id_for_task_session(row["task_session_id"])

    def _task_text_for_session(self, task_session_id: str) -> str | None:
        row = self.store.task_session(task_session_id)
        if not row:
            return None
        try:
            metadata = json.loads(row["metadata_json"] or "{}")
        except json.JSONDecodeError:
            metadata = {}
        task = metadata.get("task") or metadata.get("objective")
        return str(task) if task else None

    def _codex_write_scope_overlap(
        self,
        parent_session_id: str,
        parallel_run_id: str,
        write_scope: list[str],
    ) -> list[str]:
        if not write_scope:
            return []
        requested = set(write_scope)
        active: set[str] = set()
        stopped_children: set[str] = set()
        for row in self.store.agent_session_events(parent_session_id):
            try:
                payload = json.loads(row["payload_json"] or "{}")
            except json.JSONDecodeError:
                payload = {}
            if payload.get("parallel_run_id") != parallel_run_id:
                continue
            child_id = payload.get("child_agent_session_id")
            if row["event_type"] == "codex_child_stop" and child_id:
                stopped_children.add(str(child_id))
            if row["event_type"] != "codex_child_start" or not child_id:
                continue
            if str(child_id) in stopped_children:
                continue
            active.update(str(path) for path in payload.get("write_scope", []) or [])
        return sorted(requested & active)

    def _codex_child_events(self, parallel_run_id: str) -> list[dict[str, Any]]:
        rows = self.store.agent_sessions(workspace_id=self._workspace_id(), limit=200)
        events: list[dict[str, Any]] = []
        for row in rows:
            for event in self.store.agent_session_events(row["session_id"]):
                if event["event_type"] not in {"codex_child_start", "codex_child_stop"}:
                    continue
                try:
                    payload = json.loads(event["payload_json"] or "{}")
                except json.JSONDecodeError:
                    payload = {}
                if payload.get("parallel_run_id") == parallel_run_id:
                    events.append({**dict(event), "payload": payload})
        return events

    def _record_agent_session_event(
        self, session_id: str, event_type: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return self._agent_session_memory().event(
            session_id=session_id,
            event_type=event_type,
            payload=payload,
        )

    def session_memory(self) -> AgentSessionMemory:
        snapshot = self.resolver.resolve()
        return self._agent_session_memory(snapshot.repo_id)

    def session_start(
        self, task: str, agent_name: str = "codex", metadata: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        result = self._agent_session_memory(snapshot.repo_id).start(
            task=task,
            agent_name=agent_name,
            metadata={
                **(metadata or {}),
                "bound_snapshot_id": snapshot.snapshot_id,
                "base_commit_sha": snapshot.base_commit_sha,
                "worktree_state": snapshot.worktree_state,
            },
        )
        result["lease"] = self.store.acquire_session_lease(
            session_id=result["session_id"],
            workspace_id=self._workspace_id(),
            repo_id=snapshot.repo_id,
            agent_name=agent_name,
            bound_snapshot_id=snapshot.snapshot_id,
        )
        return result

    def session_event(
        self, session_id: str, event_type: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return self.session_memory().event(
            session_id=session_id, event_type=event_type, payload=payload
        )

    def session_finish(
        self, session_id: str, result: str, metadata: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        finished = self.session_memory().finish(
            session_id=session_id, result=result, metadata=metadata
        )
        finished["released_leases"] = self.store.release_session_leases(session_id)
        state = (
            "completed"
            if result.strip().lower() in {"pass", "passed", "ok", "success"}
            else "ready_to_resume"
        )
        self._continuation_memory().upsert_for_agent_session(
            session_id,
            event="session_finish",
            state=state,
            next_action=None if state == "completed" else "Resume from the latest incomplete plan step.",
            reason=f"session finished: {result}",
        )
        dream_enabled = (
            self.settings.learning.memory.dream_on_finish
            or self.settings.learning.memory.reflect_on_finish
        )
        if self.settings.learning.enabled and dream_enabled:
            try:
                finished["reflection"] = self.memory_dream(session_id=session_id)
            except Exception as exc:  # noqa: BLE001 - session finish must remain durable.
                self._learning_event_logger(
                    "phase1",
                    "reflection_error",
                    session_id,
                    {"error": str(exc)},
                )
                finished["reflection"] = {
                    "ok": False,
                    "session_id": session_id,
                    "error": str(exc),
                }
        return finished

    def session_explain(self, session_id: str) -> dict[str, Any]:
        return self.session_memory().explain(session_id)

    def session_leases(self, *, status: str | None = "active") -> dict[str, Any]:
        snapshot = self.resolver.current_identity()
        rows = self.store.session_leases(
            workspace_id=self._workspace_id(),
            repo_id=snapshot.repo_id,
            status=status,
        )
        return {"ok": True, "leases": [_lease_dict(row) for row in rows]}

    def session_declare_impact(self, session_id: str, paths: list[str]) -> dict[str, Any]:
        result = self.store.declare_session_impact(session_id=session_id, paths=paths)
        self.session_memory().event(
            session_id=session_id,
            event_type="impact_declared",
            payload={
                "paths": result["impact_paths"],
                "impact_hash": result["impact_hash"],
                "conflict_ids": [item["conflict_id"] for item in result["conflicts"]],
            },
        )
        return result

    def session_conflicts(self, *, status: str | None = "open") -> dict[str, Any]:
        snapshot = self.resolver.current_identity()
        rows = self.store.session_conflicts(
            workspace_id=self._workspace_id(),
            repo_id=snapshot.repo_id,
            status=status,
        )
        return {"ok": True, "conflicts": [_conflict_dict(row) for row in rows]}

    def session_conflict_update(self, conflict_id: str, status: str) -> dict[str, Any]:
        return self.store.update_session_conflict_status(conflict_id, status)

    def _learning_recall_weights(self) -> dict[str, float]:
        memory = self.settings.learning.memory
        return {
            "recency": memory.recall_recency_weight,
            "importance": memory.recall_importance_weight,
            "relevance": memory.recall_relevance_weight,
        }

    def _learning_event_logger(
        self, phase: str, kind: str, ref: str | None, payload: dict[str, Any]
    ) -> None:
        self.store.write_learning_event(phase=phase, kind=kind, ref=ref, payload=payload)

    def runtime(self) -> RuntimeIngestor:
        snapshot = self.resolver.resolve()
        return RuntimeIngestor(
            self.repo_root,
            self.store,
            repo_id=snapshot.repo_id,
            workspace_id=stable_id(str(self.repo_root))[:16],
        )

    def runtime_ingest(self, source: str, path: str | None = None) -> dict[str, Any]:
        if source == "incidents":
            if not path:
                raise ValueError("runtime ingest incidents requires a path")
            events = runtime_incidents.load(Path(path))
        elif source == "sentry":
            if not path:
                raise ValueError("runtime ingest sentry requires a JSON path")
            events = runtime_sentry.load(Path(path))
        elif source == "ci-failures":
            if not path:
                raise ValueError("runtime ingest ci-failures requires a log path")
            events = runtime_ci_failures.load(Path(path))
        elif source == "feature-flags":
            if not path:
                raise ValueError("runtime ingest feature-flags requires a JSON path")
            events = runtime_feature_flags.load(Path(path))
        elif source == "opentelemetry":
            if not path:
                raise ValueError("runtime ingest opentelemetry requires a JSON path")
            events = runtime_opentelemetry.load(Path(path))
        else:
            raise ValueError(f"unknown runtime source: {source}")
        return self.runtime().ingest_events(source, events)

    def runtime_link_errors(self) -> dict[str, Any]:
        return self.runtime().linked_errors()

    def runtime_candidates(self) -> dict[str, Any]:
        return self.runtime().candidates()

    def org(self) -> OrgIngestor:
        snapshot = self.resolver.resolve()
        return OrgIngestor(
            self.repo_root,
            self.store,
            repo_id=snapshot.repo_id,
            workspace_id=stable_id(str(self.repo_root))[:16],
        )

    def org_connector_add(
        self,
        kind: str,
        *,
        config: dict[str, Any] | None = None,
        display_name: str | None = None,
        secret_ref: str | None = None,
        access_scope: str = "restricted",
        remote_enabled: bool = False,
    ) -> dict[str, Any]:
        return self.org().connector_add(
            kind=kind,
            display_name=display_name,
            config=config or {},
            secret_ref=secret_ref,
            access_scope=access_scope,
            remote_enabled=remote_enabled,
        )

    def org_connectors(self, kind: str | None = None) -> dict[str, Any]:
        return self.org().connectors(kind=kind)

    def org_ingest(
        self,
        connector: str,
        *,
        since: str | None = None,
        path: str | None = None,
        remote: bool = False,
        actor: str = "system",
    ) -> dict[str, Any]:
        return self.org().ingest(connector, since=since, path=path, remote=remote, actor=actor)

    def org_candidates(
        self,
        *,
        status: str | None = "quarantined",
        source: str | None = None,
        scope: str | None = None,
        actor: str = "local-user",
        limit: int = 100,
    ) -> dict[str, Any]:
        return self.org().candidates(
            status=status,
            source=source,
            scope=scope,
            actor=actor,
            limit=limit,
        )

    def org_approve(
        self, candidate_id: str, *, actor: str = "codeowner", supersede: str | None = None
    ) -> dict[str, Any]:
        return self.org().approve(candidate_id, actor=actor, supersede=supersede)

    def org_reject(
        self, candidate_id: str, *, actor: str = "codeowner", reason: str = "rejected"
    ) -> dict[str, Any]:
        return self.org().reject(candidate_id, actor=actor, reason=reason)

    def org_audit(self, candidate_id: str) -> dict[str, Any]:
        return self.org().audit(candidate_id)

    def decision(self) -> DecisionEngine:
        snapshot = self.resolver.resolve()
        return DecisionEngine(
            repo_root=self.repo_root,
            store=self.store,
            impact=self.impact,
            memory=self.unified_memory(),
            workspace_id=stable_id(str(self.repo_root))[:16],
            repo_id=snapshot.repo_id,
        )

    def decision_start(
        self,
        question: str,
        *,
        options: list[str] | None = None,
        seed_paths: list[str] | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.decision().start(
            question=question,
            options_seed=options or [],
            seed_paths=seed_paths or [],
            snapshot=snapshot,
        )

    def decision_analyze(self, decision_id: str) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.decision().analyze(decision_id, snapshot=snapshot)

    def decision_record(
        self,
        decision_id: str,
        *,
        chosen_option_id: str,
        rationale: str,
        actor: str = "local-user",
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.decision().record(
            decision_id,
            chosen_option_id=chosen_option_id,
            rationale=rationale,
            actor=actor,
            snapshot=snapshot,
        )

    def decision_show(self, decision_id: str) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.decision().show(decision_id, snapshot=snapshot)

    def decision_list(self, *, status: str | None = None, limit: int = 50) -> dict[str, Any]:
        return self.decision().list(status=status, limit=limit)

    def dashboard_data(self) -> dict[str, Any]:
        return {"ok": True, "dashboard": Dashboard(self.store, repo_root=self.repo_root).data()}

    def dashboard_render(self, output: str = ".ctxlayer/dashboard.html") -> dict[str, Any]:
        return Dashboard(self.store, repo_root=self.repo_root).render_html(self.repo_root / output)

    def metrics_rollup(
        self,
        *,
        label: str | None = None,
        limit: int = 30,
        output: str | None = None,
    ) -> dict[str, Any]:
        """Emit a privacy-safe, anonymized rollup of this project's CTX Layer impact.

        Read-only: aggregates benchmark lift, outcomes, and learning activity into
        numeric metrics plus an opaque ``project_id`` (and optional ``label``) so a
        deployment's impact can be compared against others without exporting any
        repository content. Collect one per install and diff them.
        """
        snapshot = self.resolver.resolve()
        files = self.store.snapshot_files(snapshot.snapshot_id)
        graph = self.store.graph_stats(snapshot.repo_id)
        scale = {
            "files": len(files),
            "loc": sum(int(row["loc"] or 0) for row in files),
            # Only count-shaped graph fields; central_files carries paths, so it is dropped.
            "symbols": int(graph.get("symbols", 0)),
            "logical_edges": graph.get("logical_edges", {}),
            "semantic_nodes": graph.get("semantic_nodes", {}),
            "semantic_edges": graph.get("semantic_edges", {}),
        }
        rollup = MetricsRollup(
            self.store,
            project_id=self._workspace_id(),
            repo_id=snapshot.repo_id,
            label=label if label is not None else self.settings.toolchain.project_label,
            version=__version__,
            generated_at=utc_now(),
            scale=scale,
            limit=limit,
        ).data()
        if output:
            out_path = self.repo_root / output
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(json.dumps(rollup, indent=2, sort_keys=True), encoding="utf-8")
            rollup["output"] = str(out_path)
        return rollup

    def semantic_index(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve(refresh=True)
        return self.semantic.index(snapshot)

    def semantic_search(self, query: str, limit: int = 20) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.semantic.search(snapshot.repo_id, query, limit)

    def search_repo(self, term: str, max_hops: int = 2, limit: int = 20) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        self.semantic.index(snapshot)
        return self.semantic.search_repo(
            snapshot,
            term,
            max_hops=max_hops,
            limit=limit,
        )

    def graph_stats(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.semantic.stats(snapshot.repo_id)

    def graph_health(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve(refresh=True)
        return self.semantic.health(snapshot.repo_id, snapshot=snapshot)

    def impact_of(self, paths: list[str] | None = None) -> dict[str, Any]:
        return self.get_impact_report(paths=paths or [])

    def business_entity_add(
        self,
        *,
        node_type: str,
        name: str,
        attrs: dict[str, Any] | None = None,
        origin: str = "manual",
        source_type: str | None = None,
        source_ref: str | None = None,
        proposed_by: str = "user",
        confidence: float = 0.9,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.business_graph.add_entity(
            repo_id=snapshot.repo_id,
            node_type=node_type,
            name=name,
            attrs=attrs or {},
            origin=origin,
            source_type=source_type,
            source_ref=source_ref,
            proposed_by=proposed_by,
            confidence=confidence,
        )

    def business_connector_candidate(
        self,
        *,
        node_type: str,
        name: str,
        attrs: dict[str, Any] | None = None,
        source_type: str = "connector",
        source_ref: str = "",
        confidence: float = 0.7,
        proposed_by: str = "connector",
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.business_graph.add_connector_candidate(
            repo_id=snapshot.repo_id,
            candidate=BusinessNodeCandidate(
                node_type=node_type,
                name=name,
                attrs=attrs or {},
                source_type=source_type,
                source_ref=source_ref,
                confidence=confidence,
                proposed_by=proposed_by,
            ),
        )

    def business_entity_bulk_add(
        self,
        *,
        file: str,
        origin: str = "manual",
        proposed_by: str = "user",
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.business_graph.bulk_add_file(
            repo_id=snapshot.repo_id,
            file=file,
            origin=origin,
            proposed_by=proposed_by,
        )

    def business_entity_list(
        self,
        *,
        status: str | None = None,
        node_type: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.business_graph.list(
            repo_id=snapshot.repo_id,
            status=status,
            node_type=node_type,
            limit=limit,
        )

    def business_entity_approve(
        self, node_id: str, *, approver: str = "human", notes: str = ""
    ) -> dict[str, Any]:
        return self.business_graph.approve(node_id, approver=approver, notes=notes)

    def business_entity_reject(
        self, node_id: str, *, approver: str = "human", reason: str = ""
    ) -> dict[str, Any]:
        return self.business_graph.reject(node_id, approver=approver, reason=reason)

    def business_link(
        self,
        *,
        src_node_id: str,
        dst_node_id: str,
        kind: str,
        source_ref: str = "manual",
        source_type: str = "manual_entry",
        proposed_by: str = "user",
        confidence: float | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.business_graph.link(
            repo_id=snapshot.repo_id,
            src_node_id=src_node_id,
            dst_node_id=dst_node_id,
            kind=kind,
            source_ref=source_ref,
            source_type=source_type,
            proposed_by=proposed_by,
            confidence=confidence,
        )

    def semantic_explain(self, node_id: str) -> dict[str, Any]:
        return self.semantic.explain(node_id)

    def semantic_graph_for_path(self, path: str) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.semantic.graph_for_path(snapshot.repo_id, path.replace("\\", "/"))

    def graph_neighbors(
        self,
        path: str,
        *,
        max_hops: int = 1,
        limit: int = 20,
        kinds: list[str] | None = None,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        self.semantic.index(snapshot)
        return self.semantic.neighbors_for_path(
            snapshot.repo_id,
            path,
            max_hops=max_hops,
            limit=limit,
            kinds=kinds,
        )

    def graph_path(
        self,
        source_path: str,
        target_path: str,
        *,
        max_hops: int = 4,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        self.semantic.index(snapshot)
        return self.semantic.path_between(
            snapshot.repo_id,
            source_path,
            target_path,
            max_hops=max_hops,
        )

    def graph_tests_for_path(self, path: str) -> dict[str, Any]:
        report = self.get_impact_report(paths=[path.replace("\\", "/")])
        tests = [
            item
            for item in report.get("tests", [])
            if item.get("path") or item.get("command")
        ]
        return {
            "ok": True,
            "path": path.replace("\\", "/"),
            "tests": tests,
            "impact_report_id": report.get("impact_report_id"),
            "risk": report.get("risk", {}),
        }

    def graph_contracts_for_path(self, path: str) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        self.semantic.index(snapshot)
        return self.semantic.contracts_for_path(snapshot.repo_id, path)

    def semantic_list(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.semantic.list_nodes(snapshot.repo_id)

    def semantic_low_confidence(self, threshold: float = 0.5) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        self.semantic.index(snapshot)
        return self.semantic.low_confidence_regions(snapshot.repo_id, threshold)

    def semantic_accuracy_eval(self, fixtures: str | None = None) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.graph_accuracy.run(repo_id=snapshot.repo_id, fixtures=fixtures)

    def semantic_repair_list(
        self,
        *,
        status: str | None = "open",
        limit: int = 100,
    ) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.semantic_repair.list(repo_id=snapshot.repo_id, status=status, limit=limit)

    def semantic_repair_confirm(
        self,
        finding_id: str,
        *,
        actor: str = "human",
        rationale: str = "",
    ) -> dict[str, Any]:
        return self.semantic_repair.confirm(finding_id, actor=actor, rationale=rationale)

    def semantic_repair_reject(
        self,
        finding_id: str,
        *,
        actor: str = "human",
        rationale: str = "",
    ) -> dict[str, Any]:
        return self.semantic_repair.reject(finding_id, actor=actor, rationale=rationale)

    def architecture_infer(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        self.semantic.index(snapshot)
        return self.architecture.infer(snapshot)

    def architecture_explain(self, service_name: str) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        self.semantic.index(snapshot)
        return self.architecture.explain(snapshot, service_name)

    def architecture_drift(self, *, strict: bool = False) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        self.semantic.index(snapshot)
        return self.architecture.drift(snapshot, strict=strict)

    def architecture_critical_paths(self) -> dict[str, Any]:
        snapshot = self.resolver.resolve()
        return self.architecture.critical_paths(snapshot)

    def agent_route(
        self,
        task: str,
        *,
        risk_score: float = 0.0,
        capabilities: list[str] | None = None,
        remote_review_enabled: bool = False,
    ) -> dict[str, Any]:
        return self.agent_router.route(
            task=task,
            risk_score=risk_score,
            capabilities=capabilities,
            remote_review_enabled=remote_review_enabled,
        )

    def bench(self) -> dict[str, Any]:
        start = time.perf_counter()
        snapshot = self.resolver.resolve(refresh=True)
        index_ms = (time.perf_counter() - start) * 1000
        start = time.perf_counter()
        rows = self.store.search_chunks(snapshot.snapshot_id, "snapshot context resolver", limit=20)
        search_ms = (time.perf_counter() - start) * 1000
        files = self.store.snapshot_files(snapshot.snapshot_id)
        loc = sum(int(row["loc"] or 0) for row in files)
        return {
            "snapshot_id": snapshot.snapshot_id,
            "files": len(files),
            "loc": loc,
            "index_ms": round(index_ms, 2),
            "parse_loc_per_sec": round(loc / max(index_ms / 1000, 0.001), 2),
            "search_ms": round(search_ms, 2),
            "search_results": len(rows),
        }

    def doctor(self) -> dict[str, Any]:
        tree_sitter = tree_sitter_status()
        setup = setup_readiness(self.repo_root)
        remediation = _setup_remediation(setup.get("missing", []))
        blocking_missing = _setup_blocking_missing(setup.get("missing", []))
        return {
            "ok": True,
            "operational": True,
            "setup_complete": bool(setup["ok"]),
            "ready_for_work": not blocking_missing,
            "setup_blocking": bool(blocking_missing),
            "setup_blocking_missing": blocking_missing,
            "setup_advisory_missing": [
                item for item in setup.get("missing", []) if item not in blocking_missing
            ],
            "repo": str(self.repo_root),
            "database": str(self.workspace_dir / "workspace.db"),
            "store": self.store.capabilities(),
            "tree_sitter": {
                "available": tree_sitter.available,
                "languages": tree_sitter.languages,
                "error": tree_sitter.error,
            },
            "settings": {
                "parser_backend": self.settings.toolchain.parser_backend,
                "embed_backend": self.settings.toolchain.embed_backend,
                "embed_model": self.settings.toolchain.embed_model,
                "vector_backend": self.settings.toolchain.vector_backend,
                "security": self.security_status(),
            },
            "setup": setup,
            "remediation": remediation,
        }

    def _snapshot_dict(self, snapshot: SnapshotInfo) -> dict[str, Any]:
        return {
            "repo_id": snapshot.repo_id,
            "snapshot_id": snapshot.snapshot_id,
            "base_commit_sha": snapshot.base_commit_sha,
            "tree_digest": snapshot.tree_digest,
            "dirty_digest": snapshot.dirty_digest,
            "worktree_state": snapshot.worktree_state,
            "branch_hint": snapshot.branch_hint,
        }

    def _pack_binding(self, snapshot: SnapshotInfo, bind_snapshot: str | None) -> dict[str, Any]:
        bound_snapshot_id = bind_snapshot or snapshot.snapshot_id
        mode = "pinned" if bind_snapshot else "auto"
        bound_row = self.store.snapshot_row(bound_snapshot_id)
        staleness = self._staleness_for_bound_snapshot(bound_snapshot_id, current=snapshot)
        return {
            "bound_snapshot_id": bound_snapshot_id,
            "binding_mode": mode,
            "bound_at": utc_now(),
            "base_commit_sha": bound_row["base_commit_sha"] if bound_row else snapshot.base_commit_sha,
            "worktree_state": bound_row["worktree_state"] if bound_row else snapshot.worktree_state,
            "staleness": staleness,
        }

    def _staleness_for_bound_snapshot(
        self, bound_snapshot_id: str | None, current: SnapshotInfo | None = None
    ) -> dict[str, Any]:
        current = current or self.resolver.current_identity()
        state = "fresh" if bound_snapshot_id == current.snapshot_id else "stale"
        return {
            "state": state,
            "bound_snapshot_id": bound_snapshot_id,
            "current_snapshot_id": current.snapshot_id,
            "current_base_commit_sha": current.base_commit_sha,
            "current_worktree_state": current.worktree_state,
        }


def _benchmark_row_dict(row: Any, *, include_report: bool = False) -> dict[str, Any]:
    gate = None
    gate_status = row["gate_status"]
    if gate_status or row["gate_ok"] is not None:
        gate = {"ok": bool(row["gate_ok"]) if row["gate_ok"] is not None else None}
        if gate_status:
            gate["status"] = gate_status
    result = {
        "benchmark_run_id": row["benchmark_run_id"],
        "repo_id": row["repo_id"],
        "cases": int(row["cases"] or 0),
        "success_rate_delta": float(row["success_rate_delta"] or 0.0),
        "tests_pass_rate_delta": float(row["tests_pass_rate_delta"] or 0.0),
        "wrong_files_touched_reduction": float(row["wrong_files_touched_reduction"] or 0.0),
        "missing_files_reduction": float(row["missing_files_reduction"] or 0.0),
        "agent_seconds_reduction": float(row["agent_seconds_reduction"] or 0.0),
        "memory_score": float(row["memory_score"] or 0.0),
        "context_retrieval_score": float(row["context_retrieval_score"] or 0.0),
        "gate": gate,
        "delta": parse_run_json(row["delta_json"]),
        "lift_attribution": parse_run_json(row["lift_attribution_json"]),
        "roadmap_pruning": parse_run_json(row["roadmap_pruning_json"]),
        "created_at": row["created_at"],
    }
    if include_report:
        result["report"] = parse_run_json(row["report_json"])
    return result


def _lease_dict(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["impact_paths"] = _json_list(item.pop("impact_paths_json", "[]"))
    return item


def _conflict_dict(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["paths"] = _json_list(item.pop("paths_json", "[]"))
    item["detail"] = _json_dict(item.pop("detail_json", "{}"))
    return item


def _json_list(value: str | None) -> list[str]:
    try:
        parsed = json.loads(value or "[]")
    except json.JSONDecodeError:
        return []
    return [str(item) for item in parsed] if isinstance(parsed, list) else []


def _json_dict(value: str | None) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _benchmark_failure_traces(report: dict[str, Any], *, limit: int = 8) -> list[dict[str, Any]]:
    traces: list[dict[str, Any]] = []
    for case in report.get("case_results", []) or []:
        if not isinstance(case, dict):
            continue
        ctxlayer = (case.get("arms") or {}).get("ctxlayer", {})
        if not isinstance(ctxlayer, dict):
            continue
        score = ctxlayer.get("score") if isinstance(ctxlayer.get("score"), dict) else {}
        failed = ctxlayer.get("success") is False or bool(score.get("missing_files")) or bool(
            score.get("wrong_files_touched")
        )
        if not failed:
            continue
        traces.append(
            {
                "case_id": case.get("case_id"),
                "task": case.get("task"),
                "expected_files": case.get("expected_files", []),
                "changed_files": ctxlayer.get("changed_files", []),
                "missing": score.get("missing", []),
                "wrong_files": score.get("wrong_files", []),
                "tests_passed": ctxlayer.get("tests_passed"),
                "preflight": _compact_preflight(ctxlayer.get("preflight")),
            }
        )
        if len(traces) >= limit:
            break
    return traces


def _compact_preflight(preflight: Any) -> dict[str, Any]:
    if not isinstance(preflight, dict):
        return {}
    check = preflight.get("check_diff") if isinstance(preflight.get("check_diff"), dict) else {}
    impact = preflight.get("impact") if isinstance(preflight.get("impact"), dict) else {}
    return {
        "check_diff_ok": check.get("ok"),
        "violations": check.get("violations", [])[:3] if isinstance(check.get("violations"), list) else [],
        "impact_tests": [
            item.get("command")
            for item in impact.get("tests", [])[:5]
            if isinstance(item, dict) and item.get("command")
        ]
        if isinstance(impact.get("tests"), list)
        else [],
    }


def git_changed_paths(repo_root: Path, *, staged: bool = False) -> list[str]:
    args = ["git", "diff", "--name-only", "HEAD"]
    if staged:
        args = ["git", "diff", "--cached", "--name-only", "HEAD"]
    try:
        result = subprocess.run(
            args,
            cwd=repo_root,
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=10,
        )
    except (subprocess.SubprocessError, FileNotFoundError):
        return []
    return [line.strip().replace("\\", "/") for line in result.stdout.splitlines() if line.strip()]


def git_deleted_paths(repo_root: Path, *, staged: bool = False) -> list[str]:
    args = ["git", "diff", "--name-only", "--diff-filter=D", "HEAD"]
    if staged:
        args = ["git", "diff", "--cached", "--name-only", "--diff-filter=D", "HEAD"]
    try:
        result = subprocess.run(
            args,
            cwd=repo_root,
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=10,
        )
    except (subprocess.SubprocessError, FileNotFoundError):
        return []
    return [line.strip().replace("\\", "/") for line in result.stdout.splitlines() if line.strip()]


def paths_from_diff(diff: str | None) -> list[str]:
    if not diff:
        return []
    paths: set[str] = set()
    for line in diff.splitlines():
        if line.startswith("diff --git "):
            parts = line.split()
            if len(parts) >= 4:
                paths.add(parts[3].removeprefix("b/"))
        elif line.startswith("+++ b/"):
            paths.add(line[6:])
        elif line.startswith("--- a/"):
            paths.add(line[6:])
    return sorted(path for path in paths if path and path != "/dev/null")


def _continuation_state_for_task_state(state: str) -> str:
    return {
        "INTAKE": "intake",
        "PACK": "packed",
        "PLAN": "planned",
        "EXECUTE": "editing",
        "PREFLIGHT": "checking",
        "OUTCOME": "ready_to_resume",
    }.get(state.upper(), "ready_to_resume")


def _setup_remediation(missing: list[str]) -> dict[str, str]:
    commands = {
        "agents_contract": "ctxlayer --repo . setup codex --install-hooks --configure-mcp",
        "agents_file": "ctxlayer --repo . bootstrap --agents codex",
        "capabilities_file": "ctxlayer --repo . bootstrap --agents codex",
        "codex_mcp_snippet": "ctxlayer --repo . setup codex --configure-mcp",
        "ctxlayer_ignored": "ctxlayer --repo . init",
        "git_repo": "ctxlayer --repo . setup codex --init-git",
        "pre_commit_hook": "ctxlayer --repo . setup codex --install-hooks",
        "post_commit_hook": "ctxlayer --repo . setup codex --install-hooks",
    }
    return {name: commands[name] for name in missing if name in commands}


def _setup_blocking_missing(missing: list[str]) -> list[str]:
    blocking = {"git_repo"}
    return [item for item in missing if item in blocking]
