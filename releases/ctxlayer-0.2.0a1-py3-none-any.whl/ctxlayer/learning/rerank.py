from __future__ import annotations

from typing import Any

from ctxlayer.learning.judge import deterministic_first_judge
from ctxlayer.learning.provider import AgentProvider
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import canonical_json, stable_id


RERANK_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": ["items"],
    "properties": {
        "items": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["id", "rank", "rationale"],
                "properties": {
                    "id": {"type": "string"},
                    "rank": {"type": "integer", "minimum": 1},
                    "rationale": {"type": "string"},
                    "risk_note": {"type": "string"},
                },
                "additionalProperties": False,
            },
        }
    },
    "additionalProperties": False,
}


class BoundedReranker:
    def __init__(
        self,
        *,
        store: SQLiteStore,
        provider: AgentProvider,
        model_family: str | None = None,
        budget_tokens: int | None = None,
        order_only: bool = True,
        require_judge: bool = False,
        judge_provider: AgentProvider | None = None,
        judge_model_family: str | None = None,
        judge_votes: int = 1,
        judge_min_pass_rate: float = 1.0,
        fail_closed_on_disagreement: bool = False,
        max_disagreement: float = 0.5,
    ):
        self.store = store
        self.provider = provider
        self.model_family = model_family
        self.budget_tokens = budget_tokens
        self.order_only = order_only
        self.require_judge = require_judge
        self.judge_provider = judge_provider
        self.judge_model_family = judge_model_family
        self.judge_votes = judge_votes
        self.judge_min_pass_rate = judge_min_pass_rate
        self.fail_closed_on_disagreement = fail_closed_on_disagreement
        self.max_disagreement = max_disagreement

    def rerank(
        self,
        *,
        repo_id: str,
        task: str,
        candidates: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        if not candidates:
            return candidates
        indexed = [
            {
                "id": candidate_id(item, index),
                "index": index,
                "path": item.get("path"),
                "category": item.get("category"),
                "start_line": item.get("start_line"),
                "end_line": item.get("end_line"),
                "score": round(float(item.get("score") or 0.0), 6),
                "provenance": sorted(str(value) for value in item.get("provenance", [])),
                "text_preview": _preview(str(item.get("text") or "")),
            }
            for index, item in enumerate(candidates)
        ]
        raw = self.provider.complete(
            prompt=rerank_prompt(task, indexed, order_only=self.order_only),
            role="reranker",
            schema=RERANK_SCHEMA,
            model_family=self.model_family,
            budget_tokens=self.budget_tokens,
        )
        if raw is None:
            return candidates
        validation = validate_rerank(raw, [item["id"] for item in indexed])
        if not validation["ok"]:
            self._event(
                "rerank_rejected",
                repo_id,
                {
                    "reason": validation["reason"],
                    "candidate_count": len(indexed),
                    "output_count": validation.get("output_count"),
                },
            )
            return candidates
        safety = _safety_floor(raw, indexed, candidates)
        provenance_record = {
            "rerank_id": stable_id(repo_id, task, canonical_json([item["id"] for item in indexed])),
            "candidate_pool": [item["id"] for item in indexed],
            "permutation_valid": bool(validation["ok"]),
            "order_only": self.order_only,
            "safety_floor_held": safety["ok"],
            "safety_violations": safety["violations"],
            "boosts_applied": _boosts(candidates),
            "judge": None,
        }
        if not safety["ok"]:
            self._event(
                "rerank_rejected",
                repo_id,
                {
                    "reason": "safety_floor_violation",
                    "candidate_count": len(indexed),
                    "rerank_provenance": provenance_record,
                },
            )
            return candidates

        judge = None
        if self.require_judge:
            judge = deterministic_first_judge(
                name="rerank_order",
                deterministic={"ok": True, "reason": "permutation_valid", **validation},
                provider=self.judge_provider or self.provider,
                prompt_payload={
                    "task": task,
                    "order_only": self.order_only,
                    "input_candidates": indexed,
                    "proposed_order": raw,
                },
                model_family=self.judge_model_family,
                budget_tokens=self.budget_tokens,
                votes=self.judge_votes,
                min_pass_rate=self.judge_min_pass_rate,
                fail_closed_on_disagreement=self.fail_closed_on_disagreement,
                max_disagreement=self.max_disagreement,
            )
            if not judge["ok"]:
                self._event(
                    "rerank_judge_rejected",
                    repo_id,
                    {
                        "candidate_count": len(indexed),
                        "judge": judge,
                    },
                )
                return candidates
        provenance_record["judge"] = judge

        rank_by_id = {
            item["id"]: (int(item["rank"]), order)
            for order, item in enumerate(raw["items"])
        }
        rationale_by_id = {
            item["id"]: _one_line(item.get("rationale", ""))
            for item in raw["items"]
        }
        risk_note_by_id = {
            item["id"]: _one_line(item.get("risk_note", ""))
            for item in raw["items"]
            if item.get("risk_note")
        }
        ordered = sorted(indexed, key=lambda item: (*rank_by_id[item["id"]], item["index"]))
        result: list[dict[str, Any]] = []
        for order, descriptor in enumerate(ordered):
            original = candidates[int(descriptor["index"])]
            clone = dict(original)
            provenance = set(str(value) for value in clone.get("provenance", []))
            provenance.add("rerank:agent")
            clone["provenance"] = sorted(provenance)
            clone["rerank_order"] = order
            clone["rerank_id"] = descriptor["id"]
            clone["rerank_rationale"] = rationale_by_id.get(descriptor["id"], "")
            clone["rerank_provenance"] = provenance_record
            risk_note = risk_note_by_id.get(descriptor["id"])
            if risk_note:
                clone["rerank_risk_note"] = risk_note
            result.append(clone)
        self._event(
            "rerank_accepted",
            repo_id,
            {
                "candidate_count": len(indexed),
                "order_only": self.order_only,
                "first_ids": [item["id"] for item in ordered[:5]],
                "judge": judge,
                "rerank_provenance": provenance_record,
            },
        )
        self._event(
            "rerank_safety_floor_held",
            repo_id,
            {
                "candidate_count": len(indexed),
                "rerank_id": provenance_record["rerank_id"],
                "safety_floor_held": True,
            },
        )
        return result

    def _event(self, kind: str, ref: str | None, payload: dict[str, Any]) -> None:
        self.store.write_learning_event(phase="phase3", kind=kind, ref=ref, payload=payload)


def rerank_prompt(
    task: str,
    candidates: list[dict[str, Any]],
    *,
    order_only: bool = True,
) -> str:
    rules = [
        "Reorder the candidate ids for this coding task.",
        "Return strict JSON only with an items array.",
        "Use every input id exactly once. Do not add, remove, rename, or edit candidates.",
        "Attach one short rationale per id.",
        "Optionally attach risk_note when the rank depends on uncertain or risky context.",
    ]
    if order_only:
        rules.append("Only ranking may change; scores and candidate contents are fixed.")
    return "\n".join(
        [
            *rules,
            canonical_json({"task": task, "candidates": candidates}),
        ]
    )


def validate_rerank(raw: Any, expected_ids: list[str]) -> dict[str, Any]:
    if not isinstance(raw, dict):
        return {"ok": False, "reason": "non_object", "output_count": None}
    items = raw.get("items")
    if not isinstance(items, list):
        return {"ok": False, "reason": "missing_items", "output_count": None}
    output_ids = [item.get("id") for item in items if isinstance(item, dict)]
    if len(output_ids) != len(items):
        return {"ok": False, "reason": "invalid_item", "output_count": len(items)}
    if len(set(output_ids)) != len(output_ids):
        return {"ok": False, "reason": "duplicate_id", "output_count": len(output_ids)}
    if set(output_ids) != set(expected_ids):
        return {"ok": False, "reason": "set_mismatch", "output_count": len(output_ids)}
    ranks = [item.get("rank") for item in items if isinstance(item, dict)]
    if any(not isinstance(rank, int) or isinstance(rank, bool) or rank < 1 for rank in ranks):
        return {"ok": False, "reason": "invalid_rank", "output_count": len(output_ids)}
    for item in items:
        if (
            isinstance(item, dict)
            and "risk_note" in item
            and not isinstance(item["risk_note"], str)
        ):
            return {"ok": False, "reason": "invalid_risk_note", "output_count": len(output_ids)}
    return {"ok": True, "reason": "accepted", "output_count": len(output_ids)}


def candidate_id(item: dict[str, Any], index: int) -> str:
    return stable_id(
        "rerank",
        index,
        item.get("path") or "",
        item.get("category") or "",
        item.get("start_line") or 0,
        item.get("end_line") or 0,
    )


def _safety_floor(
    raw: dict[str, Any],
    indexed: list[dict[str, Any]],
    candidates: list[dict[str, Any]],
) -> dict[str, Any]:
    unsafe = {
        indexed[index]["id"]
        for index, candidate in enumerate(candidates)
        if _unsafe_candidate(candidate)
    }
    if not unsafe:
        return {"ok": True, "violations": []}
    clean = {item["id"] for item in indexed if item["id"] not in unsafe}
    ordered_ids = [
        item["id"]
        for item in sorted(raw["items"], key=lambda item: (int(item["rank"]), item["id"]))
    ]
    first_clean = min((ordered_ids.index(item_id) for item_id in clean), default=None)
    violations = []
    if first_clean is not None:
        for item_id in unsafe:
            unsafe_rank = ordered_ids.index(item_id)
            if unsafe_rank < first_clean:
                violations.append(
                    {
                        "candidate_id": item_id,
                        "rule": "unsafe_candidate_above_clean",
                        "reason": "learned rerank cannot promote quarantined, unsafe, or external non-authoritative context",
                    }
                )
    return {"ok": not violations, "violations": violations}


def _unsafe_candidate(item: dict[str, Any]) -> bool:
    status = str(item.get("status") or "").lower()
    trust = str(item.get("trust") or item.get("trust_tier") or "").lower()
    provenance = {str(value).lower() for value in item.get("provenance", []) or []}
    metadata = item.get("metadata") if isinstance(item.get("metadata"), dict) else {}
    defense = metadata.get("defense_result") or metadata.get("memory_defense") if isinstance(metadata, dict) else {}
    return bool(
        status in {"quarantined", "rejected", "expired", "needs_review"}
        or trust in {"unsafe", "untrusted"}
        or "unsafe" in provenance
        or "quarantined" in provenance
        or "external:non_authoritative" in provenance
        or (isinstance(defense, dict) and defense.get("serve_authoritative") is False)
    )


def _boosts(candidates: list[dict[str, Any]]) -> dict[str, float]:
    outcome = any("rerank:outcome" in set(item.get("provenance", []) or []) for item in candidates)
    memory = any("rerank:memory" in set(item.get("provenance", []) or []) for item in candidates)
    return {"outcome_boost": 1.0 if outcome else 0.0, "memory_boost": 1.0 if memory else 0.0}


def _preview(text: str, limit: int = 500) -> str:
    return _one_line(text)[:limit]


def _one_line(text: str, limit: int = 200) -> str:
    return " ".join(str(text or "").strip().split())[:limit]
