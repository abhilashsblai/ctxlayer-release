from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any

from ctxlayer.config import Settings
from ctxlayer.compiler.explanations import explain_item, negative_context
from ctxlayer.governance import ConstitutionBuilder
from ctxlayer.learning.provider import build_agent_provider
from ctxlayer.learning.neural_rerank import NeuralReranker
from ctxlayer.learning.rerank import BoundedReranker
from ctxlayer.linking import owners_for_path
from ctxlayer.learning.skills import SkillLibrary, pack_skill
from ctxlayer.memory.serving import relevant_rules
from ctxlayer.memory.continuation import ContinuationMemory
from ctxlayer.memory.unified import UnifiedMemory
from ctxlayer.retrieval.embedder import cosine, make_embedder
from ctxlayer.semantic.confidence import confidence_tier
from ctxlayer.snapshot import SnapshotInfo
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import canonical_json, estimate_tokens, sha256_text, stable_id


class ContextCompiler:
    def __init__(self, repo_root: Path, store: SQLiteStore, settings: Settings):
        self.repo_root = repo_root
        self.store = store
        self.settings = settings
        self.embedder = make_embedder(
            model_name=settings.toolchain.embed_model,
            backend=settings.toolchain.embed_backend,
        )
        self._active_repo_id: str | None = None

    def compile(
        self,
        *,
        snapshot: SnapshotInfo,
        task: str,
        budget: int | None = None,
        seed_paths: list[str] | None = None,
        write: bool = True,
        rerank: bool = True,
    ) -> dict[str, Any]:
        budget = budget or self.settings.pack.default_budget_tokens
        seed_paths = sorted({_normalize_path(path) for path in seed_paths or [] if path})
        self._active_repo_id = snapshot.repo_id
        candidates = self._rank_candidates(snapshot, task, seed_paths, rerank=rerank)
        selected: list[dict[str, Any]] = []
        tokens = 0
        selected_paths: set[str] = set()
        quota_tokens = {
            "implementation": int(budget * self.settings.pack.implementation_quota),
            "test": int(budget * self.settings.pack.test_quota),
            "constraint": int(budget * self.settings.pack.constraint_quota),
            "file": budget,
        }
        used_by_category: dict[str, int] = defaultdict(int)

        for item in candidates:
            category = item["category"]
            item_tokens = int(item["token_count"])
            if item_tokens > self.settings.pack.max_file_tokens:
                item = self._skeleton_item(snapshot.snapshot_id, item)
                item_tokens = int(item["token_count"])
            category_limit = quota_tokens.get(category, budget)
            if tokens + item_tokens > budget:
                continue
            if category in quota_tokens and used_by_category[category] + item_tokens > category_limit:
                if category != "file":
                    continue
            selected.append(item)
            selected_paths.add(item["path"])
            tokens += item_tokens
            used_by_category[category] += item_tokens

        selected.extend(self._linked_tests(snapshot, selected_paths, budget - tokens))
        selected = sorted(
            {f"{item['path']}:{item.get('start_line') or 0}:{item['category']}": item for item in selected}.values(),
            key=_selection_sort_key,
        )
        tokens = sum(int(item["token_count"]) for item in selected)
        selected_paths_for_rules = [item["path"] for item in selected]
        business_rules = self._business_rules_for_paths(selected_paths_for_rules, task)
        continuations = self._continuations_for_task(selected_paths_for_rules, task)
        policy_references = self._policy_references_for_paths(selected_paths_for_rules, task)
        project_memory = self._project_memory_for_paths(selected_paths_for_rules, task)
        memory_retrieval = self._memory_retrieval_summary(task)
        runtime_evidence = self._runtime_evidence_for_paths(selected_paths_for_rules, task)
        skills = self._skills_for_task(task, budget)
        skill_tokens = sum(int(item.get("token_count", 0)) for item in skills)
        for item in selected:
            item["selection_explanation"] = explain_item(
                item,
                business_rules=business_rules,
                runtime_evidence=runtime_evidence,
                project_memory=project_memory,
            )
        constitution = ConstitutionBuilder(
            self.repo_root,
            self.store,
            self.settings,
            workspace_id=stable_id(str(self.repo_root))[:16],
        ).build(snapshot.repo_id)
        selected_seed_paths = sorted(set(seed_paths) & selected_paths)
        missing_seed_paths = sorted(set(seed_paths) - selected_paths)
        seed_coverage = {
            "seeded_paths": seed_paths,
            "selected_seed_paths": selected_seed_paths,
            "missing_seed_paths": missing_seed_paths,
            "edit_scope_confidence": "seeded" if seed_paths and not missing_seed_paths else "partial_seed" if seed_paths else "unseeded",
        }
        low_confidence = any(float(item["score"]) < 0.2 for item in selected)
        warnings = []
        if low_confidence:
            if seed_paths and not missing_seed_paths:
                warnings.append(
                    {
                        "kind": "low_confidence_retrieval_seeded_scope",
                        "message": "Retrieval confidence is low, but all seeded edit paths were included. Proceed if these seed paths cover every intended edit.",
                        "seeded_paths": seed_paths,
                    }
                )
            else:
                warnings.append(
                    {
                        "kind": "low_confidence_pack",
                        "message": "This pack is low confidence. Rerun with --seed-path for every intended edit before coding.",
                        "example": 'ctxlayer --repo . pack --task "<task>" --seed-path <path-to-edit>',
                        "missing_seed_paths": missing_seed_paths,
                    }
                )
        manifest = {
            "schema_version": "ctxlayer.context_pack.v1",
            "pack_id": "",
            "repo_id": snapshot.repo_id,
            "snapshot_id": snapshot.snapshot_id,
            "base_commit_sha": snapshot.base_commit_sha,
            "worktree_state": snapshot.worktree_state,
            "constitution_hash": constitution["constitution_hash"],
            "task_text_hash": sha256_text(task),
            "budget_tokens": budget,
            "used_tokens": tokens + skill_tokens,
            "seed_paths": seed_paths,
            "seed_coverage": seed_coverage,
            "low_confidence": low_confidence,
            "warnings": warnings,
            "items": selected,
            "business_rules": business_rules,
            "continuations": continuations,
            "policy_references": policy_references,
            "project_memory": project_memory,
            "memory_retrieval": memory_retrieval,
            "skills": skills,
            "runtime_evidence": runtime_evidence,
            "negative_context": negative_context(selected_paths_for_rules, seed_paths),
            "optimization_guidance": self._optimization_guidance(),
            "provenance": {
                "compiler": "local-deterministic-v1",
                "embed_model": self.settings.toolchain.embed_model,
                "legs": ["lexical", "vector", "seed", "graph", "history"],
                "rerank": self._rerank_label(rerank),
            },
        }
        pack_id_parts: list[Any] = [
            snapshot.snapshot_id,
            sha256_text(task),
            canonical_json(selected),
            canonical_json(continuations),
            canonical_json(policy_references),
            canonical_json(project_memory),
            canonical_json(memory_retrieval),
        ]
        if skills:
            pack_id_parts.append(canonical_json(skills))
        guidance = manifest.get("optimization_guidance")
        if guidance:
            pack_id_parts.append(canonical_json(guidance))
        pack_id_parts.extend([constitution["constitution_hash"], budget])
        pack_id = stable_id(*pack_id_parts)
        manifest["pack_id"] = pack_id
        if write:
            reconstructible = snapshot.worktree_state == "clean" or self.settings.audit.retain_dirty_blobs
            self.store.write_pack(
                pack_id=pack_id,
                snapshot_id=snapshot.snapshot_id,
                repo_id=snapshot.repo_id,
                task_text_hash=sha256_text(task),
                manifest=manifest,
                reconstructible=reconstructible,
            )
            for memory in project_memory:
                self.store.record_memory_access(
                    pack_id=pack_id,
                    memory_record_id=memory["record_id"],
                    score=float(memory["score"]),
                    signals=memory["signals"],
                )
            for policy in policy_references:
                self.store.record_memory_access(
                    pack_id=pack_id,
                    memory_record_id=policy["record_id"],
                    score=float(policy["score"]),
                    signals=policy["signals"],
                )
            for continuation in continuations:
                self.store.record_memory_access(
                    pack_id=pack_id,
                    memory_record_id=continuation["record_id"],
                    score=float(continuation["score"]),
                    signals=continuation.get("signals", []),
                )
        return manifest

    def _rank_candidates(
        self, snapshot: SnapshotInfo, task: str, seed_paths: list[str], *, rerank: bool = True
    ) -> list[dict[str, Any]]:
        rows = self.store.search_chunks(snapshot.snapshot_id, task, limit=200)
        scored: dict[str, dict[str, Any]] = {}
        for idx, row in enumerate(rows):
            score = self.settings.retrieval.lexical_weight * (1.0 / (idx + 1))
            scored[row["chunk_id"]] = self._item_from_row(row, score, ["lexical"])

        for idx, row in enumerate(self._vector_rows(snapshot.snapshot_id, task, limit=60)):
            score = (
                self.settings.retrieval.vector_weight
                * (1.0 / (idx + 1))
                * max(0.0, float(row["_vector_score"]))
            )
            item = self._item_from_row(row, score, ["vector"])
            scored[row["chunk_id"]] = _merge_item(scored.get(row["chunk_id"]), item)

        for seed in seed_paths:
            for row in self.store.chunks_by_paths(snapshot.snapshot_id, [seed], limit_per_path=20):
                item = self._item_from_row(row, 1.0, ["seed_path"])
                scored[row["chunk_id"]] = _merge_item(scored.get(row["chunk_id"]), item)
            for graph_path, confidence, kind in self._graph_paths(snapshot, seed):
                for nrow in self.store.chunks_by_paths(snapshot.snapshot_id, [graph_path], limit_per_path=3):
                    nitem = self._item_from_row(
                        nrow,
                        self.settings.retrieval.graph_weight * confidence,
                        [f"graph:{kind}"],
                    )
                    nitem["graph_confidence"] = confidence
                    nitem["confidence_tier"] = confidence_tier(confidence)
                    scored[nrow["chunk_id"]] = _merge_item(scored.get(nrow["chunk_id"]), nitem)
            for row in self.store.cochanged_paths(snapshot.repo_id, seed, limit=8):
                for hrow in self.store.chunks_by_paths(snapshot.snapshot_id, [row["path"]], limit_per_path=2):
                    hitem = self._item_from_row(
                        hrow,
                        self.settings.retrieval.history_weight * float(row["jaccard"]),
                        ["history:cochange"],
                    )
                    scored[hrow["chunk_id"]] = _merge_item(scored.get(hrow["chunk_id"]), hitem)
        if not scored:
            for row in self.store.fallback_chunks(snapshot.snapshot_id, limit=25):
                scored[row["chunk_id"]] = self._item_from_row(row, 0.05, ["fallback"])
        candidates = list(scored.values())
        if rerank:
            candidates = self._bounded_rerank(snapshot.repo_id, candidates)
            candidates = self._neural_rerank(snapshot.repo_id, task, candidates)
            candidates = self._agent_rerank(snapshot.repo_id, task, candidates)
        return sorted(candidates, key=_selection_sort_key)

    def _bounded_rerank(self, repo_id: str, candidates: list[dict[str, Any]]) -> list[dict[str, Any]]:
        # Reorder only inside the deterministic candidate set; never add or remove files.
        outcome_paths = {
            path
            for row in self.store.conn.execute("SELECT files_changed_json FROM outcomes").fetchall()
            for path in _json_list(row["files_changed_json"])
        }
        memory_paths = {
            row["path"]
            for row in self.store.conn.execute(
                "SELECT path FROM memory_evidence WHERE repo_id = ? AND path IS NOT NULL",
                (repo_id,),
            ).fetchall()
        }
        reranked = []
        candidate_pool = []
        for item in candidates:
            path = item["path"]
            candidate_pool.append(path)
            boost = 0.0
            provenance = list(item.get("provenance", []))
            if path in outcome_paths:
                boost += self.settings.learning.rerank.outcome_boost
                provenance.append("rerank:outcome")
            if path in memory_paths:
                boost += self.settings.learning.rerank.memory_boost
                provenance.append("rerank:memory")
            clone = dict(item)
            clone["score"] = round(float(item["score"]) + boost, 6)
            clone["provenance"] = sorted(set(provenance))
            reranked.append(clone)
        self._learning_event_logger(
            "phase_h4",
            "rerank_safety_floor_held",
            repo_id,
            {
                "candidate_count": len(candidates),
                "rerank_provenance": {
                    "rerank_id": stable_id(repo_id, "deterministic-boost", canonical_json(candidate_pool)),
                    "candidate_pool": candidate_pool,
                    "permutation_valid": True,
                    "order_only": True,
                    "safety_floor_held": True,
                    "safety_violations": [],
                    "boosts_applied": {
                        "outcome_boost": self.settings.learning.rerank.outcome_boost,
                        "memory_boost": self.settings.learning.rerank.memory_boost,
                    },
                    "judge": None,
                },
            },
        )
        return reranked

    def _agent_rerank(
        self,
        repo_id: str,
        task: str,
        candidates: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        if not (self.settings.learning.enabled and self.settings.learning.rerank.enabled):
            return candidates
        provider = build_agent_provider(
            self.settings,
            repo_root=self.repo_root,
            event_logger=self._learning_event_logger,
        )
        return BoundedReranker(
            store=self.store,
            provider=provider,
            model_family=self.settings.learning.actor_model_family,
            budget_tokens=self.settings.learning.max_tokens_per_task,
            order_only=self.settings.learning.rerank.order_only,
            require_judge=self.settings.learning.rerank.require_judge,
            judge_provider=provider,
            judge_model_family=self.settings.learning.judge_model_family,
            judge_votes=self.settings.learning.rerank.judge_votes,
            judge_min_pass_rate=self.settings.learning.rerank.judge_min_pass_rate,
            fail_closed_on_disagreement=(
                self.settings.learning.rerank.fail_closed_on_disagreement
            ),
            max_disagreement=self.settings.learning.rerank.max_disagreement,
        ).rerank(repo_id=repo_id, task=task, candidates=candidates)

    def _neural_rerank(
        self,
        repo_id: str,
        task: str,
        candidates: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        rerank_config = self.settings.learning.rerank
        if not (
            self.settings.learning.enabled
            and rerank_config.neural_enabled
            and rerank_config.neural_model
        ):
            return candidates
        result = NeuralReranker(
            model_name=rerank_config.neural_model,
            top_k=rerank_config.neural_top_k,
        ).rerank(task=task, candidates=candidates)
        self._learning_event_logger(
            "phase3",
            "neural_rerank",
            repo_id,
            {
                "status": result.get("status"),
                "candidate_count": len(candidates),
                "window": result.get("window"),
                "model": rerank_config.neural_model,
            },
        )
        if result.get("status") != "reranked":
            return candidates
        reranked = []
        for order, item in enumerate(result.get("candidates") or candidates):
            clone = dict(item)
            provenance = set(str(value) for value in clone.get("provenance", []))
            provenance.add("rerank:neural")
            clone["provenance"] = sorted(provenance)
            clone["rerank_order"] = order
            reranked.append(clone)
        return reranked

    def _rerank_label(self, enabled: bool) -> str:
        if not enabled:
            return "disabled"
        rerank_config = self.settings.learning.rerank
        if (
            self.settings.learning.enabled
            and rerank_config.neural_enabled
            and rerank_config.neural_model
        ):
            if rerank_config.enabled:
                return "bounded-outcome+neural+agent-order-v1"
            return "bounded-outcome+neural-v1"
        if self.settings.learning.enabled and self.settings.learning.rerank.enabled:
            return "bounded-outcome+agent-order-v1"
        return "bounded-outcome-v1"

    def _optimization_guidance(self) -> dict[str, Any]:
        instruction = self.settings.learning.optimize.pack_template_instruction.strip()
        return {"pack_template_instruction": instruction} if instruction else {}

    def _learning_event_logger(
        self, phase: str, kind: str, ref: str | None, payload: dict[str, Any]
    ) -> None:
        self.store.write_learning_event(phase=phase, kind=kind, ref=ref, payload=payload)

    def _graph_paths(self, snapshot: SnapshotInfo, seed: str) -> list[tuple[str, float, str]]:
        by_path_kind: dict[tuple[str, str], tuple[str, float, str]] = {}
        for edge in self.store.graph_walk(
            repo_id=snapshot.repo_id,
            start_paths=[seed],
            kinds=["imports", "tests", "calls"],
            max_hops=3,
            limit=60,
        ):
            target = edge.get("to", {})
            path = target.get("path")
            if not path or path == seed:
                continue
            depth = int(edge.get("depth") or 1)
            confidence = float(edge.get("confidence") or 0.0) * (0.7 ** max(0, depth - 1))
            if confidence < 0.15:
                continue
            kind = f"n_hop:{edge.get('kind', 'edge')}:d{depth}"
            key = (path, kind)
            current = by_path_kind.get(key)
            item = (path, round(confidence, 4), kind)
            if current is None or item[1] > current[1]:
                by_path_kind[key] = item
        return sorted(by_path_kind.values(), key=lambda item: (item[0], item[2]))

    def _vector_rows(self, snapshot_id: str, task: str, limit: int) -> list[Any]:
        query_vector = self.embedder.embed(task)
        sqlite_vec_rows = self.store.search_vector_chunks(
            snapshot_id=snapshot_id,
            model=self.embedder.model_name,
            dims=self.embedder.dims,
            vector=query_vector,
            limit=limit,
        )
        if sqlite_vec_rows:
            return sqlite_vec_rows
        rows = []
        for row in self.store.chunk_vectors(snapshot_id, self.embedder.model_name):
            vector = json.loads(row["vector_json"])
            enriched = dict(row)
            enriched["_vector_score"] = cosine(query_vector, vector)
            rows.append(enriched)
        rows.sort(key=lambda row: (-float(row["_vector_score"]), row["path"], row["start_line"] or 0))
        return [row for row in rows[:limit] if float(row["_vector_score"]) > 0]

    def _linked_tests(
        self, snapshot: SnapshotInfo, paths: set[str], remaining_budget: int
    ) -> list[dict[str, Any]]:
        if remaining_budget <= 0:
            return []
        tests: list[dict[str, Any]] = []
        used = 0
        for path in sorted(paths):
            inbound_tests = self.store.neighbors(
                repo_id=snapshot.repo_id,
                node_type="file",
                node_id=path,
                kinds=["tests"],
                direction="in",
            )
            for neighbor in inbound_tests:
                for row in self.store.chunks_by_paths(
                    snapshot.snapshot_id, [neighbor.node_id], limit_per_path=3
                ):
                    item = self._item_from_row(row, 0.75 * neighbor.confidence, ["linked_test"])
                    if used + int(item["token_count"]) <= remaining_budget:
                        tests.append(item)
                        used += int(item["token_count"])
        return tests

    def _skeleton_item(self, snapshot_id: str, item: dict[str, Any]) -> dict[str, Any]:
        row = self.store.conn.execute(
            """
            SELECT fv.skeleton
            FROM snapshot_files sf
            JOIN file_versions fv ON fv.file_version_id = sf.file_version_id
            WHERE sf.snapshot_id = ? AND sf.path = ?
            """,
            (snapshot_id, item["path"]),
        ).fetchone()
        skeleton = row["skeleton"] if row and row["skeleton"] else item["text"][:4_000]
        clone = dict(item)
        clone["text"] = skeleton
        clone["token_count"] = estimate_tokens(skeleton)
        clone["provenance"] = [*clone["provenance"], "skeleton_fallback"]
        return clone

    def _item_from_row(self, row: Any, score: float, provenance: list[str]) -> dict[str, Any]:
        return {
            "path": row["path"],
            "symbol_identity_id": row["symbol_identity_id"],
            "category": row["category"],
            "start_line": row["start_line"],
            "end_line": row["end_line"],
            "text": row["text"],
            "token_count": row["token_count"],
            "score": round(score, 6),
            "trust_tier": "source",
            "provenance": provenance,
            "owners": self._owners(row["path"]),
            "churn": self._churn(row["path"]),
        }

    def _owners(self, path: str) -> list[str]:
        if not self._active_repo_id:
            return []
        rows = [dict(row) for row in self.store.ownership(self._active_repo_id)]
        return owners_for_path(path, rows)

    def _churn(self, path: str) -> dict[str, Any] | None:
        if not self._active_repo_id:
            return None
        row = self.store.churn_for_path(self._active_repo_id, path)
        if not row:
            return None
        return {"commits": row["commits"], "last_touched_at": row["last_touched_at"]}

    def _business_rules_for_paths(self, paths: list[str], task: str) -> list[dict[str, Any]]:
        workspace_id = stable_id(str(self.repo_root))[:16]
        approved = UnifiedMemory(
            self.store, workspace_id=workspace_id, repo_id=self._active_repo_id
        ).active_business_rules()
        task_terms = _terms(task)
        scoped = relevant_rules(approved, paths)
        term_matched = [
            rule
            for rule in approved
            if len(task_terms & _terms(rule["rule_text"])) >= 2 and rule not in scoped
        ]
        return [
            {
                "rule_id": rule["rule_id"],
                "text": rule["rule_text"],
                "status": rule["status"],
                "scope": rule["scope_glob"],
                "provenance": [rule["source_ref"]],
                "trust": "approved_business_rule",
            }
            for rule in [*scoped, *term_matched]
        ]

    def _continuations_for_task(self, paths: list[str], task: str) -> list[dict[str, Any]]:
        workspace_id = stable_id(str(self.repo_root))[:16]
        continuations = ContinuationMemory(
            self.store,
            workspace_id=workspace_id,
            repo_id=self._active_repo_id,
            recall_weights={
                "recency": 0.5,
                "importance": 0.3,
                "relevance": 0.2,
            },
            repo_root=self.repo_root,
        ).for_pack(task, paths, limit=3)
        self._last_continuations = continuations
        return continuations

    def _project_memory_for_paths(self, paths: list[str], task: str) -> list[dict[str, Any]]:
        workspace_id = stable_id(str(self.repo_root))[:16]
        recall = UnifiedMemory(
            self.store,
            workspace_id=workspace_id,
            repo_id=self._active_repo_id,
            recall_weights={
                "recency": self.settings.learning.memory.recall_recency_weight,
                "importance": self.settings.learning.memory.recall_importance_weight,
                "relevance": self.settings.learning.memory.recall_relevance_weight,
            },
            embedder=self.embedder,
        ).recall(
            task,
            paths=paths,
            types=[
                "architectural_decision",
                "convention",
                "decision",
                "fact",
                "failure_lesson",
                "gotcha",
                "outcome",
                "pattern",
                "preference",
                "runtime_signal",
                "workflow",
            ],
            limit=10,
            active_only=True,
            include_untrusted_candidates=self.settings.learning.enabled,
        )
        self._last_memory_recall = recall
        return [
            {
                "record_id": item["record_id"],
                "type": item["type"],
                "text": item["assertion"],
                "status": item["status"],
                "trust": item["trust"],
                "score": item["score"],
                "signals": item["signals"],
                "staleness_state": item.get("staleness_state"),
                "provenance_summary": item.get("provenance_summary"),
                "evidence": item["evidence"],
                "why_recalled": item["why_recalled"],
            }
            for item in recall["results"]
        ]

    def _policy_references_for_paths(self, paths: list[str], task: str) -> list[dict[str, Any]]:
        workspace_id = stable_id(str(self.repo_root))[:16]
        recall = UnifiedMemory(
            self.store,
            workspace_id=workspace_id,
            repo_id=self._active_repo_id,
            recall_weights={
                "recency": self.settings.learning.memory.recall_recency_weight,
                "importance": self.settings.learning.memory.recall_importance_weight,
                "relevance": self.settings.learning.memory.recall_relevance_weight,
            },
            embedder=self.embedder,
        ).recall(
            task,
            paths=paths,
            types=["policy_reference"],
            limit=5,
            active_only=True,
            include_untrusted_candidates=False,
        )
        self._last_policy_recall = recall
        return [
            {
                "record_id": item["record_id"],
                "type": item["type"],
                "text": item["assertion"],
                "status": item["status"],
                "trust": item["trust"],
                "score": item["score"],
                "signals": item["signals"],
                "staleness_state": item.get("staleness_state"),
                "provenance_summary": item.get("provenance_summary"),
                "evidence": item["evidence"],
                "why_recalled": item["why_recalled"],
            }
            for item in recall["results"]
        ]

    def _memory_retrieval_summary(self, task: str) -> dict[str, Any]:
        project = getattr(self, "_last_memory_recall", None) or {}
        policy = getattr(self, "_last_policy_recall", None) or {}
        continuations = getattr(self, "_last_continuations", None) or []
        served_counts: dict[str, int] = {}
        signal_counts: dict[str, int] = {}
        stale_counts: dict[str, int] = {}
        for item in (project.get("results") or []) + (policy.get("results") or []) + continuations:
            item_type = str(item.get("type") or "continuation")
            served_counts[item_type] = served_counts.get(item_type, 0) + 1
            staleness = str(item.get("staleness_state") or "unknown")
            stale_counts[staleness] = stale_counts.get(staleness, 0) + 1
            for signal in item.get("signals") or []:
                kind = str(signal.get("kind") or "unknown")
                signal_counts[kind] = signal_counts.get(kind, 0) + 1
        excluded: dict[str, int] = {}
        for recall in (project, policy):
            for key, value in ((recall.get("defense") or {}).get("excluded") or {}).items():
                excluded[key] = excluded.get(key, 0) + int(value or 0)
        backend_status = project.get("backend_status") or policy.get("backend_status") or {}
        policy_count = int(served_counts.get("policy_reference", 0))
        preference_count = int(served_counts.get("preference", 0))
        stale_served = int(stale_counts.get("stale", 0))
        unsafe_excluded = int(excluded.get("unsafe_memory", 0)) + int(
            excluded.get("quarantined_or_terminal", 0)
        )
        external_denied = int(excluded.get("external_default_deny", 0))
        return {
            "query": task,
            "weights": {
                "recency": self.settings.learning.memory.recall_recency_weight,
                "importance": self.settings.learning.memory.recall_importance_weight,
                "relevance": self.settings.learning.memory.recall_relevance_weight,
            },
            "backend_status": backend_status,
            "excluded_counts": excluded,
            "served_counts_by_type": served_counts,
            "signal_counts": signal_counts,
            "staleness_counts": stale_counts,
            "continuation_priority": {
                "served_before_project_memory": True,
                "served_count": len(continuations),
            },
            "diagnostics": {
                "vector_backend_available": backend_status.get("memory_vector_backend") != "unavailable",
                "quarantined_excluded": int(excluded.get("quarantined_or_terminal", 0)),
                "unsafe_excluded": int(excluded.get("unsafe_memory", 0)),
                "external_default_deny_excluded": external_denied,
                "expired_excluded": int(excluded.get("expired", 0)),
                "stale_served": stale_served,
            },
            "security_proof": {
                "pack_filter_defense": {
                    "quarantine_exclusion_enforced": True,
                    "unsafe_memory_exclusion_enforced": True,
                    "query_injection_blocked": int(excluded.get("query_injection", 0)) > 0,
                    "unsafe_or_quarantined_excluded": unsafe_excluded,
                    "external_default_deny_enforced": True,
                    "external_default_deny_excluded": external_denied,
                },
                "policy_precedence": {
                    "policy_references_served_before_project_memory": True,
                    "policy_reference_count": policy_count,
                    "preference_count": preference_count,
                    "policy_over_preference": bool(policy_count) or preference_count == 0,
                },
                "stale_unsafe_exclusion": {
                    "expired_excluded": int(excluded.get("expired", 0)),
                    "stale_served": stale_served,
                    "unsafe_or_quarantined_excluded": unsafe_excluded,
                    "stale_unsafe_exclusion_rate": 1.0
                    if unsafe_excluded or int(excluded.get("expired", 0))
                    else 0.0,
                },
            },
        }

    def _skills_for_task(self, task: str, budget: int) -> list[dict[str, Any]]:
        if not self.settings.learning.enabled or self.settings.learning.skills.inject_top_k <= 0:
            return []
        workspace_id = stable_id(str(self.repo_root))[:16]
        library = SkillLibrary(
            store=self.store,
            repo_root=self.repo_root,
            workspace_id=workspace_id,
            repo_id=self._active_repo_id,
            settings=self.settings,
            critical_path_globs=self.settings.eval.critical_paths,
        )
        search = library.search(task, limit=max(1, self.settings.learning.skills.inject_top_k))
        quota = max(0, int(budget * 0.05))
        used = 0
        selected = []
        for item in search["results"]:
            packed = pack_skill(item)
            token_count = int(packed["token_count"])
            if quota and used + token_count > quota:
                continue
            selected.append(packed)
            used += token_count
        return selected

    def _runtime_evidence_for_paths(self, paths: list[str], task: str) -> list[dict[str, Any]]:
        task_terms = _terms(task)
        evidence = []
        for row in self.store.runtime_events(self._active_repo_id):
            path = row["path"]
            message_terms = _terms(row["message"])
            if (path and path in paths) or len(task_terms & message_terms) >= 2:
                evidence.append(
                    {
                        "runtime_event_id": row["runtime_event_id"],
                        "source": row["source"],
                        "title": row["title"],
                        "message": row["message"],
                        "path": path,
                        "severity": row["severity"],
                        "trust": "runtime_evidence_unapproved",
                    }
                )
        return evidence[:10]

    def get_manifest(self, pack_id: str) -> dict[str, Any] | None:
        row = self.store.get_pack(pack_id)
        return json.loads(row["manifest_json"]) if row else None

    def reconstruct(self, pack_id: str, task_text: str | None = None) -> dict[str, Any]:
        row = self.store.get_pack(pack_id)
        if not row:
            raise KeyError(f"pack not found: {pack_id}")
        if not row["reconstructible"]:
            raise ValueError("pack is not reconstructible because it was served from a dirty overlay")
        if task_text is not None and sha256_text(task_text) != row["task_text_hash"]:
            raise ValueError("supplied task text does not match task_text_hash")
        return json.loads(row["manifest_json"])


def _merge_item(existing: dict[str, Any] | None, incoming: dict[str, Any]) -> dict[str, Any]:
    if existing is None:
        return incoming
    merged = dict(existing)
    merged["score"] = round(float(existing["score"]) + float(incoming["score"]), 6)
    merged["provenance"] = sorted(set(existing["provenance"]) | set(incoming["provenance"]))
    if "graph_confidence" in incoming:
        merged["graph_confidence"] = incoming["graph_confidence"]
    if "confidence_tier" in incoming:
        order = {"low": 0, "medium": 1, "high": 2}
        existing_tier = str(merged.get("confidence_tier") or incoming["confidence_tier"])
        incoming_tier = str(incoming["confidence_tier"])
        merged["confidence_tier"] = (
            existing_tier
            if order.get(existing_tier, 2) <= order.get(incoming_tier, 2)
            else incoming_tier
        )
    return merged


def _selection_sort_key(item: dict[str, Any]) -> tuple[Any, ...]:
    if "rerank_order" in item:
        return (
            0,
            int(item["rerank_order"]),
            -float(item["score"]),
            item["path"],
            item.get("start_line") or 0,
        )
    return (1, -float(item["score"]), item["path"], item.get("start_line") or 0)


def _normalize_path(path: str) -> str:
    return path.replace("\\", "/").removeprefix("./")


def _terms(text: str) -> set[str]:
    import re

    return {term for term in re.findall(r"[a-zA-Z][a-zA-Z0-9_]{3,}", text.lower())}


def _json_list(value: str) -> list[Any]:
    try:
        parsed = json.loads(value or "[]")
    except json.JSONDecodeError:
        return []
    return parsed if isinstance(parsed, list) else []
