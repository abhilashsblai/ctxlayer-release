GITHUB_ACTION_YAML = """name: CTXLAYER Safety Check

on:
  pull_request:

jobs:
  ctxlayer:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - name: Install ctxlayer
        run: pipx install ctxlayer
      - name: Run CTXLAYER CI check
        run: ctxlayer ci check --base origin/main --head HEAD
"""
