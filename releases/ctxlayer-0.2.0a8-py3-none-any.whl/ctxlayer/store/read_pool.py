from __future__ import annotations

import sqlite3
from collections.abc import Callable, Iterable, Sequence
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, TypeVar

T = TypeVar("T")


class SQLiteReadPool:
    """Small read-only connection pool for independent hot-path SQL legs."""

    def __init__(
        self,
        db_path: Path,
        *,
        max_workers: int = 4,
        timeout: float = 5.0,
    ) -> None:
        self.db_path = db_path
        self.max_workers = max(1, int(max_workers))
        self.timeout = timeout
        self._executor: ThreadPoolExecutor | None = None

    def __enter__(self) -> "SQLiteReadPool":
        self._executor = ThreadPoolExecutor(max_workers=self.max_workers)
        return self

    def __exit__(self, *_exc: object) -> None:
        if self._executor is not None:
            self._executor.shutdown(wait=True)
            self._executor = None

    def query_all(
        self, sql: str, params: Sequence[Any] | None = None
    ) -> list[dict[str, Any]]:
        with self._connect() as conn:
            return [dict(row) for row in conn.execute(sql, params or ()).fetchall()]

    def parallel_map(self, calls: Iterable[Callable[["SQLiteReadPool"], T]]) -> list[T]:
        call_list = list(calls)
        if not call_list:
            return []
        if self._executor is None or self.max_workers <= 1 or len(call_list) == 1:
            return [call(self) for call in call_list]
        futures = [self._executor.submit(call, self) for call in call_list]
        return [future.result() for future in futures]

    def _connect(self) -> sqlite3.Connection:
        uri = f"{self.db_path.resolve().as_uri()}?mode=ro&cache=shared"
        conn = sqlite3.connect(
            uri,
            uri=True,
            timeout=self.timeout,
            check_same_thread=False,
        )
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA query_only=ON")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=5000")
        conn.execute("PRAGMA temp_store=MEMORY")
        conn.execute("PRAGMA cache_size=-32768")
        conn.execute("PRAGMA mmap_size=268435456")
        return conn
