from __future__ import annotations

import json
import fnmatch
import random
import sqlite3
import struct
import time
from contextlib import contextmanager
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from importlib import resources
from pathlib import Path
from typing import Any

from ctxlayer.utils import canonical_json, stable_id, utc_now


@dataclass(frozen=True)
class Neighbor:
    node_type: str
    node_id: str
    repo_id: str
    kind: str
    confidence: float
    metadata: dict[str, Any]


@dataclass(frozen=True)
class Migration:
    version: int
    name: str
    sql: str


BUSINESS_NODE_TYPES = (
    "customer",
    "contract",
    "revenue",
    "sla",
    "product",
    "market",
    "risk",
    "compliance_obligation",
    "objective",
)
BUSINESS_EDGE_KINDS = (
    "serves",
    "used_by",
    "carries",
    "governed_by",
    "realizes",
    "exposes",
)
TRUST_RANK = {"low": 0, "medium": 1, "high": 2, "source": 3}
LATEST_MIGRATION_VERSION = 38


class CtxBudgetExceeded(TimeoutError):
    """Raised when a bounded CTX hot-path query exceeds its wall-clock budget."""

    def __init__(self, budget_ms: int | float):
        super().__init__(f"CTX query budget exceeded after {budget_ms} ms")
        self.budget_ms = float(budget_ms)


class SQLiteStore:
    """SQLite-backed graph store.

    This is intentionally the only module that issues application SQL. Other
    packages use this class rather than depending on table details directly.
    """

    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.cold_archive_path = db_path.with_suffix(".cold.db")
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(db_path), timeout=5.0)
        self.conn.row_factory = sqlite3.Row
        self.conn.create_function("ctxlayer_stable_id8", 8, _stable_edge_id_sql)
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.conn.execute("PRAGMA busy_timeout=5000")
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self.conn.execute("PRAGMA temp_store=MEMORY")
        self.conn.execute("PRAGMA cache_size=-65536")
        self.conn.execute("PRAGMA mmap_size=268435456")
        self.conn.execute("PRAGMA wal_autocheckpoint=1000")
        self.sqlite_vec_loaded = self._try_load_sqlite_vec()

    def _try_load_sqlite_vec(self) -> bool:
        try:
            import sqlite_vec

            self.conn.enable_load_extension(True)
            sqlite_vec.load(self.conn)
        except Exception:
            return False
        finally:
            try:
                self.conn.enable_load_extension(False)
            except Exception:
                pass
        return True

    def capabilities(self) -> dict[str, Any]:
        compile_options = [
            row[0] for row in self.conn.execute("PRAGMA compile_options").fetchall()
        ]
        return {
            "sqlite_version": sqlite3.sqlite_version,
            "wal": True,
            "fts5": any("ENABLE_FTS5" in option for option in compile_options),
            "sqlite_vec": self.sqlite_vec_loaded,
            "vector_store": "sqlite-vec" if self.sqlite_vec_loaded else "json-cosine",
        }

    def close(self) -> None:
        self.conn.close()

    def __enter__(self) -> "SQLiteStore":
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def migrate(self) -> None:
        try:
            row = self.conn.execute(
                "SELECT COUNT(*) FROM schema_migrations WHERE version BETWEEN 1 AND ?",
                (LATEST_MIGRATION_VERSION,),
            ).fetchone()
            if row and int(row[0]) == LATEST_MIGRATION_VERSION:
                return
        except sqlite3.OperationalError as exc:
            if "no such table" not in str(exc).lower():
                raise

        schema = (
            resources.files("ctxlayer.store")
            .joinpath("schema.sql")
            .read_text(encoding="utf-8")
        )
        migrations = [
            Migration(1, "bootstrap_schema", schema),
            Migration(2, "context_pack_metadata_column", "SELECT 1;"),
            Migration(3, "business_memory_v2_columns", "SELECT 1;"),
            Migration(4, "unified_memory_tables", "SELECT 1;"),
            Migration(5, "cognitive_memory_tables", "SELECT 1;"),
            Migration(6, "constitution_governance_tables", "SELECT 1;"),
            Migration(7, "structured_task_plan_tables", "SELECT 1;"),
            Migration(8, "learning_substrate_phase0", "SELECT 1;"),
            Migration(9, "memory_os_foundation", "SELECT 1;"),
            Migration(10, "efficacy_scorecards", "SELECT 1;"),
            Migration(11, "intent_engine_tables", "SELECT 1;"),
            Migration(12, "goal_governance_tables", "SELECT 1;"),
            Migration(13, "extraction_quality_trust_calibration", "SELECT 1;"),
            Migration(14, "semantic_graph_accuracy_drift", "SELECT 1;"),
            Migration(15, "concurrency_staleness", "SELECT 1;"),
            Migration(16, "loop_security", "SELECT 1;"),
            Migration(17, "business_graph_entities", "SELECT 1;"),
            Migration(18, "org_knowledge_ingestion", "SELECT 1;"),
            Migration(19, "decision_support", "SELECT 1;"),
            Migration(20, "edge_dedup_one_time", "SELECT 1;"),
            Migration(21, "reliability_health_and_verification", "SELECT 1;"),
            Migration(22, "skill_revision_capture", "SELECT 1;"),
            Migration(23, "skill_metrics_telemetry", "SELECT 1;"),
            Migration(24, "revision_classification_router", "SELECT 1;"),
            Migration(25, "skill_refinement_governance", "SELECT 1;"),
            Migration(26, "refinement_efficacy_closure", "SELECT 1;"),
            Migration(27, "cross_project_skill_substrate", "SELECT 1;"),
            Migration(28, "maintenance_keepsnap_defaults", "SELECT 1;"),
            Migration(29, "retention_policies_table", "SELECT 1;"),
            Migration(30, "maintenance_state_runs", "SELECT 1;"),
            Migration(31, "chunk_vector_blob_columns", "SELECT 1;"),
            Migration(32, "chunks_drop_text_normalized", "SELECT 1;"),
            Migration(33, "context_pack_snapshot_unpinning", "SELECT 1;"),
            Migration(34, "learning_reliability_summary", "SELECT 1;"),
            Migration(35, "write_time_guardrails", "SELECT 1;"),
            Migration(36, "anticipation_layer", "SELECT 1;"),
            Migration(37, "anticipation_collection_links", "SELECT 1;"),
            Migration(38, "fluid_memory_indexes", "SELECT 1;"),
        ]
        with self.conn:
            self.conn.executescript(schema)
            for migration in migrations:
                existing = self.conn.execute(
                    "SELECT checksum FROM schema_migrations WHERE version = ?",
                    (migration.version,),
                ).fetchone()
                checksum = stable_id(migration.name, migration.sql)
                if existing:
                    continue
                if migration.version == 2:
                    self._ensure_column(
                        "context_packs", "metadata_json", "TEXT NOT NULL DEFAULT '{}'"
                    )
                elif migration.version == 3:
                    self._ensure_column("business_rules", "supersedes_rule_id", "TEXT")
                    self._ensure_column("business_rules", "updated_at", "TEXT")
                    self._ensure_column("business_rule_evidence", "repo_id", "TEXT")
                    self._ensure_column(
                        "business_rule_evidence", "evidence_kind", "TEXT"
                    )
                    self._ensure_column(
                        "business_rule_evidence", "evidence_hash", "TEXT"
                    )
                    self._ensure_column(
                        "business_rule_evidence", "line_start", "INTEGER"
                    )
                    self._ensure_column("business_rule_evidence", "line_end", "INTEGER")
                elif migration.version == 4:
                    self._seed_memory_decay_policies()
                elif migration.version == 8:
                    self._ensure_learning_substrate()
                elif migration.version == 9:
                    self._ensure_memory_os_schema()
                elif migration.version == 11:
                    self._ensure_intent_schema()
                elif migration.version == 12:
                    self._ensure_goal_schema()
                elif migration.version == 13:
                    self._ensure_extraction_quality_schema()
                elif migration.version == 14:
                    self._ensure_semantic_quality_schema()
                elif migration.version == 15:
                    self._ensure_concurrency_schema()
                elif migration.version == 17:
                    self._ensure_business_graph_schema()
                elif migration.version == 18:
                    self._ensure_org_ingestion_schema()
                elif migration.version == 19:
                    self._ensure_decision_schema()
                elif migration.version == 20:
                    self.deduplicate_edges()
                    self.conn.execute(
                        """
                        INSERT OR REPLACE INTO edge_maintenance_state(id, last_dedup_at)
                        VALUES (1, ?)
                        """,
                        (utc_now(),),
                    )
                elif migration.version == 21:
                    self._ensure_reliability_schema()
                elif migration.version in {22, 23, 24, 25, 26, 27}:
                    self._ensure_skill_evolution_schema()
                elif migration.version == 28:
                    pass
                elif migration.version == 29:
                    self._ensure_retention_policy_schema()
                elif migration.version == 30:
                    self._ensure_maintenance_schema()
                elif migration.version == 31:
                    self._ensure_vector_blob_schema()
                elif migration.version == 32:
                    self._drop_chunks_text_normalized()
                elif migration.version == 33:
                    self._ensure_context_pack_snapshot_nullable()
                elif migration.version == 34:
                    self._ensure_learning_reliability_schema()
                elif migration.version == 35:
                    self._ensure_memory_enforcement_schema()
                elif migration.version in {36, 37}:
                    self._ensure_anticipation_schema()
                elif migration.version == 38:
                    self._ensure_fluid_memory_schema()
                elif migration.version in {5, 6, 7, 16}:
                    pass
                else:
                    self.conn.executescript(migration.sql)
                self.conn.execute(
                    """
                    INSERT OR IGNORE INTO schema_migrations(version, name, applied_at, checksum)
                    VALUES (?, ?, ?, ?)
                    """,
                    (migration.version, migration.name, utc_now(), checksum),
                )

    def _execute_write(
        self,
        fn: Any,
        *,
        max_attempts: int = 6,
        base_delay: float = 0.05,
    ) -> Any:
        for attempt in range(max_attempts):
            try:
                return fn()
            except sqlite3.OperationalError as exc:
                message = str(exc).lower()
                locked = "locked" in message or "busy" in message
                if not locked or attempt == max_attempts - 1:
                    raise
                time.sleep(base_delay * (2**attempt) + random.uniform(0, base_delay))
        raise RuntimeError("unreachable write retry state")

    @contextmanager
    def budget(self, ms: int | float):
        """Abort long-running SQLite work on CTX hot paths."""

        budget_ms = max(float(ms), 1.0)
        deadline = time.perf_counter() + (budget_ms / 1000.0)
        tripped = False

        def progress() -> int:
            nonlocal tripped
            if time.perf_counter() > deadline:
                tripped = True
                return 1
            return 0

        self.conn.set_progress_handler(progress, 1000)
        try:
            yield
        except sqlite3.OperationalError as exc:
            if tripped or "interrupted" in str(exc).lower():
                raise CtxBudgetExceeded(budget_ms) from exc
            raise
        finally:
            self.conn.set_progress_handler(None, 0)

    def _ensure_column(self, table: str, column: str, definition: str) -> None:
        existing = {
            row["name"]
            for row in self.conn.execute(f"PRAGMA table_info({table})").fetchall()
        }
        if column not in existing:
            try:
                self.conn.execute(
                    f"ALTER TABLE {table} ADD COLUMN {column} {definition}"
                )
            except sqlite3.OperationalError as exc:
                if "duplicate column name" not in str(exc).lower():
                    raise

    def _table_exists(self, table: str) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", (table,)
        ).fetchone()
        return row is not None

    def _ensure_reliability_schema(self) -> None:
        self._ensure_column(
            "task_plans",
            "required_verifications_json",
            "TEXT NOT NULL DEFAULT '[]'",
        )
        self._ensure_column("task_plans", "governed_class", "TEXT")
        self._ensure_column("task_sessions", "governed_class", "TEXT")
        self._ensure_column("agent_sessions", "governed_class", "TEXT")
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS ctx_health_probes (
              probe_id TEXT PRIMARY KEY,
              status TEXT NOT NULL,
              reasons_json TEXT NOT NULL DEFAULT '[]',
              db_bytes INTEGER NOT NULL DEFAULT 0,
              wal_bytes INTEGER NOT NULL DEFAULT 0,
              last_recall_ms REAL,
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_ctx_health_probes_created
              ON ctx_health_probes(created_at);

            CREATE TABLE IF NOT EXISTS task_verifications (
              verification_id TEXT PRIMARY KEY,
              task_session_id TEXT,
              plan_id TEXT,
              name TEXT NOT NULL,
              command TEXT NOT NULL,
              status TEXT NOT NULL,
              report_json TEXT NOT NULL DEFAULT '{}',
              audit_hash TEXT NOT NULL,
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_task_verifications_plan_name
              ON task_verifications(plan_id, name, created_at);

            CREATE INDEX IF NOT EXISTS idx_task_verifications_session_name
              ON task_verifications(task_session_id, name, created_at);
            """
        )

    def _ensure_skill_evolution_schema(self) -> None:
        self._ensure_column("skill", "metrics_version", "INTEGER NOT NULL DEFAULT 0")
        self._ensure_column("skill", "last_measured_at", "TEXT")
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS artifact_outputs (
              output_id TEXT PRIMARY KEY,
              repo_id TEXT NOT NULL,
              workspace_id TEXT NOT NULL,
              skill_id TEXT,
              session_id TEXT,
              task_session_id TEXT,
              artifact_kind TEXT NOT NULL,
              summary TEXT NOT NULL DEFAULT '',
              structure_json TEXT NOT NULL DEFAULT '{}',
              content_hash TEXT NOT NULL,
              status TEXT NOT NULL DEFAULT 'produced',
              created_at TEXT NOT NULL,
              accepted_at TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_artifact_outputs_skill_created
              ON artifact_outputs(repo_id, skill_id, created_at);

            CREATE TABLE IF NOT EXISTS revision_events (
              revision_id TEXT PRIMARY KEY,
              output_id TEXT,
              repo_id TEXT NOT NULL,
              workspace_id TEXT NOT NULL,
              skill_id TEXT,
              session_id TEXT,
              task_session_id TEXT,
              event_type TEXT NOT NULL,
              signal_kind TEXT NOT NULL,
              request_summary TEXT NOT NULL DEFAULT '',
              theme TEXT NOT NULL DEFAULT 'unclassified',
              confidence REAL NOT NULL DEFAULT 0.0,
              status TEXT NOT NULL DEFAULT 'linked',
              actor TEXT NOT NULL DEFAULT 'user',
              created_at TEXT NOT NULL,
              metadata_json TEXT NOT NULL DEFAULT '{}'
            );

            CREATE INDEX IF NOT EXISTS idx_revision_events_skill_created
              ON revision_events(repo_id, skill_id, created_at);
            CREATE INDEX IF NOT EXISTS idx_revision_events_output
              ON revision_events(output_id, event_type);

            CREATE TABLE IF NOT EXISTS skill_metrics (
              metric_id TEXT PRIMARY KEY,
              repo_id TEXT NOT NULL,
              workspace_id TEXT NOT NULL,
              skill_id TEXT NOT NULL,
              usage_count INTEGER NOT NULL DEFAULT 0,
              accept_first_pass_count INTEGER NOT NULL DEFAULT 0,
              revised_output_count INTEGER NOT NULL DEFAULT 0,
              revision_count INTEGER NOT NULL DEFAULT 0,
              accept_first_pass_rate REAL NOT NULL DEFAULT 0.0,
              revision_rate REAL NOT NULL DEFAULT 0.0,
              avg_revisions_per_output REAL NOT NULL DEFAULT 0.0,
              trend TEXT NOT NULL DEFAULT 'flat',
              sample_tier TEXT NOT NULL DEFAULT 'low',
              themes_json TEXT NOT NULL DEFAULT '{}',
              measured_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_skill_metrics_skill_measured
              ON skill_metrics(skill_id, measured_at);

            CREATE TABLE IF NOT EXISTS revision_classifications (
              classification_id TEXT PRIMARY KEY,
              revision_id TEXT NOT NULL,
              repo_id TEXT NOT NULL,
              skill_id TEXT,
              label TEXT NOT NULL,
              attribution TEXT NOT NULL,
              route TEXT NOT NULL,
              confidence REAL NOT NULL DEFAULT 0.0,
              rationale TEXT NOT NULL DEFAULT '',
              adjudicated INTEGER NOT NULL DEFAULT 0,
              created_at TEXT NOT NULL,
              metadata_json TEXT NOT NULL DEFAULT '{}'
            );

            CREATE INDEX IF NOT EXISTS idx_revision_classifications_revision
              ON revision_classifications(revision_id, created_at);
            CREATE INDEX IF NOT EXISTS idx_revision_classifications_skill_label
              ON revision_classifications(skill_id, label, created_at);

            CREATE TABLE IF NOT EXISTS skill_improvement_records (
              sir_id TEXT PRIMARY KEY,
              repo_id TEXT NOT NULL,
              skill_id TEXT NOT NULL,
              pattern TEXT NOT NULL,
              proposed_delta TEXT NOT NULL,
              evidence_refs_json TEXT NOT NULL DEFAULT '[]',
              evidence_count INTEGER NOT NULL DEFAULT 0,
              trust_tier TEXT NOT NULL DEFAULT 'low',
              status TEXT NOT NULL DEFAULT 'candidate',
              benchmark_ref TEXT,
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_skill_improvement_records_skill_status
              ON skill_improvement_records(skill_id, status, updated_at);

            CREATE TABLE IF NOT EXISTS skill_versions (
              version_id TEXT PRIMARY KEY,
              skill_id TEXT NOT NULL,
              repo_id TEXT NOT NULL,
              version INTEGER NOT NULL,
              guidance_hash TEXT NOT NULL,
              guidance_summary TEXT NOT NULL DEFAULT '',
              source_sir_id TEXT,
              active INTEGER NOT NULL DEFAULT 0,
              created_at TEXT NOT NULL,
              activated_at TEXT,
              UNIQUE(skill_id, version)
            );

            CREATE INDEX IF NOT EXISTS idx_skill_versions_skill_active
              ON skill_versions(skill_id, active, version);

            CREATE TABLE IF NOT EXISTS skill_refinement_approvals (
              approval_id TEXT PRIMARY KEY,
              sir_id TEXT NOT NULL,
              repo_id TEXT NOT NULL,
              skill_id TEXT NOT NULL,
              approved_by TEXT NOT NULL,
              status TEXT NOT NULL,
              reason TEXT NOT NULL DEFAULT '',
              created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS refinement_benchmarks (
              benchmark_id TEXT PRIMARY KEY,
              sir_id TEXT NOT NULL,
              repo_id TEXT NOT NULL,
              skill_id TEXT NOT NULL,
              baseline_version_id TEXT,
              candidate_version_id TEXT,
              result TEXT NOT NULL,
              revision_rate_delta REAL NOT NULL DEFAULT 0.0,
              regressions INTEGER NOT NULL DEFAULT 0,
              details_json TEXT NOT NULL DEFAULT '{}',
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_refinement_benchmarks_sir_created
              ON refinement_benchmarks(sir_id, created_at);

            CREATE TABLE IF NOT EXISTS skill_closure_probes (
              probe_id TEXT PRIMARY KEY,
              repo_id TEXT NOT NULL,
              skill_id TEXT,
              sir_id TEXT,
              status TEXT NOT NULL,
              details_json TEXT NOT NULL DEFAULT '{}',
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_skill_closure_probes_created
              ON skill_closure_probes(repo_id, created_at);

            CREATE TABLE IF NOT EXISTS skill_promotions (
              promotion_id TEXT PRIMARY KEY,
              repo_id TEXT NOT NULL,
              skill_id TEXT NOT NULL,
              global_skill_id TEXT,
              direction TEXT NOT NULL,
              status TEXT NOT NULL,
              privacy_status TEXT NOT NULL DEFAULT 'not_checked',
              approver TEXT,
              details_json TEXT NOT NULL DEFAULT '{}',
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_skill_promotions_skill_created
              ON skill_promotions(skill_id, created_at);
            """
        )

    def _ensure_retention_policy_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS retention_policies (
              target TEXT PRIMARY KEY,
              keep_full_days INTEGER,
              keep_summary_days INTEGER,
              max_rows INTEGER,
              scope TEXT NOT NULL DEFAULT 'global',
              updated_at TEXT NOT NULL
            );
            """
        )
        defaults = [
            ("context_packs", 14, None, None, "global"),
            ("agent_session_events", 90, None, 2000, "per_repo"),
            ("learning_event", 90, None, None, "global"),
            ("memory_access_log", 90, None, None, "global"),
            ("memory_utilization", 90, None, None, "global"),
            ("semantic_drift_findings", 90, None, None, "global"),
        ]
        with self.conn:
            for target, keep_full, keep_summary, max_rows, scope in defaults:
                self.conn.execute(
                    """
                    INSERT OR IGNORE INTO retention_policies(
                      target, keep_full_days, keep_summary_days, max_rows, scope, updated_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (target, keep_full, keep_summary, max_rows, scope, utc_now()),
                )

    def _ensure_maintenance_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS maintenance_state (
              id INTEGER PRIMARY KEY CHECK (id = 1),
              last_maintenance_at TEXT,
              last_light_maintenance_at TEXT,
              last_degraded_auto_gc_at TEXT
            );

            CREATE TABLE IF NOT EXISTS maintenance_runs (
              maintenance_run_id TEXT PRIMARY KEY,
              trigger TEXT NOT NULL,
              mode TEXT NOT NULL,
              status TEXT NOT NULL,
              counts_json TEXT NOT NULL DEFAULT '{}',
              bytes_before INTEGER NOT NULL DEFAULT 0,
              bytes_after INTEGER NOT NULL DEFAULT 0,
              compact_json TEXT NOT NULL DEFAULT '{}',
              duration_ms REAL NOT NULL DEFAULT 0.0,
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_maintenance_runs_created
              ON maintenance_runs(created_at);
            """
        )
        with self.conn:
            self.conn.execute("INSERT OR IGNORE INTO maintenance_state(id) VALUES (1)")

    def _ensure_learning_reliability_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS task_learning_summary (
              task_session_id TEXT PRIMARY KEY,
              idempotency_key TEXT NOT NULL,
              consolidated_at TEXT NOT NULL,
              trigger TEXT NOT NULL,
              session_ids_json TEXT NOT NULL DEFAULT '[]',
              counts_json TEXT NOT NULL DEFAULT '{}',
              record_refs_json TEXT NOT NULL DEFAULT '{}',
              narrative TEXT NOT NULL DEFAULT ''
            );

            CREATE INDEX IF NOT EXISTS idx_learning_event_ref_ts
              ON learning_event(ref, ts);

            CREATE INDEX IF NOT EXISTS idx_memory_records_status
              ON memory_records(status);
            """
        )

    def _ensure_memory_enforcement_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS memory_enforcement (
              directive_id TEXT PRIMARY KEY,
              record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
              repo_id TEXT,
              enforcement_level TEXT NOT NULL,
              severity TEXT NOT NULL,
              path_globs_json TEXT NOT NULL,
              symbol_ids_json TEXT,
              anti_patterns_json TEXT,
              required_patterns_json TEXT,
              rationale TEXT,
              remediation TEXT,
              status TEXT NOT NULL,
              approved_by TEXT,
              source TEXT,
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL,
              CHECK (enforcement_level IN ('advisory', 'warn', 'block')),
              CHECK (severity IN ('low', 'medium', 'high', 'critical')),
              CHECK (status IN ('active', 'suspended', 'superseded'))
            );

            CREATE INDEX IF NOT EXISTS idx_memory_enforcement_repo_status_level
              ON memory_enforcement(repo_id, status, enforcement_level);

            CREATE INDEX IF NOT EXISTS idx_memory_enforcement_record
              ON memory_enforcement(record_id);
            """
        )

    def _ensure_anticipation_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS anticipation_models (
              model_id TEXT PRIMARY KEY,
              repo_id TEXT NOT NULL,
              workspace_id TEXT,
              kind TEXT NOT NULL DEFAULT 'frequency_v0',
              params_json TEXT NOT NULL DEFAULT '{}',
              calibration_json TEXT NOT NULL DEFAULT '{}',
              trained_on_count INTEGER NOT NULL DEFAULT 0,
              ece REAL,
              params_hash TEXT NOT NULL,
              created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_anticipation_models_repo
              ON anticipation_models(repo_id, kind, created_at);

            CREATE TABLE IF NOT EXISTS anticipation_predictions (
              prediction_id TEXT PRIMARY KEY,
              repo_id TEXT NOT NULL,
              workspace_id TEXT,
              session_id TEXT,
              task_session_id TEXT,
              model_id TEXT NOT NULL,
              context_hash TEXT NOT NULL,
              context_json TEXT NOT NULL DEFAULT '{}',
              observation_json TEXT NOT NULL DEFAULT '{}',
              surprise_raw REAL NOT NULL,
              surprise REAL NOT NULL,
              components_json TEXT NOT NULL DEFAULT '{}',
              latency_ms REAL,
              timed_out INTEGER NOT NULL DEFAULT 0,
              source TEXT,
              audit_hash TEXT NOT NULL,
              created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_anticipation_predictions_session
              ON anticipation_predictions(session_id, created_at);
            CREATE INDEX IF NOT EXISTS idx_anticipation_predictions_repo
              ON anticipation_predictions(repo_id, created_at);

            CREATE TABLE IF NOT EXISTS anticipation_updates (
              update_id TEXT PRIMARY KEY,
              repo_id TEXT NOT NULL,
              session_id TEXT NOT NULL,
              task_session_id TEXT,
              signal_kind TEXT NOT NULL,
              context_hash TEXT NOT NULL,
              observation_json TEXT NOT NULL DEFAULT '{}',
              magnitude REAL NOT NULL DEFAULT 1.0,
              delta_json TEXT NOT NULL DEFAULT '{}',
              audit_hash TEXT NOT NULL,
              created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_anticipation_updates_session
              ON anticipation_updates(session_id, created_at);

            CREATE TABLE IF NOT EXISTS anticipation_interoception (
              intero_id TEXT PRIMARY KEY,
              repo_id TEXT NOT NULL,
              session_id TEXT NOT NULL,
              task_session_id TEXT,
              components_json TEXT NOT NULL DEFAULT '{}',
              gut REAL NOT NULL,
              summary TEXT NOT NULL DEFAULT '',
              created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_anticipation_intero_session
              ON anticipation_interoception(session_id, created_at);
            """
        )
        self._ensure_column("anticipation_predictions", "latency_ms", "REAL")
        self._ensure_column(
            "anticipation_predictions", "timed_out", "INTEGER NOT NULL DEFAULT 0"
        )
        self._ensure_column("anticipation_predictions", "source", "TEXT")
        self._ensure_column("outcomes", "linked_prediction_id", "TEXT")
        self._ensure_column(
            "outcomes", "prediction_link_json", "TEXT NOT NULL DEFAULT '{}'"
        )
        self.conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_outcomes_linked_prediction
              ON outcomes(linked_prediction_id);
            """
        )

    def _ensure_vector_blob_schema(self) -> None:
        self._ensure_column("chunk_vectors", "vector_blob", "BLOB")
        self._ensure_column("chunk_vectors", "encoding", "TEXT NOT NULL DEFAULT 'json'")
        self._ensure_column("chunk_vectors", "scale", "REAL")

    def _drop_chunks_text_normalized(self) -> None:
        columns = {
            row["name"]
            for row in self.conn.execute("PRAGMA table_info(chunks)").fetchall()
        }
        if "text_normalized" not in columns:
            return
        try:
            self.conn.execute("ALTER TABLE chunks DROP COLUMN text_normalized")
        except sqlite3.OperationalError:
            self._rebuild_chunks_without_text_normalized()

    def _rebuild_chunks_without_text_normalized(self) -> None:
        with self.conn:
            self.conn.execute("PRAGMA foreign_keys=OFF")
            self.conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS chunks_new (
                  chunk_id TEXT PRIMARY KEY,
                  snapshot_id TEXT NOT NULL REFERENCES snapshots(snapshot_id),
                  repo_id TEXT NOT NULL,
                  path TEXT NOT NULL,
                  symbol_identity_id TEXT,
                  category TEXT NOT NULL,
                  start_line INTEGER,
                  end_line INTEGER,
                  text TEXT NOT NULL,
                  token_count INTEGER NOT NULL
                );

                INSERT OR REPLACE INTO chunks_new(
                  chunk_id, snapshot_id, repo_id, path, symbol_identity_id,
                  category, start_line, end_line, text, token_count
                )
                SELECT chunk_id, snapshot_id, repo_id, path, symbol_identity_id,
                       category, start_line, end_line, text, token_count
                FROM chunks;

                DROP TABLE chunks;
                ALTER TABLE chunks_new RENAME TO chunks;

                CREATE INDEX IF NOT EXISTS idx_chunks_snapshot_path
                  ON chunks(snapshot_id, path);
                CREATE INDEX IF NOT EXISTS idx_chunks_symbol
                  ON chunks(symbol_identity_id);
                """
            )
            self.conn.execute("PRAGMA foreign_keys=ON")

    def _ensure_context_pack_snapshot_nullable(self) -> None:
        columns = self.conn.execute("PRAGMA table_info(context_packs)").fetchall()
        snapshot_column = next(
            (row for row in columns if row["name"] == "snapshot_id"), None
        )
        if snapshot_column is None or not int(snapshot_column["notnull"]):
            return
        with self.conn:
            self.conn.execute("PRAGMA foreign_keys=OFF")
            self.conn.executescript(
                """
                CREATE TABLE context_packs_new (
                  pack_id TEXT PRIMARY KEY,
                  snapshot_id TEXT REFERENCES snapshots(snapshot_id),
                  repo_id TEXT NOT NULL,
                  task_text_hash TEXT NOT NULL,
                  manifest_json TEXT NOT NULL,
                  reconstructible INTEGER NOT NULL DEFAULT 1,
                  created_at TEXT NOT NULL,
                  metadata_json TEXT NOT NULL DEFAULT '{}',
                  bound_snapshot_id TEXT,
                  binding_mode TEXT NOT NULL DEFAULT 'auto',
                  bound_at TEXT,
                  base_commit_sha TEXT,
                  worktree_state TEXT,
                  staleness_state TEXT NOT NULL DEFAULT 'fresh'
                );

                INSERT OR REPLACE INTO context_packs_new(
                  pack_id, snapshot_id, repo_id, task_text_hash, manifest_json,
                  reconstructible, created_at, metadata_json, bound_snapshot_id,
                  binding_mode, bound_at, base_commit_sha, worktree_state,
                  staleness_state
                )
                SELECT pack_id, snapshot_id, repo_id, task_text_hash, manifest_json,
                       reconstructible, created_at, metadata_json,
                       COALESCE(bound_snapshot_id, snapshot_id), binding_mode,
                       bound_at, base_commit_sha, worktree_state, staleness_state
                FROM context_packs;

                DROP TABLE context_packs;
                ALTER TABLE context_packs_new RENAME TO context_packs;
                """
            )
            self.conn.execute("PRAGMA foreign_keys=ON")

    def _ensure_concurrency_schema(self) -> None:
        for table in ("context_packs", "intents", "goals"):
            if not self._table_exists(table):
                continue
            self._ensure_column(table, "bound_snapshot_id", "TEXT")
            self._ensure_column(table, "binding_mode", "TEXT NOT NULL DEFAULT 'auto'")
            self._ensure_column(table, "bound_at", "TEXT")
            self._ensure_column(table, "base_commit_sha", "TEXT")
            self._ensure_column(table, "worktree_state", "TEXT")
            self._ensure_column(
                table, "staleness_state", "TEXT NOT NULL DEFAULT 'fresh'"
            )
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS session_leases (
              lease_id TEXT PRIMARY KEY,
              session_id TEXT NOT NULL,
              workspace_id TEXT NOT NULL,
              repo_id TEXT,
              agent_name TEXT NOT NULL DEFAULT 'codex',
              bound_snapshot_id TEXT,
              impact_paths_json TEXT NOT NULL DEFAULT '[]',
              impact_hash TEXT NOT NULL DEFAULT '',
              status TEXT NOT NULL DEFAULT 'active',
              acquired_at TEXT NOT NULL,
              renewed_at TEXT NOT NULL,
              expires_at TEXT NOT NULL,
              released_at TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_session_leases_scope_status
              ON session_leases(workspace_id, repo_id, status, expires_at);

            CREATE INDEX IF NOT EXISTS idx_session_leases_session_status
              ON session_leases(session_id, status, expires_at);

            CREATE TABLE IF NOT EXISTS session_conflicts (
              conflict_id TEXT PRIMARY KEY,
              workspace_id TEXT NOT NULL,
              repo_id TEXT,
              left_session_id TEXT NOT NULL,
              right_session_id TEXT NOT NULL,
              conflict_type TEXT NOT NULL,
              severity TEXT NOT NULL DEFAULT 'warning',
              status TEXT NOT NULL DEFAULT 'open',
              paths_json TEXT NOT NULL DEFAULT '[]',
              detail_json TEXT NOT NULL DEFAULT '{}',
              detected_at TEXT NOT NULL,
              updated_at TEXT NOT NULL,
              acknowledged_at TEXT,
              resolved_at TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_session_conflicts_scope_status
              ON session_conflicts(workspace_id, repo_id, status, detected_at);

            CREATE TABLE IF NOT EXISTS audit_chain_state (
              chain_id TEXT PRIMARY KEY,
              tip_hash TEXT NOT NULL,
              height INTEGER NOT NULL DEFAULT 0,
              updated_at TEXT NOT NULL
            );
            """
        )
        self.conn.execute(
            """
            INSERT OR IGNORE INTO audit_chain_state(chain_id, tip_hash, height, updated_at)
            SELECT 'default', COALESCE(row_hash, ''), (SELECT COUNT(*) FROM audit_log), ?
            FROM (SELECT row_hash FROM audit_log ORDER BY audit_id DESC LIMIT 1)
            """,
            (utc_now(),),
        )
        self.conn.execute(
            """
            INSERT OR IGNORE INTO audit_chain_state(chain_id, tip_hash, height, updated_at)
            VALUES ('default', '', 0, ?)
            """,
            (utc_now(),),
        )

    def _ensure_learning_substrate(self) -> None:
        self._ensure_column(
            "memory_records", "trust", "TEXT NOT NULL DEFAULT 'candidate'"
        )
        self._ensure_column(
            "memory_records", "provenance_json", "TEXT NOT NULL DEFAULT '{}'"
        )
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS learning_candidate (
              candidate_id TEXT PRIMARY KEY,
              kind TEXT NOT NULL,
              payload_json TEXT NOT NULL,
              provenance_json TEXT NOT NULL DEFAULT '{}',
              confidence REAL NOT NULL DEFAULT 0.0,
              status TEXT NOT NULL DEFAULT 'candidate',
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_learning_candidate_status
              ON learning_candidate(kind, status, created_at);

            CREATE TABLE IF NOT EXISTS skill (
              skill_id TEXT PRIMARY KEY,
              name TEXT NOT NULL,
              nl_description TEXT NOT NULL,
              trigger_signature TEXT NOT NULL,
              steps_json TEXT NOT NULL DEFAULT '[]',
              evidence_json TEXT NOT NULL DEFAULT '[]',
              embedding_ref TEXT,
              provenance_json TEXT NOT NULL DEFAULT '{}',
              success_count INTEGER NOT NULL DEFAULT 0,
              fail_count INTEGER NOT NULL DEFAULT 0,
              last_validated_at TEXT,
              status TEXT NOT NULL DEFAULT 'candidate',
              trust TEXT NOT NULL DEFAULT 'untrusted',
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_skill_status_trust
              ON skill(status, trust, updated_at);

            CREATE TABLE IF NOT EXISTS learning_run (
              run_id TEXT PRIMARY KEY,
              target TEXT NOT NULL,
              kind TEXT NOT NULL,
              before_json TEXT NOT NULL DEFAULT '{}',
              after_json TEXT NOT NULL DEFAULT '{}',
              train_metrics_json TEXT NOT NULL DEFAULT '{}',
              holdout_metrics_json TEXT NOT NULL DEFAULT '{}',
              gate_pass INTEGER NOT NULL DEFAULT 0,
              archived INTEGER NOT NULL DEFAULT 0,
              promoted INTEGER NOT NULL DEFAULT 0,
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_learning_run_kind_target
              ON learning_run(kind, target, created_at);

            CREATE TABLE IF NOT EXISTS learning_event (
              event_id TEXT PRIMARY KEY,
              ts TEXT NOT NULL,
              phase TEXT NOT NULL,
              kind TEXT NOT NULL,
              ref TEXT,
              payload_json TEXT NOT NULL DEFAULT '{}'
            );

            CREATE INDEX IF NOT EXISTS idx_learning_event_ts
              ON learning_event(ts, phase, kind);

            CREATE TABLE IF NOT EXISTS agent_benchmark_run (
              benchmark_run_id TEXT PRIMARY KEY,
              repo_id TEXT NOT NULL,
              cases INTEGER NOT NULL DEFAULT 0,
              success_rate_delta REAL NOT NULL DEFAULT 0.0,
              tests_pass_rate_delta REAL NOT NULL DEFAULT 0.0,
              wrong_files_touched_reduction REAL NOT NULL DEFAULT 0.0,
              missing_files_reduction REAL NOT NULL DEFAULT 0.0,
              agent_seconds_reduction REAL NOT NULL DEFAULT 0.0,
              memory_score REAL NOT NULL DEFAULT 0.0,
              context_retrieval_score REAL NOT NULL DEFAULT 0.0,
              gate_ok INTEGER,
              gate_status TEXT,
              delta_json TEXT NOT NULL DEFAULT '{}',
              lift_attribution_json TEXT NOT NULL DEFAULT '{}',
              roadmap_pruning_json TEXT NOT NULL DEFAULT '{}',
              report_json TEXT NOT NULL DEFAULT '{}',
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_agent_benchmark_run_repo_created
              ON agent_benchmark_run(repo_id, created_at);
            """
        )
        self._ensure_column("skill", "provenance_json", "TEXT NOT NULL DEFAULT '{}'")
        with self.conn:
            self.conn.execute(
                """
                UPDATE memory_records
                SET trust = CASE
                  WHEN status = 'active' THEN 'active'
                  WHEN status = 'approved' THEN 'approved'
                  WHEN status = 'candidate' THEN 'candidate'
                  ELSE COALESCE(NULLIF(trust, ''), 'candidate')
                END
                WHERE trust IS NULL
                   OR trust = ''
                   OR (trust = 'candidate' AND status IN ('active', 'approved'))
                """
            )
            self.conn.execute(
                """
                UPDATE memory_records
                SET provenance_json = ?
                WHERE provenance_json IS NULL OR provenance_json = ''
                """,
                (
                    canonical_json(
                        {
                            "generator": "deterministic",
                            "validator": "none",
                            "input_source": "repo",
                        }
                    ),
                ),
            )

    def _ensure_memory_os_schema(self) -> None:
        self._ensure_column("memory_records", "title", "TEXT")
        self._ensure_column("memory_records", "importance", "REAL NOT NULL DEFAULT 0.5")
        self._ensure_column("memory_records", "applies_when", "TEXT")
        self._ensure_column("memory_records", "avoid_when", "TEXT")
        self._ensure_column("memory_records", "invalidates_when", "TEXT")
        self._ensure_column("memory_records", "last_validated_at", "TEXT")
        self.conn.executescript(
            """
            CREATE INDEX IF NOT EXISTS idx_memory_records_scope_type_status
              ON memory_records(workspace_id, repo_id, type, status, trust);

            CREATE INDEX IF NOT EXISTS idx_memory_records_validation
              ON memory_records(updated_at, last_validated_at);

            CREATE INDEX IF NOT EXISTS idx_memory_records_expiry
              ON memory_records(expires_at, status);

            CREATE TABLE IF NOT EXISTS memory_review_queue (
              review_id TEXT PRIMARY KEY,
              record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
              reason TEXT NOT NULL,
              severity TEXT NOT NULL,
              status TEXT NOT NULL,
              created_at TEXT NOT NULL,
              resolved_at TEXT,
              resolution TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_memory_review_queue_status
              ON memory_review_queue(status, severity, created_at);

            CREATE TABLE IF NOT EXISTS memory_revision (
              revision_id TEXT PRIMARY KEY,
              record_id TEXT NOT NULL REFERENCES memory_records(record_id) ON DELETE CASCADE,
              previous_hash TEXT,
              record_json TEXT NOT NULL,
              actor TEXT NOT NULL,
              reason TEXT,
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_memory_revision_record
              ON memory_revision(record_id, created_at);
            """
        )
        with self.conn:
            self.conn.execute(
                """
                UPDATE memory_records
                SET importance = confidence
                WHERE importance IS NULL
                """
            )

    def _ensure_intent_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS intents (
              intent_id TEXT PRIMARY KEY,
              workspace_id TEXT NOT NULL,
              repo_id TEXT,
              snapshot_id TEXT NOT NULL REFERENCES snapshots(snapshot_id),
              problem_statement TEXT NOT NULL,
              problem_text_hash TEXT NOT NULL,
              skeleton_hash TEXT NOT NULL,
              status TEXT NOT NULL,
              selected_goal_id TEXT,
              audit_hash TEXT NOT NULL,
              prev_audit_hash TEXT NOT NULL,
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL,
              metadata_json TEXT NOT NULL DEFAULT '{}'
            );

            CREATE INDEX IF NOT EXISTS idx_intents_scope
              ON intents(workspace_id, repo_id, status);

            CREATE UNIQUE INDEX IF NOT EXISTS idx_intents_reproduce
              ON intents(problem_text_hash, snapshot_id);

            CREATE TABLE IF NOT EXISTS intent_evidence (
              evidence_id TEXT PRIMARY KEY,
              intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
              ref TEXT NOT NULL,
              source_type TEXT NOT NULL,
              repo_id TEXT,
              path TEXT,
              symbol_identity_id TEXT,
              line_start INTEGER,
              line_end INTEGER,
              evidence_hash TEXT NOT NULL,
              confidence REAL NOT NULL DEFAULT 1.0,
              metadata_json TEXT NOT NULL DEFAULT '{}'
            );

            CREATE INDEX IF NOT EXISTS idx_intent_evidence_intent
              ON intent_evidence(intent_id, source_type);

            CREATE TABLE IF NOT EXISTS intent_decomposition_nodes (
              node_id TEXT PRIMARY KEY,
              intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
              parent_id TEXT,
              label TEXT NOT NULL,
              node_kind TEXT NOT NULL,
              origin TEXT NOT NULL,
              status TEXT NOT NULL,
              confidence REAL NOT NULL DEFAULT 1.0,
              evidence_refs_json TEXT NOT NULL DEFAULT '[]',
              ordinal INTEGER NOT NULL DEFAULT 0,
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_intent_nodes_intent
              ON intent_decomposition_nodes(intent_id, parent_id, ordinal);

            CREATE TABLE IF NOT EXISTS intent_hypotheses (
              hypothesis_id TEXT PRIMARY KEY,
              intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
              statement TEXT NOT NULL,
              origin TEXT NOT NULL,
              confidence REAL NOT NULL,
              rank INTEGER NOT NULL,
              verified INTEGER NOT NULL DEFAULT 0,
              evidence_refs_json TEXT NOT NULL DEFAULT '[]',
              signals_json TEXT NOT NULL DEFAULT '{}',
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_intent_hypotheses_intent
              ON intent_hypotheses(intent_id, rank);

            CREATE TABLE IF NOT EXISTS intent_stakeholders (
              stakeholder_id TEXT PRIMARY KEY,
              intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
              owner TEXT NOT NULL,
              files_json TEXT NOT NULL DEFAULT '[]',
              reason TEXT NOT NULL,
              source TEXT NOT NULL,
              confidence REAL NOT NULL DEFAULT 1.0
            );

            CREATE TABLE IF NOT EXISTS intent_contradictions (
              contradiction_id TEXT PRIMARY KEY,
              intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
              a_ref TEXT NOT NULL,
              b_ref TEXT NOT NULL,
              description TEXT NOT NULL,
              detector TEXT NOT NULL,
              severity TEXT NOT NULL,
              created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS intent_candidate_goals (
              goal_id TEXT PRIMARY KEY,
              intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
              statement TEXT NOT NULL,
              success_metric TEXT,
              metric_source TEXT NOT NULL,
              confidence REAL NOT NULL,
              origin TEXT NOT NULL,
              evidence_refs_json TEXT NOT NULL DEFAULT '[]',
              created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS intent_open_questions (
              question_id TEXT PRIMARY KEY,
              intent_id TEXT NOT NULL REFERENCES intents(intent_id) ON DELETE CASCADE,
              question TEXT NOT NULL,
              reason TEXT NOT NULL,
              created_at TEXT NOT NULL
            );
            """
        )

    def _ensure_goal_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS goals (
              goal_id TEXT PRIMARY KEY,
              intent_id TEXT NOT NULL,
              workspace_id TEXT NOT NULL,
              repo_id TEXT,
              snapshot_id TEXT,
              statement TEXT NOT NULL,
              success_metric TEXT NOT NULL,
              metric_kind TEXT NOT NULL DEFAULT 'technical',
              metric_target TEXT,
              hypothesis TEXT,
              confidence REAL NOT NULL DEFAULT 0.0,
              status TEXT NOT NULL DEFAULT 'proposed',
              challenge_state TEXT NOT NULL DEFAULT 'none',
              permission_mode TEXT NOT NULL DEFAULT 'warn',
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL,
              metadata_json TEXT NOT NULL DEFAULT '{}'
            );

            CREATE INDEX IF NOT EXISTS idx_goals_scope_status
              ON goals(workspace_id, repo_id, status);

            CREATE INDEX IF NOT EXISTS idx_goals_intent
              ON goals(intent_id);

            CREATE TABLE IF NOT EXISTS goal_evidence (
              evidence_id TEXT PRIMARY KEY,
              goal_id TEXT NOT NULL REFERENCES goals(goal_id) ON DELETE CASCADE,
              ref TEXT NOT NULL,
              source_type TEXT NOT NULL,
              weight REAL NOT NULL DEFAULT 1.0,
              detail_json TEXT NOT NULL DEFAULT '{}',
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_goal_evidence_goal
              ON goal_evidence(goal_id);

            CREATE TABLE IF NOT EXISTS goal_alternatives (
              alt_id TEXT PRIMARY KEY,
              goal_id TEXT NOT NULL REFERENCES goals(goal_id) ON DELETE CASCADE,
              statement TEXT NOT NULL,
              projected_metric_delta TEXT NOT NULL,
              rationale TEXT NOT NULL,
              confidence REAL NOT NULL DEFAULT 0.0,
              evidence_refs_json TEXT NOT NULL DEFAULT '[]',
              rank INTEGER NOT NULL DEFAULT 0,
              status TEXT NOT NULL DEFAULT 'proposed',
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_goal_alternatives_goal
              ON goal_alternatives(goal_id, rank);

            CREATE TABLE IF NOT EXISTS goal_decisions (
              decision_id TEXT PRIMARY KEY,
              goal_id TEXT NOT NULL REFERENCES goals(goal_id) ON DELETE CASCADE,
              kind TEXT NOT NULL,
              alt_id TEXT,
              actor TEXT NOT NULL,
              rationale TEXT,
              permission_mode TEXT NOT NULL,
              audit_row_hash TEXT,
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_goal_decisions_goal
              ON goal_decisions(goal_id, created_at);
            """
        )

    def _ensure_extraction_quality_schema(self) -> None:
        self._ensure_column("business_rule_candidates", "raw_score", "REAL")
        self._ensure_column("business_rule_candidates", "calibrated_confidence", "REAL")
        self._ensure_column("business_rule_candidates", "trust_tier", "TEXT")
        self._ensure_column("business_rule_candidates", "confidence_method", "TEXT")
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS trust_calibration (
              calibration_id TEXT PRIMARY KEY,
              repo_id TEXT,
              source_type TEXT NOT NULL,
              default_tier TEXT NOT NULL,
              approvals INTEGER NOT NULL,
              rejections INTEGER NOT NULL,
              approval_rate REAL NOT NULL,
              sample_size INTEGER NOT NULL,
              confidence_floor REAL NOT NULL,
              method TEXT NOT NULL,
              computed_at TEXT NOT NULL,
              UNIQUE(repo_id, source_type)
            );

            CREATE INDEX IF NOT EXISTS idx_trust_calibration_scope
              ON trust_calibration(repo_id, source_type);

            CREATE TABLE IF NOT EXISTS extraction_eval_results (
              result_id TEXT PRIMARY KEY,
              memory_eval_run_id TEXT NOT NULL REFERENCES memory_eval_runs(memory_eval_run_id),
              repo_id TEXT,
              source_type TEXT NOT NULL,
              corpus_version TEXT NOT NULL,
              true_positive INTEGER NOT NULL,
              false_positive INTEGER NOT NULL,
              false_negative INTEGER NOT NULL,
              precision REAL NOT NULL,
              recall REAL NOT NULL,
              f1 REAL NOT NULL,
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_extraction_eval_results_run
              ON extraction_eval_results(memory_eval_run_id, source_type);
            """
        )

    def _ensure_semantic_quality_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS semantic_drift_findings (
              finding_id TEXT PRIMARY KEY,
              repo_id TEXT NOT NULL,
              snapshot_id TEXT NOT NULL,
              finding_type TEXT NOT NULL,
              severity TEXT NOT NULL,
              node_id TEXT,
              edge_id TEXT,
              paths_json TEXT NOT NULL DEFAULT '[]',
              detail TEXT NOT NULL,
              confidence REAL,
              status TEXT NOT NULL DEFAULT 'open',
              detected_at TEXT NOT NULL,
              resolved_at TEXT,
              audit_hash TEXT,
              prev_audit_hash TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_semantic_drift_repo_status
              ON semantic_drift_findings(repo_id, status, severity);

            CREATE TABLE IF NOT EXISTS semantic_accuracy_runs (
              accuracy_run_id TEXT PRIMARY KEY,
              repo_id TEXT NOT NULL,
              fixture_set TEXT NOT NULL,
              metrics_json TEXT NOT NULL,
              passed INTEGER NOT NULL,
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_semantic_accuracy_repo_created
              ON semantic_accuracy_runs(repo_id, created_at);
            """
        )

    def _ensure_business_graph_schema(self) -> None:
        self._ensure_column("semantic_nodes", "trust_tier", "TEXT")
        self._ensure_column("semantic_nodes", "status", "TEXT")
        self._ensure_column(
            "semantic_nodes", "provenance_json", "TEXT NOT NULL DEFAULT '{}'"
        )
        self.conn.executescript(
            """
            CREATE INDEX IF NOT EXISTS idx_semantic_nodes_repo_type_status
              ON semantic_nodes(repo_id, node_type, status);

            CREATE TABLE IF NOT EXISTS business_node_approvals (
              approval_id TEXT PRIMARY KEY,
              node_id TEXT NOT NULL REFERENCES semantic_nodes(node_id) ON DELETE CASCADE,
              repo_id TEXT NOT NULL,
              decision TEXT NOT NULL,
              approver TEXT NOT NULL,
              notes TEXT,
              from_status TEXT,
              to_status TEXT NOT NULL,
              audit_row_hash TEXT,
              created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_business_node_approvals_node
              ON business_node_approvals(node_id, created_at);

            CREATE INDEX IF NOT EXISTS idx_business_node_approvals_repo_decision
              ON business_node_approvals(repo_id, decision, created_at);
            """
        )

    def _ensure_org_ingestion_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS org_knowledge_candidates (
              candidate_id TEXT PRIMARY KEY,
              workspace_id TEXT NOT NULL,
              repo_id TEXT,
              memory_record_id TEXT REFERENCES memory_records(record_id) ON DELETE SET NULL,
              source_connector TEXT NOT NULL,
              source_ref TEXT NOT NULL,
              content_extract TEXT NOT NULL,
              content_hash TEXT NOT NULL,
              extracted_type TEXT NOT NULL,
              trust_tier TEXT NOT NULL DEFAULT 'low',
              confidence REAL NOT NULL DEFAULT 0.3,
              status TEXT NOT NULL DEFAULT 'quarantined',
              defense_result TEXT NOT NULL DEFAULT '{}',
              contradictions TEXT NOT NULL DEFAULT '[]',
              linked_entities TEXT NOT NULL DEFAULT '[]',
              captured_at TEXT,
              ingested_at TEXT NOT NULL,
              decay_at TEXT,
              provenance TEXT NOT NULL DEFAULT '{}',
              redaction_summary TEXT NOT NULL DEFAULT '{}',
              access_scope TEXT NOT NULL DEFAULT 'restricted',
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_org_cand_status
              ON org_knowledge_candidates(workspace_id, repo_id, status);

            CREATE INDEX IF NOT EXISTS idx_org_cand_source
              ON org_knowledge_candidates(source_connector, source_ref);

            CREATE UNIQUE INDEX IF NOT EXISTS idx_org_cand_hash
              ON org_knowledge_candidates(workspace_id, content_hash);

            CREATE TABLE IF NOT EXISTS org_connectors (
              connector_id TEXT PRIMARY KEY,
              workspace_id TEXT NOT NULL,
              kind TEXT NOT NULL,
              display_name TEXT NOT NULL,
              config_json TEXT NOT NULL DEFAULT '{}',
              secret_ref TEXT,
              access_scope TEXT NOT NULL DEFAULT 'restricted',
              remote_enabled INTEGER NOT NULL DEFAULT 0,
              enabled INTEGER NOT NULL DEFAULT 1,
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_org_connectors_workspace_kind
              ON org_connectors(workspace_id, kind, enabled);

            CREATE TABLE IF NOT EXISTS org_ingest_runs (
              run_id TEXT PRIMARY KEY,
              connector_id TEXT NOT NULL REFERENCES org_connectors(connector_id),
              workspace_id TEXT NOT NULL,
              since TEXT,
              items_seen INTEGER NOT NULL DEFAULT 0,
              items_quarantined INTEGER NOT NULL DEFAULT 0,
              items_rejected INTEGER NOT NULL DEFAULT 0,
              redactions INTEGER NOT NULL DEFAULT 0,
              remote_used INTEGER NOT NULL DEFAULT 0,
              audit_hash TEXT,
              started_at TEXT NOT NULL,
              finished_at TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_org_ingest_runs_connector_started
              ON org_ingest_runs(connector_id, started_at);
            """
        )

    def _ensure_decision_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS decisions (
              decision_id TEXT PRIMARY KEY,
              workspace_id TEXT NOT NULL,
              repo_id TEXT,
              question TEXT NOT NULL,
              status TEXT NOT NULL DEFAULT 'open',
              snapshot_id TEXT,
              briefing_json TEXT NOT NULL DEFAULT '{}',
              human_decision_json TEXT,
              audit_hash TEXT,
              prev_audit_hash TEXT,
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_decisions_repo
              ON decisions(repo_id, status);

            CREATE INDEX IF NOT EXISTS idx_decisions_workspace_status
              ON decisions(workspace_id, status, updated_at);
            """
        )

    def _seed_memory_decay_policies(self) -> None:
        policies = [
            ("runtime_signal", 30, 14, 0),
            ("gotcha", 180, 90, 0),
            ("business_rule", None, None, 1),
            ("architectural_decision", None, None, 1),
            ("convention", 365, 180, 0),
            ("outcome", None, None, 0),
            ("pattern", None, None, 1),
        ]
        self.conn.executemany(
            """
            INSERT OR IGNORE INTO memory_decay_policies(
              type, default_ttl_days, stale_after_days, requires_manual_expiry
            )
            VALUES (?, ?, ?, ?)
            """,
            policies,
        )

    def _ensure_fluid_memory_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE INDEX IF NOT EXISTS idx_snapshots_repo_created
              ON snapshots(repo_id, created_at DESC, snapshot_id);
            CREATE INDEX IF NOT EXISTS idx_context_packs_snapshot_created
              ON context_packs(snapshot_id, created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_context_packs_reconstructible_created
              ON context_packs(reconstructible, created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_memory_evidence_repo_path_record
              ON memory_evidence(repo_id, path, record_id);
            CREATE INDEX IF NOT EXISTS idx_agent_session_events_time
              ON agent_session_events(event_time DESC, event_id DESC);
            """
        )

    def upsert_repo(
        self, repo_id: str, root_path: Path, remote_url: str | None = None
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO repos(repo_id, root_path, remote_url, created_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(repo_id) DO UPDATE SET
                  root_path=excluded.root_path,
                  remote_url=COALESCE(excluded.remote_url, repos.remote_url)
                """,
                (repo_id, str(root_path), remote_url, utc_now()),
            )

    def open_snapshot(
        self,
        *,
        snapshot_id: str,
        repo_id: str,
        base_commit_sha: str,
        tree_digest: str,
        dirty_digest: str,
        worktree_state: str,
        branch_hint: str | None,
        parent_snapshot: str | None,
        indexer_version: str,
        parser_bundle_version: str,
        chunker_version: str,
        embed_model: str,
    ) -> str:
        parent = parent_snapshot
        if parent is None:
            latest = self.latest_snapshot(repo_id=repo_id, branch_hint=branch_hint)
            if latest is not None and latest["snapshot_id"] != snapshot_id:
                parent = latest["snapshot_id"]
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO snapshots(
                  snapshot_id, repo_id, base_commit_sha, tree_digest, dirty_digest,
                  worktree_state, branch_hint, parent_snapshot, indexer_version,
                  parser_bundle_version, chunker_version, embed_model, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    snapshot_id,
                    repo_id,
                    base_commit_sha,
                    tree_digest,
                    dirty_digest,
                    worktree_state,
                    branch_hint,
                    parent,
                    indexer_version,
                    parser_bundle_version,
                    chunker_version,
                    embed_model,
                    utc_now(),
                ),
            )
        return snapshot_id

    def snapshot_exists(self, snapshot_id: str) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM snapshots WHERE snapshot_id = ?", (snapshot_id,)
        ).fetchone()
        return row is not None

    def snapshot_row(self, snapshot_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM snapshots WHERE snapshot_id = ?", (snapshot_id,)
        ).fetchone()

    def latest_snapshot(
        self, *, repo_id: str, branch_hint: str | None = None
    ) -> sqlite3.Row | None:
        params: list[Any] = [repo_id]
        branch_clause = ""
        if branch_hint:
            branch_clause = "AND branch_hint = ?"
            params.append(branch_hint)
        return self.conn.execute(
            f"""
            SELECT * FROM snapshots
            WHERE repo_id = ? {branch_clause}
            ORDER BY created_at DESC, snapshot_id DESC
            LIMIT 1
            """,
            params,
        ).fetchone()

    def snapshot_lineage(self, snapshot_id: str, limit: int = 50) -> list[sqlite3.Row]:
        rows: list[sqlite3.Row] = []
        current = snapshot_id
        seen: set[str] = set()
        while current and current not in seen and len(rows) < max(1, limit):
            seen.add(current)
            row = self.snapshot_row(current)
            if row is None:
                break
            rows.append(row)
            current = row["parent_snapshot"]
        return rows

    def put_file_version(
        self,
        *,
        snapshot_id: str,
        repo_id: str,
        path: str,
        file_version_id: str,
        lang: str | None,
        loc: int,
        skeleton: str,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO file_versions(file_version_id, repo_id, lang, loc, skeleton)
                VALUES (?, ?, ?, ?, ?)
                """,
                (file_version_id, repo_id, lang, loc, skeleton),
            )
            self.conn.execute(
                """
                INSERT OR REPLACE INTO snapshot_files(snapshot_id, path, file_version_id)
                VALUES (?, ?, ?)
                """,
                (snapshot_id, path, file_version_id),
            )

    def resolve_identity(
        self, *, repo_id: str, path: str, kind: str, qualname: str, is_test: bool
    ) -> str:
        symbol_identity_id = stable_id(repo_id, path, kind, qualname)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO symbol_identities(
                  symbol_identity_id, repo_id, path, kind, qualname, is_test
                )
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(symbol_identity_id) DO UPDATE SET is_test=excluded.is_test
                """,
                (symbol_identity_id, repo_id, path, kind, qualname, int(is_test)),
            )
        return symbol_identity_id

    def put_occurrence(
        self,
        *,
        symbol_identity_id: str,
        file_version_id: str,
        start_line: int | None,
        end_line: int | None,
        signature: str,
        docstring: str | None,
    ) -> str:
        symbol_occurrence_id = stable_id(
            symbol_identity_id, file_version_id, start_line, end_line
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO symbol_occurrences(
                  symbol_occurrence_id, symbol_identity_id, file_version_id,
                  start_line, end_line, signature, docstring
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    symbol_occurrence_id,
                    symbol_identity_id,
                    file_version_id,
                    start_line,
                    end_line,
                    signature,
                    docstring,
                ),
            )
        return symbol_occurrence_id

    def put_edge(
        self,
        *,
        scope_snapshot_id: str | None,
        src_repo_id: str,
        src_node_type: str,
        src_node_id: str,
        dst_repo_id: str,
        dst_node_type: str,
        dst_node_id: str,
        kind: str,
        confidence: float,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        metadata = metadata or {}
        edge_id = stable_id(
            scope_snapshot_id or "",
            src_repo_id,
            src_node_type,
            src_node_id,
            dst_repo_id,
            dst_node_type,
            dst_node_id,
            kind,
        )
        with self.conn:
            existing = self.conn.execute(
                "SELECT confidence, metadata_json FROM edges WHERE edge_id = ?",
                (edge_id,),
            ).fetchone()
            if existing:
                confidence = max(float(existing["confidence"]), float(confidence))
                metadata = _merge_metadata(
                    json.loads(existing["metadata_json"] or "{}"), metadata
                )
            self.conn.execute(
                """
                INSERT INTO edges(
                  edge_id, scope_snapshot_id, src_repo_id, src_node_type, src_node_id,
                  dst_repo_id, dst_node_type, dst_node_id, kind, confidence, metadata_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(edge_id) DO UPDATE SET
                  confidence=excluded.confidence,
                  metadata_json=excluded.metadata_json
                """,
                (
                    edge_id,
                    scope_snapshot_id,
                    src_repo_id,
                    src_node_type,
                    src_node_id,
                    dst_repo_id,
                    dst_node_type,
                    dst_node_id,
                    kind,
                    confidence,
                    canonical_json(metadata),
                ),
            )
        return edge_id

    def deduplicate_edges(self) -> dict[str, Any]:
        summary = self.conn.execute(
            """
            SELECT
              COUNT(*) AS edge_count,
              (
                SELECT COALESCE(SUM(cnt - 1), 0)
                FROM (
                  SELECT COUNT(*) AS cnt
                  FROM edges
                  GROUP BY
                    scope_snapshot_id, src_repo_id, src_node_type, src_node_id,
                    dst_repo_id, dst_node_type, dst_node_id, kind
                  HAVING COUNT(*) > 1
                )
              ) AS duplicate_count,
              SUM(
                CASE
                  WHEN edge_id != ctxlayer_stable_id8(
                    scope_snapshot_id, src_repo_id, src_node_type, src_node_id,
                    dst_repo_id, dst_node_type, dst_node_id, kind
                  )
                  THEN 1 ELSE 0
                END
              ) AS rewrite_count
            FROM edges
            """
        ).fetchone()
        edge_count = int(summary["edge_count"] or 0) if summary else 0
        duplicate_count = int(summary["duplicate_count"] or 0) if summary else 0
        rewrite_count = int(summary["rewrite_count"] or 0) if summary else 0
        if duplicate_count == 0 and rewrite_count == 0:
            return {"ok": True, "edges": edge_count, "duplicates_removed": 0}

        cursor = self.conn.execute(
            """
            SELECT * FROM edges
            ORDER BY
              scope_snapshot_id, src_repo_id, src_node_type, src_node_id,
              dst_repo_id, dst_node_type, dst_node_id, kind, edge_id
            """
        )
        grouped: dict[tuple[Any, ...], dict[str, Any]] = {}
        rewrite_needed = False
        while True:
            rows = cursor.fetchmany(10_000)
            if not rows:
                break
            for row in rows:
                key = _edge_logical_key(row)
                canonical_edge_id = stable_id(*[part or "" for part in key])
                if row["edge_id"] != canonical_edge_id:
                    rewrite_needed = True
                current = grouped.get(key)
                metadata = json.loads(row["metadata_json"] or "{}")
                if current is None:
                    grouped[key] = {
                        "edge_id": canonical_edge_id,
                        "scope_snapshot_id": row["scope_snapshot_id"],
                        "src_repo_id": row["src_repo_id"],
                        "src_node_type": row["src_node_type"],
                        "src_node_id": row["src_node_id"],
                        "dst_repo_id": row["dst_repo_id"],
                        "dst_node_type": row["dst_node_type"],
                        "dst_node_id": row["dst_node_id"],
                        "kind": row["kind"],
                        "confidence": float(row["confidence"]),
                        "metadata": metadata,
                        "count": 1,
                    }
                    continue
                current["confidence"] = max(
                    float(current["confidence"]), float(row["confidence"])
                )
                current["metadata"] = _merge_metadata(current["metadata"], metadata)
                current["count"] += 1

        duplicates = sum(item["count"] - 1 for item in grouped.values())
        if duplicates or rewrite_needed:
            with self.conn:
                self.conn.execute("DELETE FROM edges")
                self.conn.executemany(
                    """
                    INSERT INTO edges(
                      edge_id, scope_snapshot_id, src_repo_id, src_node_type, src_node_id,
                      dst_repo_id, dst_node_type, dst_node_id, kind, confidence, metadata_json
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    [
                        (
                            item["edge_id"],
                            item["scope_snapshot_id"],
                            item["src_repo_id"],
                            item["src_node_type"],
                            item["src_node_id"],
                            item["dst_repo_id"],
                            item["dst_node_type"],
                            item["dst_node_id"],
                            item["kind"],
                            item["confidence"],
                            canonical_json(
                                _merge_metadata(
                                    item["metadata"],
                                    {"deduped_edge_count": item["count"]},
                                )
                                if item["count"] > 1
                                else item["metadata"]
                            ),
                        )
                        for item in grouped.values()
                    ],
                )
        return {"ok": True, "edges": len(grouped), "duplicates_removed": duplicates}

    def clear_snapshot_derived(self, snapshot_id: str) -> None:
        with self.conn:
            self.conn.execute(
                "DELETE FROM chunks_fts WHERE chunk_id IN (SELECT chunk_id FROM chunks WHERE snapshot_id = ?)",
                (snapshot_id,),
            )
            self.conn.execute(
                "DELETE FROM chunks WHERE snapshot_id = ?", (snapshot_id,)
            )
            self.conn.execute(
                "DELETE FROM edges WHERE scope_snapshot_id = ?", (snapshot_id,)
            )

    def put_chunk(
        self,
        *,
        chunk_id: str,
        snapshot_id: str,
        repo_id: str,
        path: str,
        symbol_identity_id: str | None,
        category: str,
        start_line: int | None,
        end_line: int | None,
        text: str,
        text_normalized: str,
        token_count: int,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO chunks(
                  chunk_id, snapshot_id, repo_id, path, symbol_identity_id,
                  category, start_line, end_line, text, token_count
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    chunk_id,
                    snapshot_id,
                    repo_id,
                    path,
                    symbol_identity_id,
                    category,
                    start_line,
                    end_line,
                    text,
                    token_count,
                ),
            )
            self.conn.execute(
                "INSERT OR REPLACE INTO chunks_fts(chunk_id, text_normalized) VALUES (?, ?)",
                (chunk_id, text_normalized),
            )

    def put_chunk_vector(
        self,
        *,
        chunk_id: str,
        dims: int,
        vector: list[float],
        model: str,
        encoding: str = "f32",
    ) -> None:
        vector_blob, stored_encoding, scale = _pack_vector(vector, encoding)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO chunk_vectors(
                  chunk_id, dims, vector_json, model, vector_blob, encoding, scale
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    chunk_id,
                    dims,
                    canonical_json(vector),
                    model,
                    vector_blob,
                    stored_encoding,
                    scale,
                ),
            )
            if self.sqlite_vec_loaded:
                self._ensure_vec_table(dims)
                row = self.conn.execute(
                    "SELECT vec_rowid FROM chunk_vector_rows WHERE chunk_id = ?",
                    (chunk_id,),
                ).fetchone()
                if row:
                    vec_rowid = int(row["vec_rowid"])
                    self.conn.execute(
                        f"DELETE FROM {self._vec_table(dims)} WHERE rowid = ?",
                        (vec_rowid,),
                    )
                    self.conn.execute(
                        """
                        UPDATE chunk_vector_rows
                        SET dims = ?, model = ?
                        WHERE chunk_id = ?
                        """,
                        (dims, model, chunk_id),
                    )
                else:
                    cur = self.conn.execute(
                        """
                        INSERT INTO chunk_vector_rows(chunk_id, dims, model)
                        VALUES (?, ?, ?)
                        """,
                        (chunk_id, dims, model),
                    )
                    vec_rowid = int(cur.lastrowid)
                self.conn.execute(
                    f"INSERT INTO {self._vec_table(dims)}(rowid, embedding) VALUES (?, ?)",
                    (vec_rowid, canonical_json(vector)),
                )

    def _vec_table(self, dims: int) -> str:
        return f"vec_chunks_{int(dims)}"

    def _ensure_vec_table(self, dims: int) -> None:
        if not self.sqlite_vec_loaded:
            return
        self.conn.execute(
            f"CREATE VIRTUAL TABLE IF NOT EXISTS {self._vec_table(dims)} USING vec0(embedding float[{int(dims)}])"
        )

    def chunk_vectors(
        self, snapshot_id: str, model: str | None = None, limit: int | None = None
    ) -> list[sqlite3.Row]:
        params: list[Any] = [snapshot_id]
        where_model = ""
        if model:
            where_model = " AND v.model = ?"
            params.append(model)
        limit_sql = ""
        if limit is not None:
            limit_sql = " LIMIT ?"
            params.append(max(1, int(limit)))
        rows = self.conn.execute(
            f"""
            SELECT c.*, v.vector_json, v.vector_blob, v.encoding, v.scale, v.dims, v.model
            FROM chunks c
            JOIN chunk_vectors v ON v.chunk_id = c.chunk_id
            WHERE c.snapshot_id = ? {where_model}
            ORDER BY c.path, c.start_line
            {limit_sql}
            """,
            params,
        ).fetchall()
        if rows or self._snapshot_has_hot_chunks(snapshot_id):
            return rows
        return self._cold_chunk_vectors(snapshot_id, model=model, limit=limit)

    def search_vector_chunks(
        self,
        *,
        snapshot_id: str,
        model: str,
        dims: int,
        vector: list[float],
        limit: int,
    ) -> list[dict[str, Any]]:
        if not self.sqlite_vec_loaded:
            return []
        self._ensure_vec_table(dims)
        rows = self.conn.execute(
            f"""
            SELECT c.*, v.distance AS distance
            FROM {self._vec_table(dims)} v
            JOIN chunk_vector_rows r ON r.vec_rowid = v.rowid
            JOIN chunks c ON c.chunk_id = r.chunk_id
            WHERE v.embedding MATCH ?
              AND k = ?
              AND c.snapshot_id = ?
              AND r.model = ?
            ORDER BY v.distance
            """,
            (canonical_json(vector), limit, snapshot_id, model),
        ).fetchall()
        results: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            item["_vector_score"] = 1.0 / (1.0 + float(row["distance"]))
            results.append(item)
        return results

    def search_chunks(
        self, snapshot_id: str, query: str, limit: int = 50
    ) -> list[sqlite3.Row]:
        terms = [term for term in query.replace('"', " ").split() if len(term) > 1]
        if not terms:
            return []
        fts_query = " OR ".join(f'"{term}"' for term in terms[:8])
        try:
            rows = self.conn.execute(
                """
                SELECT c.*, bm25(chunks_fts) AS rank
                FROM chunks_fts
                JOIN chunks c ON c.chunk_id = chunks_fts.chunk_id
                WHERE c.snapshot_id = ? AND chunks_fts MATCH ?
                ORDER BY rank
                LIMIT ?
                """,
                (snapshot_id, fts_query, limit),
            ).fetchall()
        except sqlite3.OperationalError:
            rows = []
        if rows:
            return rows
        if not self._snapshot_has_hot_chunks(snapshot_id):
            return self._search_cold_chunks(snapshot_id, query, limit=limit)
        like = "%" + "%".join(terms[:4]) + "%"
        return self.conn.execute(
            """
            SELECT c.*, 100.0 AS rank
            FROM chunks_fts
            JOIN chunks c ON c.chunk_id = chunks_fts.chunk_id
            WHERE c.snapshot_id = ? AND chunks_fts.text_normalized LIKE ?
            ORDER BY token_count ASC
            LIMIT ?
            """,
            (snapshot_id, like, limit),
        ).fetchall()

    def chunks_by_paths(
        self, snapshot_id: str, paths: Iterable[str], limit_per_path: int = 3
    ) -> list[sqlite3.Row]:
        rows: list[sqlite3.Row] = []
        for path in sorted(set(paths)):
            rows.extend(
                self.conn.execute(
                    """
                    SELECT * FROM chunks
                    WHERE snapshot_id = ? AND path = ?
                    ORDER BY token_count ASC, start_line
                    LIMIT ?
                    """,
                    (snapshot_id, path, limit_per_path),
                ).fetchall()
            )
        if not rows and not self._snapshot_has_hot_chunks(snapshot_id):
            return self._cold_chunks_by_paths(
                snapshot_id, paths, limit_per_path=limit_per_path
            )
        return rows

    def fallback_chunks(self, snapshot_id: str, limit: int = 25) -> list[sqlite3.Row]:
        rows = self.conn.execute(
            """
            SELECT * FROM chunks
            WHERE snapshot_id = ?
            ORDER BY token_count ASC, path
            LIMIT ?
            """,
            (snapshot_id, limit),
        ).fetchall()
        if rows or self._snapshot_has_hot_chunks(snapshot_id):
            return rows
        return self._cold_fallback_chunks(snapshot_id, limit=limit)

    def cold_archive_stats(self) -> dict[str, Any]:
        path = self.cold_archive_path
        if not path.exists():
            return {
                "enabled": False,
                "archive_db_path": str(path),
                "snapshots": 0,
                "chunks": 0,
                "edges": 0,
            }
        conn = self._open_cold_archive()
        if conn is None:
            return {
                "enabled": False,
                "archive_db_path": str(path),
                "snapshots": 0,
                "chunks": 0,
                "edges": 0,
            }
        try:
            if not self._cold_archive_has_queryable_chunks(conn):
                snapshots = int(
                    conn.execute("SELECT COUNT(*) FROM cold_snapshots").fetchone()[0]
                )
                return {
                    "enabled": True,
                    "archive_db_path": str(path),
                    "snapshots": snapshots,
                    "chunks": 0,
                    "edges": 0,
                    "queryable": False,
                }
            return {
                "enabled": True,
                "archive_db_path": str(path),
                "queryable": True,
                "snapshots": int(
                    conn.execute("SELECT COUNT(*) FROM cold_snapshots").fetchone()[0]
                ),
                "chunks": int(
                    conn.execute("SELECT COUNT(*) FROM cold_chunks").fetchone()[0]
                ),
                "edges": int(
                    conn.execute("SELECT COUNT(*) FROM cold_edges").fetchone()[0]
                ),
            }
        finally:
            conn.close()

    def _snapshot_has_hot_chunks(self, snapshot_id: str) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM chunks WHERE snapshot_id = ? LIMIT 1",
            (snapshot_id,),
        ).fetchone()
        return row is not None

    def _open_cold_archive(self) -> sqlite3.Connection | None:
        path = self.cold_archive_path
        if not path.exists():
            return None
        self._ensure_cold_archive_queryable()
        uri = f"{path.resolve().as_uri()}?mode=ro"
        conn = sqlite3.connect(uri, uri=True, timeout=5.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA query_only=ON")
        conn.execute("PRAGMA busy_timeout=5000")
        return conn

    def _search_cold_chunks(
        self, snapshot_id: str, query: str, *, limit: int
    ) -> list[sqlite3.Row]:
        terms = [term for term in query.replace('"', " ").split() if len(term) > 1]
        if not terms:
            return []
        conn = self._open_cold_archive()
        if conn is None:
            return []
        try:
            if not self._cold_archive_has_queryable_chunks(conn):
                return []
            fts_query = " OR ".join(f'"{term}"' for term in terms[:8])
            try:
                rows = conn.execute(
                    """
                    SELECT c.*, bm25(cold_chunks_fts) AS rank
                    FROM cold_chunks_fts
                    JOIN cold_chunks c ON c.chunk_id = cold_chunks_fts.chunk_id
                    WHERE c.snapshot_id = ? AND cold_chunks_fts MATCH ?
                    ORDER BY rank
                    LIMIT ?
                    """,
                    (snapshot_id, fts_query, limit),
                ).fetchall()
            except sqlite3.OperationalError:
                rows = []
            if rows:
                return rows
            like = "%" + "%".join(terms[:4]) + "%"
            return conn.execute(
                """
                SELECT c.*, 100.0 AS rank
                FROM cold_chunks c
                WHERE c.snapshot_id = ? AND c.text_normalized LIKE ?
                ORDER BY token_count ASC
                LIMIT ?
                """,
                (snapshot_id, like, limit),
            ).fetchall()
        finally:
            conn.close()

    def _cold_chunks_by_paths(
        self, snapshot_id: str, paths: Iterable[str], *, limit_per_path: int
    ) -> list[sqlite3.Row]:
        conn = self._open_cold_archive()
        if conn is None:
            return []
        try:
            if not self._cold_archive_has_queryable_chunks(conn):
                return []
            rows: list[sqlite3.Row] = []
            for path in sorted(set(paths)):
                rows.extend(
                    conn.execute(
                        """
                        SELECT * FROM cold_chunks
                        WHERE snapshot_id = ? AND path = ?
                        ORDER BY token_count ASC, start_line
                        LIMIT ?
                        """,
                        (snapshot_id, path, limit_per_path),
                    ).fetchall()
                )
            return rows
        finally:
            conn.close()

    def _cold_fallback_chunks(
        self, snapshot_id: str, *, limit: int
    ) -> list[sqlite3.Row]:
        conn = self._open_cold_archive()
        if conn is None:
            return []
        try:
            if not self._cold_archive_has_queryable_chunks(conn):
                return []
            return conn.execute(
                """
                SELECT * FROM cold_chunks
                WHERE snapshot_id = ?
                ORDER BY token_count ASC, path
                LIMIT ?
                """,
                (snapshot_id, limit),
            ).fetchall()
        finally:
            conn.close()

    def _cold_chunk_vectors(
        self, snapshot_id: str, *, model: str | None, limit: int | None
    ) -> list[sqlite3.Row]:
        conn = self._open_cold_archive()
        if conn is None:
            return []
        try:
            if not self._cold_archive_has_queryable_chunks(conn):
                return []
            params: list[Any] = [snapshot_id]
            where_model = ""
            if model:
                where_model = " AND v.model = ?"
                params.append(model)
            limit_sql = ""
            if limit is not None:
                limit_sql = " LIMIT ?"
                params.append(max(1, int(limit)))
            return conn.execute(
                f"""
                SELECT c.*, v.vector_json, v.vector_blob, v.encoding, v.scale,
                       v.dims, v.model
                FROM cold_chunks c
                JOIN cold_chunk_vectors v ON v.chunk_id = c.chunk_id
                WHERE c.snapshot_id = ? {where_model}
                ORDER BY c.path, c.start_line
                {limit_sql}
                """,
                params,
            ).fetchall()
        finally:
            conn.close()

    def _cold_archive_has_queryable_chunks(self, conn: sqlite3.Connection) -> bool:
        row = conn.execute(
            """
            SELECT 1
            FROM sqlite_master
            WHERE type IN ('table', 'virtual') AND name = 'cold_chunks'
            LIMIT 1
            """
        ).fetchone()
        return row is not None

    def _ensure_cold_archive_queryable(self) -> None:
        path = self.cold_archive_path
        if not path.exists():
            return
        archive = sqlite3.connect(str(path), timeout=10.0)
        archive.row_factory = sqlite3.Row
        try:
            self._ensure_cold_archive_schema(archive)
            snapshots = archive.execute(
                "SELECT snapshot_id, payload_json FROM cold_snapshots"
            ).fetchall()
            for snapshot in snapshots:
                snapshot_id = snapshot["snapshot_id"]
                existing = archive.execute(
                    "SELECT 1 FROM cold_chunks WHERE snapshot_id = ? LIMIT 1",
                    (snapshot_id,),
                ).fetchone()
                if existing:
                    continue
                try:
                    payload = json.loads(snapshot["payload_json"] or "{}")
                except json.JSONDecodeError:
                    continue
                if not isinstance(payload, dict):
                    continue
                chunks = [
                    item for item in payload.get("chunks", []) if isinstance(item, dict)
                ]
                files = [
                    item
                    for item in payload.get("snapshot_files", [])
                    if isinstance(item, dict)
                ]
                edges = [
                    item for item in payload.get("edges", []) if isinstance(item, dict)
                ]
                self._write_cold_snapshot_rows(
                    archive,
                    snapshot_id=snapshot_id,
                    files=files,
                    chunks=chunks,
                    vectors=[],
                    edges=edges,
                )
            archive.commit()
        finally:
            archive.close()

    def neighbors(
        self,
        *,
        repo_id: str,
        node_type: str,
        node_id: str,
        kinds: Iterable[str] | None = None,
        direction: str = "out",
    ) -> list[Neighbor]:
        kind_filter = tuple(kinds or ())
        params: list[Any] = [repo_id, node_type, node_id]
        where_kind = ""
        if kind_filter:
            where_kind = f" AND kind IN ({','.join('?' for _ in kind_filter)})"
            params.extend(kind_filter)
        if direction == "in":
            sql = f"""
                SELECT src_node_type AS node_type, src_node_id AS node_id, src_repo_id AS repo_id,
                       kind, confidence, metadata_json
                FROM edges
                WHERE dst_repo_id = ? AND dst_node_type = ? AND dst_node_id = ? {where_kind}
            """
        else:
            sql = f"""
                SELECT dst_node_type AS node_type, dst_node_id AS node_id, dst_repo_id AS repo_id,
                       kind, confidence, metadata_json
                FROM edges
                WHERE src_repo_id = ? AND src_node_type = ? AND src_node_id = ? {where_kind}
            """
        merged: dict[tuple[str, str, str, str], Neighbor] = {}
        for row in self.conn.execute(sql, params).fetchall():
            key = (row["repo_id"], row["node_type"], row["node_id"], row["kind"])
            metadata = json.loads(row["metadata_json"] or "{}")
            existing = merged.get(key)
            if existing is None:
                merged[key] = Neighbor(
                    node_type=row["node_type"],
                    node_id=row["node_id"],
                    repo_id=row["repo_id"],
                    kind=row["kind"],
                    confidence=float(row["confidence"]),
                    metadata=metadata,
                )
            else:
                merged[key] = Neighbor(
                    node_type=existing.node_type,
                    node_id=existing.node_id,
                    repo_id=existing.repo_id,
                    kind=existing.kind,
                    confidence=max(existing.confidence, float(row["confidence"])),
                    metadata=_merge_metadata(existing.metadata, metadata),
                )
        return [merged[key] for key in sorted(merged)]

    def logical_edges(
        self, where_sql: str = "", params: Iterable[Any] = ()
    ) -> list[dict[str, Any]]:
        sql = "SELECT * FROM edges"
        if where_sql:
            sql += f" WHERE {where_sql}"
        rows = self.conn.execute(sql, tuple(params)).fetchall()
        grouped: dict[tuple[Any, ...], dict[str, Any]] = {}
        for row in rows:
            key = _edge_logical_key(row)
            item = grouped.get(key)
            metadata = json.loads(row["metadata_json"] or "{}")
            if item is None:
                grouped[key] = {
                    "edge_id": row["edge_id"],
                    "scope_snapshot_id": row["scope_snapshot_id"],
                    "src_repo_id": row["src_repo_id"],
                    "src_node_type": row["src_node_type"],
                    "src_node_id": row["src_node_id"],
                    "dst_repo_id": row["dst_repo_id"],
                    "dst_node_type": row["dst_node_type"],
                    "dst_node_id": row["dst_node_id"],
                    "kind": row["kind"],
                    "confidence": float(row["confidence"]),
                    "metadata": metadata,
                    "metadata_json": canonical_json(metadata),
                    "deduped_edge_count": 1,
                }
            else:
                item["confidence"] = max(
                    float(item["confidence"]), float(row["confidence"])
                )
                item["metadata"] = _merge_metadata(item["metadata"], metadata)
                item["deduped_edge_count"] += 1
                item["metadata_json"] = canonical_json(item["metadata"])
        return sorted(
            grouped.values(),
            key=lambda item: (
                item["src_repo_id"],
                item["src_node_id"],
                item["dst_repo_id"],
                item["dst_node_id"],
                item["kind"],
            ),
        )

    def snapshot_files(self, snapshot_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT sf.path, sf.file_version_id, fv.lang, fv.loc, fv.skeleton
            FROM snapshot_files sf
            JOIN file_versions fv ON fv.file_version_id = sf.file_version_id
            WHERE sf.snapshot_id = ?
            ORDER BY sf.path
            """,
            (snapshot_id,),
        ).fetchall()

    def symbol_rows_for_snapshot(self, snapshot_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT si.*, so.start_line, so.end_line, so.signature, so.docstring, sf.path
            FROM snapshot_files sf
            JOIN symbol_occurrences so ON so.file_version_id = sf.file_version_id
            JOIN symbol_identities si ON si.symbol_identity_id = so.symbol_identity_id
            WHERE sf.snapshot_id = ?
            ORDER BY si.path, si.qualname
            """,
            (snapshot_id,),
        ).fetchall()

    def symbols_named(self, repo_id: str, names: Iterable[str]) -> list[sqlite3.Row]:
        names = sorted({name for name in names if name})
        if not names:
            return []
        rows: dict[str, sqlite3.Row] = {}
        for name in names:
            for row in self.conn.execute(
                """
                SELECT * FROM symbol_identities
                WHERE repo_id = ? AND (qualname = ? OR qualname LIKE ?)
                ORDER BY path, qualname
                """,
                (repo_id, name, f"%.{name}"),
            ).fetchall():
                rows[row["symbol_identity_id"]] = row
        return list(rows.values())

    def symbol_identity(self, symbol_identity_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM symbol_identities WHERE symbol_identity_id = ?",
            (symbol_identity_id,),
        ).fetchone()

    def put_test_command(self, *, repo_id: str, path_glob: str, command: str) -> str:
        command_id = stable_id(repo_id, path_glob, command)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO test_commands(command_id, repo_id, path_glob, command)
                VALUES (?, ?, ?, ?)
                """,
                (command_id, repo_id, path_glob, command),
            )
        return command_id

    def test_commands(self, repo_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM test_commands WHERE repo_id = ? ORDER BY path_glob, command",
            (repo_id,),
        ).fetchall()

    def replace_ownership(self, repo_id: str, rows: Iterable[dict[str, Any]]) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM ownership WHERE repo_id = ?", (repo_id,))
            for row in rows:
                owner_id = stable_id(
                    repo_id, row["path_glob"], row["owner"], row["source"]
                )
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO ownership(
                      owner_id, repo_id, path_glob, owner, source, confidence
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        owner_id,
                        repo_id,
                        row["path_glob"],
                        row["owner"],
                        row["source"],
                        float(row.get("confidence", 1.0)),
                    ),
                )

    def ownership(self, repo_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM ownership WHERE repo_id = ? ORDER BY path_glob, owner",
            (repo_id,),
        ).fetchall()

    def replace_history_signals(
        self,
        *,
        repo_id: str,
        churn_rows: Iterable[dict[str, Any]],
        cochange_rows: Iterable[dict[str, Any]],
    ) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM churn WHERE repo_id = ?", (repo_id,))
            self.conn.execute("DELETE FROM cochange WHERE repo_id = ?", (repo_id,))
            for row in churn_rows:
                churn_id = stable_id(repo_id, row["path"], row.get("author") or "")
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO churn(
                      churn_id, repo_id, path, author, commits, last_commit_sha, last_touched_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        churn_id,
                        repo_id,
                        row["path"],
                        row.get("author"),
                        int(row["commits"]),
                        row.get("last_commit_sha"),
                        row.get("last_touched_at"),
                    ),
                )
            for row in cochange_rows:
                a, b = sorted([row["path_a"], row["path_b"]])
                cochange_id = stable_id(repo_id, a, b)
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO cochange(
                      cochange_id, repo_id, path_a, path_b, commits_together,
                      commits_a, commits_b, jaccard
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        cochange_id,
                        repo_id,
                        a,
                        b,
                        int(row["commits_together"]),
                        int(row["commits_a"]),
                        int(row["commits_b"]),
                        float(row["jaccard"]),
                    ),
                )

    def cochanged_paths(
        self, repo_id: str, path: str, limit: int = 10
    ) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT CASE WHEN path_a = ? THEN path_b ELSE path_a END AS path,
                   commits_together, commits_a, commits_b, jaccard
            FROM cochange
            WHERE repo_id = ? AND (path_a = ? OR path_b = ?)
            ORDER BY jaccard DESC, commits_together DESC, path
            LIMIT ?
            """,
            (path, repo_id, path, path, limit),
        ).fetchall()

    def churn_for_path(self, repo_id: str, path: str) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT path, SUM(commits) AS commits, MAX(last_touched_at) AS last_touched_at
            FROM churn
            WHERE repo_id = ? AND path = ?
            GROUP BY path
            """,
            (repo_id, path),
        ).fetchone()

    def write_eval_run(
        self,
        *,
        eval_run_id: str,
        repo_id: str,
        mode: str,
        train_count: int,
        holdout_count: int,
        metrics: dict[str, Any],
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO eval_runs(
                  eval_run_id, repo_id, mode, train_count, holdout_count, metrics_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    eval_run_id,
                    repo_id,
                    mode,
                    train_count,
                    holdout_count,
                    canonical_json(metrics),
                    utc_now(),
                ),
            )

    def write_efficacy_scorecard(
        self,
        *,
        repo_id: str,
        report: dict[str, Any],
        eval_run_id: str | None = None,
        audit_hash: str | None = None,
    ) -> str:
        created_at = str(report.get("created_at") or utc_now())
        scorecard_id = stable_id(
            "efficacy_scorecard",
            repo_id,
            eval_run_id or "",
            canonical_json(report),
            created_at,
        )
        gate = _dict(report.get("gate"))
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO efficacy_scorecards(
                  scorecard_id, repo_id, eval_run_id, schema_version, gate_status,
                  report_json, audit_hash, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    scorecard_id,
                    repo_id,
                    eval_run_id,
                    str(report.get("schema_version") or ""),
                    str(gate.get("status") or "") or None,
                    canonical_json(report),
                    audit_hash,
                    created_at,
                ),
            )
        return scorecard_id

    def efficacy_scorecards(
        self,
        *,
        repo_id: str | None = None,
        limit: int = 20,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if repo_id:
            clauses.append("repo_id = ?")
            params.append(repo_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM efficacy_scorecards
            {where}
            ORDER BY created_at DESC, scorecard_id DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def write_agent_benchmark_run(
        self,
        *,
        repo_id: str,
        report: dict[str, Any],
    ) -> str:
        created_at = str(report.get("created_at") or utc_now())
        delta = _dict(report.get("delta"))
        lift_attribution = _dict(report.get("lift_attribution"))
        roadmap_pruning = _dict(report.get("roadmap_pruning"))
        components = _dict(lift_attribution.get("components"))
        memory = _dict(components.get("memory"))
        context_retrieval = _dict(components.get("context_retrieval"))
        gate = _dict(report.get("gate"))
        gate_ok = gate.get("ok")
        if isinstance(gate_ok, bool):
            gate_ok_value: int | None = int(gate_ok)
        else:
            gate_ok_value = None
        benchmark_run_id = stable_id(
            "agent_benchmark_run",
            repo_id,
            canonical_json(delta),
            canonical_json(lift_attribution),
            canonical_json(roadmap_pruning),
            created_at,
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO agent_benchmark_run(
                  benchmark_run_id, repo_id, cases, success_rate_delta,
                  tests_pass_rate_delta, wrong_files_touched_reduction,
                  missing_files_reduction, agent_seconds_reduction, memory_score,
                  context_retrieval_score, gate_ok, gate_status, delta_json,
                  lift_attribution_json, roadmap_pruning_json, report_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    benchmark_run_id,
                    repo_id,
                    int(report.get("cases") or 0),
                    _float_metric(delta, "success_rate_delta"),
                    _float_metric(delta, "tests_pass_rate_delta"),
                    _float_metric(delta, "wrong_files_touched_reduction"),
                    _float_metric(delta, "missing_files_reduction"),
                    _float_metric(delta, "agent_seconds_reduction"),
                    _float_metric(memory, "score"),
                    _float_metric(context_retrieval, "score"),
                    gate_ok_value,
                    str(gate.get("status") or "") or None,
                    canonical_json(delta),
                    canonical_json(lift_attribution),
                    canonical_json(roadmap_pruning),
                    canonical_json(report),
                    created_at,
                ),
            )
        return benchmark_run_id

    def agent_benchmark_runs(
        self,
        *,
        repo_id: str | None = None,
        limit: int = 20,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if repo_id:
            clauses.append("repo_id = ?")
            params.append(repo_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM agent_benchmark_run
            {where}
            ORDER BY created_at DESC, benchmark_run_id DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def put_dirty_blob(
        self, *, snapshot_id: str, path: str, content_hash: str, content: bytes
    ) -> str:
        blob_id = stable_id(snapshot_id, path, content_hash)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO dirty_blobs(blob_id, snapshot_id, path, content_hash, content)
                VALUES (?, ?, ?, ?, ?)
                """,
                (blob_id, snapshot_id, path, content_hash, content),
            )
        return blob_id

    def write_release_report(
        self, *, repo_id: str, version: str, report: dict[str, Any]
    ) -> str:
        report_id = stable_id(repo_id, version, canonical_json(report), utc_now())
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO release_reports(release_report_id, repo_id, version, report_json, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (report_id, repo_id, version, canonical_json(report), utc_now()),
            )
        return report_id

    def latest_release_report(self, repo_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT * FROM release_reports
            WHERE repo_id = ?
            ORDER BY created_at DESC
            LIMIT 1
            """,
            (repo_id,),
        ).fetchone()

    def write_ci_report(
        self, *, repo_id: str, status: str, report: dict[str, Any]
    ) -> str:
        report_id = stable_id(repo_id, status, canonical_json(report), utc_now())
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO ci_reports(ci_report_id, repo_id, status, report_json, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (report_id, repo_id, status, canonical_json(report), utc_now()),
            )
        return report_id

    def write_constitution(
        self,
        *,
        workspace_id: str,
        repo_id: str,
        manifest: dict[str, Any],
    ) -> str:
        constitution_hash = str(
            manifest.get("constitution_hash") or stable_id(canonical_json(manifest))
        )
        constitution_id = stable_id(workspace_id, repo_id, constitution_hash)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO constitutions(
                  constitution_id, workspace_id, repo_id, constitution_hash,
                  manifest_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    constitution_id,
                    workspace_id,
                    repo_id,
                    constitution_hash,
                    canonical_json(manifest),
                    utc_now(),
                ),
            )
        return constitution_id

    def latest_constitution(self, repo_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT * FROM constitutions
            WHERE repo_id = ?
            ORDER BY created_at DESC
            LIMIT 1
            """,
            (repo_id,),
        ).fetchone()

    def constitution_by_hash(self, constitution_hash: str) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT * FROM constitutions
            WHERE constitution_hash = ?
            ORDER BY created_at DESC
            LIMIT 1
            """,
            (constitution_hash,),
        ).fetchone()

    def add_workspace_repo(
        self, *, workspace_root: str, repo_id: str, name: str, root_path: str
    ) -> str:
        workspace_repo_id = stable_id(workspace_root, repo_id, root_path)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO workspace_repos(
                  workspace_repo_id, workspace_root, repo_id, name, root_path
                )
                VALUES (?, ?, ?, ?, ?)
                """,
                (workspace_repo_id, workspace_root, repo_id, name, root_path),
            )
        return workspace_repo_id

    def workspace_repos(self, workspace_root: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM workspace_repos WHERE workspace_root = ? ORDER BY name",
            (workspace_root,),
        ).fetchall()

    def replace_contracts(
        self, *, repo_id: str, contracts: Iterable[dict[str, Any]]
    ) -> None:
        with self.conn:
            self.conn.execute(
                "DELETE FROM crossrepo_contracts WHERE repo_id = ?", (repo_id,)
            )
            for contract in contracts:
                contract_id = stable_id(
                    repo_id,
                    contract["path"],
                    contract["kind"],
                    contract["name"],
                    canonical_json(contract.get("metadata", {})),
                )
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO crossrepo_contracts(
                      contract_id, repo_id, path, kind, name, metadata_json
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        contract_id,
                        repo_id,
                        contract["path"],
                        contract["kind"],
                        contract["name"],
                        canonical_json(contract.get("metadata", {})),
                    ),
                )

    def contracts(self, repo_id: str | None = None) -> list[sqlite3.Row]:
        if repo_id:
            return self.conn.execute(
                "SELECT * FROM crossrepo_contracts WHERE repo_id = ? ORDER BY kind, name",
                (repo_id,),
            ).fetchall()
        return self.conn.execute(
            "SELECT * FROM crossrepo_contracts ORDER BY repo_id, kind, name"
        ).fetchall()

    def write_audit_anchor(
        self, *, target: str, tip_hash: str, location: str | None
    ) -> str:
        anchor_id = stable_id(target, tip_hash, location or "", utc_now())
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO audit_anchors(anchor_id, target, tip_hash, location, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (anchor_id, target, tip_hash, location, utc_now()),
            )
        return anchor_id

    def upsert_business_rule(
        self,
        *,
        workspace_id: str,
        repo_id: str | None,
        scope_glob: str | None,
        rule_text: str,
        source_type: str,
        source_ref: str,
        confidence: float,
        status: str = "candidate",
    ) -> str:
        rule_id = stable_id(
            workspace_id, repo_id or "", scope_glob or "", rule_text, source_ref
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO business_rules(
                  rule_id, workspace_id, repo_id, scope_glob, rule_text, source_type,
                  source_ref, confidence, status, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(rule_id) DO UPDATE SET confidence=excluded.confidence
                """,
                (
                    rule_id,
                    workspace_id,
                    repo_id,
                    scope_glob,
                    rule_text,
                    source_type,
                    source_ref,
                    confidence,
                    status,
                    utc_now(),
                ),
            )
        return rule_id

    def upsert_business_rule_candidate(
        self,
        *,
        workspace_id: str,
        repo_id: str | None,
        rule_text: str,
        source_type: str,
        confidence: float,
        raw_score: float | None = None,
        calibrated_confidence: float | None = None,
        trust_tier: str | None = None,
        confidence_method: str | None = None,
        status: str = "candidate",
    ) -> str:
        candidate_id = stable_id(workspace_id, repo_id or "", rule_text, source_type)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO business_rule_candidates(
                  candidate_id, workspace_id, repo_id, rule_text, source_type,
                  confidence, raw_score, calibrated_confidence, trust_tier,
                  confidence_method, status, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(candidate_id) DO UPDATE SET
                  confidence=excluded.confidence,
                  raw_score=excluded.raw_score,
                  calibrated_confidence=excluded.calibrated_confidence,
                  trust_tier=excluded.trust_tier,
                  confidence_method=excluded.confidence_method,
                  status=CASE
                    WHEN business_rule_candidates.status = 'rejected' THEN 'rejected'
                    WHEN business_rule_candidates.status = 'promoted' THEN 'promoted'
                    ELSE excluded.status
                  END
                """,
                (
                    candidate_id,
                    workspace_id,
                    repo_id,
                    rule_text,
                    source_type,
                    confidence,
                    raw_score,
                    calibrated_confidence,
                    trust_tier,
                    confidence_method,
                    status,
                    utc_now(),
                ),
            )
        return candidate_id

    def put_business_rule_candidate_evidence(
        self,
        *,
        candidate_id: str,
        repo_id: str | None,
        path: str | None,
        symbol_identity_id: str | None,
        evidence_kind: str,
        evidence_hash: str,
        line_start: int | None = None,
        line_end: int | None = None,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO business_rule_candidate_evidence(
                  candidate_id, repo_id, path, symbol_identity_id, evidence_kind,
                  evidence_hash, line_start, line_end
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    candidate_id,
                    repo_id,
                    path,
                    symbol_identity_id,
                    evidence_kind,
                    evidence_hash,
                    line_start,
                    line_end,
                ),
            )

    def business_rule_candidates(self, status: str | None = None) -> list[sqlite3.Row]:
        if status == "all":
            return self.conn.execute(
                "SELECT * FROM business_rule_candidates ORDER BY status, confidence DESC, rule_text"
            ).fetchall()
        if status:
            return self.conn.execute(
                """
                SELECT * FROM business_rule_candidates
                WHERE status = ?
                ORDER BY confidence DESC, rule_text
                """,
                (status,),
            ).fetchall()
        return self.conn.execute(
            "SELECT * FROM business_rule_candidates ORDER BY status, confidence DESC, rule_text"
        ).fetchall()

    def business_rule_candidate(self, candidate_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM business_rule_candidates WHERE candidate_id = ?",
            (candidate_id,),
        ).fetchone()

    def candidate_evidence(self, candidate_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM business_rule_candidate_evidence
            WHERE candidate_id = ?
            ORDER BY path, line_start
            """,
            (candidate_id,),
        ).fetchall()

    def set_candidate_status(self, candidate_id: str, status: str) -> None:
        with self.conn:
            self.conn.execute(
                "UPDATE business_rule_candidates SET status = ? WHERE candidate_id = ?",
                (status, candidate_id),
            )

    def put_business_rule_evidence(
        self,
        *,
        rule_id: str,
        path: str | None,
        symbol_identity_id: str | None,
        quote_hash: str | None,
        evidence_type: str,
        repo_id: str | None = None,
        evidence_hash: str | None = None,
        line_start: int | None = None,
        line_end: int | None = None,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO business_rule_evidence(
                  rule_id, repo_id, path, symbol_identity_id, quote_hash, evidence_type,
                  evidence_kind, evidence_hash, line_start, line_end
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    rule_id,
                    repo_id,
                    path,
                    symbol_identity_id,
                    quote_hash,
                    evidence_type,
                    evidence_type,
                    evidence_hash or quote_hash or "",
                    line_start,
                    line_end,
                ),
            )

    def business_rules(self, status: str | None = None) -> list[sqlite3.Row]:
        if status:
            return self.conn.execute(
                "SELECT * FROM business_rules WHERE status = ? ORDER BY confidence DESC, rule_text",
                (status,),
            ).fetchall()
        return self.conn.execute(
            "SELECT * FROM business_rules ORDER BY status, confidence DESC, rule_text"
        ).fetchall()

    def set_business_rule_status(
        self,
        *,
        rule_id: str,
        status: str,
        approved_by: str | None = None,
        supersedes_rule_id: str | None = None,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                UPDATE business_rules
                SET status = ?, approved_by = ?, approved_at = ?,
                    supersedes_rule_id = COALESCE(?, supersedes_rule_id),
                    updated_at = ?
                WHERE rule_id = ?
                """,
                (
                    status,
                    approved_by,
                    utc_now() if status in {"approved", "active"} else None,
                    supersedes_rule_id,
                    utc_now(),
                    rule_id,
                ),
            )

    def record_business_rule_approval(
        self,
        *,
        rule_id: str,
        approver: str,
        source: str,
        decision: str,
        notes: str | None = None,
    ) -> str:
        approval_id = stable_id(
            rule_id, approver, source, decision, notes or "", utc_now()
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO business_rule_approvals(
                  approval_id, rule_id, approver, source, decision, notes, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (approval_id, rule_id, approver, source, decision, notes, utc_now()),
            )
        return approval_id

    def approval_counts_by_source(
        self, repo_id: str | None = None
    ) -> list[sqlite3.Row]:
        where = ""
        params: tuple[Any, ...] = ()
        if repo_id is not None:
            where = "WHERE COALESCE(br.repo_id, bc.repo_id) = ?"
            params = (repo_id,)
        return self.conn.execute(
            f"""
            SELECT
              COALESCE(br.source_type, bc.source_type, 'unknown') AS source_type,
              SUM(CASE WHEN a.decision = 'approve' THEN 1 ELSE 0 END) AS approvals,
              SUM(CASE WHEN a.decision IN ('reject', 'supersede') THEN 1 ELSE 0 END) AS rejections
            FROM business_rule_approvals a
            LEFT JOIN business_rules br ON br.rule_id = a.rule_id
            LEFT JOIN business_rule_candidates bc ON bc.candidate_id = a.rule_id
            {where}
            GROUP BY COALESCE(br.source_type, bc.source_type, 'unknown')
            """,
            params,
        ).fetchall()

    def write_trust_calibration(self, row: dict[str, Any]) -> str:
        computed_at = str(row.get("computed_at") or utc_now())
        calibration_id = row.get("calibration_id") or stable_id(
            "trust_calibration",
            row.get("repo_id") or "",
            row["source_type"],
            computed_at,
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO trust_calibration(
                  calibration_id, repo_id, source_type, default_tier, approvals,
                  rejections, approval_rate, sample_size, confidence_floor, method,
                  computed_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(repo_id, source_type) DO UPDATE SET
                  calibration_id=excluded.calibration_id,
                  default_tier=excluded.default_tier,
                  approvals=excluded.approvals,
                  rejections=excluded.rejections,
                  approval_rate=excluded.approval_rate,
                  sample_size=excluded.sample_size,
                  confidence_floor=excluded.confidence_floor,
                  method=excluded.method,
                  computed_at=excluded.computed_at
                """,
                (
                    calibration_id,
                    row.get("repo_id"),
                    row["source_type"],
                    row["default_tier"],
                    int(row.get("approvals", 0)),
                    int(row.get("rejections", 0)),
                    float(row.get("approval_rate", 0.0)),
                    int(row.get("sample_size", 0)),
                    float(row.get("confidence_floor", 0.0)),
                    row["method"],
                    computed_at,
                ),
            )
        return str(calibration_id)

    def trust_calibration_for(
        self, repo_id: str | None, source_type: str | None = None
    ) -> list[sqlite3.Row]:
        if source_type is not None:
            return self.conn.execute(
                """
                SELECT * FROM trust_calibration
                WHERE (repo_id = ? OR (repo_id IS NULL AND ? IS NULL))
                  AND source_type = ?
                ORDER BY computed_at DESC
                """,
                (repo_id, repo_id, source_type),
            ).fetchall()
        return self.conn.execute(
            """
            SELECT * FROM trust_calibration
            WHERE repo_id = ? OR (repo_id IS NULL AND ? IS NULL)
            ORDER BY source_type
            """,
            (repo_id, repo_id),
        ).fetchall()

    def write_extraction_eval_results(
        self, memory_eval_run_id: str, rows: list[dict[str, Any]]
    ) -> None:
        with self.conn:
            for row in rows:
                result_id = row.get("result_id") or stable_id(
                    "extraction_eval",
                    memory_eval_run_id,
                    row.get("repo_id") or "",
                    row["source_type"],
                    row["corpus_version"],
                )
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO extraction_eval_results(
                      result_id, memory_eval_run_id, repo_id, source_type,
                      corpus_version, true_positive, false_positive,
                      false_negative, precision, recall, f1, created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        result_id,
                        memory_eval_run_id,
                        row.get("repo_id"),
                        row["source_type"],
                        row["corpus_version"],
                        int(row.get("true_positive", 0)),
                        int(row.get("false_positive", 0)),
                        int(row.get("false_negative", 0)),
                        float(row.get("precision", 0.0)),
                        float(row.get("recall", 0.0)),
                        float(row.get("f1", 0.0)),
                        row.get("created_at") or utc_now(),
                    ),
                )

    def extraction_eval_results(
        self, *, repo_id: str | None = None, limit: int = 50
    ) -> list[sqlite3.Row]:
        if repo_id is not None:
            return self.conn.execute(
                """
                SELECT r.*, m.created_at AS run_created_at, m.metrics_json
                FROM extraction_eval_results r
                JOIN memory_eval_runs m ON m.memory_eval_run_id = r.memory_eval_run_id
                WHERE r.repo_id = ?
                ORDER BY m.created_at DESC, r.source_type
                LIMIT ?
                """,
                (repo_id, limit),
            ).fetchall()
        return self.conn.execute(
            """
            SELECT r.*, m.created_at AS run_created_at, m.metrics_json
            FROM extraction_eval_results r
            JOIN memory_eval_runs m ON m.memory_eval_run_id = r.memory_eval_run_id
            ORDER BY m.created_at DESC, r.source_type
            LIMIT ?
            """,
            (limit,),
        ).fetchall()

    def rule_evidence(self, rule_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM business_rule_evidence
            WHERE rule_id = ?
            ORDER BY path, line_start
            """,
            (rule_id,),
        ).fetchall()

    def add_runtime_event(
        self,
        *,
        source: str,
        repo_id: str | None,
        title: str,
        message: str,
        path: str | None,
        symbol_identity_id: str | None,
        severity: str,
        event_hash: str,
    ) -> str:
        event_id = stable_id(source, repo_id or "", title, message, event_hash)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO runtime_events(
                  runtime_event_id, source, repo_id, title, message, path,
                  symbol_identity_id, severity, event_hash, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    event_id,
                    source,
                    repo_id,
                    title,
                    message,
                    path,
                    symbol_identity_id,
                    severity,
                    event_hash,
                    utc_now(),
                ),
            )
        return event_id

    def runtime_events(self, repo_id: str | None = None) -> list[sqlite3.Row]:
        if repo_id:
            return self.conn.execute(
                "SELECT * FROM runtime_events WHERE repo_id = ? ORDER BY created_at DESC",
                (repo_id,),
            ).fetchall()
        return self.conn.execute(
            "SELECT * FROM runtime_events ORDER BY created_at DESC"
        ).fetchall()

    def replace_semantic_graph(
        self,
        *,
        repo_id: str,
        nodes: Iterable[dict[str, Any]],
        edges: Iterable[dict[str, Any]],
        evidence: Iterable[dict[str, Any]],
        file_index: Iterable[dict[str, Any]] | None = None,
    ) -> None:
        with self.conn:
            preserved_business_edges = self.conn.execute(
                f"""
                SELECT e.*
                FROM semantic_edges e
                JOIN semantic_nodes src ON src.node_id = e.src_node_id
                JOIN semantic_nodes dst ON dst.node_id = e.dst_node_id
                WHERE e.kind IN ({",".join("?" for _ in BUSINESS_EDGE_KINDS)})
                  AND (src.repo_id = ? OR dst.repo_id = ?)
                """,
                (*BUSINESS_EDGE_KINDS, repo_id, repo_id),
            ).fetchall()
            preserved_edge_ids = [row["edge_id"] for row in preserved_business_edges]
            preserved_business_evidence: list[sqlite3.Row] = []
            if preserved_edge_ids:
                placeholders = ",".join("?" for _ in preserved_edge_ids)
                preserved_business_evidence = self.conn.execute(
                    f"""
                    SELECT * FROM semantic_evidence
                    WHERE edge_id IN ({placeholders})
                    """,
                    preserved_edge_ids,
                ).fetchall()
            existing_node_ids = [
                row["node_id"]
                for row in self.conn.execute(
                    f"""
                    SELECT node_id FROM semantic_nodes
                    WHERE repo_id = ?
                      AND node_type NOT IN ({",".join("?" for _ in BUSINESS_NODE_TYPES)})
                    """,
                    (repo_id, *BUSINESS_NODE_TYPES),
                ).fetchall()
            ]
            if existing_node_ids:
                placeholders = ",".join("?" for _ in existing_node_ids)
                self.conn.execute(
                    f"DELETE FROM semantic_edges WHERE src_node_id IN ({placeholders}) "
                    f"OR dst_node_id IN ({placeholders})",
                    [*existing_node_ids, *existing_node_ids],
                )
                self.conn.execute(
                    f"DELETE FROM semantic_evidence WHERE node_id IN ({placeholders})",
                    existing_node_ids,
                )
            self.conn.execute(
                f"""
                DELETE FROM semantic_nodes
                WHERE repo_id = ?
                  AND node_type NOT IN ({",".join("?" for _ in BUSINESS_NODE_TYPES)})
                """,
                (repo_id, *BUSINESS_NODE_TYPES),
            )

            for node in nodes:
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO semantic_nodes(
                      node_id, repo_id, node_type, name, stable_key, confidence, source,
                      metadata_json, trust_tier, status, provenance_json, created_at, updated_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        node["node_id"],
                        node.get("repo_id"),
                        node["node_type"],
                        node["name"],
                        node["stable_key"],
                        float(node["confidence"]),
                        node["source"],
                        canonical_json(node.get("metadata", {})),
                        node.get("trust_tier"),
                        node.get("status"),
                        canonical_json(node.get("provenance", {})),
                        utc_now(),
                        utc_now(),
                    ),
                )

            for edge in edges:
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO semantic_edges(
                      edge_id, src_node_id, dst_node_id, kind, confidence,
                      evidence_json, metadata_json, created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        edge["edge_id"],
                        edge["src_node_id"],
                        edge["dst_node_id"],
                        edge["kind"],
                        float(edge["confidence"]),
                        canonical_json(edge.get("evidence", [])),
                        canonical_json(edge.get("metadata", {})),
                        utc_now(),
                    ),
                )

            for edge in preserved_business_edges:
                endpoints = self.conn.execute(
                    """
                    SELECT COUNT(*) AS count
                    FROM semantic_nodes
                    WHERE node_id IN (?, ?)
                    """,
                    (edge["src_node_id"], edge["dst_node_id"]),
                ).fetchone()
                if int(endpoints["count"] if endpoints else 0) != 2:
                    continue
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO semantic_edges(
                      edge_id, src_node_id, dst_node_id, kind, confidence,
                      evidence_json, metadata_json, created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        edge["edge_id"],
                        edge["src_node_id"],
                        edge["dst_node_id"],
                        edge["kind"],
                        float(edge["confidence"]),
                        edge["evidence_json"],
                        edge["metadata_json"],
                        edge["created_at"],
                    ),
                )
            for item in preserved_business_evidence:
                if not self.conn.execute(
                    "SELECT 1 FROM semantic_edges WHERE edge_id = ?",
                    (item["edge_id"],),
                ).fetchone():
                    continue
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO semantic_evidence(
                      evidence_id, node_id, edge_id, repo_id, path, symbol_identity_id,
                      line_start, line_end, evidence_kind, evidence_hash
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        item["evidence_id"],
                        item["node_id"],
                        item["edge_id"],
                        item["repo_id"],
                        item["path"],
                        item["symbol_identity_id"],
                        item["line_start"],
                        item["line_end"],
                        item["evidence_kind"],
                        item["evidence_hash"],
                    ),
                )

            for item in evidence:
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO semantic_evidence(
                      evidence_id, node_id, edge_id, repo_id, path, symbol_identity_id,
                      line_start, line_end, evidence_kind, evidence_hash
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        item["evidence_id"],
                        item.get("node_id"),
                        item.get("edge_id"),
                        item.get("repo_id"),
                        item.get("path"),
                        item.get("symbol_identity_id"),
                        item.get("line_start"),
                        item.get("line_end"),
                        item["evidence_kind"],
                        item["evidence_hash"],
                    ),
                )
            if file_index is not None:
                self.conn.execute(
                    "DELETE FROM semantic_file_index WHERE repo_id = ?", (repo_id,)
                )
                for item in file_index:
                    self.conn.execute(
                        """
                        INSERT OR REPLACE INTO semantic_file_index(
                          repo_id, path, file_version_id, parser_backend, indexed_at
                        )
                        VALUES (?, ?, ?, ?, ?)
                        """,
                        (
                            repo_id,
                            item["path"],
                            item["file_version_id"],
                            item["parser_backend"],
                            utc_now(),
                        ),
                    )

    def semantic_nodes(
        self, repo_id: str | None = None, *, include_inactive: bool = False
    ) -> list[sqlite3.Row]:
        active_clause = (
            "" if include_inactive else "AND (status IS NULL OR status = 'active')"
        )
        if repo_id:
            return self.conn.execute(
                f"""
                SELECT * FROM semantic_nodes
                WHERE repo_id = ?
                  {active_clause}
                ORDER BY node_type, name
                """,
                (repo_id,),
            ).fetchall()
        return self.conn.execute(
            f"""
            SELECT * FROM semantic_nodes
            WHERE 1 = 1 {active_clause}
            ORDER BY repo_id, node_type, name
            """
        ).fetchall()

    def semantic_node(self, node_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM semantic_nodes WHERE node_id = ?", (node_id,)
        ).fetchone()

    def semantic_search(
        self, repo_id: str, query: str, limit: int = 20
    ) -> list[sqlite3.Row]:
        terms = [term.lower() for term in query.split() if len(term) > 1]
        if not terms:
            return []
        like = "%" + "%".join(terms[:5]) + "%"
        return self.conn.execute(
            """
            SELECT * FROM semantic_nodes
            WHERE repo_id = ?
              AND (status IS NULL OR status = 'active')
              AND (
                lower(name) LIKE ?
                OR lower(node_type) LIKE ?
                OR lower(metadata_json) LIKE ?
              )
            ORDER BY confidence DESC, node_type, name
            LIMIT ?
            """,
            (repo_id, like, like, like, limit),
        ).fetchall()

    def semantic_edges_for_node(
        self, node_id: str, *, include_inactive: bool = False
    ) -> list[sqlite3.Row]:
        active_clause = (
            ""
            if include_inactive
            else "AND (src.status IS NULL OR src.status = 'active') "
            "AND (dst.status IS NULL OR dst.status = 'active')"
        )
        return self.conn.execute(
            f"""
            SELECT e.*, src.node_type AS src_type, src.name AS src_name,
                   dst.node_type AS dst_type, dst.name AS dst_name,
                   src.trust_tier AS src_trust_tier, dst.trust_tier AS dst_trust_tier,
                   src.status AS src_status, dst.status AS dst_status
            FROM semantic_edges e
            JOIN semantic_nodes src ON src.node_id = e.src_node_id
            JOIN semantic_nodes dst ON dst.node_id = e.dst_node_id
            WHERE (e.src_node_id = ? OR e.dst_node_id = ?)
              {active_clause}
            ORDER BY e.kind, src.name, dst.name
            """,
            (node_id, node_id),
        ).fetchall()

    def semantic_edges(
        self, repo_id: str | None = None, *, include_inactive: bool = False
    ) -> list[sqlite3.Row]:
        repo_join = """
        JOIN semantic_nodes src ON src.node_id = e.src_node_id
        JOIN semantic_nodes dst ON dst.node_id = e.dst_node_id
        """
        params: list[Any] = []
        where = ""
        if repo_id:
            where = "WHERE (src.repo_id = ? OR dst.repo_id = ?)"
            params.extend([repo_id, repo_id])
        active = (
            ""
            if include_inactive
            else "(src.status IS NULL OR src.status = 'active') "
            "AND (dst.status IS NULL OR dst.status = 'active')"
        )
        if active:
            where = f"{where} AND {active}" if where else f"WHERE {active}"
        return self.conn.execute(
            f"""
            SELECT e.*, src.node_type AS src_type, src.name AS src_name,
                   dst.node_type AS dst_type, dst.name AS dst_name,
                   src.trust_tier AS src_trust_tier, dst.trust_tier AS dst_trust_tier,
                   src.status AS src_status, dst.status AS dst_status
            FROM semantic_edges e
            {repo_join}
            {where}
            ORDER BY e.kind, src.name, dst.name
            """,
            params,
        ).fetchall()

    def delete_semantic_node(self, node_id: str) -> bool:
        with self.conn:
            cur = self.conn.execute(
                "DELETE FROM semantic_nodes WHERE node_id = ?", (node_id,)
            )
        return cur.rowcount > 0

    def update_semantic_node_metadata(
        self,
        node_id: str,
        metadata: dict[str, Any],
        *,
        confidence: float | None = None,
    ) -> None:
        with self.conn:
            if confidence is None:
                self.conn.execute(
                    """
                    UPDATE semantic_nodes
                    SET metadata_json = ?, updated_at = ?
                    WHERE node_id = ?
                    """,
                    (canonical_json(metadata), utc_now(), node_id),
                )
            else:
                self.conn.execute(
                    """
                    UPDATE semantic_nodes
                    SET metadata_json = ?, confidence = ?, updated_at = ?
                    WHERE node_id = ?
                    """,
                    (canonical_json(metadata), float(confidence), utc_now(), node_id),
                )

    def update_semantic_edge_metadata(
        self,
        edge_id: str,
        metadata: dict[str, Any],
        *,
        confidence: float | None = None,
    ) -> None:
        with self.conn:
            if confidence is None:
                self.conn.execute(
                    "UPDATE semantic_edges SET metadata_json = ? WHERE edge_id = ?",
                    (canonical_json(metadata), edge_id),
                )
            else:
                self.conn.execute(
                    "UPDATE semantic_edges SET metadata_json = ?, confidence = ? WHERE edge_id = ?",
                    (canonical_json(metadata), float(confidence), edge_id),
                )

    def semantic_evidence(
        self, *, node_id: str | None = None, edge_id: str | None = None
    ) -> list[sqlite3.Row]:
        if node_id:
            return self.conn.execute(
                """
                SELECT * FROM semantic_evidence
                WHERE node_id = ?
                ORDER BY path, line_start, evidence_kind
                """,
                (node_id,),
            ).fetchall()
        if edge_id:
            return self.conn.execute(
                """
                SELECT * FROM semantic_evidence
                WHERE edge_id = ?
                ORDER BY path, line_start, evidence_kind
                """,
                (edge_id,),
            ).fetchall()
        return self.conn.execute(
            "SELECT * FROM semantic_evidence ORDER BY path, line_start, evidence_kind"
        ).fetchall()

    def upsert_business_node(
        self,
        *,
        repo_id: str,
        node_type: str,
        name: str,
        metadata: dict[str, Any],
        provenance: dict[str, Any],
        confidence: float,
        trust_tier: str,
        status: str = "candidate",
    ) -> sqlite3.Row:
        if node_type not in BUSINESS_NODE_TYPES:
            raise ValueError(f"unsupported business node type: {node_type}")
        stable_key = f"business:{repo_id}:{node_type}:{_slug(name)}"
        node_id = stable_id(stable_key)
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO semantic_nodes(
                  node_id, repo_id, node_type, name, stable_key, confidence, source,
                  metadata_json, trust_tier, status, provenance_json, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(node_id) DO UPDATE SET
                  name = excluded.name,
                  confidence = excluded.confidence,
                  source = excluded.source,
                  metadata_json = excluded.metadata_json,
                  trust_tier = excluded.trust_tier,
                  status = excluded.status,
                  provenance_json = excluded.provenance_json,
                  updated_at = excluded.updated_at
                """,
                (
                    node_id,
                    repo_id,
                    node_type,
                    name,
                    stable_key,
                    float(confidence),
                    str(
                        provenance.get("source_type")
                        or provenance.get("origin")
                        or "business"
                    ),
                    canonical_json(metadata),
                    trust_tier,
                    status,
                    canonical_json(provenance),
                    now,
                    now,
                ),
            )
        return self.semantic_node(node_id)  # type: ignore[return-value]

    def business_nodes(
        self,
        repo_id: str,
        *,
        status: str | None = None,
        node_type: str | None = None,
        limit: int = 100,
    ) -> list[sqlite3.Row]:
        clauses = [
            "repo_id = ?",
            f"node_type IN ({','.join('?' for _ in BUSINESS_NODE_TYPES)})",
        ]
        params: list[Any] = [repo_id, *BUSINESS_NODE_TYPES]
        if status:
            clauses.append("status = ?")
            params.append(status)
        if node_type:
            clauses.append("node_type = ?")
            params.append(node_type)
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM semantic_nodes
            WHERE {" AND ".join(clauses)}
            ORDER BY updated_at DESC, node_type, name
            LIMIT ?
            """,
            params,
        ).fetchall()

    def approve_business_node(
        self,
        node_id: str,
        *,
        decision: str,
        approver: str,
        notes: str = "",
    ) -> sqlite3.Row:
        if decision not in {"approve", "reject"}:
            raise ValueError("decision must be approve or reject")
        node = self.semantic_node(node_id)
        if not node:
            raise KeyError(f"business node not found: {node_id}")
        if node["node_type"] not in BUSINESS_NODE_TYPES:
            raise ValueError(f"not a business node: {node_id}")
        from_status = node["status"] or "active"
        to_status = "active" if decision == "approve" else "rejected"
        approval_id = stable_id(node_id, decision, approver, notes, utc_now())
        with self.conn:
            self.conn.execute(
                "UPDATE semantic_nodes SET status = ?, updated_at = ? WHERE node_id = ?",
                (to_status, utc_now(), node_id),
            )
            self.conn.execute(
                """
                INSERT INTO business_node_approvals(
                  approval_id, node_id, repo_id, decision, approver, notes,
                  from_status, to_status, audit_row_hash, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    approval_id,
                    node_id,
                    node["repo_id"],
                    decision,
                    approver,
                    notes,
                    from_status,
                    to_status,
                    None,
                    utc_now(),
                ),
            )
        audit = self.append_audit(
            pack_id=f"business-node:{node_id}",
            payload={
                "event": "business_node_decision",
                "node_id": node_id,
                "repo_id": node["repo_id"],
                "decision": decision,
                "from_status": from_status,
                "to_status": to_status,
                "approver": approver,
            },
        )
        with self.conn:
            self.conn.execute(
                "UPDATE business_node_approvals SET audit_row_hash = ? WHERE approval_id = ?",
                (audit["row_hash"], approval_id),
            )
        return self.semantic_node(node_id)  # type: ignore[return-value]

    def link_business_edge(
        self,
        *,
        repo_id: str,
        src_node_id: str,
        dst_node_id: str,
        kind: str,
        provenance: dict[str, Any],
        confidence: float | None = None,
    ) -> sqlite3.Row:
        src = self.semantic_node(src_node_id)
        dst = self.semantic_node(dst_node_id)
        if not src or not dst:
            raise KeyError("business link endpoints must exist")
        if src["repo_id"] != repo_id or dst["repo_id"] != repo_id:
            raise ValueError("business link endpoints must belong to the same repo")
        if not _valid_business_edge(src["node_type"], kind, dst["node_type"]):
            raise ValueError(
                f"invalid business edge: {src['node_type']} --{kind}--> {dst['node_type']}"
            )
        for endpoint in (src, dst):
            if (
                endpoint["node_type"] in BUSINESS_NODE_TYPES
                and endpoint["status"] != "active"
            ):
                raise ValueError(
                    "business links require active approved business endpoints"
                )
        min_confidence = min(
            float(src["confidence"] or 0.0), float(dst["confidence"] or 0.0)
        )
        edge_confidence = min(
            min_confidence, float(confidence if confidence is not None else 1.0)
        )
        trust_tier = _min_trust(
            src["trust_tier"],
            dst["trust_tier"],
            str(provenance.get("trust_tier") or "high"),
        )
        edge_id = stable_id(repo_id, src_node_id, kind, dst_node_id)
        metadata = {
            "provenance": provenance,
            "trust_tier": trust_tier,
            "status": "active",
            "business_edge": True,
        }
        evidence_ids: list[str] = []
        source_ref = str(provenance.get("source_ref") or "")
        if source_ref:
            evidence_ids.append(
                stable_id(edge_id, source_ref, "business_edge_evidence")
            )
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO semantic_edges(
                  edge_id, src_node_id, dst_node_id, kind, confidence,
                  evidence_json, metadata_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    edge_id,
                    src_node_id,
                    dst_node_id,
                    kind,
                    edge_confidence,
                    canonical_json(evidence_ids),
                    canonical_json(metadata),
                    utc_now(),
                ),
            )
            if source_ref:
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO semantic_evidence(
                      evidence_id, node_id, edge_id, repo_id, path, symbol_identity_id,
                      line_start, line_end, evidence_kind, evidence_hash
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        evidence_ids[0],
                        None,
                        edge_id,
                        repo_id,
                        source_ref.replace("\\", "/"),
                        None,
                        None,
                        None,
                        "business_edge",
                        stable_id(source_ref),
                    ),
                )
        return self.conn.execute(
            """
            SELECT e.*, src.node_type AS src_type, src.name AS src_name,
                   dst.node_type AS dst_type, dst.name AS dst_name,
                   src.trust_tier AS src_trust_tier, dst.trust_tier AS dst_trust_tier,
                   src.status AS src_status, dst.status AS dst_status
            FROM semantic_edges e
            JOIN semantic_nodes src ON src.node_id = e.src_node_id
            JOIN semantic_nodes dst ON dst.node_id = e.dst_node_id
            WHERE e.edge_id = ?
            """,
            (edge_id,),
        ).fetchone()  # type: ignore[return-value]

    def business_exposure_walk(
        self,
        repo_id: str,
        start_paths: Iterable[str],
        *,
        active_only: bool = True,
        max_hops: int = 5,
    ) -> dict[str, Any]:
        normalized = sorted(
            {path.replace("\\", "/").removeprefix("./") for path in start_paths if path}
        )
        if not normalized:
            return _empty_business_exposure()
        placeholders = ",".join("?" for _ in normalized)
        active_clause = (
            "AND (n.status IS NULL OR n.status = 'active')" if active_only else ""
        )
        seeds = self.conn.execute(
            f"""
            SELECT DISTINCT n.*
            FROM semantic_evidence ev
            JOIN semantic_nodes n ON n.node_id = ev.node_id
            WHERE ev.repo_id = ?
              AND ev.path IN ({placeholders})
              {active_clause}
            """,
            (repo_id, *normalized),
        ).fetchall()
        business_rows = {
            row["node_id"]: row
            for row in self.business_nodes(
                repo_id, status="active" if active_only else None, limit=10000
            )
        }
        routes_by_node: dict[str, dict[str, Any]] = {}
        queue: list[tuple[str, int, float, str, list[str], list[str], bool]] = []
        for seed in seeds:
            route = [str(seed["name"])]
            degraded = float(seed["confidence"] or 0.0) < 0.5
            queue.append(
                (
                    seed["node_id"],
                    0,
                    float(seed["confidence"] or 0.0),
                    "high",
                    route,
                    [],
                    degraded,
                )
            )
        seen: set[tuple[str, int]] = set()
        while queue:
            node_id, depth, confidence, trust, route, evidence_refs, degraded = (
                queue.pop(0)
            )
            if depth >= max_hops or (node_id, depth) in seen:
                continue
            seen.add((node_id, depth))
            rows = self.conn.execute(
                """
                SELECT e.*, dst.node_id AS dst_id, dst.node_type AS dst_type,
                       dst.name AS dst_name, dst.confidence AS dst_confidence,
                       dst.trust_tier AS dst_trust_tier, dst.status AS dst_status,
                       dst.metadata_json AS dst_metadata_json
                FROM semantic_edges e
                JOIN semantic_nodes dst ON dst.node_id = e.dst_node_id
                WHERE e.src_node_id = ?
                  AND e.kind IN (?, ?, ?, ?, ?, ?)
                  AND (? = 0 OR dst.status = 'active' OR dst.status IS NULL)
                ORDER BY e.kind, dst.node_type, dst.name
                """,
                (node_id, *BUSINESS_EDGE_KINDS, 1 if active_only else 0),
            ).fetchall()
            for edge in rows:
                metadata = json.loads(edge["metadata_json"] or "{}")
                if metadata.get("status") not in {None, "active"}:
                    continue
                next_conf = min(
                    confidence,
                    float(edge["confidence"] or 0.0),
                    float(edge["dst_confidence"] or 0.0),
                )
                next_trust = _min_trust(
                    trust, edge["dst_trust_tier"], metadata.get("trust_tier")
                )
                next_route = [*route, str(edge["dst_name"])]
                next_evidence = [
                    *evidence_refs,
                    *json.loads(edge["evidence_json"] or "[]"),
                ]
                next_degraded = degraded or next_conf < 0.5
                if edge["dst_id"] in business_rows:
                    item = routes_by_node.get(edge["dst_id"])
                    if item is None or next_conf > float(item["confidence"]):
                        routes_by_node[edge["dst_id"]] = {
                            "node_id": edge["dst_id"],
                            "node_type": edge["dst_type"],
                            "name": edge["dst_name"],
                            "trust_tier": next_trust,
                            "confidence": round(next_conf, 4),
                            "degraded": next_degraded,
                            "via_paths": [next_route],
                            "evidence_refs": sorted(set(next_evidence)),
                            "metadata": json.loads(edge["dst_metadata_json"] or "{}"),
                        }
                    else:
                        existing_paths = item.setdefault("via_paths", [])
                        if next_route not in existing_paths:
                            existing_paths.append(next_route)
                        item["evidence_refs"] = sorted(
                            set(item.get("evidence_refs", [])) | set(next_evidence)
                        )
                queue.append(
                    (
                        edge["dst_id"],
                        depth + 1,
                        next_conf,
                        next_trust,
                        next_route,
                        next_evidence,
                        next_degraded,
                    )
                )
        exposure: dict[str, list[dict[str, Any]]] = {
            kind: [] for kind in BUSINESS_NODE_TYPES
        }
        for item in routes_by_node.values():
            exposure[item["node_type"]].append(item)
        exposure = {
            kind: sorted(items, key=lambda item: (item["name"], item["node_id"]))
            for kind, items in sorted(exposure.items())
            if items
        }
        trusts = [item["trust_tier"] for items in exposure.values() for item in items]
        summary = {f"{kind}s": len(items) for kind, items in exposure.items()}
        return {
            "schema_version": "ctxlayer.business_exposure.v1",
            "authoritative": False,
            "requires_human_review": True,
            "lowest_trust_tier": _min_trust(*trusts) if trusts else None,
            "exposure": exposure,
            "exposure_summary": summary,
        }

    def add_org_connector(
        self,
        *,
        workspace_id: str,
        kind: str,
        display_name: str,
        config: dict[str, Any] | None = None,
        secret_ref: str | None = None,
        access_scope: str = "restricted",
        remote_enabled: bool = False,
        enabled: bool = True,
    ) -> sqlite3.Row:
        connector_id = stable_id(workspace_id, kind, display_name)
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO org_connectors(
                  connector_id, workspace_id, kind, display_name, config_json,
                  secret_ref, access_scope, remote_enabled, enabled, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(connector_id) DO UPDATE SET
                  config_json = excluded.config_json,
                  secret_ref = excluded.secret_ref,
                  access_scope = excluded.access_scope,
                  remote_enabled = excluded.remote_enabled,
                  enabled = excluded.enabled,
                  updated_at = excluded.updated_at
                """,
                (
                    connector_id,
                    workspace_id,
                    kind,
                    display_name,
                    canonical_json(config or {}),
                    secret_ref,
                    access_scope,
                    1 if remote_enabled else 0,
                    1 if enabled else 0,
                    now,
                    now,
                ),
            )
        return self.org_connector(connector_id)  # type: ignore[return-value]

    def org_connector(self, connector_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM org_connectors WHERE connector_id = ?", (connector_id,)
        ).fetchone()

    def org_connectors(
        self,
        *,
        workspace_id: str,
        kind: str | None = None,
        enabled: bool | None = None,
    ) -> list[sqlite3.Row]:
        clauses = ["workspace_id = ?"]
        params: list[Any] = [workspace_id]
        if kind:
            clauses.append("kind = ?")
            params.append(kind)
        if enabled is not None:
            clauses.append("enabled = ?")
            params.append(1 if enabled else 0)
        return self.conn.execute(
            f"""
            SELECT * FROM org_connectors
            WHERE {" AND ".join(clauses)}
            ORDER BY kind, display_name
            """,
            params,
        ).fetchall()

    def start_org_ingest_run(
        self,
        *,
        connector_id: str,
        workspace_id: str,
        since: str | None = None,
        remote_used: bool = False,
    ) -> str:
        run_id = stable_id(
            connector_id, workspace_id, since or "", utc_now(), str(time.time_ns())
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO org_ingest_runs(
                  run_id, connector_id, workspace_id, since, remote_used, started_at
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    connector_id,
                    workspace_id,
                    since,
                    1 if remote_used else 0,
                    utc_now(),
                ),
            )
        return run_id

    def finish_org_ingest_run(
        self,
        run_id: str,
        *,
        items_seen: int,
        items_quarantined: int,
        items_rejected: int,
        redactions: int,
        audit_hash: str | None = None,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                UPDATE org_ingest_runs
                SET items_seen = ?, items_quarantined = ?, items_rejected = ?,
                    redactions = ?, audit_hash = ?, finished_at = ?
                WHERE run_id = ?
                """,
                (
                    items_seen,
                    items_quarantined,
                    items_rejected,
                    redactions,
                    audit_hash,
                    utc_now(),
                    run_id,
                ),
            )

    def org_ingest_runs(
        self, *, workspace_id: str | None = None, limit: int = 50
    ) -> list[sqlite3.Row]:
        params: list[Any] = []
        where = ""
        if workspace_id:
            where = "WHERE workspace_id = ?"
            params.append(workspace_id)
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM org_ingest_runs
            {where}
            ORDER BY started_at DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def upsert_org_candidate(
        self,
        *,
        candidate_id: str,
        workspace_id: str,
        repo_id: str | None,
        memory_record_id: str | None,
        source_connector: str,
        source_ref: str,
        content_extract: str,
        content_hash: str,
        extracted_type: str,
        confidence: float,
        defense_result: dict[str, Any],
        contradictions: list[dict[str, Any]] | None = None,
        linked_entities: list[str] | None = None,
        captured_at: str | None = None,
        decay_at: str | None = None,
        provenance: dict[str, Any] | None = None,
        redaction_summary: dict[str, Any] | None = None,
        access_scope: str = "restricted",
    ) -> sqlite3.Row:
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO org_knowledge_candidates(
                  candidate_id, workspace_id, repo_id, memory_record_id, source_connector,
                  source_ref, content_extract, content_hash, extracted_type, trust_tier,
                  confidence, status, defense_result, contradictions, linked_entities,
                  captured_at, ingested_at, decay_at, provenance, redaction_summary,
                  access_scope, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'low', ?, 'quarantined', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(workspace_id, content_hash) DO UPDATE SET
                  memory_record_id = COALESCE(excluded.memory_record_id, org_knowledge_candidates.memory_record_id),
                  source_connector = excluded.source_connector,
                  source_ref = excluded.source_ref,
                  content_extract = excluded.content_extract,
                  extracted_type = excluded.extracted_type,
                  confidence = excluded.confidence,
                  status = org_knowledge_candidates.status,
                  defense_result = excluded.defense_result,
                  contradictions = excluded.contradictions,
                  linked_entities = excluded.linked_entities,
                  captured_at = excluded.captured_at,
                  decay_at = excluded.decay_at,
                  provenance = excluded.provenance,
                  redaction_summary = excluded.redaction_summary,
                  access_scope = excluded.access_scope,
                  updated_at = excluded.updated_at
                """,
                (
                    candidate_id,
                    workspace_id,
                    repo_id,
                    memory_record_id,
                    source_connector,
                    source_ref,
                    content_extract,
                    content_hash,
                    extracted_type,
                    confidence,
                    canonical_json(defense_result),
                    canonical_json(contradictions or []),
                    canonical_json(linked_entities or []),
                    captured_at,
                    now,
                    decay_at,
                    canonical_json(provenance or {}),
                    canonical_json(redaction_summary or {}),
                    access_scope,
                    now,
                    now,
                ),
            )
        return self.conn.execute(
            """
            SELECT * FROM org_knowledge_candidates
            WHERE workspace_id = ? AND content_hash = ?
            """,
            (workspace_id, content_hash),
        ).fetchone()  # type: ignore[return-value]

    def update_org_candidate_memory(
        self, candidate_id: str, memory_record_id: str
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                UPDATE org_knowledge_candidates
                SET memory_record_id = ?, updated_at = ?
                WHERE candidate_id = ?
                """,
                (memory_record_id, utc_now(), candidate_id),
            )

    def set_org_candidate_status(
        self,
        candidate_id: str,
        *,
        status: str,
        actor: str,
        reason: str,
        memory_status: str | None = None,
        memory_trust: str | None = None,
    ) -> sqlite3.Row:
        row = self.org_candidate(candidate_id)
        if not row:
            raise KeyError(f"org candidate not found: {candidate_id}")
        with self.conn:
            self.conn.execute(
                """
                UPDATE org_knowledge_candidates
                SET status = ?, updated_at = ?
                WHERE candidate_id = ?
                """,
                (status, utc_now(), candidate_id),
            )
        if row["memory_record_id"] and memory_status:
            self.set_memory_record_status(
                record_id=row["memory_record_id"],
                status=memory_status,
                trust=memory_trust,
                actor=actor,
                reason=reason,
            )
        return self.org_candidate(candidate_id)  # type: ignore[return-value]

    def org_candidate(self, candidate_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM org_knowledge_candidates WHERE candidate_id = ?",
            (candidate_id,),
        ).fetchone()

    def org_candidates(
        self,
        *,
        workspace_id: str,
        repo_id: str | None = None,
        status: str | None = None,
        source_connector: str | None = None,
        access_scope: str | None = None,
        limit: int = 100,
    ) -> list[sqlite3.Row]:
        clauses = ["workspace_id = ?"]
        params: list[Any] = [workspace_id]
        if repo_id:
            clauses.append("(repo_id = ? OR repo_id IS NULL)")
            params.append(repo_id)
        if status:
            clauses.append("status = ?")
            params.append(status)
        if source_connector:
            clauses.append("source_connector = ?")
            params.append(source_connector)
        if access_scope:
            clauses.append("access_scope = ?")
            params.append(access_scope)
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM org_knowledge_candidates
            WHERE {" AND ".join(clauses)}
            ORDER BY updated_at DESC, source_connector, source_ref
            LIMIT ?
            """,
            params,
        ).fetchall()

    def create_decision(
        self,
        *,
        decision_id: str,
        workspace_id: str,
        repo_id: str | None,
        question: str,
        snapshot_id: str | None,
        briefing: dict[str, Any] | None = None,
        audit: dict[str, Any] | None = None,
    ) -> sqlite3.Row:
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO decisions(
                  decision_id, workspace_id, repo_id, question, status, snapshot_id,
                  briefing_json, audit_hash, prev_audit_hash, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, 'open', ?, ?, ?, ?, ?, ?)
                """,
                (
                    decision_id,
                    workspace_id,
                    repo_id,
                    question,
                    snapshot_id,
                    canonical_json(briefing or {}),
                    (audit or {}).get("row_hash"),
                    (audit or {}).get("prev_hash"),
                    now,
                    now,
                ),
            )
        return self.get_decision(decision_id)  # type: ignore[return-value]

    def get_decision(self, decision_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM decisions WHERE decision_id = ?",
            (decision_id,),
        ).fetchone()

    def update_decision_briefing(
        self,
        decision_id: str,
        *,
        briefing: dict[str, Any],
        audit: dict[str, Any] | None = None,
    ) -> sqlite3.Row:
        with self.conn:
            self.conn.execute(
                """
                UPDATE decisions
                SET status = 'analyzed',
                    snapshot_id = ?,
                    briefing_json = ?,
                    human_decision_json = NULL,
                    audit_hash = ?,
                    prev_audit_hash = ?,
                    updated_at = ?
                WHERE decision_id = ?
                """,
                (
                    briefing.get("snapshot_id"),
                    canonical_json(briefing),
                    (audit or {}).get("row_hash"),
                    (audit or {}).get("prev_hash"),
                    utc_now(),
                    decision_id,
                ),
            )
        row = self.get_decision(decision_id)
        if row is None:
            raise KeyError(f"decision not found: {decision_id}")
        return row

    def set_decision_human_decision(
        self,
        decision_id: str,
        *,
        human_decision: dict[str, Any],
        audit: dict[str, Any] | None = None,
    ) -> sqlite3.Row:
        with self.conn:
            self.conn.execute(
                """
                UPDATE decisions
                SET status = 'decided',
                    human_decision_json = ?,
                    audit_hash = ?,
                    prev_audit_hash = ?,
                    updated_at = ?
                WHERE decision_id = ?
                """,
                (
                    canonical_json(human_decision),
                    (audit or {}).get("row_hash"),
                    (audit or {}).get("prev_hash"),
                    utc_now(),
                    decision_id,
                ),
            )
        row = self.get_decision(decision_id)
        if row is None:
            raise KeyError(f"decision not found: {decision_id}")
        return row

    def list_decisions(
        self,
        *,
        workspace_id: str | None = None,
        repo_id: str | None = None,
        status: str | None = None,
        limit: int = 50,
    ) -> list[sqlite3.Row]:
        clauses: list[str] = []
        params: list[Any] = []
        if workspace_id:
            clauses.append("workspace_id = ?")
            params.append(workspace_id)
        if repo_id:
            clauses.append("(repo_id = ? OR repo_id IS NULL)")
            params.append(repo_id)
        if status:
            clauses.append("status = ?")
            params.append(status)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM decisions
            {where}
            ORDER BY updated_at DESC, created_at DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def semantic_file_index(self, repo_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM semantic_file_index
            WHERE repo_id = ?
            ORDER BY path
            """,
            (repo_id,),
        ).fetchall()

    def graph_file_centrality(
        self,
        repo_id: str,
        *,
        kinds: Iterable[str] | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        kind_filter = tuple(kinds or ("imports", "tests", "calls"))
        params: list[Any] = [repo_id, repo_id]
        where_kind = ""
        if kind_filter:
            where_kind = f" AND kind IN ({','.join('?' for _ in kind_filter)})"
            params.extend(kind_filter)
        rows = self.conn.execute(
            f"""
            SELECT * FROM edges
            WHERE src_repo_id = ? AND dst_repo_id = ? {where_kind}
            ORDER BY src_node_type, src_node_id, dst_node_type, dst_node_id, kind
            """,
            params,
        ).fetchall()
        symbol_paths = {
            row["symbol_identity_id"]: row["path"]
            for row in self.conn.execute(
                "SELECT symbol_identity_id, path FROM symbol_identities WHERE repo_id = ?",
                (repo_id,),
            ).fetchall()
        }
        by_path: dict[str, dict[str, Any]] = {}

        def edge_path(node_type: str, node_id: str) -> str | None:
            if node_type == "file":
                return node_id
            if node_type == "symbol":
                return symbol_paths.get(node_id)
            return None

        def ensure(path: str) -> dict[str, Any]:
            item = by_path.get(path)
            if item is None:
                item = {
                    "path": path,
                    "in_degree": 0,
                    "out_degree": 0,
                    "degree": 0,
                    "kinds": {},
                    "score": 0.0,
                }
                by_path[path] = item
            return item

        for row in rows:
            src_path = edge_path(row["src_node_type"], row["src_node_id"])
            dst_path = edge_path(row["dst_node_type"], row["dst_node_id"])
            if not src_path and not dst_path:
                continue
            kind = row["kind"]
            if src_path:
                item = ensure(src_path)
                item["out_degree"] += 1
                item["degree"] += 1
                item["kinds"][kind] = item["kinds"].get(kind, 0) + 1
            if dst_path and dst_path != src_path:
                item = ensure(dst_path)
                item["in_degree"] += 1
                item["degree"] += 1
                item["kinds"][kind] = item["kinds"].get(kind, 0) + 1

        max_degree = max((int(item["degree"]) for item in by_path.values()), default=0)
        ranked = []
        for item in by_path.values():
            clone = dict(item)
            clone["kinds"] = dict(sorted(clone["kinds"].items()))
            clone["score"] = round(
                (int(clone["degree"]) / max_degree) if max_degree else 0.0, 4
            )
            ranked.append(clone)
        ranked.sort(key=lambda item: (-float(item["score"]), item["path"]))
        return ranked[:limit] if limit else ranked

    def graph_stats(self, repo_id: str | None = None) -> dict[str, Any]:
        edge_params: list[Any] = []
        edge_where = ""
        if repo_id:
            edge_where = "WHERE src_repo_id = ? OR dst_repo_id = ?"
            edge_params.extend([repo_id, repo_id])
        edge_counts = {
            row["kind"]: int(row["count"])
            for row in self.conn.execute(
                f"""
                SELECT kind, COUNT(*) AS count
                FROM edges
                {edge_where}
                GROUP BY kind
                ORDER BY kind
                """,
                edge_params,
            ).fetchall()
        }
        node_params: list[Any] = []
        node_where = ""
        if repo_id:
            node_where = "WHERE repo_id = ?"
            node_params.append(repo_id)
        semantic_node_counts = {
            row["node_type"]: int(row["count"])
            for row in self.conn.execute(
                f"""
                SELECT node_type, COUNT(*) AS count
                FROM semantic_nodes
                {node_where}
                GROUP BY node_type
                ORDER BY node_type
                """,
                node_params,
            ).fetchall()
        }
        semantic_edge_params: list[Any] = []
        semantic_edge_repo = ""
        if repo_id:
            semantic_edge_repo = """
            JOIN semantic_nodes src ON src.node_id = e.src_node_id
            JOIN semantic_nodes dst ON dst.node_id = e.dst_node_id
            WHERE src.repo_id = ? OR dst.repo_id = ?
            """
            semantic_edge_params.extend([repo_id, repo_id])
        semantic_edge_counts = {
            row["kind"]: int(row["count"])
            for row in self.conn.execute(
                f"""
                SELECT e.kind, COUNT(*) AS count
                FROM semantic_edges e
                {semantic_edge_repo}
                GROUP BY e.kind
                ORDER BY e.kind
                """,
                semantic_edge_params,
            ).fetchall()
        }
        confidence_distribution = {
            "nodes": {"high": 0, "medium": 0, "low": 0},
            "edges": {"high": 0, "medium": 0, "low": 0},
        }
        for row in self.conn.execute(
            f"SELECT confidence FROM semantic_nodes {node_where}",
            node_params,
        ).fetchall():
            confidence_distribution["nodes"][_confidence_tier(row["confidence"])] += 1
        edge_confidence_sql = "SELECT e.confidence FROM semantic_edges e"
        if repo_id:
            edge_confidence_sql += """
            JOIN semantic_nodes src ON src.node_id = e.src_node_id
            JOIN semantic_nodes dst ON dst.node_id = e.dst_node_id
            WHERE src.repo_id = ? OR dst.repo_id = ?
            """
        for row in self.conn.execute(
            edge_confidence_sql, semantic_edge_params
        ).fetchall():
            confidence_distribution["edges"][_confidence_tier(row["confidence"])] += 1
        business_node_params: list[Any] = [*BUSINESS_NODE_TYPES]
        business_node_repo = ""
        if repo_id:
            business_node_repo = "AND repo_id = ?"
            business_node_params.append(repo_id)
        business_nodes_by_status = {
            row["status"] or "active": int(row["count"])
            for row in self.conn.execute(
                f"""
                SELECT COALESCE(status, 'active') AS status, COUNT(*) AS count
                FROM semantic_nodes
                WHERE node_type IN ({",".join("?" for _ in BUSINESS_NODE_TYPES)})
                  {business_node_repo}
                GROUP BY COALESCE(status, 'active')
                ORDER BY status
                """,
                business_node_params,
            ).fetchall()
        }
        business_nodes_by_type = {
            row["node_type"]: int(row["count"])
            for row in self.conn.execute(
                f"""
                SELECT node_type, COUNT(*) AS count
                FROM semantic_nodes
                WHERE node_type IN ({",".join("?" for _ in BUSINESS_NODE_TYPES)})
                  AND status = 'active'
                  {business_node_repo}
                GROUP BY node_type
                ORDER BY node_type
                """,
                business_node_params,
            ).fetchall()
        }
        business_approval_funnel = {
            row["decision"]: int(row["count"])
            for row in self.conn.execute(
                """
                SELECT decision, COUNT(*) AS count
                FROM business_node_approvals
                WHERE (? IS NULL OR repo_id = ?)
                GROUP BY decision
                ORDER BY decision
                """,
                (repo_id, repo_id),
            ).fetchall()
        }
        business_edges_active = self.conn.execute(
            f"""
            SELECT COUNT(*) AS count
            FROM semantic_edges e
            JOIN semantic_nodes src ON src.node_id = e.src_node_id
            JOIN semantic_nodes dst ON dst.node_id = e.dst_node_id
            WHERE e.kind IN ({",".join("?" for _ in BUSINESS_EDGE_KINDS)})
              AND (src.status IS NULL OR src.status = 'active')
              AND (dst.status IS NULL OR dst.status = 'active')
              AND (? IS NULL OR src.repo_id = ? OR dst.repo_id = ?)
            """,
            (*BUSINESS_EDGE_KINDS, repo_id, repo_id, repo_id),
        ).fetchone()
        org_status_counts = {
            row["status"]: int(row["count"])
            for row in self.conn.execute(
                """
                SELECT status, COUNT(*) AS count
                FROM org_knowledge_candidates
                WHERE (? IS NULL OR repo_id = ? OR repo_id IS NULL)
                GROUP BY status
                ORDER BY status
                """,
                (repo_id, repo_id),
            ).fetchall()
        }
        org_source_counts = {
            row["source_connector"]: int(row["count"])
            for row in self.conn.execute(
                """
                SELECT source_connector, COUNT(*) AS count
                FROM org_knowledge_candidates
                WHERE (? IS NULL OR repo_id = ? OR repo_id IS NULL)
                GROUP BY source_connector
                ORDER BY source_connector
                """,
                (repo_id, repo_id),
            ).fetchall()
        }
        org_run_totals = self.conn.execute(
            """
            SELECT COUNT(*) AS runs,
                   COALESCE(SUM(items_seen), 0) AS items_seen,
                   COALESCE(SUM(items_quarantined), 0) AS items_quarantined,
                   COALESCE(SUM(items_rejected), 0) AS items_rejected,
                   COALESCE(SUM(redactions), 0) AS redactions,
                   COALESCE(SUM(remote_used), 0) AS remote_used
            FROM org_ingest_runs
            """
        ).fetchone()
        drift_status_counts = {
            row["status"]: int(row["count"])
            for row in self.conn.execute(
                """
                SELECT status, COUNT(*) AS count
                FROM semantic_drift_findings
                WHERE (? IS NULL OR repo_id = ?)
                GROUP BY status
                ORDER BY status
                """,
                (repo_id, repo_id),
            ).fetchall()
        }
        latest_accuracy = self.semantic_accuracy_runs(repo_id, limit=1)
        file_params: list[Any] = []
        file_join = ""
        file_where = ""
        if repo_id:
            file_join = "JOIN snapshots s ON s.snapshot_id = sf.snapshot_id"
            file_where = "WHERE s.repo_id = ?"
            file_params.append(repo_id)
        file_count = self.conn.execute(
            f"""
            SELECT COUNT(DISTINCT sf.path) AS count
            FROM snapshot_files sf
            {file_join}
            {file_where}
            """,
            file_params,
        ).fetchone()
        symbol_params: list[Any] = []
        symbol_where = ""
        if repo_id:
            symbol_where = "WHERE repo_id = ?"
            symbol_params.append(repo_id)
        symbol_count = self.conn.execute(
            f"""
            SELECT COUNT(*) AS count
            FROM symbol_identities
            {symbol_where}
            """,
            symbol_params,
        ).fetchone()
        return {
            "ok": True,
            "repo_id": repo_id,
            "files": int(file_count["count"] if file_count else 0),
            "symbols": int(symbol_count["count"] if symbol_count else 0),
            "logical_edges": edge_counts,
            "semantic_nodes": semantic_node_counts,
            "semantic_edges": semantic_edge_counts,
            "semantic_file_index": (
                len(self.semantic_file_index(repo_id)) if repo_id else 0
            ),
            "semantic_confidence_distribution": confidence_distribution,
            "business_graph": {
                "active_nodes_by_type": business_nodes_by_type,
                "nodes_by_status": business_nodes_by_status,
                "approval_funnel": business_approval_funnel,
                "active_business_edges": int(
                    business_edges_active["count"] if business_edges_active else 0
                ),
            },
            "org_ingestion": {
                "candidates_by_status": org_status_counts,
                "candidates_by_source": org_source_counts,
                "runs": int(org_run_totals["runs"] if org_run_totals else 0),
                "items_seen": int(
                    org_run_totals["items_seen"] if org_run_totals else 0
                ),
                "items_quarantined": int(
                    org_run_totals["items_quarantined"] if org_run_totals else 0
                ),
                "items_rejected": int(
                    org_run_totals["items_rejected"] if org_run_totals else 0
                ),
                "redactions": int(
                    org_run_totals["redactions"] if org_run_totals else 0
                ),
                "remote_used": int(
                    org_run_totals["remote_used"] if org_run_totals else 0
                ),
            },
            "semantic_drift_findings": drift_status_counts,
            "semantic_accuracy_latest": (
                _semantic_accuracy_row(latest_accuracy[0]) if latest_accuracy else None
            ),
            "central_files": (
                self.graph_file_centrality(repo_id, limit=10) if repo_id else []
            ),
        }

    def graph_walk(
        self,
        *,
        repo_id: str,
        start_paths: Iterable[str],
        kinds: Iterable[str] | None = None,
        max_hops: int = 2,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        graph_kinds = tuple(kinds or ("imports", "tests", "calls", "defines"))
        normalized = sorted(
            {path.replace("\\", "/").removeprefix("./") for path in start_paths if path}
        )
        symbol_paths = {
            row["symbol_identity_id"]: row["path"]
            for row in self.conn.execute(
                "SELECT symbol_identity_id, path FROM symbol_identities WHERE repo_id = ?",
                (repo_id,),
            ).fetchall()
        }

        def readable(node_type: str, node_id: str) -> dict[str, Any]:
            item: dict[str, Any] = {"node_type": node_type, "node_id": node_id}
            if node_type == "file":
                item["path"] = node_id
            elif node_type == "symbol":
                item["path"] = symbol_paths.get(node_id)
                row = self.symbol_identity(node_id)
                if row:
                    item["qualname"] = row["qualname"]
                    item["kind"] = row["kind"]
            return item

        seen: set[tuple[str, str]] = {("file", path) for path in normalized}
        queue: list[tuple[str, str, int, float, list[str]]] = [
            ("file", path, 0, 1.0, [path]) for path in normalized
        ]
        results: dict[tuple[str, str, str, str, str], dict[str, Any]] = {}
        while queue and len(results) < limit:
            node_type, node_id, depth, confidence, route = queue.pop(0)
            if depth >= max(0, max_hops):
                continue
            for direction in ("out", "in"):
                for neighbor in self.neighbors(
                    repo_id=repo_id,
                    node_type=node_type,
                    node_id=node_id,
                    kinds=graph_kinds,
                    direction=direction,
                ):
                    next_confidence = confidence * neighbor.confidence
                    if next_confidence < 0.2:
                        continue
                    next_node = (neighbor.node_type, neighbor.node_id)
                    source = readable(node_type, node_id)
                    target = readable(neighbor.node_type, neighbor.node_id)
                    route_label = str(
                        target.get("path") or target.get("qualname") or neighbor.node_id
                    )
                    record = {
                        "from": source,
                        "to": target,
                        "direction": direction,
                        "kind": neighbor.kind,
                        "depth": depth + 1,
                        "confidence": round(next_confidence, 4),
                        "route": [*route, route_label],
                        "metadata": neighbor.metadata,
                    }
                    key = (
                        source["node_type"],
                        source["node_id"],
                        target["node_type"],
                        target["node_id"],
                        neighbor.kind,
                    )
                    existing = results.get(key)
                    if existing is None or float(record["confidence"]) > float(
                        existing["confidence"]
                    ):
                        results[key] = record
                    if next_node not in seen:
                        seen.add(next_node)
                        queue.append(
                            (
                                neighbor.node_type,
                                neighbor.node_id,
                                depth + 1,
                                next_confidence,
                                [*route, route_label],
                            )
                        )
                    if len(results) >= limit:
                        break
                if len(results) >= limit:
                    break
        return sorted(
            results.values(),
            key=lambda item: (int(item["depth"]), item["kind"], item["route"]),
        )

    def write_memory_eval_run(self, *, repo_id: str, metrics: dict[str, Any]) -> str:
        run_id = stable_id(repo_id, canonical_json(metrics), utc_now())
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_eval_runs(memory_eval_run_id, repo_id, metrics_json, created_at)
                VALUES (?, ?, ?, ?)
                """,
                (run_id, repo_id, canonical_json(metrics), utc_now()),
            )
        return run_id

    def write_semantic_accuracy_run(
        self,
        *,
        repo_id: str,
        fixture_set: str,
        metrics: dict[str, Any],
        passed: bool,
    ) -> str:
        created_at = utc_now()
        run_id = stable_id(repo_id, fixture_set, canonical_json(metrics), created_at)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO semantic_accuracy_runs(
                  accuracy_run_id, repo_id, fixture_set, metrics_json, passed, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    repo_id,
                    fixture_set,
                    canonical_json(metrics),
                    1 if passed else 0,
                    created_at,
                ),
            )
        return run_id

    def semantic_accuracy_runs(
        self,
        repo_id: str | None = None,
        *,
        limit: int = 20,
    ) -> list[sqlite3.Row]:
        if repo_id:
            return self.conn.execute(
                """
                SELECT * FROM semantic_accuracy_runs
                WHERE repo_id = ?
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (repo_id, limit),
            ).fetchall()
        return self.conn.execute(
            """
            SELECT * FROM semantic_accuracy_runs
            ORDER BY created_at DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()

    def write_semantic_drift_findings(
        self,
        *,
        repo_id: str,
        snapshot_id: str,
        findings: Iterable[dict[str, Any]],
    ) -> list[str]:
        ids: list[str] = []
        previous = self.conn.execute(
            """
            SELECT audit_hash FROM semantic_drift_findings
            WHERE repo_id = ? AND audit_hash IS NOT NULL
            ORDER BY detected_at DESC, finding_id DESC
            LIMIT 1
            """,
            (repo_id,),
        ).fetchone()
        prev_hash = previous["audit_hash"] if previous else ""
        with self.conn:
            for finding in findings:
                detected_at = str(finding.get("detected_at") or utc_now())
                paths = list(finding.get("paths") or [])
                payload = {
                    "repo_id": repo_id,
                    "snapshot_id": snapshot_id,
                    "finding_type": finding["finding_type"],
                    "severity": finding["severity"],
                    "node_id": finding.get("node_id"),
                    "edge_id": finding.get("edge_id"),
                    "paths": paths,
                    "detail": finding["detail"],
                    "confidence": finding.get("confidence"),
                    "status": finding.get("status", "open"),
                    "detected_at": detected_at,
                    "prev_audit_hash": prev_hash,
                }
                finding_id = str(
                    finding.get("finding_id") or stable_id(canonical_json(payload))
                )
                audit_hash = stable_id(
                    prev_hash, canonical_json({**payload, "finding_id": finding_id})
                )
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO semantic_drift_findings(
                      finding_id, repo_id, snapshot_id, finding_type, severity, node_id,
                      edge_id, paths_json, detail, confidence, status, detected_at,
                      resolved_at, audit_hash, prev_audit_hash
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        finding_id,
                        repo_id,
                        snapshot_id,
                        finding["finding_type"],
                        finding["severity"],
                        finding.get("node_id"),
                        finding.get("edge_id"),
                        canonical_json(paths),
                        finding["detail"],
                        finding.get("confidence"),
                        finding.get("status", "open"),
                        detected_at,
                        finding.get("resolved_at"),
                        audit_hash,
                        prev_hash,
                    ),
                )
                ids.append(finding_id)
                prev_hash = audit_hash
        return ids

    def semantic_drift_findings(
        self,
        repo_id: str | None = None,
        *,
        status: str | None = None,
        limit: int = 100,
    ) -> list[sqlite3.Row]:
        clauses: list[str] = []
        params: list[Any] = []
        if repo_id:
            clauses.append("repo_id = ?")
            params.append(repo_id)
        if status:
            clauses.append("status = ?")
            params.append(status)
        where = "WHERE " + " AND ".join(clauses) if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM semantic_drift_findings
            {where}
            ORDER BY detected_at DESC, severity DESC, finding_type, finding_id
            LIMIT ?
            """,
            params,
        ).fetchall()

    def semantic_drift_finding(self, finding_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM semantic_drift_findings WHERE finding_id = ?",
            (finding_id,),
        ).fetchone()

    def update_semantic_drift_finding(
        self,
        finding_id: str,
        *,
        status: str,
        audit_hash: str,
        prev_audit_hash: str,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                UPDATE semantic_drift_findings
                SET status = ?, resolved_at = ?, audit_hash = ?, prev_audit_hash = ?
                WHERE finding_id = ?
                """,
                (status, utc_now(), audit_hash, prev_audit_hash, finding_id),
            )

    def snapshot_diff(
        self, left_snapshot: str, right_snapshot: str
    ) -> dict[str, list[str]]:
        left = {
            row["path"]: row["file_version_id"]
            for row in self.conn.execute(
                "SELECT path, file_version_id FROM snapshot_files WHERE snapshot_id = ?",
                (left_snapshot,),
            ).fetchall()
        }
        right = {
            row["path"]: row["file_version_id"]
            for row in self.conn.execute(
                "SELECT path, file_version_id FROM snapshot_files WHERE snapshot_id = ?",
                (right_snapshot,),
            ).fetchall()
        }
        added: list[str] = []
        removed: list[str] = []
        changed: list[str] = []
        for path in sorted(set(left) | set(right)):
            if path not in left:
                added.append(path)
            elif path not in right:
                removed.append(path)
            elif left[path] != right[path]:
                changed.append(path)
        return {"added": added, "removed": removed, "changed": changed}

    def upsert_memory_record(
        self,
        *,
        record_id: str,
        workspace_id: str,
        repo_id: str | None,
        scope: str,
        type: str,
        subject_key: str,
        assertion: str,
        status: str,
        confidence: float,
        source_kind: str,
        extraction_method: str,
        title: str | None = None,
        importance: float | None = None,
        applies_when: str | None = None,
        avoid_when: str | None = None,
        trust: str | None = None,
        owner: str | None = None,
        expires_at: str | None = None,
        invalidates_when: str | None = None,
        last_validated_at: str | None = None,
        superseded_by: str | None = None,
        provenance: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        actor: str = "system",
        reason: str = "upsert_memory_record",
    ) -> str:
        now = utc_now()
        actual_trust = trust or _memory_trust_for_status(status)
        actual_importance = confidence if importance is None else importance
        actual_provenance = provenance or {
            "generator": "deterministic",
            "validator": "none",
            "input_source": "repo",
        }
        if status in {"approved", "active"} and _is_unvalidated_agent_memory(
            actual_provenance
        ):
            raise ValueError(
                "agent-generated memory requires a validator before promotion"
            )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_records(
                  record_id, workspace_id, repo_id, scope, type, subject_key,
                  title, assertion, status, trust, confidence, importance, source_kind,
                  extraction_method, applies_when, avoid_when, owner, expires_at,
                  invalidates_when, last_validated_at, superseded_by, provenance_json,
                  metadata_json, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(record_id) DO UPDATE SET
                  workspace_id=excluded.workspace_id,
                  repo_id=excluded.repo_id,
                  scope=excluded.scope,
                  type=excluded.type,
                  subject_key=excluded.subject_key,
                  title=excluded.title,
                  assertion=excluded.assertion,
                  status=excluded.status,
                  trust=excluded.trust,
                  confidence=excluded.confidence,
                  importance=excluded.importance,
                  source_kind=excluded.source_kind,
                  extraction_method=excluded.extraction_method,
                  applies_when=excluded.applies_when,
                  avoid_when=excluded.avoid_when,
                  owner=excluded.owner,
                  expires_at=excluded.expires_at,
                  invalidates_when=excluded.invalidates_when,
                  last_validated_at=excluded.last_validated_at,
                  superseded_by=COALESCE(excluded.superseded_by, memory_records.superseded_by),
                  provenance_json=excluded.provenance_json,
                  metadata_json=excluded.metadata_json,
                  updated_at=excluded.updated_at
                """,
                (
                    record_id,
                    workspace_id,
                    repo_id,
                    scope,
                    type,
                    subject_key,
                    title,
                    assertion,
                    status,
                    actual_trust,
                    confidence,
                    actual_importance,
                    source_kind,
                    extraction_method,
                    applies_when,
                    avoid_when,
                    owner,
                    expires_at,
                    invalidates_when,
                    last_validated_at,
                    superseded_by,
                    canonical_json(actual_provenance),
                    canonical_json(metadata or {}),
                    now,
                    now,
                ),
            )
            if status in {"rejected", "expired", "quarantined", "superseded"}:
                self.conn.execute(
                    "DELETE FROM memory_vectors WHERE record_id = ?", (record_id,)
                )
        self.write_memory_revision(record_id=record_id, actor=actor, reason=reason)
        return record_id

    def memory_record(self, record_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM memory_records WHERE record_id = ?", (record_id,)
        ).fetchone()

    def memory_records(
        self,
        *,
        type: str | None = None,
        status: str | None = None,
        repo_id: str | None = None,
        workspace_id: str | None = None,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if type:
            clauses.append("type = ?")
            params.append(type)
        if status:
            clauses.append("status = ?")
            params.append(status)
        if repo_id:
            clauses.append("(repo_id = ? OR scope = 'workspace')")
            params.append(repo_id)
        if workspace_id:
            clauses.append("workspace_id = ?")
            params.append(workspace_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        return self.conn.execute(
            f"""
            SELECT * FROM memory_records
            {where}
            ORDER BY status, confidence DESC, assertion
            """,
            params,
        ).fetchall()

    def update_memory_record(
        self,
        *,
        record_id: str,
        patch: dict[str, Any],
        actor: str = "system",
        reason: str | None = None,
    ) -> None:
        allowed = {
            "type",
            "scope",
            "subject_key",
            "title",
            "assertion",
            "status",
            "trust",
            "confidence",
            "importance",
            "source_kind",
            "extraction_method",
            "applies_when",
            "avoid_when",
            "owner",
            "expires_at",
            "invalidates_when",
            "last_validated_at",
            "superseded_by",
            "provenance_json",
            "metadata_json",
        }
        selected = {key: value for key, value in patch.items() if key in allowed}
        if not selected:
            return
        row = self.memory_record(record_id)
        if row is None:
            raise KeyError(f"memory record not found: {record_id}")
        provenance = _json_dict(
            selected.get("provenance_json") or row["provenance_json"]
        )
        next_status = str(selected.get("status", row["status"]))
        if next_status in {"approved", "active"} and _is_unvalidated_agent_memory(
            provenance
        ):
            raise ValueError(
                "agent-generated memory requires real-outcome or human validation"
            )
        assignments = [f"{key} = ?" for key in selected]
        values = list(selected.values())
        assignments.append("updated_at = ?")
        values.append(utc_now())
        values.append(record_id)
        with self.conn:
            self.conn.execute(
                f"UPDATE memory_records SET {', '.join(assignments)} WHERE record_id = ?",
                values,
            )
            if next_status in {"rejected", "expired", "quarantined", "superseded"}:
                self.conn.execute(
                    "DELETE FROM memory_vectors WHERE record_id = ?", (record_id,)
                )
        self.write_memory_revision(
            record_id=record_id, actor=actor, reason=reason or "update"
        )

    def write_memory_revision(
        self,
        *,
        record_id: str,
        actor: str,
        reason: str | None = None,
    ) -> str:
        row = self.memory_record(record_id)
        if row is None:
            raise KeyError(f"memory record not found: {record_id}")
        record_json = canonical_json(dict(row))
        previous = self.conn.execute(
            """
            SELECT record_json FROM memory_revision
            WHERE record_id = ?
            ORDER BY rowid DESC
            LIMIT 1
            """,
            (record_id,),
        ).fetchone()
        previous_hash = stable_id(previous["record_json"]) if previous else None
        revision_id = stable_id(
            record_id, previous_hash or "", record_json, actor, reason or "", utc_now()
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_revision(
                  revision_id, record_id, previous_hash, record_json, actor, reason, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    revision_id,
                    record_id,
                    previous_hash,
                    record_json,
                    actor,
                    reason,
                    utc_now(),
                ),
            )
        return revision_id

    def memory_revisions(self, record_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM memory_revision
            WHERE record_id = ?
            ORDER BY rowid
            """,
            (record_id,),
        ).fetchall()

    def memory_revision(self, revision_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM memory_revision WHERE revision_id = ?", (revision_id,)
        ).fetchone()

    def enqueue_memory_review(
        self,
        *,
        record_id: str,
        reason: str,
        severity: str,
    ) -> str:
        sequence = self.conn.execute(
            "SELECT COUNT(*) FROM memory_review_queue WHERE record_id = ?", (record_id,)
        ).fetchone()[0]
        review_id = stable_id(record_id, reason, severity, utc_now(), sequence)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_review_queue(
                  review_id, record_id, reason, severity, status, created_at
                )
                VALUES (?, ?, ?, ?, 'open', ?)
                """,
                (review_id, record_id, reason, severity, utc_now()),
            )
        return review_id

    def memory_review_queue(self, status: str | None = None) -> list[sqlite3.Row]:
        if status:
            return self.conn.execute(
                """
                SELECT * FROM memory_review_queue
                WHERE status = ?
                ORDER BY severity DESC, created_at DESC
                """,
                (status,),
            ).fetchall()
        return self.conn.execute(
            """
            SELECT * FROM memory_review_queue
            ORDER BY status, severity DESC, created_at DESC
            """
        ).fetchall()

    def memory_review(self, review_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM memory_review_queue WHERE review_id = ?",
            (review_id,),
        ).fetchone()

    def resolve_memory_review(
        self,
        *,
        review_id: str,
        status: str,
        resolution: dict[str, Any],
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                UPDATE memory_review_queue
                SET status = ?, resolved_at = ?, resolution = ?
                WHERE review_id = ?
                """,
                (status, utc_now(), canonical_json(resolution), review_id),
            )

    def memory_records_by_subject(
        self,
        *,
        subject_key: str,
        type: str | None = None,
        repo_id: str | None = None,
        workspace_id: str | None = None,
    ) -> list[sqlite3.Row]:
        clauses = ["subject_key = ?"]
        params: list[Any] = [subject_key]
        if type:
            clauses.append("type = ?")
            params.append(type)
        if repo_id:
            clauses.append("(repo_id = ? OR scope = 'workspace')")
            params.append(repo_id)
        if workspace_id:
            clauses.append("workspace_id = ?")
            params.append(workspace_id)
        return self.conn.execute(
            f"""
            SELECT * FROM memory_records
            WHERE {' AND '.join(clauses)}
            ORDER BY status, confidence DESC, assertion
            """,
            params,
        ).fetchall()

    def put_memory_evidence(
        self,
        *,
        record_id: str,
        repo_id: str | None,
        path: str | None,
        symbol_identity_id: str | None,
        evidence_kind: str,
        evidence_hash: str,
        line_start: int | None = None,
        line_end: int | None = None,
        source_ref: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        evidence_id = stable_id(
            record_id,
            repo_id or "",
            path or "",
            symbol_identity_id or "",
            evidence_kind,
            evidence_hash,
            str(line_start or ""),
            str(line_end or ""),
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO memory_evidence(
                  evidence_id, record_id, repo_id, path, symbol_identity_id,
                  line_start, line_end, evidence_kind, evidence_hash,
                  source_ref, metadata_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    evidence_id,
                    record_id,
                    repo_id,
                    path,
                    symbol_identity_id,
                    line_start,
                    line_end,
                    evidence_kind,
                    evidence_hash,
                    source_ref,
                    canonical_json(metadata or {}),
                ),
            )
        return evidence_id

    def memory_evidence(self, record_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM memory_evidence
            WHERE record_id = ?
            ORDER BY path, line_start, evidence_kind
            """,
            (record_id,),
        ).fetchall()

    def append_memory_transition(
        self,
        *,
        record_id: str,
        from_status: str | None,
        to_status: str,
        actor: str,
        reason: str | None = None,
    ) -> str:
        sequence = self.conn.execute(
            "SELECT COUNT(*) FROM memory_transitions WHERE record_id = ?", (record_id,)
        ).fetchone()[0]
        transition_id = stable_id(
            record_id,
            from_status or "",
            to_status,
            actor,
            reason or "",
            utc_now(),
            sequence,
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_transitions(
                  transition_id, record_id, from_status, to_status, actor, reason, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    transition_id,
                    record_id,
                    from_status,
                    to_status,
                    actor,
                    reason,
                    utc_now(),
                ),
            )
        return transition_id

    def memory_transitions(self, record_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM memory_transitions
            WHERE record_id = ?
            ORDER BY created_at, transition_id
            """,
            (record_id,),
        ).fetchall()

    def upsert_memory_conflict(
        self,
        *,
        left_record_id: str,
        right_record_id: str,
        conflict_type: str,
        summary: str,
        status: str = "open",
    ) -> str:
        ordered = sorted([left_record_id, right_record_id])
        conflict_id = stable_id(ordered[0], ordered[1], conflict_type)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_conflicts(
                  conflict_id, left_record_id, right_record_id, conflict_type,
                  summary, status, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(conflict_id) DO UPDATE SET
                  summary=excluded.summary,
                  status=excluded.status
                """,
                (
                    conflict_id,
                    ordered[0],
                    ordered[1],
                    conflict_type,
                    summary,
                    status,
                    utc_now(),
                ),
            )
        return conflict_id

    def memory_conflicts(self, status: str | None = None) -> list[sqlite3.Row]:
        if status:
            return self.conn.execute(
                "SELECT * FROM memory_conflicts WHERE status = ? ORDER BY created_at DESC",
                (status,),
            ).fetchall()
        return self.conn.execute(
            "SELECT * FROM memory_conflicts ORDER BY status, created_at DESC"
        ).fetchall()

    def set_memory_record_status(
        self,
        *,
        record_id: str,
        status: str,
        actor: str = "system",
        reason: str | None = None,
        superseded_by: str | None = None,
        trust: str | None = None,
        provenance: dict[str, Any] | None = None,
        confidence: float | None = None,
    ) -> None:
        row = self.memory_record(record_id)
        previous = row["status"] if row else None
        actual_trust = trust or _memory_trust_for_status(status)
        actual_provenance = provenance
        if row and actual_provenance is None:
            actual_provenance = _json_dict(row["provenance_json"])
        if (
            row
            and status in {"approved", "active"}
            and actor == "system"
            and _is_unvalidated_agent_memory(actual_provenance or {})
        ):
            raise ValueError(
                "agent-generated memory requires real-outcome or human validation"
            )
        with self.conn:
            self.conn.execute(
                """
                UPDATE memory_records
                SET status = ?,
                    trust = ?,
                    confidence = COALESCE(?, confidence),
                    superseded_by = COALESCE(?, superseded_by),
                    provenance_json = COALESCE(?, provenance_json),
                    updated_at = ?
                WHERE record_id = ?
                """,
                (
                    status,
                    actual_trust,
                    confidence,
                    superseded_by,
                    (
                        canonical_json(actual_provenance)
                        if provenance is not None
                        else None
                    ),
                    utc_now(),
                    record_id,
                ),
            )
            if status in {"rejected", "expired", "quarantined", "superseded"}:
                self.conn.execute(
                    "DELETE FROM memory_vectors WHERE record_id = ?", (record_id,)
                )
        if row and previous != status:
            self.append_memory_transition(
                record_id=record_id,
                from_status=previous,
                to_status=status,
                actor=actor,
                reason=reason,
            )
            self.write_memory_revision(
                record_id=record_id, actor=actor, reason=reason or status
            )

    def memory_search(
        self,
        query: str,
        *,
        types: list[str] | None = None,
        status: str | None = None,
        repo_id: str | None = None,
        workspace_id: str | None = None,
    ) -> list[sqlite3.Row]:
        terms = [term.lower() for term in query.split() if len(term) >= 2]
        rows = self.memory_records(
            status=status,
            repo_id=repo_id,
            workspace_id=workspace_id,
        )
        results = []
        allowed = set(types or [])
        for row in rows:
            if allowed and row["type"] not in allowed:
                continue
            assertion = row["assertion"].lower()
            if not terms or any(term in assertion for term in terms):
                results.append(row)
        return sorted(
            results,
            key=lambda row: (-float(row["confidence"]), row["type"], row["assertion"]),
        )

    def put_memory_vector(
        self, *, record_id: str, dims: int, vector: list[float], model: str
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO memory_vectors(record_id, dims, vector_json, model, updated_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (record_id, dims, canonical_json(vector), model, utc_now()),
            )

    def memory_vectors(self, model: str | None = None) -> list[sqlite3.Row]:
        if model:
            return self.conn.execute(
                "SELECT * FROM memory_vectors WHERE model = ? ORDER BY record_id",
                (model,),
            ).fetchall()
        return self.conn.execute(
            "SELECT * FROM memory_vectors ORDER BY record_id"
        ).fetchall()

    def upsert_memory_association(
        self,
        *,
        record_id: str,
        target_type: str,
        target_ref: str,
        kind: str,
        weight: float = 1.0,
        evidence: dict[str, Any] | None = None,
    ) -> str:
        association_id = stable_id(record_id, target_type, target_ref, kind)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_associations(
                  association_id, record_id, target_type, target_ref, kind,
                  weight, evidence_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(association_id) DO UPDATE SET
                  weight=excluded.weight,
                  evidence_json=excluded.evidence_json
                """,
                (
                    association_id,
                    record_id,
                    target_type,
                    target_ref,
                    kind,
                    weight,
                    canonical_json(evidence or {}),
                    utc_now(),
                ),
            )
        return association_id

    def memory_associations(
        self,
        *,
        record_id: str | None = None,
        target_type: str | None = None,
        target_ref: str | None = None,
        kind: str | None = None,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if record_id:
            clauses.append("record_id = ?")
            params.append(record_id)
        if target_type:
            clauses.append("target_type = ?")
            params.append(target_type)
        if target_ref:
            clauses.append("target_ref = ?")
            params.append(target_ref)
        if kind:
            clauses.append("kind = ?")
            params.append(kind)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        return self.conn.execute(
            f"""
            SELECT * FROM memory_associations
            {where}
            ORDER BY weight DESC, target_type, target_ref
            """,
            params,
        ).fetchall()

    def upsert_memory_enforcement(
        self,
        *,
        record_id: str,
        repo_id: str | None,
        enforcement_level: str,
        severity: str,
        path_globs: list[str] | None = None,
        symbol_ids: list[str] | None = None,
        anti_patterns: list[str] | None = None,
        required_patterns: list[str] | None = None,
        rationale: str | None = None,
        remediation: str | None = None,
        status: str = "active",
        approved_by: str | None = None,
        source: str = "manual",
        directive_id: str | None = None,
    ) -> str:
        level = enforcement_level.strip().lower()
        normalized_severity = severity.strip().lower()
        normalized_status = status.strip().lower()
        if level not in {"advisory", "warn", "block"}:
            raise ValueError("enforcement_level must be advisory, warn, or block")
        if normalized_severity not in {"low", "medium", "high", "critical"}:
            raise ValueError("severity must be low, medium, high, or critical")
        if normalized_status not in {"active", "suspended", "superseded"}:
            raise ValueError("status must be active, suspended, or superseded")
        if level == "block" and not str(approved_by or "").strip():
            raise ValueError("block memory enforcement requires approved_by")
        scopes = sorted(
            {_normalize_path_glob(path) for path in path_globs or [] if path}
        )
        anti = [str(item) for item in anti_patterns or [] if str(item).strip()]
        required = [str(item) for item in required_patterns or [] if str(item).strip()]
        directive_id = directive_id or stable_id(
            record_id,
            canonical_json(scopes),
            canonical_json(anti),
            canonical_json(required),
            level,
            normalized_severity,
        )
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_enforcement(
                  directive_id, record_id, repo_id, enforcement_level, severity,
                  path_globs_json, symbol_ids_json, anti_patterns_json,
                  required_patterns_json, rationale, remediation, status,
                  approved_by, source, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(directive_id) DO UPDATE SET
                  repo_id=excluded.repo_id,
                  enforcement_level=excluded.enforcement_level,
                  severity=excluded.severity,
                  path_globs_json=excluded.path_globs_json,
                  symbol_ids_json=excluded.symbol_ids_json,
                  anti_patterns_json=excluded.anti_patterns_json,
                  required_patterns_json=excluded.required_patterns_json,
                  rationale=excluded.rationale,
                  remediation=excluded.remediation,
                  status=excluded.status,
                  approved_by=excluded.approved_by,
                  source=excluded.source,
                  updated_at=excluded.updated_at
                """,
                (
                    directive_id,
                    record_id,
                    repo_id,
                    level,
                    normalized_severity,
                    canonical_json(scopes),
                    canonical_json(symbol_ids or []),
                    canonical_json(anti),
                    canonical_json(required),
                    rationale,
                    remediation,
                    normalized_status,
                    approved_by,
                    source,
                    now,
                    now,
                ),
            )
        return directive_id

    def memory_enforcement(self, directive_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT me.*, mr.assertion, mr.confidence, mr.status AS record_status,
                   mr.type AS record_type
            FROM memory_enforcement me
            LEFT JOIN memory_records mr ON mr.record_id = me.record_id
            WHERE me.directive_id = ?
            """,
            (directive_id,),
        ).fetchone()

    def memory_enforcements(
        self,
        *,
        repo_id: str | None = None,
        status: str | None = None,
        record_id: str | None = None,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if repo_id:
            clauses.append("(me.repo_id = ? OR me.repo_id IS NULL)")
            params.append(repo_id)
        if status:
            clauses.append("me.status = ?")
            params.append(status)
        if record_id:
            clauses.append("me.record_id = ?")
            params.append(record_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        return self.conn.execute(
            f"""
            SELECT me.*, mr.assertion, mr.confidence, mr.status AS record_status,
                   mr.type AS record_type
            FROM memory_enforcement me
            LEFT JOIN memory_records mr ON mr.record_id = me.record_id
            {where}
            ORDER BY me.status, me.severity DESC, me.updated_at DESC
            """,
            params,
        ).fetchall()

    def update_memory_enforcement_status(
        self,
        directive_id: str,
        *,
        status: str,
        reason: str | None = None,
    ) -> bool:
        normalized_status = status.strip().lower()
        if normalized_status not in {"active", "suspended", "superseded"}:
            raise ValueError("status must be active, suspended, or superseded")
        with self.conn:
            result = self.conn.execute(
                """
                UPDATE memory_enforcement
                SET status = ?, updated_at = ?
                WHERE directive_id = ?
                """,
                (normalized_status, utc_now(), directive_id),
            )
        return result.rowcount > 0

    def suspend_memory_enforcements_for_record(
        self, record_id: str, *, reason: str | None = None
    ) -> int:
        with self.conn:
            result = self.conn.execute(
                """
                UPDATE memory_enforcement
                SET status = 'suspended', updated_at = ?
                WHERE record_id = ? AND status = 'active'
                """,
                (utc_now(), record_id),
            )
        return int(result.rowcount or 0)

    def directives_for_paths(
        self, paths: list[str], repo_id: str | None
    ) -> list[dict[str, Any]]:
        normalized_paths = sorted(
            {_normalize_path_glob(path) for path in paths if path}
        )
        if not normalized_paths:
            return []
        rows = self.memory_enforcements(repo_id=repo_id, status="active")
        matched: list[dict[str, Any]] = []
        for row in rows:
            if str(row["record_status"] or "") not in {"active", "approved"}:
                continue
            path_globs = _json_list(row["path_globs_json"])
            if not path_globs:
                path_globs = [
                    _normalize_path_glob(assoc["target_ref"])
                    for assoc in self.memory_associations(
                        record_id=row["record_id"], target_type="file"
                    )
                ]
            matched_path = _first_matching_path(normalized_paths, path_globs)
            if not matched_path:
                continue
            item = dict(row)
            conflicts = self.memory_conflicts_for_record(
                row["record_id"], status="open"
            )
            if conflicts and item["enforcement_level"] == "block":
                item["effective_level"] = "warn"
                item["capped_reason"] = "open_memory_conflict"
            else:
                item["effective_level"] = item["enforcement_level"]
            item["path_globs"] = path_globs
            item["symbol_ids"] = _json_list(row["symbol_ids_json"])
            item["anti_patterns"] = _json_list(row["anti_patterns_json"])
            item["required_patterns"] = _json_list(row["required_patterns_json"])
            item["matched_path"] = matched_path
            item["confidence"] = float(row["confidence"] or 0.0)
            item["has_content_matcher"] = bool(
                item["anti_patterns"] or item["required_patterns"]
            )
            matched.append(item)
        return matched

    def memory_conflicts_for_record(
        self, record_id: str, *, status: str | None = None
    ) -> list[sqlite3.Row]:
        clauses = ["(left_record_id = ? OR right_record_id = ?)"]
        params: list[Any] = [record_id, record_id]
        if status:
            clauses.append("status = ?")
            params.append(status)
        return self.conn.execute(
            f"""
            SELECT * FROM memory_conflicts
            WHERE {' AND '.join(clauses)}
            ORDER BY created_at DESC
            """,
            params,
        ).fetchall()

    def start_agent_session(
        self,
        *,
        session_id: str,
        workspace_id: str,
        repo_id: str | None,
        task_text_hash: str,
        agent_name: str | None = None,
        metadata: dict[str, Any] | None = None,
        governed_class: str | None = None,
    ) -> str:
        merged_metadata = {}
        existing = self.agent_session(session_id)
        if existing:
            try:
                parsed = json.loads(existing["metadata_json"] or "{}")
            except json.JSONDecodeError:
                parsed = {}
            if isinstance(parsed, dict):
                merged_metadata.update(parsed)
        merged_metadata.update(metadata or {})
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO agent_sessions(
                  session_id, workspace_id, repo_id, task_text_hash, agent_name,
                  started_at, ended_at, status, governed_class, metadata_json
                )
                VALUES (?, ?, ?, ?, ?, ?, NULL, 'active', ?, ?)
                ON CONFLICT(session_id) DO UPDATE SET
                  workspace_id=excluded.workspace_id,
                  repo_id=excluded.repo_id,
                  task_text_hash=excluded.task_text_hash,
                  agent_name=excluded.agent_name,
                  ended_at=NULL,
                  status='active',
                  governed_class=COALESCE(excluded.governed_class, agent_sessions.governed_class),
                  metadata_json=excluded.metadata_json
                """,
                (
                    session_id,
                    workspace_id,
                    repo_id,
                    task_text_hash,
                    agent_name,
                    utc_now(),
                    governed_class,
                    canonical_json(merged_metadata),
                ),
            )
        return session_id

    def append_agent_session_event(
        self, *, session_id: str, event_type: str, payload: dict[str, Any]
    ) -> str:
        def write() -> str:
            payload_json = canonical_json(payload)
            created_at = utc_now()
            with self.conn:
                sequence = self.conn.execute(
                    """
                    SELECT COUNT(*) AS event_count
                    FROM agent_session_events
                    WHERE session_id = ?
                    """,
                    (session_id,),
                ).fetchone()["event_count"]
                event_id = stable_id(
                    session_id, event_type, payload_json, created_at, sequence
                )
                self.conn.execute(
                    """
                    INSERT INTO agent_session_events(
                      event_id, session_id, event_type, event_time, payload_json, payload_hash
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        event_id,
                        session_id,
                        event_type,
                        created_at,
                        payload_json,
                        stable_id(payload_json),
                    ),
                )
            return event_id

        return self._execute_write(write)

    def put_agent_session_artifact(
        self,
        *,
        session_id: str,
        artifact_type: str,
        ref: str,
        content_hash: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        artifact_id = stable_id(session_id, artifact_type, ref, content_hash or "")
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO agent_session_artifacts(
                  artifact_id, session_id, artifact_type, ref, content_hash, metadata_json
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    artifact_id,
                    session_id,
                    artifact_type,
                    ref,
                    content_hash,
                    canonical_json(metadata or {}),
                ),
            )
        return artifact_id

    def finish_agent_session(
        self, *, session_id: str, status: str, metadata: dict[str, Any] | None = None
    ) -> None:
        with self.conn:
            row = self.agent_session(session_id)
            merged = {}
            if row:
                try:
                    merged = json.loads(row["metadata_json"] or "{}")
                except json.JSONDecodeError:
                    merged = {}
            merged.update(metadata or {})
            self.conn.execute(
                """
                UPDATE agent_sessions
                SET status = ?, ended_at = ?, metadata_json = ?
                WHERE session_id = ?
                """,
                (status, utc_now(), canonical_json(merged), session_id),
            )

    def agent_session(self, session_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM agent_sessions WHERE session_id = ?", (session_id,)
        ).fetchone()

    def agent_sessions(
        self,
        *,
        workspace_id: str | None = None,
        repo_id: str | None = None,
        status: str | None = None,
        limit: int = 20,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if workspace_id:
            clauses.append("workspace_id = ?")
            params.append(workspace_id)
        if repo_id:
            clauses.append("repo_id = ?")
            params.append(repo_id)
        if status:
            clauses.append("status = ?")
            params.append(status)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM agent_sessions
            {where}
            ORDER BY started_at DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def agent_session_events(self, session_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM agent_session_events
            WHERE session_id = ?
            ORDER BY event_time, rowid
            """,
            (session_id,),
        ).fetchall()

    def agent_session_artifacts(self, session_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM agent_session_artifacts
            WHERE session_id = ?
            ORDER BY artifact_type, ref
            """,
            (session_id,),
        ).fetchall()

    def agent_session_for_artifact(
        self, artifact_type: str, ref: str
    ) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT s.*
            FROM agent_session_artifacts a
            JOIN agent_sessions s ON s.session_id = a.session_id
            WHERE a.artifact_type = ? AND a.ref = ?
            ORDER BY s.started_at DESC, s.session_id
            LIMIT 1
            """,
            (artifact_type, ref),
        ).fetchone()

    def put_anticipation_model(
        self,
        *,
        repo_id: str,
        workspace_id: str | None = None,
        kind: str = "frequency_v0",
        params: dict[str, Any],
        calibration: dict[str, Any] | None = None,
        trained_on_count: int = 0,
        ece: float | None = None,
    ) -> str:
        params_json = canonical_json(params)
        calibration_json = canonical_json(calibration or {})
        params_hash = stable_id(params_json, calibration_json)
        model_id = stable_id(
            "anticipation_model", repo_id, workspace_id or "", kind, params_hash
        )

        def write() -> str:
            with self.conn:
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO anticipation_models(
                      model_id, repo_id, workspace_id, kind, params_json,
                      calibration_json, trained_on_count, ece, params_hash, created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        model_id,
                        repo_id,
                        workspace_id,
                        kind,
                        params_json,
                        calibration_json,
                        int(trained_on_count),
                        ece,
                        params_hash,
                        utc_now(),
                    ),
                )
            return model_id

        return self._execute_write(write)

    def latest_anticipation_model(
        self, *, repo_id: str, kind: str = "frequency_v0"
    ) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT * FROM anticipation_models
            WHERE repo_id = ? AND kind = ?
            ORDER BY created_at DESC, model_id DESC
            LIMIT 1
            """,
            (repo_id, kind),
        ).fetchone()

    def record_anticipation_prediction(
        self,
        *,
        repo_id: str,
        workspace_id: str | None = None,
        session_id: str | None = None,
        task_session_id: str | None = None,
        model_id: str,
        context: dict[str, Any],
        observation: dict[str, Any],
        surprise_raw: float,
        surprise: float,
        components: dict[str, Any] | None = None,
        latency_ms: float | None = None,
        timed_out: bool = False,
        source: str | None = None,
    ) -> str:
        context_json = canonical_json(context)
        observation_json = canonical_json(observation)
        components_json = canonical_json(components or {})
        context_hash = stable_id(context_json)
        audit_payload = {
            "event": "anticipation_prediction",
            "repo_id": repo_id,
            "session_id": session_id,
            "task_session_id": task_session_id,
            "model_id": model_id,
            "context_hash": context_hash,
            "observation_hash": stable_id(observation_json),
            "surprise_raw": round(float(surprise_raw), 6),
            "surprise": round(float(surprise), 6),
            "latency_ms": (
                round(float(latency_ms), 3) if latency_ms is not None else None
            ),
            "timed_out": bool(timed_out),
            "source": source,
        }
        audit_hash = stable_id(canonical_json(audit_payload))

        def write() -> str:
            created_at = utc_now()
            sequence = self.conn.execute(
                "SELECT COUNT(*) AS count FROM anticipation_predictions"
            ).fetchone()["count"]
            prediction_id = stable_id(
                "anticipation_prediction",
                repo_id,
                session_id or "",
                task_session_id or "",
                model_id,
                context_hash,
                stable_id(observation_json),
                created_at,
                sequence,
            )
            with self.conn:
                self.conn.execute(
                    """
                    INSERT INTO anticipation_predictions(
                      prediction_id, repo_id, workspace_id, session_id,
                      task_session_id, model_id, context_hash, context_json,
                      observation_json, surprise_raw, surprise, components_json,
                      latency_ms, timed_out, source, audit_hash, created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        prediction_id,
                        repo_id,
                        workspace_id,
                        session_id,
                        task_session_id,
                        model_id,
                        context_hash,
                        context_json,
                        observation_json,
                        float(surprise_raw),
                        float(surprise),
                        components_json,
                        float(latency_ms) if latency_ms is not None else None,
                        1 if timed_out else 0,
                        source,
                        audit_hash,
                        created_at,
                    ),
                )
            return prediction_id

        return self._execute_write(write)

    def update_anticipation_prediction_runtime(
        self,
        prediction_id: str,
        *,
        latency_ms: float,
        timed_out: bool,
        source: str,
    ) -> None:
        def write() -> None:
            with self.conn:
                self.conn.execute(
                    """
                    UPDATE anticipation_predictions
                    SET latency_ms = ?, timed_out = ?, source = ?
                    WHERE prediction_id = ?
                    """,
                    (
                        round(float(latency_ms), 3),
                        1 if timed_out else 0,
                        source,
                        prediction_id,
                    ),
                )

        self._execute_write(write)

    def anticipation_predictions(
        self,
        *,
        session_id: str | None = None,
        repo_id: str | None = None,
        limit: int = 100,
    ) -> list[sqlite3.Row]:
        clauses: list[str] = []
        params: list[Any] = []
        if session_id:
            clauses.append("session_id = ?")
            params.append(session_id)
        if repo_id:
            clauses.append("repo_id = ?")
            params.append(repo_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM anticipation_predictions
            {where}
            ORDER BY created_at DESC, prediction_id DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def anticipation_prediction_for_outcome(
        self,
        *,
        session_id: str | None,
        files_changed: list[str],
        outcome_created_at: str,
        max_age_seconds: int = 4 * 60 * 60,
    ) -> dict[str, Any]:
        if not session_id:
            return {"status": "no_session", "strategy": "same_session_path_time_v1"}
        wanted = {
            _normalize_artifact_path(path)
            for path in files_changed
            if str(path).strip()
        }
        rows = self.conn.execute(
            """
            SELECT *
            FROM anticipation_predictions
            WHERE session_id = ? AND created_at <= ?
            ORDER BY created_at DESC, prediction_id DESC
            LIMIT 100
            """,
            (session_id, outcome_created_at),
        ).fetchall()
        candidates = []
        outcome_time = _parse_utc_timestamp(outcome_created_at)
        for row in rows:
            observation = _json_dict(row["observation_json"])
            paths = {
                _normalize_artifact_path(path)
                for path in observation.get("target_paths", [])
                if str(path).strip()
            }
            target_dir = _normalize_artifact_path(
                str(observation.get("target_dir") or "")
            )
            matched = sorted(wanted.intersection(paths))
            if not matched and target_dir:
                matched = sorted(
                    path
                    for path in wanted
                    if path == target_dir or path.startswith(f"{target_dir}/")
                )
            if not matched:
                continue
            prediction_time = _parse_utc_timestamp(str(row["created_at"]))
            age_seconds = max(0.0, (outcome_time - prediction_time).total_seconds())
            if age_seconds > max_age_seconds:
                continue
            candidates.append(
                {
                    "prediction_id": row["prediction_id"],
                    "prediction_created_at": row["created_at"],
                    "age_seconds": round(age_seconds, 3),
                    "matched_paths": matched,
                    "surprise": float(row["surprise"] or 0.0),
                    "latency_ms": row["latency_ms"],
                    "timed_out": bool(row["timed_out"]),
                }
            )
        if not candidates:
            return {
                "status": "no_path_overlap",
                "strategy": "same_session_path_time_v1",
                "candidate_count": len(rows),
                "files_changed": sorted(wanted),
            }
        best = candidates[0]
        return {
            "status": "linked",
            "strategy": "same_session_path_time_v1",
            "candidate_count": len(candidates),
            **best,
        }

    def anticipation_outcome_links(
        self,
        *,
        repo_id: str | None = None,
        session_id: str | None = None,
        limit: int = 100,
    ) -> list[sqlite3.Row]:
        clauses: list[str] = []
        params: list[Any] = []
        if repo_id:
            clauses.append("cp.repo_id = ?")
            params.append(repo_id)
        if session_id:
            clauses.append("json_extract(o.prediction_link_json, '$.session_id') = ?")
            params.append(session_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT o.*, cp.repo_id
            FROM outcomes o
            LEFT JOIN context_packs cp ON cp.pack_id = o.pack_id
            {where}
            ORDER BY o.created_at DESC, o.outcome_id DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def record_anticipation_update(
        self,
        *,
        repo_id: str,
        session_id: str,
        signal_kind: str,
        context: dict[str, Any],
        observation: dict[str, Any],
        magnitude: float = 1.0,
        task_session_id: str | None = None,
        delta: dict[str, Any] | None = None,
    ) -> str:
        context_json = canonical_json(context)
        observation_json = canonical_json(observation)
        delta_json = canonical_json(delta or {})
        context_hash = stable_id(context_json)
        audit_payload = {
            "event": "anticipation_update",
            "repo_id": repo_id,
            "session_id": session_id,
            "signal_kind": signal_kind,
            "context_hash": context_hash,
            "observation_hash": stable_id(observation_json),
            "magnitude": round(float(magnitude), 6),
        }
        audit_hash = stable_id(canonical_json(audit_payload))

        def write() -> str:
            created_at = utc_now()
            sequence = self.conn.execute(
                "SELECT COUNT(*) AS count FROM anticipation_updates"
            ).fetchone()["count"]
            update_id = stable_id(
                "anticipation_update",
                repo_id,
                session_id,
                signal_kind,
                context_hash,
                stable_id(observation_json),
                created_at,
                sequence,
            )
            with self.conn:
                self.conn.execute(
                    """
                    INSERT INTO anticipation_updates(
                      update_id, repo_id, session_id, task_session_id, signal_kind,
                      context_hash, observation_json, magnitude, delta_json,
                      audit_hash, created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        update_id,
                        repo_id,
                        session_id,
                        task_session_id,
                        signal_kind,
                        context_hash,
                        observation_json,
                        float(magnitude),
                        delta_json,
                        audit_hash,
                        created_at,
                    ),
                )
            return update_id

        return self._execute_write(write)

    def anticipation_updates(
        self, *, session_id: str, repo_id: str | None = None
    ) -> list[sqlite3.Row]:
        clauses = ["session_id = ?"]
        params: list[Any] = [session_id]
        if repo_id:
            clauses.append("repo_id = ?")
            params.append(repo_id)
        return self.conn.execute(
            f"""
            SELECT * FROM anticipation_updates
            WHERE {' AND '.join(clauses)}
            ORDER BY created_at, update_id
            """,
            params,
        ).fetchall()

    def record_interoception_sample(
        self,
        *,
        repo_id: str,
        session_id: str,
        components: dict[str, Any],
        gut: float,
        summary: str = "",
        task_session_id: str | None = None,
    ) -> str:
        components_json = canonical_json(components)

        def write() -> str:
            created_at = utc_now()
            sequence = self.conn.execute(
                "SELECT COUNT(*) AS count FROM anticipation_interoception"
            ).fetchone()["count"]
            intero_id = stable_id(
                "anticipation_interoception",
                repo_id,
                session_id,
                task_session_id or "",
                components_json,
                created_at,
                sequence,
            )
            with self.conn:
                self.conn.execute(
                    """
                    INSERT INTO anticipation_interoception(
                      intero_id, repo_id, session_id, task_session_id,
                      components_json, gut, summary, created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        intero_id,
                        repo_id,
                        session_id,
                        task_session_id,
                        components_json,
                        float(gut),
                        summary,
                        created_at,
                    ),
                )
            return intero_id

        return self._execute_write(write)

    def anticipation_interoception(
        self, *, session_id: str, repo_id: str | None = None, limit: int = 20
    ) -> list[sqlite3.Row]:
        clauses = ["session_id = ?"]
        params: list[Any] = [session_id]
        if repo_id:
            clauses.append("repo_id = ?")
            params.append(repo_id)
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM anticipation_interoception
            WHERE {' AND '.join(clauses)}
            ORDER BY created_at DESC, intero_id DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def start_task_session(
        self,
        *,
        task_session_id: str,
        workspace_id: str,
        repo_id: str | None,
        task_text_hash: str,
        constitution_hash: str | None = None,
        metadata: dict[str, Any] | None = None,
        governed_class: str | None = None,
    ) -> str:
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO task_sessions(
                  task_session_id, workspace_id, repo_id, task_text_hash, current_state,
                  pack_id, constitution_hash, governed_class, created_at, updated_at, metadata_json
                )
                VALUES (?, ?, ?, ?, COALESCE(
                  (SELECT current_state FROM task_sessions WHERE task_session_id = ?),
                  'INTAKE'
                ), COALESCE(
                  (SELECT pack_id FROM task_sessions WHERE task_session_id = ?),
                  NULL
                ), ?, COALESCE(?, (
                  SELECT governed_class FROM task_sessions WHERE task_session_id = ?
                )), COALESCE(
                  (SELECT created_at FROM task_sessions WHERE task_session_id = ?), ?
                ), ?, ?)
                """,
                (
                    task_session_id,
                    workspace_id,
                    repo_id,
                    task_text_hash,
                    task_session_id,
                    task_session_id,
                    constitution_hash,
                    governed_class,
                    task_session_id,
                    task_session_id,
                    utc_now(),
                    utc_now(),
                    canonical_json(metadata or {}),
                ),
            )
        self.append_task_session_transition(
            task_session_id=task_session_id,
            from_state=None,
            to_state="INTAKE",
            actor="system",
            reason="task session started",
        )
        return task_session_id

    def append_task_session_transition(
        self,
        *,
        task_session_id: str,
        from_state: str | None,
        to_state: str,
        actor: str,
        reason: str | None = None,
        pack_id: str | None = None,
        constitution_hash: str | None = None,
    ) -> str:
        previous = self.conn.execute(
            """
            SELECT transition_hash
            FROM task_session_transitions
            WHERE task_session_id = ?
            ORDER BY rowid DESC
            LIMIT 1
            """,
            (task_session_id,),
        ).fetchone()
        prev_hash = previous["transition_hash"] if previous else ""
        created_at = utc_now()
        payload = canonical_json(
            {
                "task_session_id": task_session_id,
                "from_state": from_state,
                "to_state": to_state,
                "actor": actor,
                "reason": reason,
                "pack_id": pack_id,
                "constitution_hash": constitution_hash,
                "created_at": created_at,
            }
        )
        transition_hash = stable_id(prev_hash, payload)
        transition_id = stable_id(
            task_session_id, to_state, actor, reason or "", created_at
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO task_session_transitions(
                  transition_id, task_session_id, from_state, to_state, actor, reason,
                  prev_hash, transition_hash, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    transition_id,
                    task_session_id,
                    from_state,
                    to_state,
                    actor,
                    reason,
                    prev_hash,
                    transition_hash,
                    created_at,
                ),
            )
            self.conn.execute(
                """
                UPDATE task_sessions
                SET current_state = ?,
                    pack_id = COALESCE(?, pack_id),
                    constitution_hash = COALESCE(?, constitution_hash),
                    updated_at = ?
                WHERE task_session_id = ?
                """,
                (to_state, pack_id, constitution_hash, created_at, task_session_id),
            )
        return transition_id

    def task_session(self, task_session_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM task_sessions WHERE task_session_id = ?", (task_session_id,)
        ).fetchone()

    def task_session_transitions(self, task_session_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM task_session_transitions
            WHERE task_session_id = ?
            ORDER BY rowid
            """,
            (task_session_id,),
        ).fetchall()

    def write_task_plan(
        self,
        *,
        workspace_id: str,
        repo_id: str | None,
        plan_hash: str,
        plan: dict[str, Any],
        validation: dict[str, Any],
        author: str,
        task_session_id: str | None = None,
        reason: str | None = None,
        status: str = "active",
        metadata: dict[str, Any] | None = None,
        previous_plan_hash: str | None = None,
        plan_id: str | None = None,
        required_verifications: list[str] | None = None,
        governed_class: str | None = None,
    ) -> dict[str, Any]:
        plan_id = plan_id or stable_id(
            workspace_id,
            repo_id or "",
            task_session_id or "",
            plan_hash,
        )
        latest = self.conn.execute(
            """
            SELECT revision_number, plan_hash
            FROM task_plan_revisions
            WHERE plan_id = ?
            ORDER BY revision_number DESC
            LIMIT 1
            """,
            (plan_id,),
        ).fetchone()
        revision_number = 1 if latest is None else int(latest["revision_number"]) + 1
        previous_hash = previous_plan_hash
        if previous_hash is None and latest is not None:
            previous_hash = latest["plan_hash"]
        created_at = utc_now()
        revision_id = stable_id(
            plan_id, revision_number, plan_hash, previous_hash or "", created_at
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO task_plans(
                  plan_id, task_session_id, workspace_id, repo_id, plan_hash, status,
                  governed_class, required_verifications_json, current_revision_id,
                  created_at, updated_at, metadata_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(plan_id) DO UPDATE SET
                  task_session_id=excluded.task_session_id,
                  workspace_id=excluded.workspace_id,
                  repo_id=excluded.repo_id,
                  plan_hash=excluded.plan_hash,
                  status=excluded.status,
                  governed_class=excluded.governed_class,
                  required_verifications_json=excluded.required_verifications_json,
                  current_revision_id=excluded.current_revision_id,
                  updated_at=excluded.updated_at,
                  metadata_json=excluded.metadata_json
                """,
                (
                    plan_id,
                    task_session_id,
                    workspace_id,
                    repo_id,
                    plan_hash,
                    status,
                    governed_class,
                    canonical_json(required_verifications or []),
                    revision_id,
                    created_at,
                    created_at,
                    canonical_json(metadata or {}),
                ),
            )
            self.conn.execute(
                """
                INSERT INTO task_plan_revisions(
                  revision_id, plan_id, revision_number, plan_hash, previous_plan_hash,
                  author, reason, plan_json, validation_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    revision_id,
                    plan_id,
                    revision_number,
                    plan_hash,
                    previous_hash,
                    author,
                    reason,
                    canonical_json(plan),
                    canonical_json(validation),
                    created_at,
                ),
            )
            if task_session_id and governed_class:
                self.conn.execute(
                    """
                    UPDATE task_sessions
                    SET governed_class = COALESCE(governed_class, ?)
                    WHERE task_session_id = ?
                    """,
                    (governed_class, task_session_id),
                )
        return {
            "plan_id": plan_id,
            "revision_id": revision_id,
            "revision_number": revision_number,
            "plan_hash": plan_hash,
            "previous_plan_hash": previous_hash,
        }

    def task_plan(self, plan_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM task_plans WHERE plan_id = ?", (plan_id,)
        ).fetchone()

    def latest_task_plan_for_session(self, task_session_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT * FROM task_plans
            WHERE task_session_id = ?
            ORDER BY updated_at DESC, plan_id
            LIMIT 1
            """,
            (task_session_id,),
        ).fetchone()

    def task_plan_revisions(self, plan_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM task_plan_revisions
            WHERE plan_id = ?
            ORDER BY revision_number
            """,
            (plan_id,),
        ).fetchall()

    def latest_task_plan_revision(self, plan_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT * FROM task_plan_revisions
            WHERE plan_id = ?
            ORDER BY revision_number DESC
            LIMIT 1
            """,
            (plan_id,),
        ).fetchone()

    def write_ctx_health_probe(
        self,
        *,
        status: str,
        reasons: list[str],
        db_bytes: int,
        wal_bytes: int,
        last_recall_ms: float | None = None,
    ) -> dict[str, Any]:
        created_at = utc_now()
        probe_id = stable_id(
            "ctx_health",
            status,
            canonical_json(reasons),
            db_bytes,
            wal_bytes,
            last_recall_ms if last_recall_ms is not None else "",
            created_at,
            time.time_ns(),
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO ctx_health_probes(
                  probe_id, status, reasons_json, db_bytes, wal_bytes,
                  last_recall_ms, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    probe_id,
                    status,
                    canonical_json(reasons),
                    int(db_bytes),
                    int(wal_bytes),
                    last_recall_ms,
                    created_at,
                ),
            )
        return {
            "probe_id": probe_id,
            "status": status,
            "reasons": reasons,
            "db_bytes": int(db_bytes),
            "wal_bytes": int(wal_bytes),
            "last_recall_ms": last_recall_ms,
            "created_at": created_at,
        }

    def latest_ctx_health_probe(self) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT * FROM ctx_health_probes
            ORDER BY created_at DESC, rowid DESC
            LIMIT 1
            """
        ).fetchone()

    def write_task_verification(
        self,
        *,
        task_session_id: str | None,
        plan_id: str | None,
        name: str,
        command: str,
        status: str,
        report: dict[str, Any],
    ) -> dict[str, Any]:
        created_at = utc_now()
        report_json = canonical_json(report)
        audit_hash = stable_id(
            task_session_id or "",
            plan_id or "",
            name,
            command,
            status,
            report_json,
            created_at,
        )
        verification_id = str(report.get("verification_id") or audit_hash)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO task_verifications(
                  verification_id, task_session_id, plan_id, name, command, status,
                  report_json, audit_hash, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(verification_id) DO UPDATE SET
                  task_session_id=excluded.task_session_id,
                  plan_id=excluded.plan_id,
                  name=excluded.name,
                  command=excluded.command,
                  status=excluded.status,
                  report_json=excluded.report_json,
                  audit_hash=excluded.audit_hash,
                  created_at=excluded.created_at
                """,
                (
                    verification_id,
                    task_session_id,
                    plan_id,
                    name,
                    command,
                    status,
                    report_json,
                    audit_hash,
                    created_at,
                ),
            )
        return {
            "verification_id": verification_id,
            "task_session_id": task_session_id,
            "plan_id": plan_id,
            "name": name,
            "command": command,
            "status": status,
            "audit_hash": audit_hash,
            "created_at": created_at,
        }

    def task_verifications(
        self, *, task_session_id: str | None = None, plan_id: str | None = None
    ) -> list[sqlite3.Row]:
        clauses: list[str] = []
        params: list[Any] = []
        if task_session_id:
            clauses.append("task_session_id = ?")
            params.append(task_session_id)
        if plan_id:
            clauses.append("plan_id = ?")
            params.append(plan_id)
        where = "WHERE " + " AND ".join(clauses) if clauses else ""
        return self.conn.execute(
            f"""
            SELECT * FROM task_verifications
            {where}
            ORDER BY created_at DESC, verification_id
            """,
            params,
        ).fetchall()

    def record_task_plan_checkpoint(
        self,
        *,
        plan_id: str,
        step_id: str,
        status: str,
        changed_paths: list[str],
        violations: list[dict[str, Any]],
    ) -> str:
        created_at = utc_now()
        checkpoint_id = stable_id(
            plan_id,
            step_id,
            status,
            canonical_json(changed_paths),
            canonical_json(violations),
            created_at,
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO task_plan_checkpoints(
                  checkpoint_id, plan_id, step_id, status, changed_paths_json,
                  violations_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    checkpoint_id,
                    plan_id,
                    step_id,
                    status,
                    canonical_json(changed_paths),
                    canonical_json(violations),
                    created_at,
                ),
            )
        return checkpoint_id

    def task_plan_checkpoints(self, plan_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM task_plan_checkpoints
            WHERE plan_id = ?
            ORDER BY rowid
            """,
            (plan_id,),
        ).fetchall()

    def record_memory_access(
        self,
        *,
        pack_id: str,
        memory_record_id: str,
        score: float,
        signals: list[dict[str, Any]],
    ) -> str:
        access_id = stable_id(pack_id, memory_record_id, utc_now())
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_access_log(
                  access_id, pack_id, memory_record_id, served_at, score, signals_json
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    access_id,
                    pack_id,
                    memory_record_id,
                    utc_now(),
                    score,
                    canonical_json(signals),
                ),
            )
        return access_id

    def memory_accesses(self, pack_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT l.*, r.type, r.assertion
            FROM memory_access_log l
            JOIN memory_records r ON r.record_id = l.memory_record_id
            WHERE l.pack_id = ?
            ORDER BY l.score DESC, r.type, r.assertion
            """,
            (pack_id,),
        ).fetchall()

    def record_memory_utilization(
        self,
        *,
        pack_id: str,
        memory_record_id: str,
        utilization_kind: str,
        score: float,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        utilization_id = stable_id(
            pack_id,
            memory_record_id,
            utilization_kind,
            canonical_json(metadata or {}),
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO memory_utilization(
                  utilization_id, pack_id, memory_record_id, utilization_kind,
                  score, metadata_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    utilization_id,
                    pack_id,
                    memory_record_id,
                    utilization_kind,
                    score,
                    canonical_json(metadata or {}),
                    utc_now(),
                ),
            )
        return utilization_id

    def memory_utilization(self, pack_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT u.*, r.type, r.assertion
            FROM memory_utilization u
            JOIN memory_records r ON r.record_id = u.memory_record_id
            WHERE u.pack_id = ?
            ORDER BY u.score DESC, r.type, r.assertion
            """,
            (pack_id,),
        ).fetchall()

    def outcome(self, outcome_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM outcomes WHERE outcome_id = ?",
            (outcome_id,),
        ).fetchone()

    def write_learning_event(
        self,
        *,
        phase: str,
        kind: str,
        ref: str | None = None,
        payload: dict[str, Any] | None = None,
    ) -> str:
        ts = utc_now()
        event_id = stable_id(
            "learning_event",
            phase,
            kind,
            ref or "",
            canonical_json(payload or {}),
            ts,
            time.time_ns(),
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO learning_event(event_id, ts, phase, kind, ref, payload_json)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (event_id, ts, phase, kind, ref, canonical_json(payload or {})),
            )
        return event_id

    def learning_events(
        self,
        limit: int = 50,
        *,
        ref: str | None = None,
        refs: list[str] | None = None,
        since: str | None = None,
    ) -> list[sqlite3.Row]:
        clauses: list[str] = []
        params: list[Any] = []
        selected_refs = sorted({*(refs or []), *([ref] if ref else [])})
        if selected_refs:
            placeholders = ",".join("?" for _ in selected_refs)
            clauses.append(f"ref IN ({placeholders})")
            params.extend(selected_refs)
        if since:
            clauses.append("ts >= ?")
            params.append(since)
        where = "WHERE " + " AND ".join(clauses) if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM learning_event
            {where}
            ORDER BY ts DESC, event_id DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def upsert_task_learning_summary(
        self,
        *,
        task_session_id: str,
        idempotency_key: str,
        trigger: str,
        session_ids: list[str],
        counts: dict[str, Any],
        record_refs: dict[str, Any],
        narrative: str,
    ) -> str:
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO task_learning_summary(
                  task_session_id, idempotency_key, consolidated_at, trigger,
                  session_ids_json, counts_json, record_refs_json, narrative
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(task_session_id) DO UPDATE SET
                  idempotency_key = excluded.idempotency_key,
                  consolidated_at = excluded.consolidated_at,
                  trigger = excluded.trigger,
                  session_ids_json = excluded.session_ids_json,
                  counts_json = excluded.counts_json,
                  record_refs_json = excluded.record_refs_json,
                  narrative = excluded.narrative
                """,
                (
                    task_session_id,
                    idempotency_key,
                    now,
                    trigger,
                    canonical_json(session_ids),
                    canonical_json(counts),
                    canonical_json(record_refs),
                    narrative,
                ),
            )
        return task_session_id

    def task_learning_summary(self, task_session_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM task_learning_summary WHERE task_session_id = ?",
            (task_session_id,),
        ).fetchone()

    def task_learning_summaries(self, limit: int = 20) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM task_learning_summary
            ORDER BY consolidated_at DESC, task_session_id
            LIMIT ?
            """,
            (limit,),
        ).fetchall()

    def write_learning_run(
        self,
        *,
        target: str,
        kind: str,
        before: dict[str, Any],
        after: dict[str, Any],
        train_metrics: dict[str, Any] | None = None,
        holdout_metrics: dict[str, Any] | None = None,
        gate_pass: bool = False,
        archived: bool = True,
        promoted: bool = False,
        run_id: str | None = None,
    ) -> str:
        created_at = utc_now()
        run_id = run_id or stable_id(
            "learning_run",
            target,
            kind,
            canonical_json(before),
            canonical_json(after),
            created_at,
        )
        with self.conn:
            if promoted:
                self.conn.execute(
                    "UPDATE learning_run SET promoted = 0 WHERE target = ?",
                    (target,),
                )
            self.conn.execute(
                """
                INSERT OR REPLACE INTO learning_run(
                  run_id, target, kind, before_json, after_json, train_metrics_json,
                  holdout_metrics_json, gate_pass, archived, promoted, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    target,
                    kind,
                    canonical_json(before),
                    canonical_json(after),
                    canonical_json(train_metrics or {}),
                    canonical_json(holdout_metrics or {}),
                    int(gate_pass),
                    int(archived),
                    int(promoted),
                    created_at,
                ),
            )
        return run_id

    def learning_run(self, run_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM learning_run WHERE run_id = ?",
            (run_id,),
        ).fetchone()

    def learning_runs(
        self,
        *,
        target: str | None = None,
        kind: str | None = None,
        promoted: bool | None = None,
        limit: int = 50,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if target:
            clauses.append("target = ?")
            params.append(target)
        if kind:
            clauses.append("kind = ?")
            params.append(kind)
        if promoted is not None:
            clauses.append("promoted = ?")
            params.append(int(promoted))
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM learning_run
            {where}
            ORDER BY promoted DESC, gate_pass DESC, created_at DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def promoted_learning_runs(self) -> list[sqlite3.Row]:
        return self.learning_runs(promoted=True, limit=100)

    def promote_learning_run(self, run_id: str) -> None:
        row = self.learning_run(run_id)
        if row is None:
            raise KeyError(f"learning run not found: {run_id}")
        with self.conn:
            self.conn.execute(
                "UPDATE learning_run SET promoted = 0 WHERE target = ?",
                (row["target"],),
            )
            self.conn.execute(
                "UPDATE learning_run SET promoted = 1, archived = 1 WHERE run_id = ?",
                (run_id,),
            )

    def unpromote_learning_run(self, run_id: str) -> None:
        with self.conn:
            self.conn.execute(
                "UPDATE learning_run SET promoted = 0 WHERE run_id = ?",
                (run_id,),
            )

    def upsert_skill(
        self,
        *,
        skill_id: str,
        name: str,
        nl_description: str,
        trigger_signature: str,
        steps: list[dict[str, Any]],
        evidence: list[dict[str, Any]] | None = None,
        embedding_ref: str | None = None,
        provenance: dict[str, Any] | None = None,
        success_count: int = 0,
        fail_count: int = 0,
        last_validated_at: str | None = None,
        status: str = "candidate",
        trust: str = "untrusted",
    ) -> str:
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO skill(
                  skill_id, name, nl_description, trigger_signature, steps_json,
                  evidence_json, embedding_ref, provenance_json, success_count,
                  fail_count, last_validated_at, status, trust, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(skill_id) DO UPDATE SET
                  name=excluded.name,
                  nl_description=excluded.nl_description,
                  trigger_signature=excluded.trigger_signature,
                  steps_json=excluded.steps_json,
                  evidence_json=excluded.evidence_json,
                  embedding_ref=excluded.embedding_ref,
                  provenance_json=excluded.provenance_json,
                  success_count=MAX(skill.success_count, excluded.success_count),
                  fail_count=MAX(skill.fail_count, excluded.fail_count),
                  last_validated_at=COALESCE(excluded.last_validated_at, skill.last_validated_at),
                  status=excluded.status,
                  trust=excluded.trust,
                  updated_at=excluded.updated_at
                """,
                (
                    skill_id,
                    name,
                    nl_description,
                    trigger_signature,
                    canonical_json(steps),
                    canonical_json(evidence or []),
                    embedding_ref,
                    canonical_json(provenance or {}),
                    success_count,
                    fail_count,
                    last_validated_at,
                    status,
                    trust,
                    now,
                    now,
                ),
            )
        return skill_id

    def skill(self, skill_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM skill WHERE skill_id = ?", (skill_id,)
        ).fetchone()

    def skills(
        self,
        *,
        status: str | None = None,
        trust: str | None = None,
        limit: int = 100,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if status:
            clauses.append("status = ?")
            params.append(status)
        if trust:
            clauses.append("trust = ?")
            params.append(trust)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM skill
            {where}
            ORDER BY status, trust, success_count DESC, fail_count ASC, updated_at DESC, name
            LIMIT ?
            """,
            params,
        ).fetchall()

    def set_skill_status(
        self,
        *,
        skill_id: str,
        status: str,
        trust: str | None = None,
        provenance: dict[str, Any] | None = None,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                UPDATE skill
                SET status = ?,
                    trust = COALESCE(?, trust),
                    provenance_json = COALESCE(?, provenance_json),
                    updated_at = ?
                WHERE skill_id = ?
                """,
                (
                    status,
                    trust,
                    canonical_json(provenance) if provenance is not None else None,
                    utc_now(),
                    skill_id,
                ),
            )

    def record_skill_replay(
        self,
        *,
        skill_id: str,
        success: bool,
        promoted: bool = False,
        provenance: dict[str, Any] | None = None,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                UPDATE skill
                SET success_count = success_count + ?,
                    fail_count = fail_count + ?,
                    last_validated_at = CASE WHEN ? THEN ? ELSE last_validated_at END,
                    status = CASE WHEN ? THEN 'active' ELSE status END,
                    trust = CASE WHEN ? THEN 'approved' ELSE trust END,
                    provenance_json = COALESCE(?, provenance_json),
                    updated_at = ?
                WHERE skill_id = ?
                """,
                (
                    1 if success else 0,
                    0 if success else 1,
                    1 if success else 0,
                    utc_now(),
                    1 if promoted else 0,
                    1 if promoted else 0,
                    canonical_json(provenance) if provenance is not None else None,
                    utc_now(),
                    skill_id,
                ),
            )

    def upsert_artifact_output(
        self,
        *,
        output_id: str,
        repo_id: str,
        workspace_id: str,
        skill_id: str | None,
        session_id: str | None,
        task_session_id: str | None,
        artifact_kind: str,
        summary: str,
        structure: dict[str, Any] | None,
        content_hash: str,
        status: str = "produced",
        accepted_at: str | None = None,
    ) -> str:
        now = utc_now()

        def write() -> None:
            with self.conn:
                self.conn.execute(
                    """
                    INSERT INTO artifact_outputs(
                      output_id, repo_id, workspace_id, skill_id, session_id,
                      task_session_id, artifact_kind, summary, structure_json,
                      content_hash, status, created_at, accepted_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(output_id) DO UPDATE SET
                      skill_id=excluded.skill_id,
                      summary=excluded.summary,
                      structure_json=excluded.structure_json,
                      status=excluded.status,
                      accepted_at=COALESCE(excluded.accepted_at, artifact_outputs.accepted_at)
                    """,
                    (
                        output_id,
                        repo_id,
                        workspace_id,
                        skill_id,
                        session_id,
                        task_session_id,
                        artifact_kind,
                        summary,
                        canonical_json(structure or {}),
                        content_hash,
                        status,
                        now,
                        accepted_at,
                    ),
                )

        self._execute_write(write)
        return output_id

    def artifact_output(self, output_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM artifact_outputs WHERE output_id = ?", (output_id,)
        ).fetchone()

    def artifact_outputs(
        self,
        *,
        skill_id: str | None = None,
        repo_id: str | None = None,
        limit: int = 100,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if skill_id:
            clauses.append("skill_id = ?")
            params.append(skill_id)
        if repo_id:
            clauses.append("repo_id = ?")
            params.append(repo_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM artifact_outputs
            {where}
            ORDER BY created_at DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def upsert_revision_event(
        self,
        *,
        revision_id: str,
        output_id: str | None,
        repo_id: str,
        workspace_id: str,
        skill_id: str | None,
        session_id: str | None,
        task_session_id: str | None,
        event_type: str,
        signal_kind: str,
        request_summary: str,
        theme: str,
        confidence: float,
        status: str,
        actor: str,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        now = utc_now()

        def write() -> None:
            with self.conn:
                self.conn.execute(
                    """
                    INSERT INTO revision_events(
                      revision_id, output_id, repo_id, workspace_id, skill_id,
                      session_id, task_session_id, event_type, signal_kind,
                      request_summary, theme, confidence, status, actor,
                      created_at, metadata_json
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(revision_id) DO UPDATE SET
                      request_summary=excluded.request_summary,
                      theme=excluded.theme,
                      confidence=excluded.confidence,
                      status=excluded.status,
                      metadata_json=excluded.metadata_json
                    """,
                    (
                        revision_id,
                        output_id,
                        repo_id,
                        workspace_id,
                        skill_id,
                        session_id,
                        task_session_id,
                        event_type,
                        signal_kind,
                        request_summary,
                        theme,
                        confidence,
                        status,
                        actor,
                        now,
                        canonical_json(metadata or {}),
                    ),
                )

        self._execute_write(write)
        return revision_id

    def revision_event(self, revision_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM revision_events WHERE revision_id = ?", (revision_id,)
        ).fetchone()

    def revision_events(
        self,
        *,
        skill_id: str | None = None,
        repo_id: str | None = None,
        output_id: str | None = None,
        event_type: str | None = None,
        limit: int = 100,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if skill_id:
            clauses.append("skill_id = ?")
            params.append(skill_id)
        if repo_id:
            clauses.append("repo_id = ?")
            params.append(repo_id)
        if output_id:
            clauses.append("output_id = ?")
            params.append(output_id)
        if event_type:
            clauses.append("event_type = ?")
            params.append(event_type)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM revision_events
            {where}
            ORDER BY created_at DESC, revision_id
            LIMIT ?
            """,
            params,
        ).fetchall()

    def insert_skill_metric(
        self,
        *,
        repo_id: str,
        workspace_id: str,
        skill_id: str,
        usage_count: int,
        accept_first_pass_count: int,
        revised_output_count: int,
        revision_count: int,
        accept_first_pass_rate: float,
        revision_rate: float,
        avg_revisions_per_output: float,
        trend: str,
        sample_tier: str,
        themes: dict[str, Any],
    ) -> str:
        measured_at = utc_now()
        metric_id = stable_id("skill_metric", repo_id, skill_id, measured_at)

        def write() -> None:
            with self.conn:
                self.conn.execute(
                    """
                    INSERT INTO skill_metrics(
                      metric_id, repo_id, workspace_id, skill_id, usage_count,
                      accept_first_pass_count, revised_output_count, revision_count,
                      accept_first_pass_rate, revision_rate, avg_revisions_per_output,
                      trend, sample_tier, themes_json, measured_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        metric_id,
                        repo_id,
                        workspace_id,
                        skill_id,
                        usage_count,
                        accept_first_pass_count,
                        revised_output_count,
                        revision_count,
                        accept_first_pass_rate,
                        revision_rate,
                        avg_revisions_per_output,
                        trend,
                        sample_tier,
                        canonical_json(themes),
                        measured_at,
                    ),
                )
                self.conn.execute(
                    """
                    UPDATE skill
                    SET metrics_version = metrics_version + 1, last_measured_at = ?
                    WHERE skill_id = ?
                    """,
                    (measured_at, skill_id),
                )

        self._execute_write(write)
        return metric_id

    def skill_metrics(
        self, *, skill_id: str | None = None, limit: int = 100
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if skill_id:
            clauses.append("skill_id = ?")
            params.append(skill_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM skill_metrics
            {where}
            ORDER BY measured_at DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def insert_revision_classification(
        self,
        *,
        revision_id: str,
        repo_id: str,
        skill_id: str | None,
        label: str,
        attribution: str,
        route: str,
        confidence: float,
        rationale: str,
        adjudicated: bool = False,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        classification_id = stable_id(
            "revision_classification", revision_id, label, attribution, route
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO revision_classifications(
                  classification_id, revision_id, repo_id, skill_id, label,
                  attribution, route, confidence, rationale, adjudicated,
                  created_at, metadata_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    classification_id,
                    revision_id,
                    repo_id,
                    skill_id,
                    label,
                    attribution,
                    route,
                    confidence,
                    rationale,
                    int(adjudicated),
                    utc_now(),
                    canonical_json(metadata or {}),
                ),
            )
        return classification_id

    def revision_classifications(
        self,
        *,
        revision_id: str | None = None,
        skill_id: str | None = None,
        limit: int = 100,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if revision_id:
            clauses.append("revision_id = ?")
            params.append(revision_id)
        if skill_id:
            clauses.append("skill_id = ?")
            params.append(skill_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM revision_classifications
            {where}
            ORDER BY created_at DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def upsert_skill_improvement(
        self,
        *,
        repo_id: str,
        skill_id: str,
        pattern: str,
        proposed_delta: str,
        evidence_ref: str,
        status: str = "candidate",
    ) -> str:
        sir_id = stable_id("skill_improvement", repo_id, skill_id, pattern)
        now = utc_now()
        existing = self.conn.execute(
            "SELECT evidence_refs_json FROM skill_improvement_records WHERE sir_id = ?",
            (sir_id,),
        ).fetchone()
        refs = set()
        if existing:
            refs.update(json.loads(existing["evidence_refs_json"] or "[]"))
        refs.add(evidence_ref)
        ordered_refs = sorted(refs)
        count = len(ordered_refs)
        trust_tier = "high" if count >= 5 else "medium" if count >= 2 else "low"
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO skill_improvement_records(
                  sir_id, repo_id, skill_id, pattern, proposed_delta,
                  evidence_refs_json, evidence_count, trust_tier, status,
                  created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(sir_id) DO UPDATE SET
                  proposed_delta=excluded.proposed_delta,
                  evidence_refs_json=excluded.evidence_refs_json,
                  evidence_count=excluded.evidence_count,
                  trust_tier=excluded.trust_tier,
                  updated_at=excluded.updated_at
                """,
                (
                    sir_id,
                    repo_id,
                    skill_id,
                    pattern,
                    proposed_delta,
                    canonical_json(ordered_refs),
                    count,
                    trust_tier,
                    status,
                    now,
                    now,
                ),
            )
        return sir_id

    def skill_improvement(self, sir_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM skill_improvement_records WHERE sir_id = ?", (sir_id,)
        ).fetchone()

    def skill_improvements(
        self,
        *,
        skill_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if skill_id:
            clauses.append("skill_id = ?")
            params.append(skill_id)
        if status:
            clauses.append("status = ?")
            params.append(status)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM skill_improvement_records
            {where}
            ORDER BY evidence_count DESC, updated_at DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def update_skill_improvement_status(
        self, sir_id: str, status: str, *, benchmark_ref: str | None = None
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                UPDATE skill_improvement_records
                SET status = ?, benchmark_ref = COALESCE(?, benchmark_ref), updated_at = ?
                WHERE sir_id = ?
                """,
                (status, benchmark_ref, utc_now(), sir_id),
            )

    def insert_skill_version(
        self,
        *,
        skill_id: str,
        repo_id: str,
        version: int,
        guidance_hash: str,
        guidance_summary: str,
        source_sir_id: str | None = None,
        active: bool = False,
    ) -> str:
        version_id = stable_id("skill_version", repo_id, skill_id, version)
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO skill_versions(
                  version_id, skill_id, repo_id, version, guidance_hash,
                  guidance_summary, source_sir_id, active, created_at, activated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    version_id,
                    skill_id,
                    repo_id,
                    version,
                    guidance_hash,
                    guidance_summary,
                    source_sir_id,
                    int(active),
                    utc_now(),
                    utc_now() if active else None,
                ),
            )
        return version_id

    def skill_versions(self, skill_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM skill_versions
            WHERE skill_id = ?
            ORDER BY version DESC
            """,
            (skill_id,),
        ).fetchall()

    def active_skill_version(self, skill_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT * FROM skill_versions
            WHERE skill_id = ? AND active = 1
            ORDER BY version DESC
            LIMIT 1
            """,
            (skill_id,),
        ).fetchone()

    def set_active_skill_version(self, skill_id: str, version_id: str) -> None:
        with self.conn:
            self.conn.execute(
                "UPDATE skill_versions SET active = 0 WHERE skill_id = ?", (skill_id,)
            )
            self.conn.execute(
                """
                UPDATE skill_versions
                SET active = 1, activated_at = ?
                WHERE skill_id = ? AND version_id = ?
                """,
                (utc_now(), skill_id, version_id),
            )

    def insert_skill_refinement_approval(
        self,
        *,
        sir_id: str,
        repo_id: str,
        skill_id: str,
        approved_by: str,
        status: str,
        reason: str,
    ) -> str:
        approval_id = stable_id(
            "skill_refinement_approval", sir_id, approved_by, status
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO skill_refinement_approvals(
                  approval_id, sir_id, repo_id, skill_id, approved_by, status,
                  reason, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    approval_id,
                    sir_id,
                    repo_id,
                    skill_id,
                    approved_by,
                    status,
                    reason,
                    utc_now(),
                ),
            )
        return approval_id

    def insert_refinement_benchmark(
        self,
        *,
        sir_id: str,
        repo_id: str,
        skill_id: str,
        baseline_version_id: str | None,
        candidate_version_id: str | None,
        result: str,
        revision_rate_delta: float,
        regressions: int,
        details: dict[str, Any],
    ) -> str:
        benchmark_id = stable_id("refinement_benchmark", sir_id, result, utc_now())
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO refinement_benchmarks(
                  benchmark_id, sir_id, repo_id, skill_id, baseline_version_id,
                  candidate_version_id, result, revision_rate_delta, regressions,
                  details_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    benchmark_id,
                    sir_id,
                    repo_id,
                    skill_id,
                    baseline_version_id,
                    candidate_version_id,
                    result,
                    revision_rate_delta,
                    regressions,
                    canonical_json(details),
                    utc_now(),
                ),
            )
        return benchmark_id

    def refinement_benchmarks(
        self, *, sir_id: str | None = None, limit: int = 100
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if sir_id:
            clauses.append("sir_id = ?")
            params.append(sir_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM refinement_benchmarks
            {where}
            ORDER BY created_at DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def insert_skill_closure_probe(
        self,
        *,
        repo_id: str,
        skill_id: str | None,
        sir_id: str | None,
        status: str,
        details: dict[str, Any],
    ) -> str:
        probe_id = stable_id(
            "skill_closure_probe", repo_id, skill_id or "", sir_id or "", utc_now()
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO skill_closure_probes(
                  probe_id, repo_id, skill_id, sir_id, status, details_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    probe_id,
                    repo_id,
                    skill_id,
                    sir_id,
                    status,
                    canonical_json(details),
                    utc_now(),
                ),
            )
        return probe_id

    def skill_closure_probes(
        self, *, skill_id: str | None = None, limit: int = 100
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if skill_id:
            clauses.append("skill_id = ?")
            params.append(skill_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM skill_closure_probes
            {where}
            ORDER BY created_at DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def insert_skill_promotion(
        self,
        *,
        repo_id: str,
        skill_id: str,
        global_skill_id: str | None,
        direction: str,
        status: str,
        privacy_status: str,
        approver: str | None,
        details: dict[str, Any],
    ) -> str:
        promotion_id = stable_id(
            "skill_promotion", repo_id, skill_id, direction, utc_now()
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO skill_promotions(
                  promotion_id, repo_id, skill_id, global_skill_id, direction,
                  status, privacy_status, approver, details_json, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    promotion_id,
                    repo_id,
                    skill_id,
                    global_skill_id,
                    direction,
                    status,
                    privacy_status,
                    approver,
                    canonical_json(details),
                    utc_now(),
                ),
            )
        return promotion_id

    def skill_promotions(
        self, *, skill_id: str | None = None, limit: int = 100
    ) -> list[sqlite3.Row]:
        clauses = []
        params: list[Any] = []
        if skill_id:
            clauses.append("skill_id = ?")
            params.append(skill_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        return self.conn.execute(
            f"""
            SELECT * FROM skill_promotions
            {where}
            ORDER BY created_at DESC
            LIMIT ?
            """,
            params,
        ).fetchall()

    def write_intent(
        self,
        *,
        header: dict[str, Any],
        evidence: list[dict[str, Any]],
        nodes: list[dict[str, Any]],
        hypotheses: list[dict[str, Any]],
        stakeholders: list[dict[str, Any]],
        contradictions: list[dict[str, Any]],
        candidate_goals: list[dict[str, Any]],
        open_questions: list[dict[str, Any]],
    ) -> None:
        intent_id = str(header["intent_id"])
        now = utc_now()
        created_at = str(header.get("created_at") or now)
        updated_at = str(header.get("updated_at") or now)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO intents(
                  intent_id, workspace_id, repo_id, snapshot_id, problem_statement,
                  problem_text_hash, skeleton_hash, status, selected_goal_id,
                  audit_hash, prev_audit_hash, created_at, updated_at, metadata_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(intent_id) DO UPDATE SET
                  workspace_id=excluded.workspace_id,
                  repo_id=excluded.repo_id,
                  snapshot_id=excluded.snapshot_id,
                  problem_statement=excluded.problem_statement,
                  problem_text_hash=excluded.problem_text_hash,
                  skeleton_hash=excluded.skeleton_hash,
                  status=excluded.status,
                  selected_goal_id=COALESCE(excluded.selected_goal_id, intents.selected_goal_id),
                  audit_hash=excluded.audit_hash,
                  prev_audit_hash=excluded.prev_audit_hash,
                  updated_at=excluded.updated_at,
                  metadata_json=excluded.metadata_json
                """,
                (
                    intent_id,
                    header["workspace_id"],
                    header.get("repo_id"),
                    header["snapshot_id"],
                    header["problem_statement"],
                    header["problem_text_hash"],
                    header["skeleton_hash"],
                    header.get("status", "draft"),
                    header.get("selected_goal_id"),
                    header["audit_hash"],
                    header["prev_audit_hash"],
                    created_at,
                    updated_at,
                    canonical_json(header.get("metadata") or {}),
                ),
            )
            for table in (
                "intent_evidence",
                "intent_decomposition_nodes",
                "intent_hypotheses",
                "intent_stakeholders",
                "intent_contradictions",
                "intent_candidate_goals",
                "intent_open_questions",
            ):
                self.conn.execute(
                    f"DELETE FROM {table} WHERE intent_id = ?", (intent_id,)
                )
            for row in evidence:
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO intent_evidence(
                      evidence_id, intent_id, ref, source_type, repo_id, path,
                      symbol_identity_id, line_start, line_end, evidence_hash,
                      confidence, metadata_json
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        row["evidence_id"],
                        intent_id,
                        row["ref"],
                        row["source_type"],
                        row.get("repo_id"),
                        row.get("path"),
                        row.get("symbol_identity_id"),
                        row.get("line_start"),
                        row.get("line_end"),
                        row["evidence_hash"],
                        float(row.get("confidence", 1.0)),
                        canonical_json(row.get("metadata") or {}),
                    ),
                )
            for row in nodes:
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO intent_decomposition_nodes(
                      node_id, intent_id, parent_id, label, node_kind, origin,
                      status, confidence, evidence_refs_json, ordinal, created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        row["node_id"],
                        intent_id,
                        row.get("parent_id"),
                        row["label"],
                        row["node_kind"],
                        row["origin"],
                        row["status"],
                        float(row.get("confidence", 1.0)),
                        canonical_json(row.get("evidence_refs") or []),
                        int(row.get("ordinal", 0)),
                        row.get("created_at") or now,
                    ),
                )
            for row in hypotheses:
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO intent_hypotheses(
                      hypothesis_id, intent_id, statement, origin, confidence,
                      rank, verified, evidence_refs_json, signals_json, created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        row["hypothesis_id"],
                        intent_id,
                        row["statement"],
                        row["origin"],
                        float(row["confidence"]),
                        int(row["rank"]),
                        int(bool(row.get("verified", False))),
                        canonical_json(row.get("evidence_refs") or []),
                        canonical_json(row.get("signals") or {}),
                        row.get("created_at") or now,
                    ),
                )
            for row in stakeholders:
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO intent_stakeholders(
                      stakeholder_id, intent_id, owner, files_json, reason, source, confidence
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        row["stakeholder_id"],
                        intent_id,
                        row["owner"],
                        canonical_json(row.get("files") or []),
                        row["reason"],
                        row["source"],
                        float(row.get("confidence", 1.0)),
                    ),
                )
            for row in contradictions:
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO intent_contradictions(
                      contradiction_id, intent_id, a_ref, b_ref, description,
                      detector, severity, created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        row["contradiction_id"],
                        intent_id,
                        row["a_ref"],
                        row["b_ref"],
                        row["description"],
                        row["detector"],
                        row["severity"],
                        row.get("created_at") or now,
                    ),
                )
            for row in candidate_goals:
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO intent_candidate_goals(
                      goal_id, intent_id, statement, success_metric, metric_source,
                      confidence, origin, evidence_refs_json, created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        row["goal_id"],
                        intent_id,
                        row["statement"],
                        row.get("success_metric"),
                        row["metric_source"],
                        float(row["confidence"]),
                        row["origin"],
                        canonical_json(row.get("evidence_refs") or []),
                        row.get("created_at") or now,
                    ),
                )
            for row in open_questions:
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO intent_open_questions(
                      question_id, intent_id, question, reason, created_at
                    )
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (
                        row["question_id"],
                        intent_id,
                        row["question"],
                        row["reason"],
                        row.get("created_at") or now,
                    ),
                )

    def intent(self, intent_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM intents WHERE intent_id = ?", (intent_id,)
        ).fetchone()

    def intent_by_reproducibility(
        self, *, problem_text_hash: str, snapshot_id: str
    ) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM intents WHERE problem_text_hash = ? AND snapshot_id = ?",
            (problem_text_hash, snapshot_id),
        ).fetchone()

    def list_intents(
        self, *, repo_id: str | None = None, status: str | None = None, limit: int = 50
    ) -> list[sqlite3.Row]:
        where = []
        params: list[Any] = []
        if repo_id is not None:
            where.append("repo_id = ?")
            params.append(repo_id)
        if status is not None:
            where.append("status = ?")
            params.append(status)
        sql = "SELECT * FROM intents"
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY updated_at DESC, intent_id DESC LIMIT ?"
        params.append(limit)
        return self.conn.execute(sql, tuple(params)).fetchall()

    def intent_evidence(self, intent_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM intent_evidence WHERE intent_id = ? ORDER BY confidence DESC, ref",
            (intent_id,),
        ).fetchall()

    def intent_nodes(self, intent_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM intent_decomposition_nodes
            WHERE intent_id = ?
            ORDER BY COALESCE(parent_id, ''), ordinal, node_id
            """,
            (intent_id,),
        ).fetchall()

    def intent_hypotheses(self, intent_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM intent_hypotheses WHERE intent_id = ? ORDER BY rank, hypothesis_id",
            (intent_id,),
        ).fetchall()

    def intent_stakeholders(self, intent_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM intent_stakeholders WHERE intent_id = ? ORDER BY owner, stakeholder_id",
            (intent_id,),
        ).fetchall()

    def intent_contradictions(self, intent_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM intent_contradictions WHERE intent_id = ? ORDER BY severity, contradiction_id",
            (intent_id,),
        ).fetchall()

    def intent_candidate_goals(self, intent_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM intent_candidate_goals
            WHERE intent_id = ?
            ORDER BY origin = 'llm_proposed', confidence DESC, goal_id
            """,
            (intent_id,),
        ).fetchall()

    def intent_goal(self, goal_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM intent_candidate_goals WHERE goal_id = ?", (goal_id,)
        ).fetchone()

    def intent_open_questions(self, intent_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM intent_open_questions WHERE intent_id = ? ORDER BY question_id",
            (intent_id,),
        ).fetchall()

    def set_intent_selected_goal(
        self,
        *,
        intent_id: str,
        goal_id: str,
        status: str = "refined",
        audit_hash: str | None = None,
        prev_audit_hash: str | None = None,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                UPDATE intents
                SET selected_goal_id = ?,
                    status = ?,
                    audit_hash = COALESCE(?, audit_hash),
                    prev_audit_hash = COALESCE(?, prev_audit_hash),
                    updated_at = ?
                WHERE intent_id = ?
                """,
                (goal_id, status, audit_hash, prev_audit_hash, utc_now(), intent_id),
            )

    def upsert_goal(self, goal: dict[str, Any]) -> None:
        now = utc_now()
        created_at = str(goal.get("created_at") or now)
        updated_at = str(goal.get("updated_at") or now)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO goals(
                  goal_id, intent_id, workspace_id, repo_id, snapshot_id, statement,
                  success_metric, metric_kind, metric_target, hypothesis, confidence,
                  status, challenge_state, permission_mode, created_at, updated_at,
                  metadata_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(goal_id) DO UPDATE SET
                  intent_id=excluded.intent_id,
                  workspace_id=excluded.workspace_id,
                  repo_id=excluded.repo_id,
                  snapshot_id=excluded.snapshot_id,
                  statement=excluded.statement,
                  success_metric=excluded.success_metric,
                  metric_kind=excluded.metric_kind,
                  metric_target=excluded.metric_target,
                  hypothesis=excluded.hypothesis,
                  confidence=excluded.confidence,
                  status=excluded.status,
                  challenge_state=excluded.challenge_state,
                  permission_mode=excluded.permission_mode,
                  updated_at=excluded.updated_at,
                  metadata_json=excluded.metadata_json
                """,
                (
                    goal["goal_id"],
                    goal["intent_id"],
                    goal["workspace_id"],
                    goal.get("repo_id"),
                    goal.get("snapshot_id"),
                    goal["statement"],
                    goal["success_metric"],
                    goal.get("metric_kind", "technical"),
                    goal.get("metric_target"),
                    goal.get("hypothesis"),
                    float(goal.get("confidence", 0.0)),
                    goal.get("status", "proposed"),
                    goal.get("challenge_state", "none"),
                    goal.get("permission_mode", "warn"),
                    created_at,
                    updated_at,
                    canonical_json(goal.get("metadata") or {}),
                ),
            )

    def update_goal(
        self,
        goal_id: str,
        *,
        status: str | None = None,
        challenge_state: str | None = None,
        confidence: float | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        row = self.goal(goal_id)
        if row is None:
            raise KeyError(f"goal not found: {goal_id}")
        current_metadata = json.loads(row["metadata_json"] or "{}")
        if metadata:
            current_metadata.update(metadata)
        with self.conn:
            self.conn.execute(
                """
                UPDATE goals
                SET status = COALESCE(?, status),
                    challenge_state = COALESCE(?, challenge_state),
                    confidence = COALESCE(?, confidence),
                    metadata_json = ?,
                    updated_at = ?
                WHERE goal_id = ?
                """,
                (
                    status,
                    challenge_state,
                    confidence,
                    canonical_json(current_metadata),
                    utc_now(),
                    goal_id,
                ),
            )

    def goal(self, goal_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM goals WHERE goal_id = ?", (goal_id,)
        ).fetchone()

    def list_goals(
        self, *, repo_id: str | None = None, status: str | None = None, limit: int = 50
    ) -> list[sqlite3.Row]:
        where = []
        params: list[Any] = []
        if repo_id is not None:
            where.append("repo_id = ?")
            params.append(repo_id)
        if status is not None:
            where.append("status = ?")
            params.append(status)
        sql = "SELECT * FROM goals"
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY updated_at DESC, goal_id DESC LIMIT ?"
        params.append(limit)
        return self.conn.execute(sql, tuple(params)).fetchall()

    def replace_goal_evidence(self, goal_id: str, rows: list[dict[str, Any]]) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM goal_evidence WHERE goal_id = ?", (goal_id,))
            for row in rows:
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO goal_evidence(
                      evidence_id, goal_id, ref, source_type, weight, detail_json, created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        row["evidence_id"],
                        goal_id,
                        row["ref"],
                        row["source_type"],
                        float(row.get("weight", 1.0)),
                        canonical_json(row.get("detail") or {}),
                        row.get("created_at") or utc_now(),
                    ),
                )

    def goal_evidence(self, goal_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM goal_evidence WHERE goal_id = ? ORDER BY weight DESC, ref",
            (goal_id,),
        ).fetchall()

    def replace_goal_alternatives(
        self, goal_id: str, rows: list[dict[str, Any]]
    ) -> None:
        existing = {
            row["alt_id"]: row["status"]
            for row in self.conn.execute(
                "SELECT alt_id, status FROM goal_alternatives WHERE goal_id = ?",
                (goal_id,),
            ).fetchall()
        }
        with self.conn:
            self.conn.execute(
                "DELETE FROM goal_alternatives WHERE goal_id = ?", (goal_id,)
            )
            for row in rows:
                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO goal_alternatives(
                      alt_id, goal_id, statement, projected_metric_delta, rationale,
                      confidence, evidence_refs_json, rank, status, created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        row["alt_id"],
                        goal_id,
                        row["statement"],
                        canonical_json(row.get("projected_metric_delta") or {}),
                        row["rationale"],
                        float(row.get("confidence", 0.0)),
                        canonical_json(row.get("evidence_refs") or []),
                        int(row.get("rank", 0)),
                        existing.get(row["alt_id"], row.get("status", "proposed")),
                        row.get("created_at") or utc_now(),
                    ),
                )

    def goal_alternatives(self, goal_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM goal_alternatives WHERE goal_id = ? ORDER BY rank, confidence DESC, alt_id",
            (goal_id,),
        ).fetchall()

    def goal_alternative(self, alt_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM goal_alternatives WHERE alt_id = ?", (alt_id,)
        ).fetchone()

    def set_goal_alternative_status(self, alt_id: str, status: str) -> None:
        with self.conn:
            self.conn.execute(
                "UPDATE goal_alternatives SET status = ? WHERE alt_id = ?",
                (status, alt_id),
            )

    def record_goal_decision(
        self,
        *,
        goal_id: str,
        kind: str,
        actor: str,
        permission_mode: str,
        alt_id: str | None = None,
        rationale: str | None = None,
        audit_row_hash: str | None = None,
        decision_id: str | None = None,
    ) -> str:
        created_at = utc_now()
        actual_id = decision_id or stable_id(
            "goal_decision",
            goal_id,
            kind,
            alt_id or "",
            actor,
            rationale or "",
            created_at,
        )
        with self.conn:
            self.conn.execute(
                """
                INSERT OR IGNORE INTO goal_decisions(
                  decision_id, goal_id, kind, alt_id, actor, rationale,
                  permission_mode, audit_row_hash, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    actual_id,
                    goal_id,
                    kind,
                    alt_id,
                    actor,
                    rationale,
                    permission_mode,
                    audit_row_hash,
                    created_at,
                ),
            )
        return actual_id

    def goal_decisions(self, goal_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM goal_decisions WHERE goal_id = ? ORDER BY created_at, decision_id",
            (goal_id,),
        ).fetchall()

    def write_pack(
        self,
        *,
        pack_id: str,
        snapshot_id: str,
        repo_id: str,
        task_text_hash: str,
        manifest: dict[str, Any],
        reconstructible: bool,
        metadata: dict[str, Any] | None = None,
        bound_snapshot_id: str | None = None,
        binding_mode: str = "auto",
        base_commit_sha: str | None = None,
        worktree_state: str | None = None,
        staleness_state: str = "fresh",
    ) -> None:
        bound_at = utc_now()
        with self.conn:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO context_packs(
                  pack_id, snapshot_id, repo_id, task_text_hash,
                  manifest_json, reconstructible, created_at, metadata_json,
                  bound_snapshot_id, binding_mode, bound_at, base_commit_sha,
                  worktree_state, staleness_state
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    pack_id,
                    snapshot_id,
                    repo_id,
                    task_text_hash,
                    canonical_json(manifest),
                    int(reconstructible),
                    utc_now(),
                    canonical_json(metadata or {}),
                    bound_snapshot_id or snapshot_id,
                    binding_mode,
                    bound_at,
                    base_commit_sha or manifest.get("base_commit_sha"),
                    worktree_state or manifest.get("worktree_state"),
                    staleness_state,
                ),
            )

    def get_pack(self, pack_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM context_packs WHERE pack_id = ?", (pack_id,)
        ).fetchone()

    def update_pack_staleness(self, pack_id: str, staleness_state: str) -> None:
        with self.conn:
            self.conn.execute(
                "UPDATE context_packs SET staleness_state = ? WHERE pack_id = ?",
                (staleness_state, pack_id),
            )

    def append_audit(self, *, pack_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        def write() -> dict[str, Any]:
            payload_json = canonical_json(payload)
            try:
                self.conn.execute("BEGIN IMMEDIATE")
                state = self.conn.execute(
                    "SELECT tip_hash, height FROM audit_chain_state WHERE chain_id = 'default'"
                ).fetchone()
                if state is None:
                    previous = self.conn.execute(
                        "SELECT row_hash FROM audit_log ORDER BY audit_id DESC LIMIT 1"
                    ).fetchone()
                    prev_hash = previous["row_hash"] if previous else ""
                    height = self.conn.execute(
                        "SELECT COUNT(*) FROM audit_log"
                    ).fetchone()[0]
                    self.conn.execute(
                        """
                        INSERT INTO audit_chain_state(chain_id, tip_hash, height, updated_at)
                        VALUES ('default', ?, ?, ?)
                        """,
                        (prev_hash, int(height), utc_now()),
                    )
                else:
                    prev_hash = state["tip_hash"]
                    height = int(state["height"])
                row_hash = stable_id(prev_hash, payload_json)
                cur = self.conn.execute(
                    """
                    INSERT INTO audit_log(pack_id, prev_hash, row_hash, payload_json, created_at)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (pack_id, prev_hash, row_hash, payload_json, utc_now()),
                )
                self.conn.execute(
                    """
                    UPDATE audit_chain_state
                    SET tip_hash = ?, height = ?, updated_at = ?
                    WHERE chain_id = 'default'
                    """,
                    (row_hash, height + 1, utc_now()),
                )
                self.conn.commit()
            except Exception:
                self.conn.rollback()
                raise
            return {
                "audit_id": cur.lastrowid,
                "prev_hash": prev_hash,
                "row_hash": row_hash,
            }

        return self._execute_write(write)

    def audit_record(self, pack_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM audit_log WHERE pack_id = ? ORDER BY audit_id DESC LIMIT 1",
            (pack_id,),
        ).fetchone()

    def verify_audit_chain(self) -> dict[str, Any]:
        rows = self.conn.execute("SELECT * FROM audit_log ORDER BY audit_id").fetchall()
        prev_hash = ""
        expected_id = 1
        for row in rows:
            expected = stable_id(prev_hash, row["payload_json"])
            if row["audit_id"] != expected_id:
                return {
                    "ok": False,
                    "audit_id": row["audit_id"],
                    "expected": expected_id,
                    "actual": row["audit_id"],
                    "reason": "audit_id_gap",
                }
            if row["prev_hash"] != prev_hash or row["row_hash"] != expected:
                return {
                    "ok": False,
                    "audit_id": row["audit_id"],
                    "expected": expected,
                    "actual": row["row_hash"],
                }
            prev_hash = row["row_hash"]
            expected_id += 1
        state = self.conn.execute(
            "SELECT tip_hash, height FROM audit_chain_state WHERE chain_id = 'default'"
        ).fetchone()
        if state and (
            state["tip_hash"] != prev_hash or int(state["height"]) != len(rows)
        ):
            return {
                "ok": False,
                "reason": "audit_state_mismatch",
                "expected": {"tip": prev_hash, "height": len(rows)},
                "actual": {"tip": state["tip_hash"], "height": int(state["height"])},
            }
        return {"ok": True, "rows": len(rows), "tip": prev_hash}

    def acquire_session_lease(
        self,
        *,
        session_id: str,
        workspace_id: str,
        repo_id: str | None,
        agent_name: str,
        bound_snapshot_id: str | None,
        ttl_seconds: int = 3600,
    ) -> dict[str, Any]:
        now = utc_now()
        expires_at = _iso_after(now, max(60, int(ttl_seconds)))
        lease_id = stable_id(session_id, bound_snapshot_id or "", "lease")
        with self.conn:
            self.conn.execute(
                """
                UPDATE session_leases
                SET status = 'released', released_at = ?
                WHERE session_id = ? AND status = 'active' AND lease_id != ?
                """,
                (now, session_id, lease_id),
            )
            self.conn.execute(
                """
                INSERT INTO session_leases(
                  lease_id, session_id, workspace_id, repo_id, agent_name,
                  bound_snapshot_id, impact_paths_json, impact_hash, status,
                  acquired_at, renewed_at, expires_at, released_at
                )
                VALUES (?, ?, ?, ?, ?, ?, '[]', '', 'active', ?, ?, ?, NULL)
                ON CONFLICT(lease_id) DO UPDATE SET
                  workspace_id=excluded.workspace_id,
                  repo_id=excluded.repo_id,
                  agent_name=excluded.agent_name,
                  bound_snapshot_id=excluded.bound_snapshot_id,
                  status='active',
                  renewed_at=excluded.renewed_at,
                  expires_at=excluded.expires_at,
                  released_at=NULL
                """,
                (
                    lease_id,
                    session_id,
                    workspace_id,
                    repo_id,
                    agent_name,
                    bound_snapshot_id,
                    now,
                    now,
                    expires_at,
                ),
            )
        return {
            "lease_id": lease_id,
            "session_id": session_id,
            "status": "active",
            "bound_snapshot_id": bound_snapshot_id,
            "expires_at": expires_at,
        }

    def release_session_leases(self, session_id: str) -> int:
        now = utc_now()
        with self.conn:
            cur = self.conn.execute(
                """
                UPDATE session_leases
                SET status = 'released', released_at = ?
                WHERE session_id = ? AND status = 'active'
                """,
                (now, session_id),
            )
        return cur.rowcount

    def session_leases(
        self,
        *,
        workspace_id: str | None = None,
        repo_id: str | None = None,
        status: str | None = "active",
    ) -> list[sqlite3.Row]:
        clauses: list[str] = []
        params: list[Any] = []
        if workspace_id:
            clauses.append("workspace_id = ?")
            params.append(workspace_id)
        if repo_id:
            clauses.append("repo_id = ?")
            params.append(repo_id)
        if status:
            clauses.append("status = ?")
            params.append(status)
        where = "WHERE " + " AND ".join(clauses) if clauses else ""
        return self.conn.execute(
            f"""
            SELECT * FROM session_leases
            {where}
            ORDER BY renewed_at DESC, lease_id
            """,
            params,
        ).fetchall()

    def declare_session_impact(
        self, *, session_id: str, paths: list[str]
    ) -> dict[str, Any]:
        normalized = sorted(
            {path.replace("\\", "/").strip("/") for path in paths if path.strip()}
        )
        now = utc_now()
        lease = self.conn.execute(
            """
            SELECT * FROM session_leases
            WHERE session_id = ? AND status = 'active'
            ORDER BY renewed_at DESC LIMIT 1
            """,
            (session_id,),
        ).fetchone()
        if lease is None:
            raise KeyError(f"active lease not found for session: {session_id}")
        impact_hash = stable_id(canonical_json(normalized))
        with self.conn:
            self.conn.execute(
                """
                UPDATE session_leases
                SET impact_paths_json = ?, impact_hash = ?, renewed_at = ?
                WHERE lease_id = ?
                """,
                (canonical_json(normalized), impact_hash, now, lease["lease_id"]),
            )
        conflicts = self._detect_session_conflicts(dict(lease), normalized, now)
        return {
            "ok": True,
            "session_id": session_id,
            "impact_paths": normalized,
            "impact_hash": impact_hash,
            "conflicts": conflicts,
        }

    def _detect_session_conflicts(
        self, lease: dict[str, Any], paths: list[str], detected_at: str
    ) -> list[dict[str, Any]]:
        path_set = set(paths)
        if not path_set:
            return []
        peers = self.session_leases(
            workspace_id=lease["workspace_id"],
            repo_id=lease["repo_id"],
            status="active",
        )
        conflicts: list[dict[str, Any]] = []
        for peer in peers:
            if peer["session_id"] == lease["session_id"]:
                continue
            peer_paths = set(_json_list(peer["impact_paths_json"]))
            overlap = sorted(path_set & peer_paths)
            if not overlap:
                continue
            pair = sorted([lease["session_id"], peer["session_id"]])
            conflict_id = stable_id(
                pair[0], pair[1], canonical_json(overlap), "path_overlap"
            )
            both_edited = self._sessions_edited_paths(pair[0], pair[1], overlap)
            severity = "error" if both_edited else "warning"
            conflict_type = "concurrent_edit" if both_edited else "impact_overlap"
            detail = {
                "left_lease_id": lease["lease_id"],
                "right_lease_id": peer["lease_id"],
                "left_snapshot_id": lease.get("bound_snapshot_id"),
                "right_snapshot_id": peer["bound_snapshot_id"],
            }
            with self.conn:
                self.conn.execute(
                    """
                    INSERT INTO session_conflicts(
                      conflict_id, workspace_id, repo_id, left_session_id, right_session_id,
                      conflict_type, severity, status, paths_json, detail_json,
                      detected_at, updated_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'open', ?, ?, ?, ?)
                    ON CONFLICT(conflict_id) DO UPDATE SET
                      conflict_type=excluded.conflict_type,
                      severity=excluded.severity,
                      status=CASE
                        WHEN session_conflicts.status = 'resolved' THEN 'resolved'
                        ELSE 'open'
                      END,
                      detail_json=excluded.detail_json,
                      updated_at=excluded.updated_at
                    """,
                    (
                        conflict_id,
                        lease["workspace_id"],
                        lease["repo_id"],
                        pair[0],
                        pair[1],
                        conflict_type,
                        severity,
                        canonical_json(overlap),
                        canonical_json(detail),
                        detected_at,
                        detected_at,
                    ),
                )
            conflicts.append(
                {
                    "conflict_id": conflict_id,
                    "left_session_id": pair[0],
                    "right_session_id": pair[1],
                    "conflict_type": conflict_type,
                    "severity": severity,
                    "status": "open",
                    "paths": overlap,
                }
            )
        return conflicts

    def _sessions_edited_paths(
        self, left_session_id: str, right_session_id: str, paths: list[str]
    ) -> bool:
        edited: dict[str, set[str]] = {left_session_id: set(), right_session_id: set()}
        for session_id in edited:
            rows = self.agent_session_events(session_id)
            for row in rows:
                if row["event_type"] != "file_edited":
                    continue
                try:
                    payload = json.loads(row["payload_json"] or "{}")
                except json.JSONDecodeError:
                    payload = {}
                path = str(payload.get("path") or "").replace("\\", "/").strip("/")
                if path:
                    edited[session_id].add(path)
        path_set = set(paths)
        return bool(
            (edited[left_session_id] & path_set)
            and (edited[right_session_id] & path_set)
        )

    def session_conflicts(
        self,
        *,
        workspace_id: str | None = None,
        repo_id: str | None = None,
        status: str | None = "open",
    ) -> list[sqlite3.Row]:
        clauses: list[str] = []
        params: list[Any] = []
        if workspace_id:
            clauses.append("workspace_id = ?")
            params.append(workspace_id)
        if repo_id:
            clauses.append("repo_id = ?")
            params.append(repo_id)
        if status:
            clauses.append("status = ?")
            params.append(status)
        where = "WHERE " + " AND ".join(clauses) if clauses else ""
        return self.conn.execute(
            f"""
            SELECT * FROM session_conflicts
            {where}
            ORDER BY updated_at DESC, conflict_id
            """,
            params,
        ).fetchall()

    def update_session_conflict_status(
        self, conflict_id: str, status: str
    ) -> dict[str, Any]:
        if status not in {"acknowledged", "resolved", "open"}:
            raise ValueError("conflict status must be open, acknowledged, or resolved")
        now = utc_now()
        acknowledged_at = now if status == "acknowledged" else None
        resolved_at = now if status == "resolved" else None
        with self.conn:
            cur = self.conn.execute(
                """
                UPDATE session_conflicts
                SET status = ?,
                    acknowledged_at = COALESCE(?, acknowledged_at),
                    resolved_at = COALESCE(?, resolved_at),
                    updated_at = ?
                WHERE conflict_id = ?
                """,
                (status, acknowledged_at, resolved_at, now, conflict_id),
            )
        return {"ok": cur.rowcount > 0, "conflict_id": conflict_id, "status": status}

    def concurrency_stats(
        self, *, workspace_id: str | None = None, repo_id: str | None = None
    ) -> dict[str, Any]:
        leases = self.session_leases(
            workspace_id=workspace_id, repo_id=repo_id, status="active"
        )
        conflicts = self.session_conflicts(
            workspace_id=workspace_id, repo_id=repo_id, status="open"
        )
        audit_state = self.conn.execute(
            "SELECT tip_hash, height, updated_at FROM audit_chain_state WHERE chain_id = 'default'"
        ).fetchone()
        return {
            "active_leases": len(leases),
            "open_conflicts": len(conflicts),
            "audit": (
                dict(audit_state) if audit_state else {"tip_hash": "", "height": 0}
            ),
        }

    def record_outcome(
        self,
        *,
        pack_id: str,
        result: str,
        files_changed: list[str],
        linked_prediction_id: str | None = None,
        prediction_link: dict[str, Any] | None = None,
    ) -> str:
        def write() -> str:
            created_at = utc_now()
            link_json = canonical_json(prediction_link or {})
            outcome_id = stable_id(
                pack_id, result, canonical_json(files_changed), created_at
            )
            with self.conn:
                self.conn.execute(
                    """
                    INSERT INTO outcomes(
                      outcome_id, pack_id, result, files_changed_json,
                      linked_prediction_id, prediction_link_json, created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        outcome_id,
                        pack_id,
                        result,
                        canonical_json(files_changed),
                        linked_prediction_id,
                        link_json,
                        created_at,
                    ),
                )
            return outcome_id

        return self._execute_write(write)

    def delete_unreferenced_file_versions(self) -> int:
        with self.conn:
            cur = self.conn.execute(
                """
                DELETE FROM file_versions
                WHERE file_version_id NOT IN (SELECT file_version_id FROM snapshot_files)
                """
            )
        return cur.rowcount

    def delete_orphan_symbols(self) -> dict[str, int]:
        with self.conn:
            occurrences = self.conn.execute(
                """
                DELETE FROM symbol_occurrences
                WHERE file_version_id NOT IN (SELECT file_version_id FROM snapshot_files)
                """
            ).rowcount
            identities = self.conn.execute(
                """
                DELETE FROM symbol_identities
                WHERE symbol_identity_id NOT IN (
                  SELECT DISTINCT symbol_identity_id
                  FROM symbol_occurrences
                  WHERE symbol_identity_id IS NOT NULL
                )
                """
            ).rowcount
        return {
            "deleted_symbol_occurrences": occurrences,
            "deleted_symbol_identities": identities,
        }

    def _old_snapshot_ids(
        self,
        *,
        keep_snapshots: int,
        keep_snapshots_per_repo: int | None,
        pack_keep_full_days: int,
    ) -> list[str]:
        pack_cutoff = _sqlite_datetime_days_ago(pack_keep_full_days)
        protected = """
          snapshot_id NOT IN (
            SELECT snapshot_id
            FROM context_packs
            WHERE snapshot_id IS NOT NULL
              AND NOT (reconstructible = 1 AND created_at < ?)
          )
          AND snapshot_id NOT IN (SELECT snapshot_id FROM intents WHERE snapshot_id IS NOT NULL)
          AND snapshot_id NOT IN (SELECT snapshot_id FROM goals WHERE snapshot_id IS NOT NULL)
        """
        old_ids: set[str] = set()
        keep_global = max(1, int(keep_snapshots))
        keep_per_repo = max(1, int(keep_snapshots_per_repo or keep_global))
        rows = self.conn.execute(
            f"""
            SELECT snapshot_id, repo_id, created_at
            FROM snapshots
            WHERE {protected}
            ORDER BY repo_id, created_at DESC, snapshot_id DESC
            """,
            (pack_cutoff,),
        ).fetchall()
        seen_by_repo: dict[str, int] = {}
        for row in rows:
            repo_id = str(row["repo_id"])
            seen_by_repo[repo_id] = seen_by_repo.get(repo_id, 0) + 1
            if seen_by_repo[repo_id] > keep_per_repo:
                old_ids.add(row["snapshot_id"])
        global_rows = self.conn.execute(
            f"""
            SELECT snapshot_id
            FROM snapshots
            WHERE {protected}
            ORDER BY created_at DESC, snapshot_id DESC
            LIMIT -1 OFFSET ?
            """,
            (pack_cutoff, keep_global),
        ).fetchall()
        old_ids.update(row["snapshot_id"] for row in global_rows)
        return sorted(old_ids)

    def prune_snapshots(
        self, snapshot_ids: list[str], *, dry_run: bool = False
    ) -> dict[str, int]:
        snapshot_ids = sorted(set(snapshot_ids))
        if not snapshot_ids:
            return {
                "deleted_chunks": 0,
                "deleted_chunk_vectors": 0,
                "deleted_chunk_vector_rows": 0,
                "deleted_fts_rows": 0,
                "deleted_edges": 0,
                "deleted_snapshot_files": 0,
                "deleted_snapshots": 0,
                "deleted_vec0_rows": 0,
            }
        placeholders = ",".join("?" for _ in snapshot_ids)
        chunk_subquery = (
            f"SELECT chunk_id FROM chunks WHERE snapshot_id IN ({placeholders})"
        )
        counts = {
            "deleted_chunks": int(
                self.conn.execute(
                    f"SELECT COUNT(*) FROM chunks WHERE snapshot_id IN ({placeholders})",
                    snapshot_ids,
                ).fetchone()[0]
            ),
            "deleted_chunk_vectors": int(
                self.conn.execute(
                    f"SELECT COUNT(*) FROM chunk_vectors WHERE chunk_id IN ({chunk_subquery})",
                    snapshot_ids,
                ).fetchone()[0]
            ),
            "deleted_chunk_vector_rows": int(
                self.conn.execute(
                    f"SELECT COUNT(*) FROM chunk_vector_rows WHERE chunk_id IN ({chunk_subquery})",
                    snapshot_ids,
                ).fetchone()[0]
            ),
            "deleted_fts_rows": int(
                self.conn.execute(
                    f"SELECT COUNT(*) FROM chunks_fts WHERE chunk_id IN ({chunk_subquery})",
                    snapshot_ids,
                ).fetchone()[0]
            ),
            "deleted_edges": int(
                self.conn.execute(
                    f"SELECT COUNT(*) FROM edges WHERE scope_snapshot_id IN ({placeholders})",
                    snapshot_ids,
                ).fetchone()[0]
            ),
            "deleted_snapshot_files": int(
                self.conn.execute(
                    f"SELECT COUNT(*) FROM snapshot_files WHERE snapshot_id IN ({placeholders})",
                    snapshot_ids,
                ).fetchone()[0]
            ),
            "deleted_snapshots": int(
                self.conn.execute(
                    f"SELECT COUNT(*) FROM snapshots WHERE snapshot_id IN ({placeholders})",
                    snapshot_ids,
                ).fetchone()[0]
            ),
            "deleted_vec0_rows": 0,
        }
        if dry_run:
            return counts
        with self.conn:
            if self.sqlite_vec_loaded:
                rowids = self.conn.execute(
                    f"""
                    SELECT vec_rowid, dims
                    FROM chunk_vector_rows
                    WHERE chunk_id IN ({chunk_subquery})
                    """,
                    snapshot_ids,
                ).fetchall()
                by_dims: dict[int, list[int]] = {}
                for row in rowids:
                    by_dims.setdefault(int(row["dims"]), []).append(
                        int(row["vec_rowid"])
                    )
                for dims, ids in by_dims.items():
                    for start in range(0, len(ids), 1000):
                        batch = ids[start : start + 1000]
                        ids_placeholders = ",".join("?" for _ in batch)
                        cur = self.conn.execute(
                            f"DELETE FROM {self._vec_table(dims)} WHERE rowid IN ({ids_placeholders})",
                            batch,
                        )
                        counts["deleted_vec0_rows"] += cur.rowcount
            self.conn.execute(
                f"DELETE FROM chunks_fts WHERE chunk_id IN ({chunk_subquery})",
                snapshot_ids,
            )
            self.conn.execute(
                f"DELETE FROM chunk_vector_rows WHERE chunk_id IN ({chunk_subquery})",
                snapshot_ids,
            )
            self.conn.execute(
                f"DELETE FROM chunk_vectors WHERE chunk_id IN ({chunk_subquery})",
                snapshot_ids,
            )
            self.conn.execute(
                f"DELETE FROM chunks WHERE snapshot_id IN ({placeholders})",
                snapshot_ids,
            )
            self.conn.execute(
                f"DELETE FROM edges WHERE scope_snapshot_id IN ({placeholders})",
                snapshot_ids,
            )
            self.conn.execute(
                f"DELETE FROM snapshot_files WHERE snapshot_id IN ({placeholders})",
                snapshot_ids,
            )
            self.conn.execute(
                f"DELETE FROM snapshots WHERE snapshot_id IN ({placeholders})",
                snapshot_ids,
            )
        return counts

    def _count_orphan_chunks(self) -> int:
        return int(
            self.conn.execute(
                """
                SELECT COUNT(*) FROM chunks
                WHERE snapshot_id NOT IN (SELECT snapshot_id FROM snapshots)
                """
            ).fetchone()[0]
        )

    def _count_orphan_snapshot_edges(self) -> int:
        return int(
            self.conn.execute(
                """
                SELECT COUNT(*) FROM edges
                WHERE scope_snapshot_id IS NOT NULL
                  AND scope_snapshot_id NOT IN (SELECT snapshot_id FROM snapshots)
                """
            ).fetchone()[0]
        )

    def _count_sessions_to_prune(self, *, max_sessions: int) -> int:
        return int(
            self.conn.execute(
                """
                SELECT COUNT(*) FROM agent_sessions
                WHERE session_id NOT IN (
                  SELECT session_id
                  FROM agent_sessions
                  ORDER BY started_at DESC
                  LIMIT ?
                )
                """,
                (max(1, int(max_sessions)),),
            ).fetchone()[0]
        )

    def _count_session_events_to_prune(
        self, *, max_sessions: int, max_session_events: int
    ) -> int:
        stale_sessions = int(
            self.conn.execute(
                """
                SELECT COUNT(*) FROM agent_session_events
                WHERE session_id NOT IN (
                  SELECT session_id
                  FROM agent_sessions
                  ORDER BY started_at DESC
                  LIMIT ?
                )
                """,
                (max(1, int(max_sessions)),),
            ).fetchone()[0]
        )
        stale_events = int(
            self.conn.execute(
                """
                SELECT COUNT(*) FROM agent_session_events
                WHERE event_id NOT IN (
                  SELECT event_id
                  FROM agent_session_events
                  ORDER BY event_time DESC, event_id DESC
                  LIMIT ?
                )
                """,
                (max(1, int(max_session_events)),),
            ).fetchone()[0]
        )
        return max(stale_sessions, stale_events)

    def retention_policies(self) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM retention_policies ORDER BY target"
        ).fetchall()

    def upsert_retention_policy(
        self,
        *,
        target: str,
        keep_full_days: int | None = None,
        keep_summary_days: int | None = None,
        max_rows: int | None = None,
        scope: str = "global",
    ) -> str:
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO retention_policies(
                  target, keep_full_days, keep_summary_days, max_rows, scope, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(target) DO UPDATE SET
                  keep_full_days=excluded.keep_full_days,
                  keep_summary_days=excluded.keep_summary_days,
                  max_rows=excluded.max_rows,
                  scope=excluded.scope,
                  updated_at=excluded.updated_at
                """,
                (target, keep_full_days, keep_summary_days, max_rows, scope, utc_now()),
            )
        return target

    def _count_policy_prunable_rows(self, *, pack_keep_full_days: int) -> int:
        cutoff = _sqlite_datetime_days_ago(pack_keep_full_days)
        return int(
            self.conn.execute(
                """
                SELECT COUNT(*) FROM context_packs
                WHERE created_at < ?
                  AND (
                    metadata_json != '{}'
                    OR (reconstructible = 1 AND snapshot_id IS NOT NULL)
                  )
                """,
                (cutoff,),
            ).fetchone()[0]
        )

    def apply_retention_policies(
        self, *, pack_keep_full_days: int, dry_run: bool = False
    ) -> dict[str, int]:
        cutoff = _sqlite_datetime_days_ago(pack_keep_full_days)
        policy_rows = self._count_policy_prunable_rows(
            pack_keep_full_days=pack_keep_full_days
        )
        metadata_rows = int(
            self.conn.execute(
                """
                SELECT COUNT(*) FROM context_packs
                WHERE created_at < ? AND metadata_json != '{}'
                """,
                (cutoff,),
            ).fetchone()[0]
        )
        unpin_rows = int(
            self.conn.execute(
                """
                SELECT COUNT(*) FROM context_packs
                WHERE created_at < ?
                  AND reconstructible = 1
                  AND snapshot_id IS NOT NULL
                """,
                (cutoff,),
            ).fetchone()[0]
        )
        if dry_run:
            return {
                "policy_prunable_rows": policy_rows,
                "metadata_stripped_context_packs": metadata_rows,
                "unpinned_context_packs": unpin_rows,
            }
        with self.conn:
            metadata_cur = self.conn.execute(
                """
                UPDATE context_packs
                SET metadata_json = '{}'
                WHERE created_at < ? AND metadata_json != '{}'
                """,
                (cutoff,),
            )
            unpin_cur = self.conn.execute(
                """
                UPDATE context_packs
                SET bound_snapshot_id = COALESCE(bound_snapshot_id, snapshot_id),
                    snapshot_id = NULL
                WHERE created_at < ?
                  AND reconstructible = 1
                  AND snapshot_id IS NOT NULL
                """,
                (cutoff,),
            )
        return {
            "policy_prunable_rows": policy_rows,
            "metadata_stripped_context_packs": metadata_cur.rowcount,
            "unpinned_context_packs": unpin_cur.rowcount,
        }

    def _estimate_reclaim_bytes(self, snapshot_ids: list[str]) -> int:
        if not snapshot_ids:
            return 0
        placeholders = ",".join("?" for _ in snapshot_ids)
        row = self.conn.execute(
            f"""
            SELECT
              COALESCE(SUM(LENGTH(c.text)), 0) AS text_bytes,
              COALESCE(SUM(LENGTH(v.vector_json)), 0) AS vector_json_bytes,
              COALESCE(SUM(LENGTH(v.vector_blob)), 0) AS vector_blob_bytes
            FROM chunks c
            LEFT JOIN chunk_vectors v ON v.chunk_id = c.chunk_id
            WHERE c.snapshot_id IN ({placeholders})
            """,
            snapshot_ids,
        ).fetchone()
        return (
            int(row["text_bytes"] or 0)
            + int(row["vector_json_bytes"] or 0)
            + int(row["vector_blob_bytes"] or 0)
        )

    def compact(
        self,
        *,
        into_threshold_bytes: int = 1_000_000_000,
        min_free_ratio: float = 0.10,
    ) -> dict[str, Any]:
        page_count = int(self.conn.execute("PRAGMA page_count").fetchone()[0])
        freelist_count = int(self.conn.execute("PRAGMA freelist_count").fetchone()[0])
        free_ratio = (freelist_count / page_count) if page_count else 0.0
        if free_ratio < float(min_free_ratio):
            return {
                "method": "skipped",
                "reason": "insufficient_free_ratio",
                "page_count": page_count,
                "freelist_count": freelist_count,
                "free_ratio": round(free_ratio, 6),
            }
        size = self.db_path.stat().st_size if self.db_path.exists() else 0
        self.conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        if size > int(into_threshold_bytes):
            dest = self.db_path.with_suffix(self.db_path.suffix + ".compact")
            result = self.compact_into(dest)
            result.update(
                {
                    "page_count": page_count,
                    "freelist_count": freelist_count,
                    "free_ratio": round(free_ratio, 6),
                }
            )
            return result
        self.conn.execute("VACUUM")
        return {
            "method": "vacuum",
            "page_count": page_count,
            "freelist_count": freelist_count,
            "free_ratio": round(free_ratio, 6),
        }

    def compact_into(self, dest_path: Path) -> dict[str, Any]:
        def cleanup_sidecar() -> tuple[bool, str | None]:
            if not dest_path.exists():
                return False, None
            try:
                dest_path.unlink()
                return True, None
            except OSError as exc:
                return False, str(exc)

        cleanup_sidecar()
        try:
            self.conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            self.conn.execute("VACUUM INTO ?", (str(dest_path),))
            check = sqlite3.connect(str(dest_path))
            try:
                integrity = check.execute("PRAGMA integrity_check").fetchone()[0]
            finally:
                check.close()
            if integrity != "ok":
                removed, cleanup_error = cleanup_sidecar()
                return {
                    "method": "vacuum_into_failed",
                    "dest_path": str(dest_path),
                    "integrity_check": integrity,
                    "swap_required": False,
                    "error": "compact copy failed integrity_check",
                    "sidecar_removed": removed,
                    "sidecar_cleanup_error": cleanup_error,
                }
        except (sqlite3.Error, OSError) as exc:
            removed, cleanup_error = cleanup_sidecar()
            return {
                "method": "vacuum_into_failed",
                "dest_path": str(dest_path),
                "swap_required": False,
                "error": str(exc),
                "sidecar_removed": removed,
                "sidecar_cleanup_error": cleanup_error,
            }
        return {
            "method": "vacuum_into",
            "dest_path": str(dest_path),
            "integrity_check": integrity,
            "swap_required": True,
            "bytes_compact": dest_path.stat().st_size if dest_path.exists() else 0,
        }

    def maintenance_state(self) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM maintenance_state WHERE id = 1"
        ).fetchone()

    def update_maintenance_state(
        self, *, full: bool, degraded_auto_gc: bool = False
    ) -> None:
        now = utc_now()
        with self.conn:
            self.conn.execute("INSERT OR IGNORE INTO maintenance_state(id) VALUES (1)")
            self.conn.execute(
                """
                UPDATE maintenance_state
                SET last_maintenance_at = ?,
                    last_light_maintenance_at = CASE WHEN ? THEN last_light_maintenance_at ELSE ? END,
                    last_degraded_auto_gc_at = CASE WHEN ? THEN ? ELSE last_degraded_auto_gc_at END
                WHERE id = 1
                """,
                (now, int(full), now, int(degraded_auto_gc), now),
            )

    def insert_maintenance_run(
        self,
        *,
        trigger: str,
        mode: str,
        status: str,
        counts: dict[str, Any],
        bytes_before: int,
        bytes_after: int,
        compact: dict[str, Any],
        duration_ms: float,
    ) -> str:
        run_id = stable_id("maintenance_run", trigger, mode, utc_now())
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO maintenance_runs(
                  maintenance_run_id, trigger, mode, status, counts_json,
                  bytes_before, bytes_after, compact_json, duration_ms, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    trigger,
                    mode,
                    status,
                    canonical_json(counts),
                    bytes_before,
                    bytes_after,
                    canonical_json(compact),
                    duration_ms,
                    utc_now(),
                ),
            )
        return run_id

    def maintenance_runs(self, *, limit: int = 50) -> list[sqlite3.Row]:
        return self.conn.execute(
            """
            SELECT * FROM maintenance_runs
            ORDER BY created_at DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()

    def db_stats(self, *, limit: int = 25) -> dict[str, Any]:
        page_count = int(self.conn.execute("PRAGMA page_count").fetchone()[0])
        freelist_count = int(self.conn.execute("PRAGMA freelist_count").fetchone()[0])
        page_size = int(self.conn.execute("PRAGMA page_size").fetchone()[0])
        objects: list[dict[str, Any]] = []
        dbstat_available = True
        try:
            rows = self.conn.execute(
                """
                SELECT name AS object, SUM(pgsize) AS bytes, COUNT(*) AS pages
                FROM dbstat
                GROUP BY name
                ORDER BY bytes DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
            objects = [dict(row) for row in rows]
        except sqlite3.Error:
            dbstat_available = False
        row_counts: dict[str, int] = {}
        for table in (
            "snapshots",
            "chunks",
            "chunk_vectors",
            "chunk_vector_rows",
            "edges",
            "context_packs",
            "agent_sessions",
            "agent_session_events",
            "chunks_fts",
        ):
            try:
                row_counts[table] = int(
                    self.conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                )
            except sqlite3.Error:
                row_counts[table] = 0
        wal_path = Path(str(self.db_path) + "-wal")
        return {
            "ok": True,
            "db_path": str(self.db_path),
            "db_bytes": self.db_path.stat().st_size if self.db_path.exists() else 0,
            "wal_bytes": wal_path.stat().st_size if wal_path.exists() else 0,
            "page_size": page_size,
            "page_count": page_count,
            "freelist_count": freelist_count,
            "freelist_ratio": (
                round(freelist_count / page_count, 6) if page_count else 0.0
            ),
            "dbstat_available": dbstat_available,
            "objects": objects,
            "row_counts": row_counts,
        }

    def optimize_query_planner(self) -> dict[str, Any]:
        start = time.perf_counter()
        analyze_ran = False
        optimize_ran = False
        errors: list[str] = []
        try:
            self.conn.execute("ANALYZE")
            analyze_ran = True
        except sqlite3.Error as exc:
            errors.append(f"analyze:{exc}")
        try:
            self.conn.execute("PRAGMA optimize")
            optimize_ran = True
        except sqlite3.Error as exc:
            errors.append(f"optimize:{exc}")
        return {
            "analyze_ran": analyze_ran,
            "optimize_ran": optimize_ran,
            "errors": errors,
            "duration_ms": round((time.perf_counter() - start) * 1000, 3),
        }

    def _ensure_cold_archive_schema(self, conn: sqlite3.Connection) -> None:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS cold_snapshots(
              snapshot_id TEXT PRIMARY KEY,
              repo_id TEXT NOT NULL,
              archived_at TEXT NOT NULL,
              payload_json TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS cold_snapshot_files(
              snapshot_id TEXT NOT NULL,
              path TEXT NOT NULL,
              file_version_id TEXT NOT NULL,
              PRIMARY KEY (snapshot_id, path)
            );

            CREATE TABLE IF NOT EXISTS cold_chunks(
              chunk_id TEXT PRIMARY KEY,
              snapshot_id TEXT NOT NULL,
              repo_id TEXT NOT NULL,
              path TEXT NOT NULL,
              symbol_identity_id TEXT,
              category TEXT NOT NULL,
              start_line INTEGER,
              end_line INTEGER,
              text TEXT NOT NULL,
              token_count INTEGER NOT NULL,
              text_normalized TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_cold_chunks_snapshot_path
              ON cold_chunks(snapshot_id, path);

            CREATE VIRTUAL TABLE IF NOT EXISTS cold_chunks_fts USING fts5(
              chunk_id UNINDEXED,
              text_normalized
            );

            CREATE TABLE IF NOT EXISTS cold_chunk_vectors(
              chunk_id TEXT PRIMARY KEY,
              dims INTEGER NOT NULL,
              vector_json TEXT NOT NULL,
              model TEXT NOT NULL,
              vector_blob BLOB,
              encoding TEXT NOT NULL DEFAULT 'json',
              scale REAL
            );

            CREATE TABLE IF NOT EXISTS cold_edges(
              edge_id TEXT PRIMARY KEY,
              scope_snapshot_id TEXT,
              src_repo_id TEXT NOT NULL,
              src_node_type TEXT NOT NULL,
              src_node_id TEXT NOT NULL,
              dst_repo_id TEXT NOT NULL,
              dst_node_type TEXT NOT NULL,
              dst_node_id TEXT NOT NULL,
              kind TEXT NOT NULL,
              confidence REAL NOT NULL DEFAULT 1.0,
              metadata_json TEXT NOT NULL DEFAULT '{}'
            );

            CREATE INDEX IF NOT EXISTS idx_cold_edges_src
              ON cold_edges(src_repo_id, src_node_type, src_node_id, kind);
            CREATE INDEX IF NOT EXISTS idx_cold_edges_dst
              ON cold_edges(dst_repo_id, dst_node_type, dst_node_id, kind);
            CREATE INDEX IF NOT EXISTS idx_cold_edges_scope
              ON cold_edges(scope_snapshot_id);
            """
        )

    def _write_cold_snapshot_rows(
        self,
        archive: sqlite3.Connection,
        *,
        snapshot_id: str,
        files: list[dict[str, Any]],
        chunks: list[dict[str, Any]],
        vectors: list[dict[str, Any]],
        edges: list[dict[str, Any]],
    ) -> None:
        archive.execute(
            """
            DELETE FROM cold_chunks_fts
            WHERE chunk_id IN (
              SELECT chunk_id FROM cold_chunks WHERE snapshot_id = ?
            )
            """,
            (snapshot_id,),
        )
        archive.execute(
            """
            DELETE FROM cold_chunk_vectors
            WHERE chunk_id IN (
              SELECT chunk_id FROM cold_chunks WHERE snapshot_id = ?
            )
            """,
            (snapshot_id,),
        )
        archive.execute(
            "DELETE FROM cold_chunks WHERE snapshot_id = ?",
            (snapshot_id,),
        )
        archive.execute(
            "DELETE FROM cold_edges WHERE scope_snapshot_id = ?",
            (snapshot_id,),
        )
        archive.execute(
            "DELETE FROM cold_snapshot_files WHERE snapshot_id = ?",
            (snapshot_id,),
        )
        archive.executemany(
            """
            INSERT OR REPLACE INTO cold_snapshot_files(
              snapshot_id, path, file_version_id
            )
            VALUES (?, ?, ?)
            """,
            [
                (
                    row["snapshot_id"],
                    row["path"],
                    row["file_version_id"],
                )
                for row in files
                if row.get("snapshot_id") and row.get("path")
            ],
        )
        archive.executemany(
            """
            INSERT OR REPLACE INTO cold_chunks(
              chunk_id, snapshot_id, repo_id, path, symbol_identity_id,
              category, start_line, end_line, text, token_count,
              text_normalized
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [
                (
                    row["chunk_id"],
                    row["snapshot_id"],
                    row["repo_id"],
                    row["path"],
                    row.get("symbol_identity_id"),
                    row["category"],
                    row.get("start_line"),
                    row.get("end_line"),
                    row["text"],
                    row["token_count"],
                    str(row["text"]).lower(),
                )
                for row in chunks
                if row.get("chunk_id") and row.get("snapshot_id")
            ],
        )
        archive.executemany(
            """
            INSERT INTO cold_chunks_fts(chunk_id, text_normalized)
            VALUES (?, ?)
            """,
            [
                (row["chunk_id"], str(row["text"]).lower())
                for row in chunks
                if row.get("chunk_id") and row.get("text") is not None
            ],
        )
        archive.executemany(
            """
            INSERT OR REPLACE INTO cold_chunk_vectors(
              chunk_id, dims, vector_json, model, vector_blob, encoding, scale
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            [
                (
                    row["chunk_id"],
                    row["dims"],
                    row["vector_json"],
                    row["model"],
                    row.get("vector_blob"),
                    row.get("encoding", "json"),
                    row.get("scale"),
                )
                for row in vectors
                if row.get("chunk_id")
            ],
        )
        archive.executemany(
            """
            INSERT OR REPLACE INTO cold_edges(
              edge_id, scope_snapshot_id, src_repo_id, src_node_type,
              src_node_id, dst_repo_id, dst_node_type, dst_node_id,
              kind, confidence, metadata_json
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [
                (
                    row["edge_id"],
                    row.get("scope_snapshot_id"),
                    row["src_repo_id"],
                    row["src_node_type"],
                    row["src_node_id"],
                    row["dst_repo_id"],
                    row["dst_node_type"],
                    row["dst_node_id"],
                    row["kind"],
                    row.get("confidence", 1.0),
                    row.get("metadata_json", "{}"),
                )
                for row in edges
                if row.get("edge_id")
            ],
        )

    def archive_snapshots(
        self, snapshot_ids: Iterable[str], archive_db_path: Path
    ) -> dict[str, Any]:
        ids = [snapshot_id for snapshot_id in snapshot_ids if snapshot_id]
        if not ids:
            return {
                "enabled": True,
                "archived_snapshots": 0,
                "archive_db_path": str(archive_db_path),
            }
        self.cold_archive_path = archive_db_path
        archive_db_path.parent.mkdir(parents=True, exist_ok=True)
        archive = sqlite3.connect(str(archive_db_path), timeout=10.0)
        try:
            archive.execute("PRAGMA journal_mode=WAL")
            archive.execute("PRAGMA synchronous=NORMAL")
            self._ensure_cold_archive_schema(archive)
            archived = 0
            archived_chunks = 0
            archived_vectors = 0
            archived_edges = 0
            for snapshot_id in ids:
                snapshot = self.conn.execute(
                    "SELECT * FROM snapshots WHERE snapshot_id = ?", (snapshot_id,)
                ).fetchone()
                if not snapshot:
                    continue
                chunks = [
                    dict(row)
                    for row in self.conn.execute(
                        "SELECT * FROM chunks WHERE snapshot_id = ? ORDER BY path, start_line",
                        (snapshot_id,),
                    ).fetchall()
                ]
                files = [
                    dict(row)
                    for row in self.conn.execute(
                        "SELECT * FROM snapshot_files WHERE snapshot_id = ? ORDER BY path",
                        (snapshot_id,),
                    ).fetchall()
                ]
                vectors = [
                    dict(row)
                    for row in self.conn.execute(
                        """
                        SELECT v.*
                        FROM chunk_vectors v
                        JOIN chunks c ON c.chunk_id = v.chunk_id
                        WHERE c.snapshot_id = ?
                        ORDER BY v.chunk_id
                        """,
                        (snapshot_id,),
                    ).fetchall()
                ]
                edges = [
                    dict(row)
                    for row in self.conn.execute(
                        """
                        SELECT *
                        FROM edges
                        WHERE scope_snapshot_id = ?
                        ORDER BY src_node_type, src_node_id, kind, dst_node_type, dst_node_id
                        """,
                        (snapshot_id,),
                    ).fetchall()
                ]
                payload = {
                    "snapshot": dict(snapshot),
                    "snapshot_files": files,
                    "chunks": chunks,
                    "edges": edges,
                }
                archive.execute(
                    """
                    INSERT OR REPLACE INTO cold_snapshots(
                      snapshot_id, repo_id, archived_at, payload_json
                    )
                    VALUES (?, ?, ?, ?)
                    """,
                    (
                        snapshot_id,
                        snapshot["repo_id"],
                        utc_now(),
                        canonical_json(payload),
                    ),
                )
                archive.execute(
                    """
                    DELETE FROM cold_chunks_fts
                    WHERE chunk_id IN (
                      SELECT chunk_id FROM cold_chunks WHERE snapshot_id = ?
                    )
                    """,
                    (snapshot_id,),
                )
                archive.execute(
                    """
                    DELETE FROM cold_chunk_vectors
                    WHERE chunk_id IN (
                      SELECT chunk_id FROM cold_chunks WHERE snapshot_id = ?
                    )
                    """,
                    (snapshot_id,),
                )
                archive.execute(
                    "DELETE FROM cold_chunks WHERE snapshot_id = ?",
                    (snapshot_id,),
                )
                archive.execute(
                    "DELETE FROM cold_edges WHERE scope_snapshot_id = ?",
                    (snapshot_id,),
                )
                archive.execute(
                    "DELETE FROM cold_snapshot_files WHERE snapshot_id = ?",
                    (snapshot_id,),
                )
                archive.executemany(
                    """
                    INSERT OR REPLACE INTO cold_snapshot_files(
                      snapshot_id, path, file_version_id
                    )
                    VALUES (?, ?, ?)
                    """,
                    [
                        (
                            row["snapshot_id"],
                            row["path"],
                            row["file_version_id"],
                        )
                        for row in files
                    ],
                )
                archive.executemany(
                    """
                    INSERT OR REPLACE INTO cold_chunks(
                      chunk_id, snapshot_id, repo_id, path, symbol_identity_id,
                      category, start_line, end_line, text, token_count,
                      text_normalized
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    [
                        (
                            row["chunk_id"],
                            row["snapshot_id"],
                            row["repo_id"],
                            row["path"],
                            row["symbol_identity_id"],
                            row["category"],
                            row["start_line"],
                            row["end_line"],
                            row["text"],
                            row["token_count"],
                            str(row["text"]).lower(),
                        )
                        for row in chunks
                    ],
                )
                archive.executemany(
                    """
                    INSERT INTO cold_chunks_fts(chunk_id, text_normalized)
                    VALUES (?, ?)
                    """,
                    [(row["chunk_id"], str(row["text"]).lower()) for row in chunks],
                )
                archive.executemany(
                    """
                    INSERT OR REPLACE INTO cold_chunk_vectors(
                      chunk_id, dims, vector_json, model, vector_blob, encoding, scale
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    [
                        (
                            row["chunk_id"],
                            row["dims"],
                            row["vector_json"],
                            row["model"],
                            row["vector_blob"],
                            row["encoding"],
                            row["scale"],
                        )
                        for row in vectors
                    ],
                )
                archive.executemany(
                    """
                    INSERT OR REPLACE INTO cold_edges(
                      edge_id, scope_snapshot_id, src_repo_id, src_node_type,
                      src_node_id, dst_repo_id, dst_node_type, dst_node_id,
                      kind, confidence, metadata_json
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    [
                        (
                            row["edge_id"],
                            row["scope_snapshot_id"],
                            row["src_repo_id"],
                            row["src_node_type"],
                            row["src_node_id"],
                            row["dst_repo_id"],
                            row["dst_node_type"],
                            row["dst_node_id"],
                            row["kind"],
                            row["confidence"],
                            row["metadata_json"],
                        )
                        for row in edges
                    ],
                )
                archived += 1
                archived_chunks += len(chunks)
                archived_vectors += len(vectors)
                archived_edges += len(edges)
            archive.commit()
            return {
                "enabled": True,
                "archived_snapshots": archived,
                "archived_chunks": archived_chunks,
                "archived_chunk_vectors": archived_vectors,
                "archived_edges": archived_edges,
                "queryable": True,
                "archive_db_path": str(archive_db_path),
            }
        finally:
            archive.close()

    def gc(
        self,
        *,
        max_audit_age_days: int = 180,
        max_sessions: int = 500,
        max_session_events: int = 2000,
        keep_snapshots: int = 50,
        keep_snapshots_per_repo: int | None = None,
        pack_keep_full_days: int = 14,
        vacuum: bool = True,
        deep: bool = False,
        prune_snapshots: bool = False,
        archive_pruned_snapshots: bool = False,
        archive_db_path: Path | None = None,
        dry_run: bool = False,
        compact_into_threshold_bytes: int = 1_000_000_000,
        compact_min_free_ratio: float = 0.10,
    ) -> dict[str, Any]:
        before_bytes = self.db_path.stat().st_size if self.db_path.exists() else 0
        checkpoint_before = self.conn.execute(
            "PRAGMA wal_checkpoint(TRUNCATE)"
        ).fetchone()
        deleted_file_versions = (
            0 if dry_run else self.delete_unreferenced_file_versions()
        )
        policy_counts = self.apply_retention_policies(
            pack_keep_full_days=pack_keep_full_days, dry_run=dry_run
        )
        old_snapshot_ids: list[str] = []
        if deep or prune_snapshots:
            old_snapshot_ids = self._old_snapshot_ids(
                keep_snapshots=keep_snapshots,
                keep_snapshots_per_repo=keep_snapshots_per_repo,
                pack_keep_full_days=pack_keep_full_days,
            )
        archive_result: dict[str, Any] = {
            "enabled": bool(archive_pruned_snapshots),
            "archived_snapshots": 0,
            "archive_db_path": str(
                archive_db_path or self.db_path.with_suffix(".cold.db")
            ),
            "dry_run": bool(dry_run),
        }
        if old_snapshot_ids and archive_pruned_snapshots and not dry_run:
            archive_result = self.archive_snapshots(
                old_snapshot_ids,
                archive_db_path or self.db_path.with_suffix(".cold.db"),
            )
        snapshot_counts = self.prune_snapshots(old_snapshot_ids, dry_run=dry_run)
        if dry_run:
            deleted_chunks = snapshot_counts["deleted_chunks"]
            deleted_chunk_vectors = snapshot_counts["deleted_chunk_vectors"]
            deleted_chunk_vector_rows = snapshot_counts["deleted_chunk_vector_rows"]
            deleted_fts_rows = snapshot_counts["deleted_fts_rows"]
            deleted_edges = snapshot_counts["deleted_edges"]
            deleted_snapshot_files = snapshot_counts["deleted_snapshot_files"]
            deleted_snapshots = snapshot_counts["deleted_snapshots"]
            deleted_vec0_rows = snapshot_counts["deleted_vec0_rows"]
            deleted_session_events = self._count_session_events_to_prune(
                max_sessions=max_sessions, max_session_events=max_session_events
            )
            deleted_sessions = self._count_sessions_to_prune(max_sessions=max_sessions)
            deleted_orphan_edges = self._count_orphan_snapshot_edges()
            deleted_orphan_chunks = self._count_orphan_chunks()
            deleted_policy_rows = policy_counts["policy_prunable_rows"]
            deleted_symbols = {
                "deleted_symbol_occurrences": 0,
                "deleted_symbol_identities": 0,
            }
        else:
            with self.conn:
                cur = self.conn.execute(
                    """
                    DELETE FROM chunks
                    WHERE snapshot_id NOT IN (SELECT snapshot_id FROM snapshots)
                    """
                )
                deleted_orphan_chunks = cur.rowcount
                cur = self.conn.execute(
                    """
                    DELETE FROM chunk_vectors
                    WHERE chunk_id NOT IN (SELECT chunk_id FROM chunks)
                    """
                )
                deleted_chunk_vectors = (
                    snapshot_counts["deleted_chunk_vectors"] + cur.rowcount
                )
                cur = self.conn.execute(
                    """
                    DELETE FROM chunk_vector_rows
                    WHERE chunk_id NOT IN (SELECT chunk_id FROM chunks)
                    """
                )
                deleted_chunk_vector_rows = (
                    snapshot_counts["deleted_chunk_vector_rows"] + cur.rowcount
                )
                cur = self.conn.execute(
                    """
                    DELETE FROM chunks_fts
                    WHERE chunk_id NOT IN (SELECT chunk_id FROM chunks)
                    """
                )
                deleted_fts_rows = snapshot_counts["deleted_fts_rows"] + cur.rowcount
                cur = self.conn.execute(
                    """
                    DELETE FROM edges
                    WHERE scope_snapshot_id IS NOT NULL
                      AND scope_snapshot_id NOT IN (SELECT snapshot_id FROM snapshots)
                    """
                )
                deleted_orphan_edges = cur.rowcount
                cur = self.conn.execute(
                    """
                    DELETE FROM agent_session_events
                    WHERE session_id NOT IN (
                      SELECT session_id
                      FROM agent_sessions
                      ORDER BY started_at DESC
                      LIMIT ?
                    )
                    """,
                    (max(1, int(max_sessions)),),
                )
                deleted_session_events = cur.rowcount
                cur = self.conn.execute(
                    """
                    DELETE FROM agent_session_events
                    WHERE event_id NOT IN (
                      SELECT event_id
                      FROM agent_session_events
                      ORDER BY event_time DESC, event_id DESC
                      LIMIT ?
                    )
                    """,
                    (max(1, int(max_session_events)),),
                )
                deleted_session_events += cur.rowcount
                cur = self.conn.execute(
                    """
                    DELETE FROM agent_sessions
                    WHERE session_id NOT IN (
                      SELECT session_id
                      FROM agent_sessions
                      ORDER BY started_at DESC
                      LIMIT ?
                    )
                    """,
                    (max(1, int(max_sessions)),),
                )
                deleted_sessions = cur.rowcount
            deleted_policy_rows = policy_counts["policy_prunable_rows"]
            deleted_symbols = self.delete_orphan_symbols()
            deleted_file_versions += self.delete_unreferenced_file_versions()
            deleted_chunks = snapshot_counts["deleted_chunks"] + deleted_orphan_chunks
            deleted_edges = snapshot_counts["deleted_edges"] + deleted_orphan_edges
            deleted_snapshot_files = snapshot_counts["deleted_snapshot_files"]
            deleted_snapshots = snapshot_counts["deleted_snapshots"]
            deleted_vec0_rows = snapshot_counts["deleted_vec0_rows"]
        if dry_run:
            deleted_chunks += deleted_orphan_chunks
            deleted_edges += deleted_orphan_edges
        vacuum_ran = False
        compact_result: dict[str, Any] = {
            "method": "skipped",
            "reason": "dry_run" if dry_run else "disabled",
        }
        if vacuum and not dry_run:
            compact_result = self.compact(
                into_threshold_bytes=compact_into_threshold_bytes,
                min_free_ratio=compact_min_free_ratio,
            )
            vacuum_ran = compact_result.get("method") in {"vacuum", "vacuum_into"}
        checkpoint_after = self.conn.execute(
            "PRAGMA wal_checkpoint(TRUNCATE)"
        ).fetchone()
        planner_result = (
            {
                "analyze_ran": False,
                "optimize_ran": False,
                "errors": [],
                "duration_ms": 0.0,
            }
            if dry_run
            else self.optimize_query_planner()
        )
        after_bytes = self.db_path.stat().st_size if self.db_path.exists() else 0
        estimated_reclaim_bytes = self._estimate_reclaim_bytes(old_snapshot_ids)
        return {
            "dry_run": bool(dry_run),
            "deleted_file_versions": deleted_file_versions,
            "deleted_chunks": deleted_chunks,
            "deleted_orphan_chunks": deleted_orphan_chunks,
            "deleted_chunk_vectors": deleted_chunk_vectors,
            "deleted_chunk_vector_rows": deleted_chunk_vector_rows,
            "deleted_fts_rows": deleted_fts_rows,
            "deleted_edges": deleted_edges,
            "deleted_orphan_edges": deleted_orphan_edges,
            "deleted_snapshot_files": deleted_snapshot_files,
            "deleted_snapshots": deleted_snapshots,
            "deleted_vec0_rows": deleted_vec0_rows,
            "deleted_sessions": deleted_sessions,
            "deleted_session_events": deleted_session_events,
            "deleted_policy_rows": deleted_policy_rows,
            "metadata_stripped_context_packs": policy_counts.get(
                "metadata_stripped_context_packs", 0
            ),
            "unpinned_context_packs": policy_counts.get("unpinned_context_packs", 0),
            **deleted_symbols,
            "deep": bool(deep),
            "content_retention_snapshots": int(keep_snapshots),
            "content_retention_snapshots_per_repo": int(
                keep_snapshots_per_repo or keep_snapshots
            ),
            "content_pruned_snapshot_count": len(old_snapshot_ids),
            "pruned_snapshot_ids": old_snapshot_ids[:50],
            "deleted_audit_rows": 0,
            "audit_retention_days": int(max_audit_age_days),
            "audit_retention_note": "audit rows are retained to preserve chain verification",
            "vacuum_ran": vacuum_ran,
            "prune_snapshots_requested": bool(prune_snapshots),
            "cold_archive": archive_result,
            "query_planner": planner_result,
            "analyze_ran": bool(planner_result["analyze_ran"]),
            "optimize_ran": bool(planner_result["optimize_ran"]),
            "compact": compact_result,
            "bytes_before": before_bytes,
            "bytes_after": after_bytes,
            "bytes_reclaimed": max(0, before_bytes - after_bytes),
            "estimated_reclaim_bytes": estimated_reclaim_bytes,
            "wal_checkpoint_before": (
                list(checkpoint_before) if checkpoint_before else []
            ),
            "wal_checkpoint_after": list(checkpoint_after) if checkpoint_after else [],
        }


def _edge_logical_key(row: Any) -> tuple[Any, ...]:
    return (
        row["scope_snapshot_id"],
        row["src_repo_id"],
        row["src_node_type"],
        row["src_node_id"],
        row["dst_repo_id"],
        row["dst_node_type"],
        row["dst_node_id"],
        row["kind"],
    )


def _pack_vector(
    vector: list[float], encoding: str = "f32"
) -> tuple[bytes | None, str, float | None]:
    requested = (encoding or "f32").lower()
    if requested == "json":
        return None, "json", None
    if requested == "i8":
        max_abs = max((abs(float(value)) for value in vector), default=0.0)
        scale = max_abs / 127.0 if max_abs else 1.0
        quantized = [
            max(-127, min(127, int(round(float(value) / scale)))) for value in vector
        ]
        return struct.pack(f"<{len(quantized)}b", *quantized), "i8", scale
    return (
        struct.pack(f"<{len(vector)}f", *(float(value) for value in vector)),
        "f32",
        None,
    )


def unpack_vector(row: Any) -> list[float]:
    encoding = str(row["encoding"] or "json") if "encoding" in row.keys() else "json"
    blob = row["vector_blob"] if "vector_blob" in row.keys() else None
    dims = int(row["dims"])
    if encoding == "f32" and blob:
        return list(struct.unpack(f"<{dims}f", blob))
    if encoding == "i8" and blob:
        raw = struct.unpack(f"<{dims}b", blob)
        scale = float(row["scale"] or 1.0)
        return [value * scale for value in raw]
    return json.loads(row["vector_json"] or "[]")


def _sqlite_datetime_days_ago(days: int) -> str:
    return (datetime.now(timezone.utc) - timedelta(days=max(0, int(days)))).isoformat()


def _stable_edge_id_sql(
    scope_snapshot_id: Any,
    src_repo_id: Any,
    src_node_type: Any,
    src_node_id: Any,
    dst_repo_id: Any,
    dst_node_type: Any,
    dst_node_id: Any,
    kind: Any,
) -> str:
    return stable_id(
        *(
            str(part) if part is not None else ""
            for part in (
                scope_snapshot_id,
                src_repo_id,
                src_node_type,
                src_node_id,
                dst_repo_id,
                dst_node_type,
                dst_node_id,
                kind,
            )
        )
    )


def _json_list(value: str | None) -> list[str]:
    try:
        parsed = json.loads(value or "[]")
    except json.JSONDecodeError:
        return []
    if not isinstance(parsed, list):
        return []
    return [str(item) for item in parsed]


def _json_dict(value: str | None) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _normalize_artifact_path(path: str) -> str:
    return str(path).replace("\\", "/").lstrip("./")


def _parse_utc_timestamp(value: str) -> datetime:
    text = str(value or "").replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        parsed = datetime.now(timezone.utc)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _iso_after(now: str, seconds: int) -> str:
    # utc_now emits ISO timestamps; keep the dependency surface small here.
    from datetime import datetime, timedelta, timezone

    text = now.replace("Z", "+00:00")
    base = datetime.fromisoformat(text)
    if base.tzinfo is None:
        base = base.replace(tzinfo=timezone.utc)
    return (base + timedelta(seconds=seconds)).isoformat()


def _merge_metadata(left: dict[str, Any], right: dict[str, Any]) -> dict[str, Any]:
    merged: dict[str, Any] = dict(left)
    for key, value in right.items():
        if key not in merged:
            merged[key] = value
            continue
        if key == "deduped_edge_count":
            merged[key] = max(int(merged[key]), int(value))
            continue
        merged[key] = _merge_metadata_value(merged[key], value)
    return {key: merged[key] for key in sorted(merged)}


def _merge_metadata_value(left: Any, right: Any) -> Any:
    if left == right:
        return left
    left_values = _metadata_values(left)
    right_values = _metadata_values(right)
    by_json = {canonical_json(value): value for value in [*left_values, *right_values]}
    values = [by_json[key] for key in sorted(by_json)]
    if all(not isinstance(value, (dict, list)) for value in values):
        return values
    return values


def _metadata_values(value: Any) -> list[Any]:
    if isinstance(value, list):
        return value
    return [value]


def _memory_trust_for_status(status: str) -> str:
    if status in {"active", "approved", "candidate", "untrusted"}:
        return status
    return "candidate"


def _confidence_tier(value: Any) -> str:
    confidence = float(value or 0.0)
    if confidence >= 0.8:
        return "high"
    if confidence >= 0.5:
        return "medium"
    return "low"


def _slug(value: str) -> str:
    text = "".join(ch.lower() if ch.isalnum() else "-" for ch in value.strip())
    return "-".join(part for part in text.split("-") if part) or "unnamed"


def _min_trust(*tiers: Any) -> str:
    values = [str(tier) for tier in tiers if tier]
    if not values:
        return "high"
    return min(values, key=lambda item: TRUST_RANK.get(item, -1))


def _valid_business_edge(src_type: str, kind: str, dst_type: str) -> bool:
    if kind not in BUSINESS_EDGE_KINDS:
        return False
    if kind == "serves":
        return dst_type == "product" and src_type not in BUSINESS_NODE_TYPES
    if kind == "used_by":
        return src_type == "product" and dst_type == "customer"
    if kind == "carries":
        return src_type in {"customer", "contract"} and dst_type in {"revenue", "sla"}
    if kind == "realizes":
        return src_type == "product" and dst_type == "objective"
    if kind == "governed_by":
        return (
            dst_type == "compliance_obligation" and src_type not in BUSINESS_NODE_TYPES
        )
    if kind == "exposes":
        return dst_type == "risk" and src_type not in BUSINESS_NODE_TYPES
    return False


def _empty_business_exposure() -> dict[str, Any]:
    return {
        "schema_version": "ctxlayer.business_exposure.v1",
        "authoritative": False,
        "requires_human_review": True,
        "lowest_trust_tier": None,
        "exposure": {},
        "exposure_summary": {},
    }


def _semantic_accuracy_row(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "accuracy_run_id": row["accuracy_run_id"],
        "repo_id": row["repo_id"],
        "fixture_set": row["fixture_set"],
        "metrics": json.loads(row["metrics_json"] or "{}"),
        "passed": bool(row["passed"]),
        "created_at": row["created_at"],
    }


def _json_dict(value: str) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _json_list(value: str | None) -> list[str]:
    try:
        parsed = json.loads(value or "[]")
    except json.JSONDecodeError:
        return []
    if not isinstance(parsed, list):
        return []
    return [str(item) for item in parsed if str(item).strip()]


def _normalize_path_glob(path: str) -> str:
    return str(path).replace("\\", "/").lstrip("./")


def _first_matching_path(paths: list[str], globs: list[str]) -> str | None:
    if not globs:
        return None
    for path in paths:
        for glob in globs:
            if fnmatch.fnmatch(path, glob) or path == glob:
                return path
    return None


def _dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _float_metric(values: dict[str, Any], key: str) -> float:
    value = values.get(key)
    return round(float(value), 6) if isinstance(value, (int, float)) else 0.0


def _is_unvalidated_agent_memory(provenance: dict[str, Any]) -> bool:
    generator = str(provenance.get("generator", ""))
    validator = str(provenance.get("validator", "none") or "none")
    return generator.startswith("agent:") and validator in {"", "none", "null"}
