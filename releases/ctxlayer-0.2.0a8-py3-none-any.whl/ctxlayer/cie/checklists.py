from __future__ import annotations

from ctxlayer.cie.complexity import infer_task_type
from ctxlayer.cie.contracts import DynamicChecklist, deterministic_id

BASELINES = {
    "api": [
        "auth",
        "input validation",
        "error handling",
        "rate limits",
        "compatibility",
        "logging",
    ],
    "database": [
        "migration",
        "rollback",
        "indexes",
        "constraints",
        "integrity",
        "performance",
    ],
    "frontend_ui": [
        "desktop screenshot",
        "mobile screenshot",
        "empty state",
        "loading state",
        "error state",
        "text overflow",
        "accessibility",
    ],
    "browser_validation": [
        "screenshot",
        "interaction",
        "console errors",
        "network errors",
        "mobile viewport",
        "desktop viewport",
    ],
    "migration": [
        "forward compatibility",
        "backward compatibility",
        "idempotency",
        "backup",
        "rollback",
    ],
    "security_sensitive": [
        "secrets",
        "authorization",
        "PII",
        "prompt injection",
        "redaction",
    ],
    "release": [
        "version",
        "release notes",
        "migration docs",
        "smoke tests",
        "rollback",
    ],
    "documentation": ["source truth", "audience", "examples", "stale references"],
    "unknown": ["requirements", "impact", "tests", "rollback", "surface parity"],
}


def checklist_preview(
    task: str = "", paths: list[str] | None = None, source_refs: list[str] | None = None
) -> DynamicChecklist:
    task_type = infer_task_type(task, paths or [])
    baseline = BASELINES.get(task_type, BASELINES["unknown"])
    refs = source_refs or ["built_in_baseline"]
    return DynamicChecklist(
        checklist_id=deterministic_id("checklist", task_type, baseline),
        task_type=task_type,
        items=[
            {
                "id": deterministic_id("checklist_item", task_type, item),
                "text": item,
                "source_ref": refs[0],
            }
            for item in baseline
        ],
        source_refs=refs,
        status="preview",
    )
