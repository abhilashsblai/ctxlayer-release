from __future__ import annotations

import os
from typing import Any

from ctxlayer.cie.contracts import InterventionRecord


def preview_adoption(report: dict[str, Any], intervention_id: str) -> dict[str, Any]:
    intervention = _find_intervention(report, intervention_id)
    if not intervention:
        return {
            "ok": False,
            "reason": "intervention_not_found",
            "intervention_id": intervention_id,
        }
    gates = _gates(intervention)
    return {
        "ok": True,
        "dry_run": True,
        "intervention": intervention,
        "gates": gates,
        "can_adopt": all(item["ok"] for item in gates),
        "required_approval": intervention.get("risk") in {"high", "critical"},
    }


def adopt_intervention(
    report: dict[str, Any],
    intervention_id: str,
    *,
    approved_by: str,
    settings: Any,
) -> dict[str, Any]:
    preview = preview_adoption(report, intervention_id)
    if not preview.get("ok"):
        return preview
    config = settings.learning.cie
    blockers = []
    if os.environ.get("CTXLAYER_LEARNING_OFF") == "1":
        blockers.append("learning_off")
    if not settings.learning.enabled:
        blockers.append("learning_disabled")
    if not config.allow_adoption:
        blockers.append("cie_adoption_disabled")
    if not approved_by:
        blockers.append("missing_approval")
    if not preview["can_adopt"]:
        blockers.append("gate_failed")
    if blockers:
        return {
            "ok": False,
            "status": "blocked",
            "intervention_id": intervention_id,
            "blockers": blockers,
            "dry_run": True,
        }
    return {
        "ok": True,
        "status": "adopted",
        "intervention_id": intervention_id,
        "approved_by": approved_by,
        "delegated": True,
        "mutation_path": "delegated_existing_surface",
    }


def reject_intervention(
    report: dict[str, Any], intervention_id: str, *, reason: str, actor: str
) -> dict[str, Any]:
    if not _find_intervention(report, intervention_id):
        return {
            "ok": False,
            "reason": "intervention_not_found",
            "intervention_id": intervention_id,
        }
    return {
        "ok": True,
        "status": "rejected",
        "intervention_id": intervention_id,
        "reason": reason,
        "actor": actor,
    }


def suspend_intervention(
    report: dict[str, Any], intervention_id: str, *, reason: str, actor: str
) -> dict[str, Any]:
    if not _find_intervention(report, intervention_id):
        return {
            "ok": False,
            "reason": "intervention_not_found",
            "intervention_id": intervention_id,
        }
    return {
        "ok": True,
        "status": "suspended",
        "intervention_id": intervention_id,
        "reason": reason,
        "actor": actor,
    }


def rollback_intervention(
    report: dict[str, Any], intervention_id: str, *, approved_by: str
) -> dict[str, Any]:
    intervention = _find_intervention(report, intervention_id)
    if not intervention:
        return {
            "ok": False,
            "reason": "intervention_not_found",
            "intervention_id": intervention_id,
        }
    return {
        "ok": True,
        "status": "rolled_back",
        "intervention_id": intervention_id,
        "approved_by": approved_by,
        "rollback_action": intervention.get("rollback_action", "manual_only"),
        "lineage_preserved": True,
    }


def default_report_intervention(
    summary: str, evidence_refs: list[str]
) -> InterventionRecord:
    return InterventionRecord(
        intervention_id=f"cie-report-{len(evidence_refs)}",
        kind="report",
        status="proposed",
        summary=summary,
        risk="low",
        gates={"config": True, "dry_run_preview": True, "security_policy": True},
        rollback_conditions=["not_applicable_for_report"],
        suspension_conditions=["not_applicable_for_report"],
        rollback_action="manual_only",
        rollback_status="not_applicable",
        evidence_refs=evidence_refs,
    )


def _find_intervention(
    report: dict[str, Any], intervention_id: str
) -> dict[str, Any] | None:
    for item in report.get("proposed_interventions", []) or []:
        if isinstance(item, dict) and item.get("intervention_id") == intervention_id:
            return item
    return None


def _gates(intervention: dict[str, Any]) -> list[dict[str, Any]]:
    gates = (
        intervention.get("gates") if isinstance(intervention.get("gates"), dict) else {}
    )
    required = {
        "config": bool(gates.get("config", True)),
        "dry_run_preview": bool(gates.get("dry_run_preview", True)),
        "security_policy": bool(gates.get("security_policy", True)),
        "rollback_conditions": bool(intervention.get("rollback_conditions")),
    }
    return [{"name": key, "ok": value} for key, value in sorted(required.items())]
