def health_schema():
    return {"ok": True}
