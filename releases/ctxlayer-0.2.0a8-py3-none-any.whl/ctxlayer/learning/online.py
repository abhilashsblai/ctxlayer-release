from __future__ import annotations

import json
from typing import Any

from ctxlayer.store import SQLiteStore
from ctxlayer.utils import canonical_json, stable_id, utc_now


class OnlineLearner:
    """Session-scoped anticipation deltas layered over the durable world model."""

    def __init__(self, store: SQLiteStore, repo_id: str, session_id: str):
        self.store = store
        self.repo_id = repo_id
        self.session_id = session_id

    def observe(
        self,
        *,
        signal_kind: str,
        context: dict[str, Any],
        observation: dict[str, Any],
        magnitude: float = 1.0,
        task_session_id: str | None = None,
    ) -> str:
        boost = _boost_for(signal_kind, magnitude)
        return self.store.record_anticipation_update(
            repo_id=self.repo_id,
            session_id=self.session_id,
            task_session_id=task_session_id,
            signal_kind=signal_kind,
            context=context,
            observation=observation,
            magnitude=magnitude,
            delta={"failure_boost": boost},
        )

    def adjust(
        self, *, context: dict[str, Any], observation: dict[str, Any]
    ) -> dict[str, Any]:
        target_dir = str(observation.get("target_dir") or "")
        boost = 0.0
        count = 0
        for row in self.store.anticipation_updates(
            session_id=self.session_id, repo_id=self.repo_id
        ):
            observed = _json(row["observation_json"])
            if str(observed.get("target_dir") or "") != target_dir:
                continue
            delta = _json(row["delta_json"])
            boost += float(delta.get("failure_boost", 0.0) or 0.0)
            count += 1
        return {"failure_boost": round(min(1.0, boost), 6), "update_count": count}

    def synthesize_candidates(self) -> list[str]:
        rows = self.store.anticipation_updates(
            session_id=self.session_id, repo_id=self.repo_id
        )
        candidates = []
        for row in rows:
            observation = _json(row["observation_json"])
            target_dir = str(observation.get("target_dir") or "unknown")
            payload = {
                "type": "failure_lesson",
                "subject_key": f"anticipation:{target_dir}",
                "assertion": (
                    f"Session {self.session_id} recorded an anticipation update near "
                    f"{target_dir}; keep this candidate quarantined until validated."
                ),
                "status": "candidate",
                "trust": "candidate",
            }
            candidate_id = stable_id(
                "anticipation_candidate", self.session_id, row["update_id"]
            )
            with self.store.conn:
                self.store.conn.execute(
                    """
                    INSERT OR IGNORE INTO learning_candidate(
                      candidate_id, kind, payload_json, provenance_json, confidence, status, created_at
                    )
                    VALUES (?, 'failure_lesson', ?, ?, 0.5, 'candidate', ?)
                    """,
                    (
                        candidate_id,
                        canonical_json(payload),
                        canonical_json(
                            {
                                "source": "anticipation_online",
                                "session_id": self.session_id,
                                "update_id": row["update_id"],
                            }
                        ),
                        utc_now(),
                    ),
                )
            candidates.append(candidate_id)
        return candidates


def _boost_for(signal_kind: str, magnitude: float) -> float:
    base = {
        "test_failure": 0.25,
        "revert": 0.2,
        "impact_break": 0.2,
        "nudge_confirmed": 0.15,
        "outcome": 0.3,
    }.get(signal_kind, 0.1)
    return round(min(1.0, base * max(0.0, float(magnitude))), 6)


def _json(value: str | None) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}
