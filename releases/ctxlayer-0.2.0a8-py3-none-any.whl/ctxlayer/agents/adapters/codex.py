from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from ctxlayer.agents.adapters.base import BootstrapContext
from ctxlayer.agents.contract import (
    SUBAGENT_SPECS,
    codex_agent_toml,
    codex_hooks_json,
    codex_mcp_config,
    codex_project_config,
    ensure_instruction_contract,
    hook_script,
    write_if_changed,
)


class CodexAdapter:
    name = "codex"
    aliases = ("openai-codex",)
    supports_hooks = True
    supports_subagents = True
    supports_skills = False
    instruction_file = "AGENTS.md"

    def detect(self, env: Mapping[str, str]) -> bool:
        return any(key.startswith("CODEX_") for key in env) or bool(
            env.get("CODEX_PROJECT_DIR") or env.get("CODEX_WORKSPACE_ROOT")
        )

    def render(self, ctx: BootstrapContext) -> list[Path]:
        written: list[Path] = []
        path, _changed = ensure_instruction_contract(
            ctx.repo_root / self.instruction_file,
            ctx.agent_names,
            agent_label="Codex",
        )
        written.append(path)
        codex_dir = ctx.repo_root / ".codex"
        agents_dir = codex_dir / "agents"
        hook_dir = ctx.repo_root / ".ctxlayer" / "codex" / "hooks"
        written.extend(
            [
                write_if_changed(
                    ctx.repo_root / ".ctxlayer" / "mcp" / "codex.config.toml",
                    codex_mcp_config(ctx.mcp_command, ctx.mcp_repo),
                ),
                write_if_changed(
                    codex_dir / "config.toml",
                    codex_project_config(ctx.mcp_command, ctx.mcp_repo),
                ),
                write_if_changed(
                    codex_dir / "hooks.json", codex_hooks_json(ctx.repo_root)
                ),
                write_if_changed(hook_dir / "ctxlayer_hook.py", hook_script()),
            ]
        )
        for spec in SUBAGENT_SPECS:
            written.append(
                write_if_changed(
                    agents_dir / f"{spec.name}.toml", codex_agent_toml(spec)
                )
            )
        return written

    def configure_mcp(
        self, ctx: BootstrapContext, *, config_path: Path | None = None
    ) -> dict[str, Any]:
        target = config_path or Path.home() / ".codex" / "config.toml"
        block = codex_mcp_config(ctx.mcp_command, ctx.mcp_repo).strip() + "\n"
        existing = target.read_text(encoding="utf-8") if target.exists() else ""
        updated = _replace_toml_table(existing, "mcp_servers.ctxlayer", block)
        changed = updated != existing
        if changed:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(updated, encoding="utf-8")
        return {
            "ok": True,
            "agent": self.name,
            "config_path": str(target),
            "changed": changed,
            "block": block,
        }

    def readiness(self, repo_root: Path) -> dict[str, Any]:
        agents_path = repo_root / self.instruction_file
        agents_text = (
            agents_path.read_text(encoding="utf-8") if agents_path.exists() else ""
        )
        checks = {
            "codex_agents_file": agents_path.exists(),
            "codex_agents_contract": "<!-- ctxlayer-agent-contract -->" in agents_text,
            "codex_mcp_snippet": (
                repo_root / ".ctxlayer" / "mcp" / "codex.config.toml"
            ).exists(),
            "codex_project_config": (repo_root / ".codex" / "config.toml").exists(),
            "codex_hooks": (repo_root / ".codex" / "hooks.json").exists()
            and (
                repo_root / ".ctxlayer" / "codex" / "hooks" / "ctxlayer_hook.py"
            ).exists(),
            "codex_agents": all(
                (repo_root / ".codex" / "agents" / f"{name}.toml").exists()
                for name in [
                    "ctx-explorer",
                    "ctx-worker",
                    "ctx-reviewer",
                    "ctx-verifier",
                ]
            ),
        }
        missing = [name for name, ok in checks.items() if not ok]
        return {
            "agent": self.name,
            "ok": not missing,
            "checks": checks,
            "missing": missing,
            "enforcement_level": "hooks",
        }

    def mcp_setup_hint(self, ctx: BootstrapContext) -> str:
        return "Copy `.ctxlayer/mcp/codex.config.toml` into Codex config or run setup with --configure-mcp."


def _replace_toml_table(existing: str, table_name: str, block: str) -> str:
    lines = existing.splitlines()
    header = f"[{table_name}]"
    output: list[str] = []
    idx = 0
    replaced = False
    while idx < len(lines):
        if lines[idx].strip() == header:
            if output and output[-1].strip():
                output.append("")
            output.extend(block.strip().splitlines())
            replaced = True
            idx += 1
            while idx < len(lines):
                stripped = lines[idx].strip()
                if stripped.startswith("[") and stripped.endswith("]"):
                    break
                idx += 1
            continue
        output.append(lines[idx])
        idx += 1

    if not replaced:
        if output and output[-1].strip():
            output.append("")
        output.extend(block.strip().splitlines())

    return "\n".join(output).rstrip() + "\n"
