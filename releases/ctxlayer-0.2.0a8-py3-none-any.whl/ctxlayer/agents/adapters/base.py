from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Protocol


@dataclass(frozen=True)
class BootstrapContext:
    repo_root: Path
    mcp_command: str
    mcp_repo: str
    shell: str
    agent_names: list[str]


class AgentAdapter(Protocol):
    name: str
    aliases: tuple[str, ...]
    supports_hooks: bool
    supports_subagents: bool
    supports_skills: bool
    instruction_file: str

    def detect(self, env: Mapping[str, str]) -> bool: ...

    def render(self, ctx: BootstrapContext) -> list[Path]: ...

    def configure_mcp(
        self, ctx: BootstrapContext, *, config_path: Path | None = None
    ) -> dict[str, Any]: ...

    def readiness(self, repo_root: Path) -> dict[str, Any]: ...

    def mcp_setup_hint(self, ctx: BootstrapContext) -> str: ...
