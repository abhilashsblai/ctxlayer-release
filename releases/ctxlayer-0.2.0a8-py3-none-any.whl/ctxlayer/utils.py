from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8", errors="surrogateescape"))


def stable_id(*parts: object) -> str:
    payload = "\x1f".join(str(part) for part in parts)
    return sha256_text(payload)


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def read_text_lossy(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def relpath(path: Path, root: Path) -> str:
    return os.path.relpath(path, root).replace("\\", "/")


def estimate_tokens(text: str) -> int:
    return max(1, (len(text) + 3) // 4)


def split_identifier_text(text: str) -> str:
    out: list[str] = []
    prev = ""
    for char in text:
        if char in "_-./\\":
            out.append(" ")
        elif prev and char.isupper() and (prev.islower() or prev.isdigit()):
            out.append(" ")
            out.append(char.lower())
        else:
            out.append(char.lower())
        prev = char
    return "".join(out)
