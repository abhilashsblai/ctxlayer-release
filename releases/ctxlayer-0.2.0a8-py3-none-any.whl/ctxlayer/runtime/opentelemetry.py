from __future__ import annotations

import json
from pathlib import Path


def load(path: Path) -> list[dict[str, str]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    spans = data.get("resourceSpans", []) if isinstance(data, dict) else data
    return [
        {
            "title": "OpenTelemetry trace signal",
            "message": str(span)[:1000],
            "path": None,
            "severity": "low",
        }
        for span in spans
    ]
