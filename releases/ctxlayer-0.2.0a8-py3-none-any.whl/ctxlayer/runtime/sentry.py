from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def load(path: Path) -> list[dict[str, Any]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(data, dict):
        data = data.get("issues", data.get("events", []))
    return [
        {
            "title": item.get("title") or item.get("culprit") or "Sentry issue",
            "message": item.get("message") or item.get("title") or "",
            "path": item.get("path") or item.get("culprit"),
            "severity": item.get("level") or "medium",
        }
        for item in data
    ]
