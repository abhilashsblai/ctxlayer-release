from __future__ import annotations

from pathlib import Path
from typing import Any


def load(folder: Path) -> list[dict[str, Any]]:
    events = []
    for path in folder.rglob("*.md"):
        text = path.read_text(encoding="utf-8", errors="replace")
        title = next(
            (line.strip("# ").strip() for line in text.splitlines() if line.strip()),
            path.stem,
        )
        events.append(
            {
                "title": title,
                "message": text[:1000],
                "path": path.as_posix(),
                "severity": "high" if "sev1" in text.lower() else "medium",
            }
        )
    return events
