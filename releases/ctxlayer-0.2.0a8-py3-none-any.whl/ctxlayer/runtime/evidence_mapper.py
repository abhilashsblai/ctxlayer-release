from __future__ import annotations

from pathlib import Path
from typing import Any

from ctxlayer.memory.unified import UnifiedMemory
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import sha256_text


class RuntimeIngestor:
    def __init__(
        self, repo_root: Path, store: SQLiteStore, repo_id: str, workspace_id: str
    ):
        self.repo_root = repo_root
        self.store = store
        self.repo_id = repo_id
        self.workspace_id = workspace_id
        self.memory = UnifiedMemory(store, workspace_id, repo_id)

    def ingest_events(
        self, source: str, events: list[dict[str, Any]]
    ) -> dict[str, Any]:
        stored = []
        for event in events:
            title = str(event.get("title") or event.get("message") or "runtime event")
            message = str(event.get("message") or title)
            path = event.get("path")
            event_hash = sha256_text(f"{source}:{title}:{message}:{path}")
            event_id = self.store.add_runtime_event(
                source=source,
                repo_id=self.repo_id,
                title=title,
                message=message,
                path=path,
                symbol_identity_id=event.get("symbol_identity_id"),
                severity=str(event.get("severity") or "medium"),
                event_hash=event_hash,
            )
            self.memory.mirror_runtime_signal(
                runtime_event_id=event_id,
                source=source,
                title=title,
                message=message,
                path=path,
                symbol_identity_id=event.get("symbol_identity_id"),
                severity=str(event.get("severity") or "medium"),
                event_hash=event_hash,
            )
            stored.append(event_id)
        return {"ok": True, "stored": stored}

    def candidates(self) -> dict[str, Any]:
        candidates = []
        for event in self.store.runtime_events(self.repo_id):
            message = event["message"]
            if not _candidate_worthy(message):
                continue
            text = _event_to_rule(message)
            candidate_id = self.store.upsert_business_rule_candidate(
                workspace_id=self.workspace_id,
                repo_id=self.repo_id,
                rule_text=text,
                source_type="runtime",
                confidence=0.5,
            )
            self.store.put_business_rule_candidate_evidence(
                candidate_id=candidate_id,
                repo_id=self.repo_id,
                path=event["path"],
                symbol_identity_id=event["symbol_identity_id"],
                evidence_kind=f"runtime:{event['source']}",
                evidence_hash=event["event_hash"],
            )
            self.memory.propose(
                record_type="business_rule",
                assertion=text,
                source_kind="runtime",
                confidence=0.5,
                scope=f"path:{event['path'] or '**'}",
                evidence=[
                    {
                        "repo_id": self.repo_id,
                        "path": event["path"],
                        "symbol_identity_id": event["symbol_identity_id"],
                        "evidence_kind": f"runtime:{event['source']}",
                        "evidence_hash": event["event_hash"],
                        "source_ref": event["runtime_event_id"],
                    }
                ],
                record_id=candidate_id,
                status="candidate",
                metadata={
                    "legacy_candidate_id": candidate_id,
                    "runtime_event_id": event["runtime_event_id"],
                },
            )
            candidates.append(
                {"candidate_id": candidate_id, "text": text, "source": event["source"]}
            )
        return {"ok": True, "candidates": candidates}

    def linked_errors(self) -> dict[str, Any]:
        return {
            "ok": True,
            "events": [
                dict(row)
                for row in self.store.runtime_events(self.repo_id)
                if row["path"] or row["symbol_identity_id"]
            ],
        }


def _candidate_worthy(message: str) -> bool:
    lowered = message.lower()
    return any(
        word in lowered
        for word in ["cannot", "must", "required", "not allowed", "may not"]
    )


def _event_to_rule(message: str) -> str:
    cleaned = " ".join(message.strip().split())
    if cleaned.endswith("."):
        cleaned = cleaned[:-1]
    return cleaned[0].upper() + cleaned[1:] + "."
