from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class HarvestedTask:
    provider: str
    id: str
    title: str
    body: str
    merge_commit_sha: str | None
