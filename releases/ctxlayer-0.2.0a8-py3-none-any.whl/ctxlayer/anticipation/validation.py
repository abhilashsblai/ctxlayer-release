from __future__ import annotations

import json
from collections import Counter
from typing import Any

from ctxlayer.retrieval.embedder import make_embedder
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import utc_now

from .embedding_model import EmbeddingWorldModel
from .surprise import SurpriseEngine
from .world_model import WorldModel, _dirname


DEFAULT_ARMS = ("baseline", "frequency_v0", "embedding_v1")
DEFAULT_SEMANTIC_MODEL = "sentence-transformers/all-MiniLM-L6-v2"


def run_benchmark(
    *,
    store: SQLiteStore,
    repo_id: str,
    settings: Any,
    arms: list[str] | None = None,
    threshold: float = 0.55,
    limit: int = 200,
    holdout_ratio: float = 0.3,
    ece_bins: int = 10,
    semantic_model: str = DEFAULT_SEMANTIC_MODEL,
    semantic_backend: str = "sentence-transformers",
) -> dict[str, Any]:
    selected = [arm.strip() for arm in (arms or list(DEFAULT_ARMS)) if arm.strip()]
    cases = _outcome_cases(store, limit=limit)
    train_cases, eval_cases = _split_cases(cases, holdout_ratio=holdout_ratio)
    report = {
        "schema_version": "ctxlayer.anticipation_benchmark.v1",
        "created_at": utc_now(),
        "cases": len(eval_cases),
        "train_cases": len(train_cases),
        "holdout_cases": len(eval_cases),
        "holdout_ratio": holdout_ratio,
        "arms": {},
        "anticipation": {},
        "gate": {"ok": False, "status": "insufficient_data"},
    }
    if not cases or not train_cases or not eval_cases:
        return report

    for arm in selected:
        report["arms"][arm] = _score_arm(
            arm=arm,
            train_cases=train_cases,
            eval_cases=eval_cases,
            store=store,
            repo_id=repo_id,
            settings=settings,
            threshold=threshold,
            ece_bins=ece_bins,
            semantic_model=semantic_model,
            semantic_backend=semantic_backend,
        )

    primary = report["arms"].get("embedding_v1") or report["arms"].get("frequency_v0")
    if primary:
        report["anticipation"] = {
            "mistake_preemption_rate": primary["mistake_preemption_rate"],
            "novel_situation_recall": primary["novel_situation_recall"],
            "nudge_precision": primary["nudge_precision"],
            "nudge_false_positive_rate": primary["nudge_false_positive_rate"],
            "surprise_ece": primary["surprise_ece"],
            "benchmark_cases": len(eval_cases),
            "train_cases": len(train_cases),
            "holdout_cases": len(eval_cases),
        }

    report["gate"] = _benchmark_gate(report, settings=settings)
    return report


def shadow_validate(
    *,
    store: SQLiteStore,
    repo_id: str,
    limit: int = 100,
    mode: str = "shadow",
) -> dict[str, Any]:
    rows = store.anticipation_predictions(repo_id=repo_id, limit=limit)
    surprise_values = [float(row["surprise"] or 0.0) for row in rows]
    fired = [value for value in surprise_values if value > 0.0]
    high = [value for value in surprise_values if value >= 0.55]
    latencies = [
        float(row["latency_ms"])
        for row in rows
        if "latency_ms" in row.keys() and row["latency_ms"] is not None
    ]
    timed_out = [
        row
        for row in rows
        if "timed_out" in row.keys() and int(row["timed_out"] or 0) != 0
    ]
    links = store.anticipation_outcome_links(repo_id=repo_id, limit=limit)
    link_counts = Counter()
    linked_surprises: list[dict[str, Any]] = []
    for row in links:
        link = _json_dict(
            row["prediction_link_json"]
            if "prediction_link_json" in row.keys()
            else "{}"
        )
        status = str(link.get("status") or "unknown")
        link_counts[status] += 1
        if status == "linked":
            linked_surprises.append(
                {
                    "prediction_id": link.get("prediction_id"),
                    "surprise": link.get("surprise"),
                    "result": row["result"],
                    "age_seconds": link.get("age_seconds"),
                }
            )
    report = {
        "schema_version": "ctxlayer.anticipation_shadow_validation.v1",
        "created_at": utc_now(),
        "mode": mode,
        "prediction_count": len(rows),
        "fired_count": len(fired),
        "high_signal_count": len(high),
        "max_surprise": round(max(surprise_values), 6) if surprise_values else 0.0,
        "avg_surprise": (
            round(sum(surprise_values) / len(surprise_values), 6)
            if surprise_values
            else 0.0
        ),
        "fires": bool(fired),
        "latency_observed": bool(latencies),
        "latency": _latency_summary(latencies),
        "timed_out_count": len(timed_out),
        "exceptions": 0,
        "outcome_link_count": len(links),
        "outcome_link_status": dict(sorted(link_counts.items())),
        "linked_outcome_examples": linked_surprises[:5],
    }
    report["gate"] = {
        "ok": report["fires"],
        "status": "shadow_signal_observed" if report["fires"] else "no_signal_observed",
    }
    return report


def _latency_summary(values: list[float]) -> dict[str, Any]:
    if not values:
        return {"count": 0}
    ordered = sorted(values)
    return {
        "count": len(ordered),
        "min_ms": round(ordered[0], 3),
        "max_ms": round(ordered[-1], 3),
        "avg_ms": round(sum(ordered) / len(ordered), 3),
        "p95_ms": round(ordered[min(len(ordered) - 1, int(len(ordered) * 0.95))], 3),
    }


def _json_dict(value: str | None) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _outcome_cases(store: SQLiteStore, *, limit: int) -> list[dict[str, Any]]:
    rows = store.conn.execute(
        """
        SELECT result, files_changed_json
        FROM outcomes
        ORDER BY created_at DESC, rowid DESC
        LIMIT ?
        """,
        (limit,),
    ).fetchall()
    cases = []
    seen_dirs: set[str] = set()
    for index, row in enumerate(reversed(rows)):
        files = _json_list(row["files_changed_json"])
        if not files:
            continue
        path = str(files[0])
        directory = _dirname(path)
        result = str(row["result"] or "").lower()
        failed = result in {"fail", "failed", "error", "revert", "broken"}
        cases.append(
            {
                "index": index,
                "path": path,
                "target_dir": directory,
                "failed": failed,
                "novel": directory not in seen_dirs,
            }
        )
        seen_dirs.add(directory)
    return cases


def _split_cases(
    cases: list[dict[str, Any]], *, holdout_ratio: float
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    if len(cases) < 2:
        return cases, []
    ratio = max(0.05, min(0.8, float(holdout_ratio)))
    train: list[dict[str, Any]] = []
    holdout: list[dict[str, Any]] = []
    for label in (False, True):
        group = [case for case in cases if bool(case["failed"]) is label]
        if len(group) <= 1:
            train.extend(group)
            continue
        count = max(1, min(len(group) - 1, round(len(group) * ratio)))
        train.extend(group[:-count])
        holdout.extend(group[-count:])
    if not holdout:
        count = max(1, min(len(cases) - 1, round(len(cases) * ratio)))
        train = cases[:-count]
        holdout = cases[-count:]
    train_dirs = {case["target_dir"] for case in train}
    holdout = [
        {**case, "novel": case["target_dir"] not in train_dirs} for case in holdout
    ]
    return (
        sorted(train, key=lambda item: int(item.get("index", 0))),
        sorted(holdout, key=lambda item: int(item.get("index", 0))),
    )


def _score_arm(
    *,
    arm: str,
    train_cases: list[dict[str, Any]],
    eval_cases: list[dict[str, Any]],
    store: SQLiteStore,
    repo_id: str,
    settings: Any,
    threshold: float,
    ece_bins: int,
    semantic_model: str,
    semantic_backend: str,
) -> dict[str, Any]:
    del settings
    if arm == "baseline":
        scores = [{"surprise": 0.0, "predicted": False, **case} for case in eval_cases]
        metrics = _metrics(scores, ece_bins=ece_bins)
        metrics["model"] = {"kind": "baseline", "trained_on_count": 0}
        return metrics
    if arm == "frequency_v0":
        model = WorldModel(store, repo_id, kind=f"benchmark_{arm}")
        return _score_production_model(
            model=model,
            arm=arm,
            train_cases=train_cases,
            eval_cases=eval_cases,
            threshold=threshold,
            ece_bins=ece_bins,
        )
    elif arm == "embedding_v1":
        model = EmbeddingWorldModel(
            store,
            repo_id,
            embedder=make_embedder(model_name=semantic_model, backend=semantic_backend),
            kind=f"benchmark_{arm}",
        )
        return _score_production_model(
            model=model,
            arm=arm,
            train_cases=train_cases,
            eval_cases=eval_cases,
            threshold=threshold,
            ece_bins=ece_bins,
        )
    return {"ok": False, "status": f"unknown_arm:{arm}"}


def _score_production_model(
    *,
    model: WorldModel | EmbeddingWorldModel,
    arm: str,
    train_cases: list[dict[str, Any]],
    eval_cases: list[dict[str, Any]],
    threshold: float,
    ece_bins: int,
) -> dict[str, Any]:
    model.train(outcome_rows=_case_outcome_rows(train_cases))
    scorer = SurpriseEngine(model.store, model)
    scored = []
    for index, case in enumerate(eval_cases):
        result = scorer.score(
            context={
                "state": "VALIDATE",
                "last_event": "outcome",
                "task_terms": _terms_for(case["path"]),
                "active_dir": case["target_dir"],
            },
            observation={
                "event_type": "file_edited",
                "target_paths": [case["path"]],
                "target_dir": case["target_dir"],
                "touches_critical": _critical(case["path"]),
            },
            session_id=f"anticipation-benchmark-{arm}-{index}",
            online=None,
        )
        surprise = scored_surprise(result)
        scored.append(
            {**case, "surprise": surprise, "predicted": surprise >= threshold}
        )
    metrics = _metrics(scored, ece_bins=ece_bins)
    metrics["model"] = _model_summary(model.latest())
    metrics["scorer"] = "production_surprise_engine"
    return metrics


def _metrics(scores: list[dict[str, Any]], *, ece_bins: int) -> dict[str, Any]:
    counts = Counter()
    error = 0.0
    novel_failures = 0
    novel_caught = 0
    for item in scores:
        predicted = bool(item["predicted"])
        failed = bool(item["failed"])
        if predicted and failed:
            counts["tp"] += 1
        elif predicted and not failed:
            counts["fp"] += 1
        elif not predicted and failed:
            counts["fn"] += 1
        else:
            counts["tn"] += 1
        error += abs(float(item["surprise"]) - (1.0 if failed else 0.0))
        if item.get("novel") and failed:
            novel_failures += 1
            if predicted:
                novel_caught += 1
    tp = counts["tp"]
    fp = counts["fp"]
    fn = counts["fn"]
    tn = counts["tn"]
    ece = _binned_ece(scores, bins=ece_bins)
    return {
        "ok": True,
        "cases": len(scores),
        "confusion": dict(counts),
        "mistake_preemption_rate": _rate(tp, tp + fn),
        "novel_situation_recall": _rate(novel_caught, novel_failures),
        "nudge_precision": _rate(tp, tp + fp),
        "nudge_false_positive_rate": _rate(fp, fp + tn),
        "surprise_mae": round(error / len(scores), 6) if scores else None,
        "surprise_ece": ece["ece"],
        "reliability_bins": ece["bins"],
    }


def _benchmark_gate(report: dict[str, Any], *, settings: Any) -> dict[str, Any]:
    arms = report.get("arms", {})
    embedding = arms.get("embedding_v1") or {}
    frequency = arms.get("frequency_v0") or {}
    baseline = arms.get("baseline") or {}
    threshold = settings.anticipation.guards.enforce_requires_ece_below
    findings = []
    if report.get("cases", 0) <= 0:
        findings.append("no_labeled_outcomes")
    embedder = (embedding.get("model") or {}).get("embedder") or {}
    if embedding and not embedder.get("semantic"):
        findings.append("semantic_arm_not_semantic")
    if embedding.get("novel_situation_recall", 0.0) < frequency.get(
        "novel_situation_recall", 0.0
    ):
        findings.append("embedding_not_above_frequency")
    if embedding.get("mistake_preemption_rate", 0.0) <= baseline.get(
        "mistake_preemption_rate", 0.0
    ):
        findings.append("anticipation_not_above_baseline")
    if float(embedding.get("surprise_ece") or 1.0) > float(threshold):
        findings.append("ece_above_threshold")
    return {
        "ok": not findings,
        "status": "passed" if not findings else "findings",
        "findings": findings,
    }


def _binned_ece(scores: list[dict[str, Any]], *, bins: int = 10) -> dict[str, Any]:
    if not scores:
        return {"ece": None, "bins": []}
    bin_count = max(1, int(bins))
    buckets: list[list[dict[str, Any]]] = [[] for _ in range(bin_count)]
    for item in scores:
        surprise = max(0.0, min(1.0, float(item.get("surprise") or 0.0)))
        index = min(bin_count - 1, int(surprise * bin_count))
        buckets[index].append(item)
    ece = 0.0
    reliability = []
    total = len(scores)
    for index, bucket in enumerate(buckets):
        if not bucket:
            continue
        expected = sum(float(item.get("surprise") or 0.0) for item in bucket) / len(
            bucket
        )
        observed = sum(1.0 if item.get("failed") else 0.0 for item in bucket) / len(
            bucket
        )
        weight = len(bucket) / total
        ece += weight * abs(expected - observed)
        reliability.append(
            {
                "bin": index,
                "count": len(bucket),
                "expected": round(expected, 6),
                "observed": round(observed, 6),
            }
        )
    return {"ece": round(ece, 6), "bins": reliability}


def scored_surprise(result: dict[str, Any]) -> float:
    value = result.get("surprise")
    if value is None:
        value = result.get("surprise_raw")
    return max(0.0, min(1.0, float(value or 0.0)))


def _model_summary(model: dict[str, Any] | None) -> dict[str, Any] | None:
    if not model:
        return None
    params = model.get("params") or {}
    kind = str(model.get("kind") or "")
    report_kind = kind.removeprefix("benchmark_")
    embedder = params.get("embedder")
    if isinstance(embedder, dict):
        embedder = {
            "backend": embedder.get("backend"),
            "model_name": embedder.get("model_name") or embedder.get("name"),
            "dims": embedder.get("dims") or embedder.get("dim"),
            "degraded_reason": embedder.get("degraded_reason")
            or embedder.get("degraded"),
            "semantic": embedder.get("backend") == "sentence-transformers"
            and not (embedder.get("degraded_reason") or embedder.get("degraded")),
        }
    return {
        "model_id": model.get("model_id"),
        "kind": report_kind or kind,
        "storage_kind": kind,
        "trained_on_count": int(model.get("trained_on_count") or 0),
        "ece": model.get("ece"),
        "params_hash": model.get("params_hash"),
        "embedder": embedder,
    }


def _case_outcome_rows(cases: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "result": "fail" if case["failed"] else "pass",
            "files": [str(case["path"])],
        }
        for case in cases
    ]


def _failure_priors_by_dir(cases: list[dict[str, Any]]) -> dict[str, float]:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for case in cases:
        grouped.setdefault(str(case["target_dir"]), []).append(case)
    return {directory: _smoothed_rate(items) for directory, items in grouped.items()}


def _smoothed_rate(cases: list[dict[str, Any]]) -> float:
    failures = sum(1 for case in cases if case["failed"])
    return (failures + 1.0) / (len(cases) + 2.0) if cases else 0.5


def _case_text(case: dict[str, Any]) -> str:
    terms = " ".join(_terms_for(case["path"]))
    critical = " critical" if _critical(case["path"]) else ""
    return f"{case['target_dir']} {terms}{critical}"


def _json_list(value: str | None) -> list[str]:
    import json

    try:
        parsed = json.loads(value or "[]")
    except json.JSONDecodeError:
        return []
    return [str(item) for item in parsed] if isinstance(parsed, list) else []


def _terms_for(path: str) -> list[str]:
    return [
        part for part in path.replace("\\", "/").replace(".", "/").split("/") if part
    ]


def _critical(path: str) -> bool:
    lowered = path.lower()
    return any(token in lowered for token in ("auth", "token", "billing", "payment"))


def _rate(numerator: int, denominator: int) -> float:
    return round(numerator / denominator, 6) if denominator else 0.0
