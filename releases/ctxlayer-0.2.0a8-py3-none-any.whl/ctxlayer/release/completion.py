from __future__ import annotations

import json
from pathlib import Path
from typing import Any


BLOCKING_STATES = {"planned", "partial", "dead_or_unused"}
RESOLVED_STATES = {"wired_end_to_end", "non_production", "deleted", "not_applicable"}

REQUIRED_WORKSTREAMS: tuple[dict[str, Any], ...] = (
    {
        "id": "01-memory-os",
        "title": "Memory OS foundation",
        "required": True,
        "status": "partial",
        "gate": "typed memory lifecycle, revisions, review queue, quarantine, and serving tests pass",
    },
    {
        "id": "02-continuation-activity-memory",
        "title": "Continuation capsules",
        "required": True,
        "status": "partial",
        "gate": "fresh-process resume benchmark and continuation pack serving tests pass",
    },
    {
        "id": "03-dreaming-consolidation-pipeline",
        "title": "Dreaming and consolidation",
        "required": True,
        "status": "partial",
        "gate": "deterministic and agent-assisted consolidation, maintenance, review, and promotion tests pass",
    },
    {
        "id": "04-retrieval-and-pack-serving",
        "title": "Retrieval and pack serving",
        "required": True,
        "status": "partial",
        "gate": "hybrid recall, vector diagnostics, continuation/policy sections, and retrieval benchmark pass",
    },
    {
        "id": "05-skill-workflow-library",
        "title": "Skill workflow library",
        "required": True,
        "status": "partial",
        "gate": "skill replay, verification commands, maintenance, interfaces, and repeated-task benchmark pass",
    },
    {
        "id": "06-code-graph-and-agent-reranking",
        "title": "Code graph and reranking",
        "required": True,
        "status": "partial",
        "gate": "incremental graph, graph MCP, reranker diagnostics, and retrieval benchmark pass",
    },
    {
        "id": "07-reflective-optimizer",
        "title": "Reflective optimizer",
        "required": True,
        "status": "partial",
        "gate": "optimizer archive/adopt/revert and holdout improvement gates pass across interfaces",
    },
    {
        "id": "08-sandboxed-self-modification",
        "title": "Sandboxed self-modification",
        "required": True,
        "status": "partial",
        "gate": "self-mod proposal, isolated validation, human approval, rollback, and safety tests pass",
    },
    {
        "id": "09-security-governance-memory-defense",
        "title": "Security governance and memory defense",
        "required": True,
        "status": "partial",
        "gate": "memory defense, quarantine workflow, role approval, and adversarial tests fail closed",
    },
    {
        "id": "10-interfaces-cli-mcp-dashboard",
        "title": "Interfaces",
        "required": True,
        "status": "partial",
        "gate": "CLI, MCP, HTTP, and dashboard parity matrix passes",
    },
    {
        "id": "11-evaluation-acceptance-gates",
        "title": "Evaluation and acceptance gates",
        "required": True,
        "status": "partial",
        "gate": "final corpus, trend, release blocker, contamination, and report gates pass",
    },
    {
        "id": "12-rollout-and-completion-roadmap",
        "title": "Rollout and completion roadmap",
        "required": True,
        "status": "partial",
        "gate": "gap-audit register, dead-code inventory, no-v0 gate, and release checklist pass",
    },
    {
        "id": "13-codex-parallel-agent-and-memory-enforcement",
        "title": "Codex memory-first and parallel-agent enforcement",
        "required": True,
        "status": "planned",
        "gate": "memory-first hooks and parallel-agent parent/child session tests pass in local, worktree, and cloud setup modes",
    },
)


def default_gap_register() -> dict[str, Any]:
    return {
        "schema_version": "ctxlayer.gap_audit_register.v1",
        "states": {
            "blocking": sorted(BLOCKING_STATES),
            "resolved": sorted(RESOLVED_STATES),
        },
        "items": [dict(item) for item in REQUIRED_WORKSTREAMS],
    }


def gap_register_paths(repo_root: Path) -> list[Path]:
    return [
        repo_root / ".ctxlayer" / "gap-audit-register.json",
        repo_root / "gap-audit-register.json",
        repo_root / "plan" / "gap-audit-register.json",
    ]


def find_gap_register(repo_root: Path) -> Path | None:
    return next((item for item in gap_register_paths(repo_root) if item.exists()), None)


def load_gap_register(repo_root: Path) -> dict[str, Any]:
    path = find_gap_register(repo_root)
    if path is None:
        return {
            "ok": False,
            "reason": "gap_audit_register_missing",
            "searched": [str(item) for item in gap_register_paths(repo_root)],
            "register": default_gap_register(),
        }
    return {
        "ok": True,
        "path": str(path),
        "register": json.loads(path.read_text(encoding="utf-8")),
    }


def write_default_gap_register(
    repo_root: Path, *, path: Path | None = None
) -> dict[str, Any]:
    target = path or (repo_root / "plan" / "gap-audit-register.json")
    if not target.is_absolute():
        target = repo_root / target
    target.parent.mkdir(parents=True, exist_ok=True)
    register = default_gap_register()
    target.write_text(
        json.dumps(register, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return {"ok": True, "path": str(target), "register": register}


def validate_gap_register(repo_root: Path) -> dict[str, Any]:
    loaded = load_gap_register(repo_root)
    register = loaded["register"]
    items = _gap_items(register)
    by_id = {str(item.get("id")): item for item in items if item.get("id")}
    missing = [
        item["id"]
        for item in REQUIRED_WORKSTREAMS
        if item["required"] and item["id"] not in by_id
    ]
    missing_gate = [
        str(item.get("id"))
        for item in items
        if bool(item.get("required", True)) and not str(item.get("gate") or "").strip()
    ]
    unresolved = [
        item
        for item in items
        if str(item.get("status") or item.get("state") or "").lower() in BLOCKING_STATES
        and bool(item.get("required", True))
    ]
    unknown_state = [
        {
            "id": item.get("id"),
            "status": item.get("status") or item.get("state"),
        }
        for item in items
        if str(item.get("status") or item.get("state") or "").lower()
        not in BLOCKING_STATES | RESOLVED_STATES
    ]
    proofless_resolved = [
        {
            "id": item.get("id"),
            "status": item.get("status") or item.get("state"),
            "missing": _resolved_proof_missing(item),
        }
        for item in items
        if bool(item.get("required", True))
        and str(item.get("status") or item.get("state") or "").lower()
        in RESOLVED_STATES
        and _resolved_proof_missing(item)
    ]
    violations = []
    if not loaded["ok"]:
        violations.append(
            {"name": "gap_audit_register_present", "reason": loaded["reason"]}
        )
    if missing:
        violations.append(
            {"name": "required_workstream_rows_present", "missing": missing}
        )
    if missing_gate:
        violations.append(
            {"name": "required_workstreams_have_gates", "missing_gate": missing_gate}
        )
    if unresolved:
        violations.append(
            {"name": "required_workstreams_resolved", "unresolved": unresolved}
        )
    if unknown_state:
        violations.append({"name": "known_workstream_states", "unknown": unknown_state})
    if proofless_resolved:
        violations.append(
            {"name": "resolved_workstreams_have_proof", "proofless": proofless_resolved}
        )
    return {
        "ok": not violations,
        "schema_version": "ctxlayer.gap_audit_validation.v1",
        "path": loaded.get("path"),
        "searched": loaded.get("searched"),
        "items": len(items),
        "required_items": sum(1 for item in items if bool(item.get("required", True))),
        "required_workstreams": [item["id"] for item in REQUIRED_WORKSTREAMS],
        "missing_required": missing,
        "missing_gate": missing_gate,
        "unresolved": unresolved,
        "unknown_state": unknown_state,
        "proofless_resolved": proofless_resolved,
        "violations": violations,
    }


def _gap_items(data: Any) -> list[dict[str, Any]]:
    if isinstance(data, list):
        return [dict(item) for item in data if isinstance(item, dict)]
    if isinstance(data, dict):
        raw = data.get("items") or data.get("gaps") or data.get("workstreams")
        if isinstance(raw, list):
            return [dict(item) for item in raw if isinstance(item, dict)]
        if isinstance(raw, dict):
            return [
                {"id": key, **value}
                for key, value in raw.items()
                if isinstance(value, dict)
            ]
    return []


def _resolved_proof_missing(item: dict[str, Any]) -> list[str]:
    status = str(item.get("status") or item.get("state") or "").lower()
    required = ["implemented_evidence", "verification", "proof_artifacts"]
    if status == "non_production":
        required = ["rationale", "claim_removal_evidence"]
    if status in {"deleted", "not_applicable"}:
        required = ["rationale"]
    missing = []
    for key in required:
        value = item.get(key)
        if value is None or value == "" or value == [] or value == {}:
            missing.append(key)
    return missing
