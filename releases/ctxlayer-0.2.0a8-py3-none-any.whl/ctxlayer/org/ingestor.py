from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ctxlayer.memory.unified import UnifiedMemory
from ctxlayer.org.connector import ConnectorItem
from ctxlayer.org.connectors import CONNECTORS
from ctxlayer.org.extraction import classify
from ctxlayer.org.privacy import redact_org_text
from ctxlayer.org.staleness import compute_decay_at, staleness_state
from ctxlayer.security.memory_defense import (
    detect_embedding_cluster_anomaly,
    evaluate_ingest,
    require_actor_role,
)
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import sha256_text, stable_id, utc_now


class OrgIngestor:
    def __init__(
        self,
        repo_root: Path,
        store: SQLiteStore,
        repo_id: str | None,
        workspace_id: str,
    ):
        self.repo_root = repo_root
        self.store = store
        self.repo_id = repo_id
        self.workspace_id = workspace_id
        self.memory = UnifiedMemory(store, workspace_id, repo_id)

    def connector_add(
        self,
        *,
        kind: str,
        display_name: str | None = None,
        config: dict[str, Any] | None = None,
        secret_ref: str | None = None,
        access_scope: str = "restricted",
        remote_enabled: bool = False,
    ) -> dict[str, Any]:
        if kind not in CONNECTORS:
            raise ValueError(f"unsupported org connector: {kind}")
        row = self.store.add_org_connector(
            workspace_id=self.workspace_id,
            kind=kind,
            display_name=display_name or kind,
            config=config or {},
            secret_ref=secret_ref,
            access_scope=access_scope,
            remote_enabled=remote_enabled,
        )
        audit = self.store.append_audit(
            pack_id=f"org-connector:{row['connector_id']}",
            payload={
                "event": "org_connector_added",
                "connector_id": row["connector_id"],
                "workspace_id": self.workspace_id,
                "kind": kind,
                "remote_enabled": bool(row["remote_enabled"]),
                "access_scope": access_scope,
            },
        )
        return {"ok": True, "connector": _connector_dict(row), "audit": audit}

    def connectors(self, *, kind: str | None = None) -> dict[str, Any]:
        rows = self.store.org_connectors(workspace_id=self.workspace_id, kind=kind)
        return {
            "ok": True,
            "connectors": [_connector_dict(row) for row in rows],
            "count": len(rows),
        }

    def ingest(
        self,
        connector: str,
        *,
        since: str | None = None,
        path: str | None = None,
        remote: bool = False,
        actor: str = "system",
    ) -> dict[str, Any]:
        connector_row = self._resolve_connector(connector, path=path)
        kind = connector_row["kind"]
        if remote and not bool(connector_row["remote_enabled"]):
            raise PermissionError(
                "remote org ingestion requires connector remote_enabled=1"
            )
        config = json.loads(connector_row["config_json"] or "{}")
        if path:
            config["path"] = path
        connector_cls = CONNECTORS[kind]
        adapter = connector_cls()
        if (
            remote
            and adapter.is_local_first()
            and not bool(connector_row["remote_enabled"])
        ):
            raise PermissionError("remote org ingestion is disabled for this connector")
        run_id = self.store.start_org_ingest_run(
            connector_id=connector_row["connector_id"],
            workspace_id=self.workspace_id,
            since=since,
            remote_used=remote,
        )
        items = list(adapter.fetch(since=since, config=config))
        redacted_items: list[tuple[ConnectorItem, str, dict[str, Any]]] = []
        embeddings: dict[str, list[float]] = {}
        for item in items:
            redacted, redaction_summary = redact_org_text(item.raw_text)
            redacted_items.append((item, redacted, redaction_summary))
            embeddings[item.source_ref] = _text_vector(redacted)
        cluster = (
            detect_embedding_cluster_anomaly(embeddings)
            if embeddings
            else {"ok": True, "flagged": []}
        )
        flagged_refs = set(cluster.get("flagged") or [])

        stored = []
        items_rejected = 0
        redaction_count = 0
        for item, redacted, redaction_summary in redacted_items:
            redaction_count += int(redaction_summary.get("redacted_count", 0) or 0)
            extraction = classify(
                ConnectorItem(
                    source_ref=item.source_ref,
                    raw_text=redacted,
                    authored_at=item.authored_at,
                    author=item.author,
                    metadata=item.metadata,
                )
            )
            defense = evaluate_ingest(
                redacted,
                actor=actor,
                source_connector=kind,
                external=True,
            )
            if "exfiltrate" in redacted.lower() or "exfiltrate" in set(
                defense.get("injection_flags") or []
            ):
                defense = {
                    **defense,
                    "ok": False,
                    "decision": "deny",
                    "reason": "unsafe_external_text",
                    "serve_authoritative": False,
                }
            if item.source_ref in flagged_refs:
                defense = {
                    **defense,
                    "ok": False,
                    "decision": "deny",
                    "reason": "cohesive_anomaly_cluster",
                    "poison_flags": sorted(
                        set(defense.get("poison_flags", [])) | {item.source_ref}
                    ),
                    "cluster_baseline": cluster.get("baseline_similarity", 0.0),
                }
            if defense["decision"] in {"deny", "quarantine"}:
                items_rejected += 1
            content_hash = sha256_text(redacted)
            candidate_id = stable_id(self.workspace_id, kind, content_hash)
            memory_record_id = stable_id("org-memory", candidate_id)
            decay_at = compute_decay_at(item.authored_at)
            provenance = {
                "origin": "org_connector",
                "source_connector": kind,
                "source_ref": item.source_ref,
                "author": item.author,
                "captured_at": item.authored_at,
                "ingested_at": utc_now(),
                "connector_id": connector_row["connector_id"],
                "access_scope": connector_row["access_scope"],
                "external": True,
                "serve_authoritative": False,
            }
            row = self.store.upsert_org_candidate(
                candidate_id=candidate_id,
                workspace_id=self.workspace_id,
                repo_id=self.repo_id,
                memory_record_id=None,
                source_connector=kind,
                source_ref=item.source_ref,
                content_extract=str(defense.get("sanitized_text") or redacted),
                content_hash=content_hash,
                extracted_type=extraction.extracted_type,
                confidence=min(float(extraction.confidence), 0.6),
                defense_result=defense,
                captured_at=item.authored_at,
                decay_at=decay_at,
                provenance=provenance,
                redaction_summary=redaction_summary,
                access_scope=str(connector_row["access_scope"] or "restricted"),
            )
            if row["status"] != "quarantined":
                stored.append(_candidate_dict(row))
                continue
            actual_memory_id = self.memory.propose(
                record_type="org_knowledge",
                assertion=str(defense.get("sanitized_text") or redacted),
                source_kind=f"org:{kind}",
                confidence=min(float(extraction.confidence), 0.6),
                scope=f"org:{kind}:{connector_row['access_scope']}",
                extraction_method="connector",
                evidence=[
                    {
                        "repo_id": self.repo_id,
                        "path": None,
                        "evidence_kind": f"org:{kind}",
                        "evidence_hash": content_hash,
                        "source_ref": item.source_ref,
                        "metadata": {"org_candidate_id": row["candidate_id"]},
                    }
                ],
                record_id=memory_record_id,
                status="quarantined",
                trust="untrusted",
                owner=actor,
                provenance=provenance,
                metadata={
                    "org_candidate_id": row["candidate_id"],
                    "extracted_type": extraction.extracted_type,
                    "subject_key": extraction.subject_key,
                    "defense_result": defense,
                    "redaction_summary": redaction_summary,
                    "access_scope": connector_row["access_scope"],
                },
                expires_at=decay_at,
            )
            self.store.update_org_candidate_memory(
                row["candidate_id"], actual_memory_id
            )
            self.store.enqueue_memory_review(
                record_id=actual_memory_id,
                reason=f"org knowledge requires codeowner review: {defense['reason']}",
                severity="critical" if defense["decision"] == "deny" else "high",
            )
            contradictions = self.memory.detect_conflicts(actual_memory_id)
            contradictions = [
                *contradictions,
                *self._org_contradictions(
                    actual_memory_id, str(defense.get("sanitized_text") or redacted)
                ),
            ]
            if contradictions:
                self.store.upsert_org_candidate(
                    candidate_id=row["candidate_id"],
                    workspace_id=self.workspace_id,
                    repo_id=self.repo_id,
                    memory_record_id=actual_memory_id,
                    source_connector=kind,
                    source_ref=item.source_ref,
                    content_extract=str(defense.get("sanitized_text") or redacted),
                    content_hash=content_hash,
                    extracted_type=extraction.extracted_type,
                    confidence=min(float(extraction.confidence), 0.6),
                    defense_result=defense,
                    contradictions=contradictions,
                    captured_at=item.authored_at,
                    decay_at=decay_at,
                    provenance=provenance,
                    redaction_summary=redaction_summary,
                    access_scope=str(connector_row["access_scope"] or "restricted"),
                )
            stored.append(
                _candidate_dict(self.store.org_candidate(row["candidate_id"]))
            )
        audit = self.store.append_audit(
            pack_id=f"org-ingest:{run_id}",
            payload={
                "event": "org_ingest_run",
                "run_id": run_id,
                "connector_id": connector_row["connector_id"],
                "kind": kind,
                "items_seen": len(items),
                "items_quarantined": len(stored),
                "items_rejected": items_rejected,
                "redactions": redaction_count,
                "remote_used": remote,
            },
        )
        self.store.finish_org_ingest_run(
            run_id,
            items_seen=len(items),
            items_quarantined=len(stored),
            items_rejected=items_rejected,
            redactions=redaction_count,
            audit_hash=audit["row_hash"],
        )
        return {
            "ok": True,
            "run_id": run_id,
            "connector_id": connector_row["connector_id"],
            "items_seen": len(items),
            "items_quarantined": len(stored),
            "items_rejected": items_rejected,
            "redactions": redaction_count,
            "remote_used": remote,
            "candidates": stored,
        }

    def candidates(
        self,
        *,
        status: str | None = "quarantined",
        source: str | None = None,
        scope: str | None = None,
        actor: str = "local-user",
        limit: int = 100,
    ) -> dict[str, Any]:
        _ = actor
        rows = self.store.org_candidates(
            workspace_id=self.workspace_id,
            repo_id=self.repo_id,
            status=status,
            source_connector=source,
            access_scope=scope,
            limit=limit,
        )
        return {
            "ok": True,
            "candidates": [_candidate_dict(row) for row in rows],
            "count": len(rows),
        }

    def approve(
        self,
        candidate_id: str,
        *,
        actor: str = "codeowner",
        supersede: str | None = None,
    ) -> dict[str, Any]:
        auth = require_actor_role(actor, "codeowner", "org_approve")
        if not auth["ok"]:
            raise PermissionError("org approval requires codeowner role")
        row = self.store.org_candidate(candidate_id)
        if not row:
            raise KeyError(f"org candidate not found: {candidate_id}")
        defense = json.loads(row["defense_result"] or "{}")
        if defense.get("decision") == "deny":
            raise ValueError("denied org candidates cannot be approved")
        memory_id = row["memory_record_id"]
        if not memory_id:
            raise ValueError("org candidate is not mirrored to memory")
        memory_row = self.store.memory_record(memory_id)
        provenance = (
            json.loads(memory_row["provenance_json"] or "{}") if memory_row else {}
        )
        provenance = {
            **provenance,
            "validator": actor,
            "approved_external": True,
            "validated_at": utc_now(),
            "serve_authoritative": False,
        }
        self.store.set_memory_record_status(
            record_id=memory_id,
            status="active",
            trust="approved_org_memory",
            actor=actor,
            reason="org candidate approved",
            superseded_by=supersede,
            provenance=provenance,
            confidence=min(float(row["confidence"] or 0.3), 0.6),
        )
        updated = self.store.set_org_candidate_status(
            candidate_id,
            status="active",
            actor=actor,
            reason="org candidate approved",
        )
        self.store.append_audit(
            pack_id=f"org-candidate:{candidate_id}",
            payload={
                "event": "org_candidate_approved",
                "candidate_id": candidate_id,
                "memory_record_id": memory_id,
                "actor": actor,
                "supersede": supersede,
                "authoritative": False,
            },
        )
        return {"ok": True, "candidate": _candidate_dict(updated)}

    def reject(
        self, candidate_id: str, *, actor: str = "codeowner", reason: str = "rejected"
    ) -> dict[str, Any]:
        auth = require_actor_role(actor, "codeowner", "org_reject")
        if not auth["ok"]:
            raise PermissionError("org rejection requires codeowner role")
        row = self.store.org_candidate(candidate_id)
        if not row:
            raise KeyError(f"org candidate not found: {candidate_id}")
        updated = self.store.set_org_candidate_status(
            candidate_id,
            status="rejected",
            actor=actor,
            reason=reason,
            memory_status="rejected",
            memory_trust="untrusted",
        )
        self.store.append_audit(
            pack_id=f"org-candidate:{candidate_id}",
            payload={
                "event": "org_candidate_rejected",
                "candidate_id": candidate_id,
                "actor": actor,
            },
        )
        return {"ok": True, "candidate": _candidate_dict(updated)}

    def audit(self, candidate_id: str) -> dict[str, Any]:
        row = self.store.org_candidate(candidate_id)
        if not row:
            raise KeyError(f"org candidate not found: {candidate_id}")
        return {
            "ok": True,
            "candidate": _candidate_dict(row),
            "memory": (
                self.memory.explain(row["memory_record_id"])
                if row["memory_record_id"]
                else None
            ),
            "audit": dict(
                self.store.audit_record(f"org-candidate:{candidate_id}") or {}
            ),
        }

    def _resolve_connector(self, connector: str, *, path: str | None = None) -> Any:
        row = self.store.org_connector(connector)
        if row:
            return row
        rows = self.store.org_connectors(
            workspace_id=self.workspace_id, kind=connector, enabled=True
        )
        if rows:
            return rows[0]
        if connector not in CONNECTORS:
            raise ValueError(f"unknown org connector: {connector}")
        config = {"path": path} if path else {}
        return self.store.add_org_connector(
            workspace_id=self.workspace_id,
            kind=connector,
            display_name=connector,
            config=config,
            remote_enabled=False,
        )

    def _org_contradictions(
        self, record_id: str, assertion: str
    ) -> list[dict[str, Any]]:
        lowered = assertion.lower()
        if "must " not in lowered and "must not" not in lowered:
            return []
        found: list[dict[str, Any]] = []
        for row in self.store.memory_records(
            type="org_knowledge",
            status="active",
            repo_id=self.repo_id,
            workspace_id=self.workspace_id,
        ):
            other = str(row["assertion"])
            other_l = other.lower()
            opposes = (
                "must not" in lowered
                and "must " in other_l
                and "must not" not in other_l
            ) or (
                "must not" in other_l
                and "must " in lowered
                and "must not" not in lowered
            )
            if not opposes:
                continue
            left_terms = {term for term in lowered.split() if len(term) > 4}
            right_terms = {term for term in other_l.split() if len(term) > 4}
            if len(left_terms & right_terms) < 2:
                continue
            conflict_id = self.store.upsert_memory_conflict(
                left_record_id=record_id,
                right_record_id=row["record_id"],
                conflict_type="org_contradiction",
                summary="Org knowledge uses conflicting obligation verbs.",
            )
            found.append(
                {
                    "conflict_id": conflict_id,
                    "other_record_id": row["record_id"],
                    "summary": "Org knowledge uses conflicting obligation verbs.",
                }
            )
        return found


def _connector_dict(row: Any) -> dict[str, Any]:
    return {
        "connector_id": row["connector_id"],
        "workspace_id": row["workspace_id"],
        "kind": row["kind"],
        "display_name": row["display_name"],
        "config": json.loads(row["config_json"] or "{}"),
        "secret_ref": row["secret_ref"],
        "access_scope": row["access_scope"],
        "remote_enabled": bool(row["remote_enabled"]),
        "enabled": bool(row["enabled"]),
    }


def _candidate_dict(row: Any) -> dict[str, Any]:
    return {
        "candidate_id": row["candidate_id"],
        "workspace_id": row["workspace_id"],
        "repo_id": row["repo_id"],
        "memory_record_id": row["memory_record_id"],
        "source_connector": row["source_connector"],
        "source_ref": row["source_ref"],
        "content_extract": row["content_extract"],
        "content_hash": row["content_hash"],
        "extracted_type": row["extracted_type"],
        "trust_tier": row["trust_tier"],
        "confidence": float(row["confidence"] or 0.0),
        "status": row["status"],
        "defense_result": json.loads(row["defense_result"] or "{}"),
        "contradictions": json.loads(row["contradictions"] or "[]"),
        "linked_entities": json.loads(row["linked_entities"] or "[]"),
        "captured_at": row["captured_at"],
        "ingested_at": row["ingested_at"],
        "decay_at": row["decay_at"],
        "staleness_state": staleness_state(row["decay_at"]),
        "provenance": json.loads(row["provenance"] or "{}"),
        "redaction_summary": json.loads(row["redaction_summary"] or "{}"),
        "access_scope": row["access_scope"],
    }


def _text_vector(text: str) -> list[float]:
    buckets = [0.0] * 16
    for token in text.lower().split():
        buckets[hash(token) % len(buckets)] += 1.0
    total = sum(buckets) or 1.0
    return [value / total for value in buckets]
