from __future__ import annotations

from fnmatch import fnmatch
from typing import Any

from ctxlayer.workflow.classifier import classify, infer_mode
from ctxlayer.workflow.feature_catalog import (
    FEATURE_CATALOG,
    WORKFLOW_RECOMMEND_SCHEMA,
    template_params,
)
from ctxlayer.workflow.playbook import FEATURE_COVERAGE, GATE_KINDS, PLAYBOOK

RESOLVABLE_PARAMS = {
    "task",
    "task_session_id",
    "pack_id",
    "plan_id",
    "paths",
    "capabilities",
    "intent_id",
    "goal_id",
}


class WorkflowRouter:
    def recommend(
        self,
        *,
        task: str,
        mode: str = "write",
        paths: list[str] | None = None,
        capabilities: list[str] | None = None,
        intent_id: str | None = None,
        goal_id: str | None = None,
        impact_report: dict[str, Any] | None = None,
        task_session_id: str | None = None,
        pack_id: str | None = None,
        plan_id: str | None = None,
        signals: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        paths = sorted({path.replace("\\", "/") for path in paths or [] if path})
        capabilities = sorted({item for item in capabilities or [] if item})
        risk_score = _risk_score(impact_report)
        normalized_mode = infer_mode(task, mode)
        task_types = classify(
            task,
            paths=paths,
            capabilities=capabilities,
            mode=normalized_mode,
            impact_risk=risk_score,
        )
        required_ids = _collect(task_types, "required_features")
        optional_ids = _collect(task_types, "optional_features")
        optional_ids = [item for item in optional_ids if item not in required_ids]
        gates = _gates(task_types)
        context = {
            "task": task,
            "paths": paths,
            "capabilities": capabilities,
            "intent_id": intent_id,
            "goal_id": goal_id,
            "task_session_id": task_session_id,
            "pack_id": pack_id,
            "plan_id": plan_id,
        }
        escalation = _escalation(task_types, paths, risk_score)
        return {
            "ok": True,
            "schema_version": WORKFLOW_RECOMMEND_SCHEMA,
            "task": task,
            "mode": normalized_mode,
            "paths": paths,
            "capabilities": capabilities,
            "intent_id": intent_id,
            "goal_id": goal_id,
            "task_types": task_types,
            "required_features": [
                _feature(feature_id, context, task_types) for feature_id in required_ids
            ],
            "optional_features": [
                _feature(feature_id, context, task_types) for feature_id in optional_ids
            ],
            "gates": [
                {"gate_id": gate, "kind": GATE_KINDS.get(gate, "durable")}
                for gate in gates
            ],
            "escalation": escalation,
            "stop_when": _stop_when(task_types),
            "signals": signals or {},
        }

    def lint(self) -> dict[str, Any]:
        errors: list[str] = []
        for feature_id, feature in FEATURE_CATALOG.items():
            coverage = FEATURE_COVERAGE.get(feature_id)
            if not coverage:
                errors.append(f"feature {feature_id} lacks coverage classification")
            elif not coverage.get("reason"):
                errors.append(f"feature {feature_id} coverage lacks reason")
            params = template_params(feature["command_template"])
            required_params = set(feature.get("required_params", []))
            missing_contract = params - set(feature.get("optional_params", [])) - required_params
            if missing_contract:
                errors.append(
                    f"feature {feature_id} template params missing from param contract: "
                    f"{', '.join(sorted(missing_contract))}"
                )
            unresolved = required_params - RESOLVABLE_PARAMS
            if unresolved:
                errors.append(
                    f"feature {feature_id} required params are not router-resolvable: "
                    f"{', '.join(sorted(unresolved))}"
                )
        referenced = {
            feature_id
            for entry in PLAYBOOK.values()
            for key in ("required_features", "optional_features")
            for feature_id in entry.get(key, [])
        }
        unknown = referenced - set(FEATURE_CATALOG)
        if unknown:
            errors.append(f"playbook references unknown features: {', '.join(sorted(unknown))}")
        return {
            "ok": not errors,
            "schema_version": "ctxlayer.workflow_lint.v1",
            "errors": errors,
            "feature_count": len(FEATURE_CATALOG),
            "task_type_count": len(PLAYBOOK),
        }


def _collect(task_types: list[str], key: str) -> list[str]:
    values: list[str] = []
    for task_type_id in task_types:
        for feature_id in PLAYBOOK[task_type_id].get(key, []):
            if feature_id not in values:
                values.append(feature_id)
    return values


def _gates(task_types: list[str]) -> list[str]:
    values: list[str] = []
    for task_type_id in task_types:
        for gate_id in PLAYBOOK[task_type_id].get("gates", []):
            if gate_id not in values:
                values.append(gate_id)
    return values


def _feature(feature_id: str, context: dict[str, Any], task_types: list[str]) -> dict[str, Any]:
    entry = FEATURE_CATALOG[feature_id]
    command, missing = _render_command(entry["command_template"], context)
    return {
        "feature_id": feature_id,
        "command": command,
        "mcp_tool": entry["mcp_tool"],
        "why": entry["purpose"],
        "gate_kind": entry["gate_kind"],
        "required_params": entry.get("required_params", []),
        "optional_params": entry.get("optional_params", []),
        "unresolved_params": missing,
        "remediation": _remediation(feature_id, missing) if missing else None,
        "task_types": [item for item in task_types if feature_id in PLAYBOOK[item].get("required_features", []) or feature_id in PLAYBOOK[item].get("optional_features", [])],
    }


def _render_command(template: str, context: dict[str, Any]) -> tuple[str, list[str]]:
    missing = [
        param
        for param in sorted(template_params(template))
        if context.get(param) in (None, "", [])
    ]
    values = {
        key: (_format_value(value) if value not in (None, "", []) else f"<{key}>")
        for key, value in context.items()
    }
    return template.format(**values), missing


def _format_value(value: Any) -> str:
    if isinstance(value, list):
        return ",".join(str(item) for item in value)
    return str(value)


def _remediation(feature_id: str, missing: list[str]) -> str:
    return (
        f"Resolve {', '.join(missing)} before running {feature_id}; "
        "use workflow start or the prior CTX command output to fill the placeholder."
    )


def _risk_score(impact_report: dict[str, Any] | None) -> float:
    if not impact_report:
        return 0.0
    risk = impact_report.get("risk", {}) if isinstance(impact_report, dict) else {}
    try:
        return float(risk.get("score", 0.0) or 0.0)
    except (TypeError, ValueError):
        return 0.0


def _escalation(task_types: list[str], paths: list[str], risk_score: float) -> dict[str, Any]:
    reasons: list[str] = []
    if risk_score >= 7.0:
        reasons.append(f"impact risk score {risk_score:g} >= 7")
    patterns = PLAYBOOK["standard_edit"]["escalate_when"]["touches"]
    touched = [path for path in paths if any(fnmatch(path, pattern) for pattern in patterns)]
    if touched:
        reasons.append(f"critical path touched: {', '.join(touched[:5])}")
    if any(item in task_types for item in {"security_change", "data_migration"}):
        reasons.append("task type requires explicit escalation review")
    return {
        "triggered": bool(reasons),
        "reasons": reasons,
        "actions": ["route to review with ctxlayer agent route"] if reasons else [],
    }


def _stop_when(task_types: list[str]) -> list[str]:
    return [PLAYBOOK[item]["stop_when"] for item in task_types if PLAYBOOK[item].get("stop_when")]
