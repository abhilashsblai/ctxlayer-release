from __future__ import annotations

from string import Formatter
from typing import Any

WORKFLOW_RECOMMEND_SCHEMA = "ctxlayer.workflow_recommend.v1"
WORKFLOW_NEXT_SCHEMA = "ctxlayer.workflow_next.v1"

UNRESOLVED_PARAM_BEHAVIOR = (
    "emit placeholder + remediation; never a half-built command"
)

FEATURE_CATALOG: dict[str, dict[str, Any]] = {
    "pack": {
        "command_template": 'ctxlayer --repo . pack --task "{task}"',
        "mcp_tool": "get_context_pack",
        "purpose": "serve snapshot-pinned context before work proceeds",
        "gate_kind": "durable",
        "required_params": ["task"],
        "optional_params": ["paths", "intent_id", "goal_id"],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "plan": {
        "command_template": (
            "ctxlayer --repo . plan create --task-session-id {task_session_id} "
            "--pack-id {pack_id} --file <plan.json>"
        ),
        "mcp_tool": "plan_create",
        "purpose": "declare intended files, capabilities, tests, and risk before edits",
        "gate_kind": "durable",
        "required_params": ["task_session_id", "pack_id"],
        "optional_params": [],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "checkpoint": {
        "command_template": (
            "ctxlayer --repo . plan checkpoint {plan_id} --step-id <step_id> "
            "--path <changed_path>"
        ),
        "mcp_tool": "plan_checkpoint",
        "purpose": "tie changed files to the active structured plan step",
        "gate_kind": "durable",
        "required_params": ["plan_id"],
        "optional_params": ["paths"],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "impact": {
        "command_template": (
            "git diff --name-only HEAD | ctxlayer --repo . impact --paths-from-stdin"
        ),
        "mcp_tool": "impact_of",
        "purpose": "identify affected code, risk, and tests",
        "gate_kind": "none",
        "required_params": [],
        "optional_params": ["paths"],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "check_diff": {
        "command_template": (
            "git diff HEAD | ctxlayer --repo . check-diff --pack-id {pack_id}"
        ),
        "mcp_tool": "check_diff_against_pack",
        "purpose": "verify changes stayed inside pack and impact scope",
        "gate_kind": "volatile",
        "required_params": ["pack_id"],
        "optional_params": ["paths"],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "tests": {
        "command_template": "<run impact-recommended tests>",
        "mcp_tool": "verify_run",
        "purpose": "persist test or verification evidence for the task",
        "gate_kind": "durable",
        "required_params": [],
        "optional_params": ["plan_id", "pack_id"],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "outcome": {
        "command_template": (
            'ctxlayer --repo . outcome --pack-id {pack_id} --result pass '
            '--summary "<what changed and why>"'
        ),
        "mcp_tool": "record_outcome",
        "purpose": "record durable pass/fail outcome and memory summary",
        "gate_kind": "durable",
        "required_params": ["pack_id"],
        "optional_params": [],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "continuation": {
        "command_template": 'ctxlayer --repo . memory recall --query "{task}"',
        "mcp_tool": "memory_recall",
        "purpose": "resume relevant prior task state or project memory",
        "gate_kind": "none",
        "required_params": ["task"],
        "optional_params": ["paths"],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "agent_route": {
        "command_template": 'ctxlayer --repo . agent route --task "{task}"',
        "mcp_tool": "agent_route",
        "purpose": "route high-risk or multi-agent work for review",
        "gate_kind": "none",
        "required_params": ["task"],
        "optional_params": ["capabilities"],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "decision": {
        "command_template": 'ctxlayer --repo . decision start --question "{task}"',
        "mcp_tool": "decision_start",
        "purpose": "capture trade-off decisions before architecture or policy changes",
        "gate_kind": "none",
        "required_params": ["task"],
        "optional_params": ["paths"],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "security_scan": {
        "command_template": "ctxlayer --repo . security scan",
        "mcp_tool": "security_scan",
        "purpose": "scan security-sensitive changes before outcome",
        "gate_kind": "durable",
        "required_params": [],
        "optional_params": [],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "release_validate": {
        "command_template": "ctxlayer --repo . release validate",
        "mcp_tool": "release_validate",
        "purpose": "validate release readiness and packaging expectations",
        "gate_kind": "durable",
        "required_params": [],
        "optional_params": [],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
    "workflow_next": {
        "command_template": (
            "ctxlayer --repo . workflow next --task-session-id {task_session_id}"
        ),
        "mcp_tool": "workflow_next",
        "purpose": "project the next CTX action from durable workflow evidence",
        "gate_kind": "none",
        "required_params": ["task_session_id"],
        "optional_params": [],
        "unresolved_param_behavior": UNRESOLVED_PARAM_BEHAVIOR,
    },
}


def template_params(template: str) -> set[str]:
    return {
        field_name
        for _, field_name, _, _ in Formatter().parse(template)
        if field_name
    }


def feature_ids() -> list[str]:
    return sorted(FEATURE_CATALOG)
