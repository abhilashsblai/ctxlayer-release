from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ctxlayer.config import Settings
from ctxlayer.governance.policy import CapabilityPolicy
from ctxlayer.store import SQLiteStore
from ctxlayer.utils import canonical_json, stable_id


class ConstitutionBuilder:
    def __init__(
        self,
        repo_root: Path,
        store: SQLiteStore,
        settings: Settings,
        *,
        workspace_id: str,
    ):
        self.repo_root = repo_root
        self.store = store
        self.settings = settings
        self.workspace_id = workspace_id

    def build(self, repo_id: str) -> dict[str, Any]:
        body = {
            "schema_version": "ctxlayer.constitution.v1",
            "workspace_id": self.workspace_id,
            "repo_id": repo_id,
            "capabilities": CapabilityPolicy(self.repo_root, self.settings).manifest,
            "critical_paths": sorted(self.settings.ci.critical_paths),
            "approved_memory": self._approved_memory(repo_id),
            "business_rules": self._business_rules(),
            "execution_states": [
                "INTAKE",
                "PACK",
                "PLAN",
                "EXECUTE",
                "PREFLIGHT",
                "OUTCOME",
            ],
        }
        constitution_hash = stable_id(canonical_json(body))
        manifest = {**body, "constitution_hash": constitution_hash}
        constitution_id = self.store.write_constitution(
            workspace_id=self.workspace_id,
            repo_id=repo_id,
            manifest=manifest,
        )
        return {"ok": True, "constitution_id": constitution_id, **manifest}

    def latest(self, repo_id: str) -> dict[str, Any]:
        row = self.store.latest_constitution(repo_id)
        if not row:
            return self.build(repo_id)
        manifest = json.loads(row["manifest_json"])
        return {"ok": True, "constitution_id": row["constitution_id"], **manifest}

    def _approved_memory(self, repo_id: str) -> list[dict[str, Any]]:
        rows = self.store.memory_records(
            workspace_id=self.workspace_id,
            repo_id=repo_id,
            status="active",
        )
        items = []
        for row in rows:
            if row["type"] == "outcome":
                continue
            items.append(
                {
                    "record_id": row["record_id"],
                    "type": row["type"],
                    "scope": row["scope"],
                    "subject_key": row["subject_key"],
                    "assertion": row["assertion"],
                    "confidence": row["confidence"],
                    "source_kind": row["source_kind"],
                }
            )
        return sorted(
            items,
            key=lambda item: (item["type"], item["subject_key"], item["record_id"]),
        )

    def _business_rules(self) -> list[dict[str, Any]]:
        rules = []
        for row in self.store.business_rules("active"):
            rules.append(
                {
                    "rule_id": row["rule_id"],
                    "scope_glob": row["scope_glob"],
                    "rule_text": row["rule_text"],
                    "confidence": row["confidence"],
                    "source_type": row["source_type"],
                    "source_ref": row["source_ref"],
                }
            )
        return sorted(
            rules, key=lambda item: (item["scope_glob"] or "", item["rule_id"])
        )
