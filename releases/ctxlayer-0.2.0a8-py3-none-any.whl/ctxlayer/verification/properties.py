from __future__ import annotations

from typing import Any, Callable, Iterable

# Property-based / invariant checks counter the "cycle of self-deception" where generated
# tests share the code's flaws (Property-Generated Solver, arXiv:2506.18315). Invariants are
# generator-proposed and therefore enter as UNTRUSTED candidates; they only become usable
# oracle once validated against real inputs (generator != validator).

PropertyFn = Callable[..., bool]


def validate_invariants(
    invariants: dict[str, PropertyFn],
    *,
    sample_args: Iterable[tuple],
) -> dict[str, Any]:
    """Check each named invariant against sampled inputs.

    Returns per-invariant results plus the subset that held on every sample (promotable to
    oracle use). An invariant that raises on any input is treated as not holding.
    """
    samples = list(sample_args)
    results: dict[str, Any] = {}
    holding: list[str] = []
    for name, fn in invariants.items():
        violations: list[str] = []
        for args in samples:
            try:
                ok = bool(fn(*args))
            except Exception as exc:  # noqa: BLE001
                ok = False
                violations.append(f"{args!r} -> raised {type(exc).__name__}")
                continue
            if not ok:
                violations.append(f"{args!r} -> False")
        held = not violations
        results[name] = {
            "held": held,
            "samples": len(samples),
            "violations": violations[:10],
            "trust": "candidate",  # generator-proposed; never authoritative until validated
        }
        if held and samples:
            holding.append(name)
    return {
        "ok": True,
        "schema_version": "ctxlayer.invariants.v1",
        "results": results,
        "holding": sorted(holding),
    }
