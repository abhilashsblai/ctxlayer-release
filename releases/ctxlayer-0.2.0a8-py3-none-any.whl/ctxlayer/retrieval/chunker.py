from __future__ import annotations

from dataclasses import dataclass

from ctxlayer.parsing.extractors import ExtractedFile
from ctxlayer.utils import estimate_tokens, split_identifier_text, stable_id


@dataclass(frozen=True)
class Chunk:
    chunk_id: str
    path: str
    symbol_identity_id: str | None
    category: str
    start_line: int | None
    end_line: int | None
    text: str
    text_normalized: str
    token_count: int


def chunk_file(
    *,
    snapshot_id: str,
    repo_id: str,
    path: str,
    text: str,
    extracted: ExtractedFile,
    symbol_ids: dict[str, str],
) -> list[Chunk]:
    chunks: list[Chunk] = []
    lines = text.splitlines()
    for symbol in extracted.symbols:
        body = "\n".join(lines[max(symbol.start_line - 1, 0) : symbol.end_line])
        if not body.strip():
            body = symbol.signature
        symbol_id = symbol_ids.get(symbol.qualname)
        category = "test" if symbol.is_test else "implementation"
        chunks.append(
            _chunk(
                snapshot_id,
                repo_id,
                path,
                symbol_id,
                category,
                symbol.start_line,
                symbol.end_line,
                body,
            )
        )
    if not chunks:
        chunks.append(
            _chunk(
                snapshot_id, repo_id, path, None, "file", 1, len(lines), text[:12_000]
            )
        )
    return chunks


def _chunk(
    snapshot_id: str,
    repo_id: str,
    path: str,
    symbol_identity_id: str | None,
    category: str,
    start_line: int | None,
    end_line: int | None,
    text: str,
) -> Chunk:
    normalized = split_identifier_text(f"{path}\n{text}")
    chunk_id = stable_id(
        snapshot_id, repo_id, path, symbol_identity_id or "", start_line, end_line, text
    )
    return Chunk(
        chunk_id=chunk_id,
        path=path,
        symbol_identity_id=symbol_identity_id,
        category=category,
        start_line=start_line,
        end_line=end_line,
        text=text,
        text_normalized=normalized,
        token_count=estimate_tokens(text),
    )
