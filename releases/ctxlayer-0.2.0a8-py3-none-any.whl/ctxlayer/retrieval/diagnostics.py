from __future__ import annotations

from typing import Any


def diagnose(report: dict[str, Any]) -> dict[str, Any]:
    missed = report.get("missed_files", [])
    categories = {
        "missed_by_entity_mining": [],
        "missed_by_graph": [],
        "missed_by_vector": [],
        "missed_by_lexical": [],
        "missed_due_to_budget": [],
        "missed_due_to_test_linkage": [],
        "missed_cross_repo": [],
        "missed_generated_code_filter": [],
    }
    for path in missed:
        if "generated" in path:
            categories["missed_generated_code_filter"].append(path)
        elif "../" in path or path.count("/") > 4:
            categories["missed_cross_repo"].append(path)
        elif path.startswith("tests/") or "/test" in path:
            categories["missed_due_to_test_linkage"].append(path)
        else:
            categories["missed_by_graph"].append(path)
    return {"ok": True, "categories": categories}
