from __future__ import annotations

from typing import Any

CALIBRATION_VERSION = "h2.v1"

CONFIDENCE_TABLE: dict[str, float] = {
    "directory": 0.72,
    "api_contract": 0.86,
    "openapi_contract": 0.92,
    "python_route_decorator": 0.91,
    "node_route_registration": 0.88,
    "source_route_literal": 0.64,
    "api_consumer": 0.78,
    "frontend_call": 0.74,
    "db_migration": 0.9,
    "model_class": 0.88,
    "feature_flag_reference": 0.82,
    "config_reference": 0.76,
    "react_component": 0.66,
    "queue_task": 0.72,
    "documentation_heading": 0.7,
    "test_name": 0.7,
    "owns_boundary": 0.78,
    "consumes": 0.8,
    "unknown": 0.45,
}


def confidence_tier(confidence: float | None) -> str:
    value = float(confidence or 0.0)
    if value >= 0.8:
        return "high"
    if value >= 0.5:
        return "medium"
    return "low"


def calibrate(inference_method: str | None, evidence_count: int = 1) -> float:
    method = inference_method or "unknown"
    base = CONFIDENCE_TABLE.get(method, CONFIDENCE_TABLE["unknown"])
    boost = min(max(evidence_count - 1, 0), 4) * 0.03
    return round(min(0.99, base + boost), 6)


def provenance(
    inference_method: str | None,
    *,
    evidence_count: int = 1,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    data: dict[str, Any] = {
        "inference_method": inference_method or "unknown",
        "calibration_version": CALIBRATION_VERSION,
        "evidence_count": int(max(evidence_count, 0)),
    }
    if extra:
        data.update(extra)
    return data


def with_provenance(
    metadata: dict[str, Any] | None,
    inference_method: str | None,
    *,
    evidence_count: int = 1,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    clone = dict(metadata or {})
    clone["provenance"] = provenance(
        inference_method,
        evidence_count=evidence_count,
        extra=extra,
    )
    return clone
