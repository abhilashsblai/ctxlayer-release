from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ctxlayer.semantic.confidence import confidence_tier

BUSINESS_NODE_TYPES: frozenset[str] = frozenset(
    {
        "customer",
        "contract",
        "revenue",
        "sla",
        "product",
        "market",
        "risk",
        "compliance_obligation",
        "objective",
    }
)

BUSINESS_EDGE_KINDS: frozenset[str] = frozenset(
    {"serves", "used_by", "carries", "governed_by", "realizes", "exposes"}
)

TECHNICAL_BUSINESS_SOURCE_TYPES: frozenset[str] = frozenset(
    {
        "repository",
        "service",
        "api",
        "api_endpoint",
        "api_contract",
        "data_entity",
        "feature_flag",
        "config_key",
        "component",
        "route",
        "schema",
        "table",
        "service_boundary",
        "workflow",
        "workflow_step",
        "domain_concept",
    }
)

BUSINESS_EDGE_TRIPLES: frozenset[tuple[str, str, str]] = frozenset(
    {
        ("*", "serves", "product"),
        ("product", "used_by", "customer"),
        ("customer", "carries", "revenue"),
        ("customer", "carries", "sla"),
        ("contract", "carries", "revenue"),
        ("contract", "carries", "sla"),
        ("product", "realizes", "objective"),
        ("*", "governed_by", "compliance_obligation"),
        ("*", "exposes", "risk"),
    }
)

BUSINESS_METADATA_SCHEMAS: dict[str, frozenset[str]] = {
    "customer": frozenset({"tier", "region", "account_id"}),
    "contract": frozenset({"contract_id", "term_end", "value_band"}),
    "revenue": frozenset({"period", "amount_band", "currency"}),
    "sla": frozenset({"target", "window", "penalty_band"}),
    "product": frozenset({"product_key", "owner_team"}),
    "market": frozenset({"segment", "geo"}),
    "risk": frozenset({"category", "severity", "likelihood"}),
    "compliance_obligation": frozenset({"framework", "control_id", "jurisdiction"}),
    "objective": frozenset({"okr_key", "horizon"}),
}

TRUST_ORDER: dict[str, int] = {"low": 0, "medium": 1, "high": 2, "source": 3}


def is_business_node_type(node_type: str | None) -> bool:
    return str(node_type or "") in BUSINESS_NODE_TYPES


def min_trust(*tiers: str | None) -> str:
    values = [str(tier) for tier in tiers if tier]
    if not values:
        return "high"
    return min(values, key=lambda item: TRUST_ORDER.get(item, -1))


def valid_business_edge(src_type: str, kind: str, dst_type: str) -> bool:
    if kind not in BUSINESS_EDGE_KINDS:
        return False
    if (src_type, kind, dst_type) in BUSINESS_EDGE_TRIPLES:
        return True
    if ("*", kind, dst_type) in BUSINESS_EDGE_TRIPLES:
        return src_type in TECHNICAL_BUSINESS_SOURCE_TYPES
    return False


@dataclass(frozen=True)
class SemanticEvidence:
    evidence_id: str
    repo_id: str
    path: str
    evidence_kind: str
    evidence_hash: str
    node_id: str | None = None
    edge_id: str | None = None
    symbol_identity_id: str | None = None
    line_start: int | None = None
    line_end: int | None = None

    def as_row(self) -> dict[str, Any]:
        return {
            "evidence_id": self.evidence_id,
            "node_id": self.node_id,
            "edge_id": self.edge_id,
            "repo_id": self.repo_id,
            "path": self.path,
            "symbol_identity_id": self.symbol_identity_id,
            "line_start": self.line_start,
            "line_end": self.line_end,
            "evidence_kind": self.evidence_kind,
            "evidence_hash": self.evidence_hash,
        }


@dataclass
class SemanticNode:
    node_id: str
    repo_id: str
    node_type: str
    name: str
    stable_key: str
    confidence: float
    source: str
    metadata: dict[str, Any] = field(default_factory=dict)
    evidence: list[SemanticEvidence] = field(default_factory=list)
    trust_tier: str | None = None
    status: str | None = None
    provenance_json: dict[str, Any] = field(default_factory=dict)

    @property
    def provenance(self) -> dict[str, Any]:
        value = self.metadata.get("provenance")
        return value if isinstance(value, dict) else {}

    @property
    def inference_method(self) -> str | None:
        value = self.provenance.get("inference_method")
        return str(value) if value else None

    @property
    def calibration_version(self) -> str | None:
        value = self.provenance.get("calibration_version")
        return str(value) if value else None

    @property
    def confidence_tier(self) -> str:
        return confidence_tier(self.confidence)

    def as_row(self) -> dict[str, Any]:
        return {
            "node_id": self.node_id,
            "repo_id": self.repo_id,
            "node_type": self.node_type,
            "name": self.name,
            "stable_key": self.stable_key,
            "confidence": self.confidence,
            "source": self.source,
            "metadata": self.metadata,
            "trust_tier": self.trust_tier,
            "status": self.status,
            "provenance": self.provenance_json,
        }


@dataclass
class SemanticEdge:
    edge_id: str
    src_node_id: str
    dst_node_id: str
    kind: str
    confidence: float
    evidence: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def provenance(self) -> dict[str, Any]:
        value = self.metadata.get("provenance")
        return value if isinstance(value, dict) else {}

    @property
    def inference_method(self) -> str | None:
        value = self.provenance.get("inference_method")
        return str(value) if value else None

    @property
    def calibration_version(self) -> str | None:
        value = self.provenance.get("calibration_version")
        return str(value) if value else None

    @property
    def confidence_tier(self) -> str:
        return confidence_tier(self.confidence)

    def as_row(self) -> dict[str, Any]:
        return {
            "edge_id": self.edge_id,
            "src_node_id": self.src_node_id,
            "dst_node_id": self.dst_node_id,
            "kind": self.kind,
            "confidence": self.confidence,
            "evidence": self.evidence,
            "metadata": self.metadata,
        }
