from __future__ import annotations

import json
import re
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from ctxlayer.semantic.confidence import calibrate, with_provenance
from ctxlayer.semantic.schema import SemanticEdge, SemanticEvidence, SemanticNode
from ctxlayer.utils import canonical_json, sha256_text, stable_id


ROUTE_RE = re.compile(r"['\"](/(?:api/)?[A-Za-z0-9_./{}:-]+)['\"]")
HTTP_DECORATOR_RE = re.compile(
    r"@(?:app|router|blueprint)\.(get|post|put|patch|delete|route)\(\s*['\"]([^'\"]+)['\"]",
    re.I,
)
NODE_ROUTE_RE = re.compile(
    r"\b(?:app|router)\.(get|post|put|patch|delete|all)\(\s*['\"]([^'\"]+)['\"]",
    re.I,
)
FETCH_RE = re.compile(
    r"\b(?:fetch|axios\.(?:get|post|put|patch|delete))\(\s*['\"]([^'\"]+)['\"]"
)
REACT_COMPONENT_RE = re.compile(r"\b(?:function|const)\s+([A-Z][A-Za-z0-9_]*)\b")
PY_MODEL_RE = re.compile(
    r"^class\s+([A-Z][A-Za-z0-9_]*)\((?:[^)]*(?:BaseModel|dataclass|Model|DeclarativeBase)[^)]*)\):",
    re.MULTILINE,
)
SQLALCHEMY_TABLE_RE = re.compile(r"__tablename__\s*=\s*['\"]([A-Za-z_][\w]*)['\"]")
CELERY_TASK_RE = re.compile(r"@(?:app|celery|shared_task)\.task|@shared_task")
YAML_ROUTE_RE = re.compile(r"^\s{0,6}(/[^:\s]+):", re.MULTILINE)
TABLE_RE = re.compile(
    r"\b(?:CREATE|ALTER)\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([A-Za-z_][\w.]*)",
    re.I,
)
FLAG_RE = re.compile(
    r"(?:feature[_-]?flag|flag|is_enabled|variation|toggle)\s*[\[(]\s*['\"]([A-Za-z_][\w.-]+)['\"]",
    re.I,
)
ENV_RE = re.compile(
    r"\b(?:os\.environ(?:\.get)?|getenv|process\.env)\s*[\[(]\s*['\"]([A-Z][A-Z0-9_]+)['\"]"
)
CONFIG_KEY_RE = re.compile(r"^\s*([A-Za-z_][\w.-]{2,})\s*[:=]", re.MULTILINE)
HEADING_RE = re.compile(r"^\s{0,3}#{1,4}\s+(.+?)\s*$", re.MULTILINE)
TEST_NAME_RE = re.compile(r"\bdef\s+test_([A-Za-z0-9_]+)\s*\(")


class SemanticGraphBuilder:
    def __init__(self, repo_root: Path, repo_id: str):
        self.repo_root = repo_root
        self.repo_id = repo_id
        self.nodes: dict[str, SemanticNode] = {}
        self.edges: dict[str, SemanticEdge] = {}
        self.evidence: dict[str, SemanticEvidence] = {}

    def scan_files(
        self, paths: Iterable[str]
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
        for rel in sorted(paths):
            path = self.repo_root / rel
            if not path.exists() or not path.is_file():
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
            self._extract_service_boundary(rel)
            self._extract_api_contracts(rel, text)
            self._extract_frontend_consumers(rel, text)
            self._extract_data_entities(rel, text)
            self._extract_feature_flags(rel, text)
            self._extract_config_keys(rel, text)
            self._extract_components_and_tasks(rel, text)
            self._extract_domain_concepts(rel, text)
        self._link_boundaries_to_nodes()
        self._link_consumers_to_contracts()
        return (
            [
                node.as_row()
                for node in sorted(self.nodes.values(), key=lambda item: item.node_id)
            ],
            [
                edge.as_row()
                for edge in sorted(self.edges.values(), key=lambda item: item.edge_id)
            ],
            [
                item.as_row()
                for item in sorted(
                    self.evidence.values(), key=lambda item: item.evidence_id
                )
            ],
        )

    def _extract_service_boundary(self, rel: str) -> None:
        parts = rel.split("/")
        if len(parts) < 2:
            return
        if parts[0] in {".ctxlayer", "tests", "docs", "Plans", "__pycache__"}:
            return
        code_exts = {
            ".py",
            ".js",
            ".jsx",
            ".ts",
            ".tsx",
            ".go",
            ".java",
            ".php",
            ".rb",
            ".rs",
        }
        if Path(rel).suffix.lower() not in code_exts:
            return
        name = parts[0]
        self._node(
            "service_boundary",
            name,
            "directory",
            rel,
            1,
            confidence=0.65,
            metadata={"directory": name},
        )

    def _extract_api_contracts(self, rel: str, text: str) -> None:
        path = Path(rel)
        routes: dict[str, dict[str, Any]] = {}
        is_openapi = any(token in path.name.lower() for token in ["openapi", "swagger"])
        if path.suffix.lower() == ".json" and is_openapi:
            try:
                data = json.loads(text)
            except json.JSONDecodeError:
                data = {}
            for route, spec in sorted((data.get("paths") or {}).items()):
                methods = sorted((spec or {}).keys()) if isinstance(spec, dict) else []
                routes[route] = {"format": "openapi", "methods": methods}
        elif path.suffix.lower() in {".yaml", ".yml"} and is_openapi:
            for route in sorted(set(YAML_ROUTE_RE.findall(text))):
                routes[route] = {"format": "openapi"}
        else:
            for route in sorted(set(ROUTE_RE.findall(text))):
                if "/" in route.strip("/"):
                    routes[route] = {"format": "source_route"}
            for _method, route in HTTP_DECORATOR_RE.findall(text):
                routes[route] = {"format": "python_route", "method": _method.upper()}
            for _method, route in NODE_ROUTE_RE.findall(text):
                routes[route] = {"format": "node_route", "method": _method.upper()}
        for route, metadata in routes.items():
            line = _line_for(text, route)
            self._node(
                "api_contract",
                route,
                "api_contract",
                rel,
                line,
                confidence=0.9,
                metadata=metadata,
                inference_method=_route_inference_method(metadata),
            )

    def _extract_frontend_consumers(self, rel: str, text: str) -> None:
        for route in sorted(set(FETCH_RE.findall(text))):
            if not route.startswith("/"):
                continue
            self._node(
                "api_contract",
                route,
                "api_consumer",
                rel,
                _line_for(text, route),
                confidence=0.76,
                metadata={"format": "frontend_call", "consumer": rel},
            )
            self._node(
                "workflow_step",
                f"consume {route}",
                "frontend_call",
                rel,
                _line_for(text, route),
                confidence=0.68,
                metadata={"route": route},
            )

    def _extract_data_entities(self, rel: str, text: str) -> None:
        tables = set(TABLE_RE.findall(text)) | set(SQLALCHEMY_TABLE_RE.findall(text))
        for model in PY_MODEL_RE.findall(text):
            tables.add(model)
        if (
            not tables
            and "migration" not in rel.lower()
            and Path(rel).suffix.lower() not in {".sql"}
        ):
            return
        for table in sorted(tables):
            self._node(
                "data_entity",
                table.strip('"`[]'),
                "db_migration",
                rel,
                _line_for(text, table),
                confidence=0.9,
                metadata={"source": "migration"},
            )

    def _extract_feature_flags(self, rel: str, text: str) -> None:
        for flag in sorted(set(FLAG_RE.findall(text))):
            self._node(
                "feature_flag",
                flag,
                "feature_flag_reference",
                rel,
                _line_for(text, flag),
                confidence=0.82,
                metadata={"reference": flag},
            )

    def _extract_config_keys(self, rel: str, text: str) -> None:
        keys = set(ENV_RE.findall(text))
        if Path(rel).suffix.lower() in {".toml", ".yaml", ".yml", ".env"}:
            keys.update(CONFIG_KEY_RE.findall(text))
        for key in sorted(keys):
            if key.lower() in {"version", "name", "description"}:
                continue
            self._node(
                "config_key",
                key,
                "config_reference",
                rel,
                _line_for(text, key),
                confidence=0.75,
                metadata={"key": key},
            )

    def _extract_components_and_tasks(self, rel: str, text: str) -> None:
        if Path(rel).suffix.lower() in {".jsx", ".tsx", ".js", ".ts"}:
            for component in sorted(set(REACT_COMPONENT_RE.findall(text))):
                if component in {"React", "Promise"}:
                    continue
                self._node(
                    "workflow_step",
                    component,
                    "react_component",
                    rel,
                    _line_for(text, component),
                    confidence=0.64,
                    metadata={"component": component},
                )
        if CELERY_TASK_RE.search(text):
            task_name = Path(rel).stem.replace("_", " ")
            self._node(
                "workflow",
                f"{task_name} task",
                "queue_task",
                rel,
                _line_for(text, "task"),
                confidence=0.72,
                metadata={"queue": "celery"},
            )

    def _extract_domain_concepts(self, rel: str, text: str) -> None:
        path = Path(rel)
        if path.suffix.lower() == ".md":
            for heading in HEADING_RE.findall(text):
                concept = _normalize_concept(heading)
                if concept:
                    self._node(
                        "domain_concept",
                        concept,
                        "documentation_heading",
                        rel,
                        _line_for(text, heading),
                        confidence=0.78,
                        metadata={"heading": heading.strip()},
                    )
        if path.name.startswith("test_") or "/tests/" in f"/{rel}":
            for name in TEST_NAME_RE.findall(text):
                concept = _normalize_concept(name.replace("_", " "))
                if concept:
                    self._node(
                        "workflow",
                        concept,
                        "test_name",
                        rel,
                        _line_for(text, f"test_{name}"),
                        confidence=0.7,
                        metadata={"test": f"test_{name}"},
                    )

    def _link_boundaries_to_nodes(self) -> None:
        boundaries = [
            node for node in self.nodes.values() if node.node_type == "service_boundary"
        ]
        for node in list(self.nodes.values()):
            if node.node_type == "service_boundary":
                continue
            evidence_paths = [ev.path for ev in node.evidence]
            for boundary in boundaries:
                if any(path.startswith(f"{boundary.name}/") for path in evidence_paths):
                    self._edge(
                        boundary,
                        node,
                        "owns_boundary",
                        evidence_ids=[ev.evidence_id for ev in node.evidence],
                        metadata={"boundary": boundary.name},
                        inference_method="owns_boundary",
                    )

    def _link_consumers_to_contracts(self) -> None:
        contracts = [
            node for node in self.nodes.values() if node.node_type == "api_contract"
        ]
        by_name = {node.name: node for node in contracts}
        for consumer in list(self.nodes.values()):
            if consumer.node_type != "workflow_step":
                continue
            route = consumer.metadata.get("route")
            if not route:
                continue
            contract = by_name.get(str(route))
            if contract is None:
                continue
            self._edge(
                consumer,
                contract,
                "consumes",
                evidence_ids=[ev.evidence_id for ev in consumer.evidence],
                metadata={"route": route, "category": "frontend_consumer"},
                inference_method="consumes",
            )

    def _node(
        self,
        node_type: str,
        name: str,
        evidence_kind: str,
        path: str,
        line: int | None,
        *,
        confidence: float,
        metadata: dict[str, Any] | None = None,
        inference_method: str | None = None,
    ) -> SemanticNode:
        method = inference_method or evidence_kind
        calibrated = calibrate(method, 1)
        stable_key = f"{self.repo_id}:{node_type}:{name.lower()}"
        node_id = stable_id(stable_key)
        node = self.nodes.get(node_id)
        if not node:
            node = SemanticNode(
                node_id=node_id,
                repo_id=self.repo_id,
                node_type=node_type,
                name=name,
                stable_key=stable_key,
                confidence=calibrated,
                source=evidence_kind,
                metadata=with_provenance(metadata, method, evidence_count=1),
            )
            self.nodes[node_id] = node
        else:
            node.metadata = {**node.metadata, **(metadata or {})}
        evidence = self._evidence(node_id, None, path, line, evidence_kind, name)
        if all(
            existing.evidence_id != evidence.evidence_id for existing in node.evidence
        ):
            node.evidence.append(evidence)
        provenance = dict(node.metadata.get("provenance") or {})
        method = str(provenance.get("inference_method") or method)
        node.confidence = max(node.confidence, calibrate(method, len(node.evidence)))
        node.metadata["provenance"] = {
            **provenance,
            "inference_method": method,
            "calibration_version": provenance.get("calibration_version") or "h2.v1",
            "evidence_count": len(node.evidence),
        }
        return node

    def _edge(
        self,
        src: SemanticNode,
        dst: SemanticNode,
        kind: str,
        *,
        confidence: float | None = None,
        evidence_ids: list[str],
        metadata: dict[str, Any] | None = None,
        inference_method: str | None = None,
    ) -> SemanticEdge:
        method = inference_method or kind
        calibrated = calibrate(method, max(1, len(evidence_ids)))
        if confidence is not None:
            calibrated = max(calibrated, min(0.99, float(confidence)))
        edge_id = stable_id(src.node_id, dst.node_id, kind)
        edge = self.edges.get(edge_id)
        if not edge:
            edge = SemanticEdge(
                edge_id=edge_id,
                src_node_id=src.node_id,
                dst_node_id=dst.node_id,
                kind=kind,
                confidence=calibrated,
                evidence=sorted(set(evidence_ids)),
                metadata=with_provenance(
                    metadata,
                    method,
                    evidence_count=max(1, len(set(evidence_ids))),
                ),
            )
            self.edges[edge_id] = edge
        else:
            edge.evidence = sorted(set(edge.evidence) | set(evidence_ids))
            edge.metadata = {**edge.metadata, **(metadata or {})}
            edge.confidence = max(
                edge.confidence, calibrate(method, len(edge.evidence))
            )
            edge.metadata["provenance"] = {
                **(edge.metadata.get("provenance") or {}),
                "inference_method": method,
                "calibration_version": "h2.v1",
                "evidence_count": len(edge.evidence),
            }
        for evidence_id in evidence_ids:
            item = self.evidence.get(evidence_id)
            if item:
                linked = SemanticEvidence(
                    evidence_id=stable_id(edge_id, evidence_id),
                    repo_id=item.repo_id,
                    path=item.path,
                    evidence_kind=f"edge:{kind}",
                    evidence_hash=sha256_text(
                        canonical_json({"edge": edge_id, "evidence": evidence_id})
                    ),
                    edge_id=edge_id,
                    line_start=item.line_start,
                    line_end=item.line_end,
                )
                self.evidence[linked.evidence_id] = linked
        return edge

    def _evidence(
        self,
        node_id: str | None,
        edge_id: str | None,
        path: str,
        line: int | None,
        evidence_kind: str,
        value: str,
    ) -> SemanticEvidence:
        evidence_hash = sha256_text(f"{path}:{line or 0}:{evidence_kind}:{value}")
        evidence_id = stable_id(node_id or "", edge_id or "", evidence_hash)
        item = SemanticEvidence(
            evidence_id=evidence_id,
            node_id=node_id,
            edge_id=edge_id,
            repo_id=self.repo_id,
            path=path,
            line_start=line,
            line_end=line,
            evidence_kind=evidence_kind,
            evidence_hash=evidence_hash,
        )
        self.evidence[evidence_id] = item
        return item


def _line_for(text: str, needle: str) -> int | None:
    idx = text.find(needle)
    if idx < 0:
        return None
    return text[:idx].count("\n") + 1


def _normalize_concept(text: str) -> str | None:
    words = [word.lower() for word in re.findall(r"[A-Za-z][A-Za-z0-9]{2,}", text)]
    stop = {"the", "and", "for", "with", "from", "this", "that", "test", "should"}
    kept = [word for word in words if word not in stop]
    if len(kept) < 2:
        return None
    return " ".join(kept[:6])


def _route_inference_method(metadata: dict[str, Any]) -> str:
    format_name = str(metadata.get("format") or "")
    if format_name == "openapi":
        return "openapi_contract"
    if format_name == "python_route":
        return "python_route_decorator"
    if format_name == "node_route":
        return "node_route_registration"
    return "source_route_literal"
