from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TreeSitterStatus:
    available: bool
    languages: list[str]
    error: str | None = None


def status() -> TreeSitterStatus:
    try:
        import tree_sitter  # noqa: F401
    except Exception as exc:  # noqa: BLE001
        return TreeSitterStatus(False, [], str(exc))
    languages: list[str] = []
    # Detect every grammar we can use for CST-precise extraction. Languages whose grammar is
    # not installed fall back to the regex extractor in extractors.py, so detection is additive
    # and never required. Install ctxlayer[full] to enable the polyglot CST path.
    for module_name, lang in [
        ("tree_sitter_python", "python"),
        ("tree_sitter_javascript", "javascript"),
        ("tree_sitter_typescript", "typescript"),
        ("tree_sitter_go", "go"),
        ("tree_sitter_java", "java"),
        ("tree_sitter_php", "php"),
        ("tree_sitter_ruby", "ruby"),
        ("tree_sitter_rust", "rust"),
    ]:
        try:
            __import__(module_name)
        except Exception:
            continue
        languages.append(lang)
    return TreeSitterStatus(bool(languages), languages, None)


def require_available() -> None:
    current = status()
    if not current.available:
        raise RuntimeError(
            "tree-sitter language packages are not installed; install ctxlayer[full] "
            "or set parser_backend='stdlib'"
        )
