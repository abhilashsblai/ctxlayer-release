from .candidates import _opposes

__all__ = ["_opposes"]
