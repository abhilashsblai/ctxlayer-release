from __future__ import annotations

from pathlib import Path

from ctxlayer.memory.evidence import RuleCandidate
from ctxlayer.memory.source_scanners.common import scan_rule_text


def scan(root: Path) -> list[RuleCandidate]:
    candidates: list[RuleCandidate] = []
    for folder in [root / "prs", root / ".ctxlayer" / "prs"]:
        if not folder.exists():
            continue
        for path in folder.rglob("*.md"):
            candidates.extend(scan_rule_text(path, root, "pr", 0.58))
    return candidates
