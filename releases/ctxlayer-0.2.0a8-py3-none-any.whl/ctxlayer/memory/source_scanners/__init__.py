from .constants import scan as scan_constants
from .docs import scan as scan_docs
from .incidents import scan as scan_incidents
from .prs import scan as scan_prs
from .routes import scan as scan_routes
from .tests import scan as scan_tests
from .validations import scan as scan_validations

SCANNERS = {
    "tests": scan_tests,
    "validations": scan_validations,
    "constants": scan_constants,
    "routes": scan_routes,
    "docs": scan_docs,
    "prs": scan_prs,
    "incidents": scan_incidents,
}

__all__ = [
    "SCANNERS",
    "scan_constants",
    "scan_docs",
    "scan_incidents",
    "scan_prs",
    "scan_routes",
    "scan_tests",
    "scan_validations",
]
