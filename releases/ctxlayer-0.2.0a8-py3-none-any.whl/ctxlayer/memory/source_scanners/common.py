from __future__ import annotations

import re
from pathlib import Path

from ctxlayer.memory.evidence import RuleCandidate, RuleEvidence

RULE_RE = re.compile(
    r"(?i)\b(?:must|must not|required|require|requires|never|always|do not|cannot|should not|may not)\b[^.\n]{8,180}"
)


def scan_rule_text(
    path: Path, root: Path, source_type: str, confidence: float
) -> list[RuleCandidate]:
    text = path.read_text(encoding="utf-8", errors="replace")
    rel = path.relative_to(root).as_posix()
    candidates: list[RuleCandidate] = []
    for match in RULE_RE.finditer(text):
        rule_text = " ".join(match.group(0).strip().split())
        line = text[: match.start()].count("\n") + 1
        candidates.append(
            RuleCandidate(
                text=rule_text,
                source_type=source_type,
                confidence=confidence,
                evidence=[
                    RuleEvidence(
                        path=rel,
                        evidence_kind=f"{source_type}_statement",
                        text=rule_text,
                        line_start=line,
                        line_end=line,
                    )
                ],
            )
        )
    return candidates
