from __future__ import annotations

import json
from typing import Any

from ctxlayer.store import SQLiteStore
from ctxlayer.utils import sha256_text, stable_id


class AgentSessionMemory:
    def __init__(self, store: SQLiteStore, workspace_id: str, repo_id: str | None):
        self.store = store
        self.workspace_id = workspace_id
        self.repo_id = repo_id

    def start(
        self,
        *,
        task: str,
        agent_name: str = "codex",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        session_id = self.session_id_for_task(task, agent_name=agent_name)
        self.store.start_agent_session(
            session_id=session_id,
            workspace_id=self.workspace_id,
            repo_id=self.repo_id,
            task_text_hash=sha256_text(task),
            agent_name=agent_name,
            metadata=metadata,
        )
        self.event(
            session_id=session_id,
            event_type="task",
            payload={"task_hash": sha256_text(task)},
        )
        return {"ok": True, "session_id": session_id, "status": "active"}

    def ensure(
        self,
        *,
        task: str,
        agent_name: str = "codex",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        session_id = self.session_id_for_task(task, agent_name=agent_name)
        existed = self.store.agent_session(session_id) is not None
        self.store.start_agent_session(
            session_id=session_id,
            workspace_id=self.workspace_id,
            repo_id=self.repo_id,
            task_text_hash=sha256_text(task),
            agent_name=agent_name,
            metadata=metadata,
        )
        if not existed:
            self.event(
                session_id=session_id,
                event_type="task",
                payload={"task_hash": sha256_text(task)},
            )
        return {
            "ok": True,
            "session_id": session_id,
            "status": "active",
            "created": not existed,
        }

    def session_id_for_task(self, task: str, *, agent_name: str = "codex") -> str:
        return stable_id(
            self.workspace_id, self.repo_id or "", sha256_text(task), agent_name
        )

    def event(
        self, *, session_id: str, event_type: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        event_id = self.store.append_agent_session_event(
            session_id=session_id,
            event_type=event_type,
            payload=payload,
        )
        if event_type in {
            "file_read",
            "file_edited",
            "test_run",
            "task_session",
            "task_transition",
            "pack_served",
            "plan_created",
            "plan_amended",
            "plan_checkpoint",
            "verification",
            "outcome",
            "workflow_recommendation_snapshot",
        }:
            ref = _artifact_ref(event_type, payload)
            if ref:
                self.store.put_agent_session_artifact(
                    session_id=session_id,
                    artifact_type=event_type,
                    ref=ref,
                    content_hash=payload.get("content_hash"),
                    metadata=payload,
                )
        return {"ok": True, "event_id": event_id}

    def finish(
        self,
        *,
        session_id: str,
        result: str,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        self.store.finish_agent_session(
            session_id=session_id,
            status=result,
            metadata=metadata,
        )
        self.event(
            session_id=session_id,
            event_type="finish",
            payload={"result": result, **(metadata or {})},
        )
        return {"ok": True, "session_id": session_id, "status": result}

    def acquire_lease(
        self,
        *,
        session_id: str,
        agent_name: str = "codex",
        bound_snapshot_id: str | None = None,
        ttl_seconds: int = 3600,
    ) -> dict[str, Any]:
        return self.store.acquire_session_lease(
            session_id=session_id,
            workspace_id=self.workspace_id,
            repo_id=self.repo_id,
            agent_name=agent_name,
            bound_snapshot_id=bound_snapshot_id,
            ttl_seconds=ttl_seconds,
        )

    def declare_impact(self, *, session_id: str, paths: list[str]) -> dict[str, Any]:
        return self.store.declare_session_impact(session_id=session_id, paths=paths)

    def conflicts(self, *, status: str | None = "open") -> list[dict[str, Any]]:
        return [
            dict(row)
            for row in self.store.session_conflicts(
                workspace_id=self.workspace_id,
                repo_id=self.repo_id,
                status=status,
            )
        ]

    def explain(self, session_id: str) -> dict[str, Any]:
        row = self.store.agent_session(session_id)
        if not row:
            return {"ok": False, "error": "session not found", "session_id": session_id}
        events = [dict(item) for item in self.store.agent_session_events(session_id)]
        artifacts = [
            dict(item) for item in self.store.agent_session_artifacts(session_id)
        ]
        return {
            "ok": True,
            "session": dict(row),
            "metadata": _json(row["metadata_json"]),
            "events": [_decode_event(event) for event in events],
            "artifacts": [_decode_artifact(artifact) for artifact in artifacts],
        }

    def recent(self, limit: int = 20) -> list[dict[str, Any]]:
        return [
            dict(row)
            for row in self.store.agent_sessions(
                workspace_id=self.workspace_id,
                repo_id=self.repo_id,
                limit=limit,
            )
        ]


def _artifact_ref(event_type: str, payload: dict[str, Any]) -> str | None:
    if event_type in {"file_read", "file_edited"}:
        return payload.get("path")
    if event_type == "test_run":
        return payload.get("command")
    if event_type in {"task_session", "task_transition"}:
        return payload.get("task_session_id")
    if event_type == "pack_served":
        return payload.get("pack_id")
    if event_type in {"plan_created", "plan_amended", "plan_checkpoint"}:
        return payload.get("checkpoint_id") or payload.get("plan_id")
    if event_type == "verification":
        return payload.get("verification_id") or payload.get("pack_id")
    if event_type == "outcome":
        return payload.get("outcome_id") or payload.get("pack_id")
    if event_type == "workflow_recommendation_snapshot":
        return payload.get("task_session_id")
    return None


def _json(value: str) -> dict[str, Any]:
    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _decode_event(event: dict[str, Any]) -> dict[str, Any]:
    return {
        **event,
        "payload": _json(event["payload_json"]),
    }


def _decode_artifact(artifact: dict[str, Any]) -> dict[str, Any]:
    return {
        **artifact,
        "metadata": _json(artifact["metadata_json"]),
    }
