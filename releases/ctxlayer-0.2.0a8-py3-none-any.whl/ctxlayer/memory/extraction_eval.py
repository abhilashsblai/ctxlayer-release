from __future__ import annotations

import json
import re
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ctxlayer.memory.calibration import SOURCE_TYPES, canonical_source_type
from ctxlayer.memory.evidence import RuleCandidate
from ctxlayer.memory.source_scanners import SCANNERS
from ctxlayer.store import SQLiteStore


@dataclass(frozen=True)
class ExpectedRule:
    id: str
    rule_text_norm: str
    match: str
    pattern: str
    must_extract: bool


@dataclass(frozen=True)
class Fixture:
    source_type: str
    input_path: Path
    expected_rules: list[ExpectedRule]
    expected_negatives: list[str]


class ExtractionEvaluator:
    def __init__(self, repo_root: Path, store: SQLiteStore, repo_id: str | None):
        self.repo_root = repo_root
        self.store = store
        self.repo_id = repo_id

    def run(
        self,
        fixtures: str | Path | None = None,
        *,
        source_type: str | None = None,
        persist: bool = True,
    ) -> dict[str, Any]:
        fixture_value = fixtures or "eval/rules"
        corpus_root = (self.repo_root / fixture_value).resolve()
        if not corpus_root.exists() and not Path(fixture_value).is_absolute():
            fallback = (Path.cwd() / fixture_value).resolve()
            if fallback.exists():
                corpus_root = fallback
        corpus = self.load_corpus(corpus_root, source_type=source_type)
        per_source = []
        for source in sorted(corpus):
            stats = {"true_positive": 0, "false_positive": 0, "false_negative": 0}
            cases = []
            for fixture in corpus[source]:
                candidates = self._run_scanner(fixture)
                scored = score_candidates(candidates, fixture)
                for key in stats:
                    stats[key] += scored[key]
                cases.append(
                    {
                        "input": fixture.input_path.name,
                        "true_positive": scored["true_positive"],
                        "false_positive": scored["false_positive"],
                        "false_negative": scored["false_negative"],
                    }
                )
            metrics = _metrics(stats)
            per_source.append(
                {
                    "source_type": source,
                    **stats,
                    **metrics,
                    "cases": cases,
                }
            )
        totals_counts = {
            "true_positive": sum(row["true_positive"] for row in per_source),
            "false_positive": sum(row["false_positive"] for row in per_source),
            "false_negative": sum(row["false_negative"] for row in per_source),
        }
        totals = {**totals_counts, **_metrics(totals_counts)}
        report = {
            "ok": True,
            "corpus_version": self._manifest(corpus_root).get(
                "corpus_version", "unknown"
            ),
            "fixtures": str(corpus_root),
            "per_source": per_source,
            "totals": totals,
        }
        if persist:
            metrics_json = {
                "kind": "extraction_eval",
                "corpus_version": report["corpus_version"],
                "per_source": [
                    {
                        "source_type": row["source_type"],
                        "precision": row["precision"],
                        "recall": row["recall"],
                        "f1": row["f1"],
                        "true_positive": row["true_positive"],
                        "false_positive": row["false_positive"],
                        "false_negative": row["false_negative"],
                    }
                    for row in per_source
                ],
                "totals": totals,
            }
            run_id = self.store.write_memory_eval_run(
                repo_id=self.repo_id or "", metrics=metrics_json
            )
            self.store.write_extraction_eval_results(
                run_id,
                [
                    {
                        "repo_id": self.repo_id,
                        "source_type": row["source_type"],
                        "corpus_version": report["corpus_version"],
                        "true_positive": row["true_positive"],
                        "false_positive": row["false_positive"],
                        "false_negative": row["false_negative"],
                        "precision": row["precision"],
                        "recall": row["recall"],
                        "f1": row["f1"],
                    }
                    for row in per_source
                ],
            )
            report["memory_eval_run_id"] = run_id
        return report

    def load_corpus(
        self, corpus_root: Path, *, source_type: str | None = None
    ) -> dict[str, list[Fixture]]:
        if not corpus_root.exists():
            raise FileNotFoundError(f"fixture corpus not found: {corpus_root}")
        manifest = self._manifest(corpus_root)
        wanted = (
            {canonical_source_type(source_type)}
            if source_type
            else set(manifest.get("source_types") or SOURCE_TYPES)
        )
        corpus: dict[str, list[Fixture]] = {}
        for source in wanted:
            source_dir = corpus_root / source
            if not source_dir.exists():
                if source == "incidents":
                    corpus[source] = []
                    continue
                raise ValueError(f"missing fixture source directory: {source}")
            fixtures = [
                self._load_fixture(source, label_path)
                for label_path in sorted(source_dir.glob("*.labels.json"))
            ]
            min_cases = int(manifest.get("min_cases_per_source", 1))
            if len(fixtures) < min_cases and source not in set(
                manifest.get("experimental", [])
            ):
                raise ValueError(
                    f"{source} has {len(fixtures)} fixtures; expected at least {min_cases}"
                )
            corpus[source] = fixtures
        return corpus

    def _manifest(self, corpus_root: Path) -> dict[str, Any]:
        path = corpus_root / "manifest.json"
        if not path.exists():
            raise ValueError(f"missing corpus manifest: {path}")
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data.get("source_types"), list):
            raise ValueError("manifest source_types must be a list")
        return data

    def _load_fixture(self, source: str, label_path: Path) -> Fixture:
        data = json.loads(label_path.read_text(encoding="utf-8"))
        declared = canonical_source_type(data.get("source_type"))
        if declared != source:
            raise ValueError(f"{label_path} declares {declared}, expected {source}")
        input_name = data.get("input")
        if not isinstance(input_name, str):
            raise ValueError(f"{label_path} missing input")
        input_path = label_path.parent / input_name
        if not input_path.exists():
            raise ValueError(f"{label_path} references missing input {input_name}")
        expected = []
        for item in data.get("expected_rules", []):
            if (
                not isinstance(item, dict)
                or not item.get("id")
                or not item.get("rule_text_norm")
            ):
                raise ValueError(f"{label_path} has malformed expected_rules item")
            expected.append(
                ExpectedRule(
                    id=str(item["id"]),
                    rule_text_norm=normalize_rule(str(item["rule_text_norm"])),
                    match=str(item.get("match", "substring")),
                    pattern=str(item.get("pattern") or item["rule_text_norm"]),
                    must_extract=bool(item.get("must_extract", True)),
                )
            )
        negatives = []
        for item in data.get("expected_negatives", []):
            if isinstance(item, dict) and item.get("text"):
                negatives.append(normalize_rule(str(item["text"])))
        return Fixture(source, input_path, expected, negatives)

    def _run_scanner(self, fixture: Fixture) -> list[RuleCandidate]:
        scanner = SCANNERS.get(fixture.source_type)
        if scanner is None:
            return []
        with tempfile.TemporaryDirectory(prefix="ctxlayer-h1-") as temp:
            root = Path(temp)
            if fixture.source_type == "prs":
                target = root / "prs" / fixture.input_path.name
            elif fixture.source_type == "incidents":
                target = root / "incidents" / fixture.input_path.name
            else:
                target = root / fixture.input_path.name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(fixture.input_path, target)
            return list(scanner(root))


def score_candidates(
    candidates: list[RuleCandidate], fixture: Fixture
) -> dict[str, Any]:
    expected = [rule for rule in fixture.expected_rules if rule.must_extract]
    matched: set[str] = set()
    false_positive = 0
    matches = []
    for candidate in candidates:
        text = normalize_rule(candidate.text)
        match = next(
            (
                rule
                for rule in expected
                if rule.id not in matched and _matches(text, rule)
            ),
            None,
        )
        if match is not None:
            matched.add(match.id)
            matches.append(
                {"candidate": candidate.text, "expected_id": match.id, "result": "tp"}
            )
            continue
        false_positive += 1
        negative = any(
            negative and negative in text for negative in fixture.expected_negatives
        )
        matches.append(
            {
                "candidate": candidate.text,
                "expected_id": None,
                "result": "fp_negative" if negative else "fp",
            }
        )
    false_negative = len([rule for rule in expected if rule.id not in matched])
    return {
        "true_positive": len(matched),
        "false_positive": false_positive,
        "false_negative": false_negative,
        "matches": matches,
    }


def normalize_rule(text: str) -> str:
    return " ".join(text.lower().strip().split())


def _matches(text: str, rule: ExpectedRule) -> bool:
    if rule.match == "regex":
        return re.search(rule.pattern, text, re.IGNORECASE) is not None
    # The semantic slot is intentionally deterministic for H1; later phases can
    # replace the implementation while keeping fixture labels stable.
    return rule.rule_text_norm in text or text in rule.rule_text_norm


def _metrics(stats: dict[str, int]) -> dict[str, float]:
    tp = stats["true_positive"]
    fp = stats["false_positive"]
    fn = stats["false_negative"]
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = (2 * precision * recall / (precision + recall)) if precision + recall else 0.0
    return {
        "precision": round(precision, 6),
        "recall": round(recall, 6),
        "f1": round(f1, 6),
    }
