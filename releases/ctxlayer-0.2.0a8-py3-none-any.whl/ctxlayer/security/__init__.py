from .secret_scan import SecretScanner

__all__ = ["SecretScanner"]
