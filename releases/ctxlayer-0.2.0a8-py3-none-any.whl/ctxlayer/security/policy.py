from __future__ import annotations


def privacy_statement() -> str:
    return (
        "The workspace database contains source-derived content. Protect it as source code. "
        "Audit hashes are tamper-evident, not tamper-proof against full filesystem control."
    )
