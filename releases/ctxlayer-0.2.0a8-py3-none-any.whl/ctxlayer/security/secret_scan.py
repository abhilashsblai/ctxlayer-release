from __future__ import annotations

import re
from pathlib import Path
from typing import Any

SECRET_PATTERNS = {
    "aws_access_key": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "generic_secret": re.compile(
        r"(?i)\b(secret|api[_-]?key|token)\s*[:=]\s*['\"]?[A-Za-z0-9_\-]{20,}"
    ),
    "private_key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
}


class SecretScanner:
    def __init__(self, root: Path):
        self.root = root

    def scan(self) -> dict[str, Any]:
        findings = []
        for path in self.root.rglob("*"):
            if not path.is_file() or ".git" in path.parts or ".ctxlayer" in path.parts:
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            for name, pattern in SECRET_PATTERNS.items():
                for match in pattern.finditer(text):
                    line = text[: match.start()].count("\n") + 1
                    findings.append(
                        {
                            "path": path.relative_to(self.root).as_posix(),
                            "line": line,
                            "kind": name,
                            "severity": "high",
                        }
                    )
        return {"ok": not findings, "findings": findings}


def redact_text(text: str) -> str:
    redacted = text
    for pattern in SECRET_PATTERNS.values():
        redacted = pattern.sub("[REDACTED_SECRET]", redacted)
    return redacted


def redact_text_with_summary(text: str) -> tuple[str, dict[str, Any]]:
    redacted = text
    kinds: list[str] = []
    count = 0
    for kind, pattern in SECRET_PATTERNS.items():
        matches = list(pattern.finditer(redacted))
        if not matches:
            continue
        kinds.append(kind)
        count += len(matches)
        redacted = pattern.sub("[REDACTED_SECRET]", redacted)
    return redacted, {"secret_kinds": sorted(set(kinds)), "secret_count": count}
